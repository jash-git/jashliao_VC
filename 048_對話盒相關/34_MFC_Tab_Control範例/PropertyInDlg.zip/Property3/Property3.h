// Property3.h : main header file for the PROPERTY3 application
//

#if !defined(AFX_PROPERTY3_H__D0B79BA5_E725_4012_86C6_AE9CA2131B06__INCLUDED_)
#define AFX_PROPERTY3_H__D0B79BA5_E725_4012_86C6_AE9CA2131B06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CProperty3App:
// See Property3.cpp for the implementation of this class
//

class CProperty3App : public CWinApp
{
public:
	CProperty3App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProperty3App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CProperty3App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTY3_H__D0B79BA5_E725_4012_86C6_AE9CA2131B06__INCLUDED_)
