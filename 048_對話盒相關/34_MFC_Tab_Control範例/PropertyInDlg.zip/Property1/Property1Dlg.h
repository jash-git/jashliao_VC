// Property1Dlg.h : header file
//

#if !defined(AFX_PROPERTY1DLG_H__D3AEA303_1310_4D25_9471_DD88C561FF5D__INCLUDED_)
#define AFX_PROPERTY1DLG_H__D3AEA303_1310_4D25_9471_DD88C561FF5D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CProperty1Dlg dialog

class CProperty1Dlg : public CDialog
{
// Construction
public:
	CProperty1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CProperty1Dlg)
	enum { IDD = IDD_PROPERTY1_DIALOG };
	CButton	m_button2;
	CButton	m_button1;
	CTabCtrl	m_tab;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProperty1Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CProperty1Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTY1DLG_H__D3AEA303_1310_4D25_9471_DD88C561FF5D__INCLUDED_)
