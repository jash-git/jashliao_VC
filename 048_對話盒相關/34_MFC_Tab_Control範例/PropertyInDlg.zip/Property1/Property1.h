// Property1.h : main header file for the PROPERTY1 application
//

#if !defined(AFX_PROPERTY1_H__30C62555_D3EB_4BF3_B2FF_32B333779B33__INCLUDED_)
#define AFX_PROPERTY1_H__30C62555_D3EB_4BF3_B2FF_32B333779B33__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CProperty1App:
// See Property1.cpp for the implementation of this class
//

class CProperty1App : public CWinApp
{
public:
	CProperty1App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProperty1App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CProperty1App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTY1_H__30C62555_D3EB_4BF3_B2FF_32B333779B33__INCLUDED_)
