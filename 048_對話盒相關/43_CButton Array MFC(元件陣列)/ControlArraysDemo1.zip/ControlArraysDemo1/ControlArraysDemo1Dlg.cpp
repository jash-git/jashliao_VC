// ControlArraysDemo1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "ControlArraysDemo1.h"
#include "ControlArraysDemo1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo1Dlg dialog

CControlArraysDemo1Dlg::CControlArraysDemo1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CControlArraysDemo1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CControlArraysDemo1Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CControlArraysDemo1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControlArraysDemo1Dlg)
	DDX_Control(pDX, IDC_EDIT1, m_edit[0]);
	DDX_Control(pDX, IDC_EDIT2, m_edit[1]);
	DDX_Control(pDX, IDC_EDIT3, m_edit[2]);
	DDX_Control(pDX, IDC_SLIDER1, m_slider[0]);
	DDX_Control(pDX, IDC_SLIDER2, m_slider[1]);
	DDX_Control(pDX, IDC_SLIDER3, m_slider[2]);
	DDX_Control(pDX, IDC_SPIN1, m_spin[0]);
	DDX_Control(pDX, IDC_SPIN2, m_spin[1]);
	DDX_Control(pDX, IDC_SPIN3, m_spin[2]);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CControlArraysDemo1Dlg, CDialog)
	//{{AFX_MSG_MAP(CControlArraysDemo1Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_VSCROLL()
	ON_EN_UPDATE(IDC_EDIT1, OnUpdateEdit1)
	ON_EN_UPDATE(IDC_EDIT2, OnUpdateEdit2)
	ON_EN_UPDATE(IDC_EDIT3, OnUpdateEdit3)
	//}}AFX_MSG_MAP

	// This is declared outside the AFX_MSG_MAP scope
	// if later you decided to add more messags if will be deleted
	ON_MESSAGE(WM_HSCROLL, OnHScrollSlider)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo1Dlg message handlers

BOOL CControlArraysDemo1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	Initialisation();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CControlArraysDemo1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CControlArraysDemo1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CControlArraysDemo1Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
void CControlArraysDemo1Dlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// nSBCode is NOT needed because the scroller in the class is spin
	// First convert the pointer to one of type CSpinButtonCtrl 
	CSpinButtonCtrl *pSpin = reinterpret_cast<CSpinButtonCtrl *>(pScrollBar);
	int nIndex = pSpin - &m_spin[0];	// Get the actual index of spin control

	CString szValue;			// The string for the edit box
	szValue.Format("%d",nPos);	// Format it that number is a string

	m_edit[nIndex].SetWindowText(szValue);	//Self explanatory
	m_slider[nIndex].SetPos(nPos);	//ditto
	
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CControlArraysDemo1Dlg::OnUpdateEdit1() 
{
	// Check to see if the control is focused
	// if so modify the other controls at index 0
	// if not no further action is taken
	if(GetFocus() == &m_edit[0])
	{
		CString szText;
		int nValue = 0;

		m_edit[0].GetWindowText(szText);
		StringToNumber(szText,nValue);

		m_slider[0].SetPos(nValue);
		m_spin[0].SetPos(nValue);
	}
	
}

void CControlArraysDemo1Dlg::OnUpdateEdit2() 
{
	// Check to see if the control is focused
	// if so modify the other controls at index 1
	// if not no further action is taken
	if(GetFocus() == &m_edit[1])
	{
		CString szText;
		int nValue = 0;

		m_edit[1].GetWindowText(szText);
		StringToNumber(szText,nValue);

		m_slider[1].SetPos(nValue);
		m_spin[1].SetPos(nValue);
	}
	
}

void CControlArraysDemo1Dlg::OnUpdateEdit3() 
{
	// Check to see if the control is focused
	// if so modify the other controls at index 2
	// if not no further action is taken
	if(GetFocus() == &m_edit[2])
	{
		CString szText;
		int nValue = 0;

		m_edit[2].GetWindowText(szText);
		StringToNumber(szText,nValue);

		m_slider[2].SetPos(nValue);
		m_spin[2].SetPos(nValue);
	}
	
}


LRESULT CControlArraysDemo1Dlg::OnHScrollSlider(WPARAM wParam, LPARAM lParam)
{
	// is wParam NOT needed because message is called by a control
	HWND hwnd;		// Interrogator of the slider's handle
	hwnd = (HWND)lParam;	//Casting to a window hadnd
	CString szValue;		// The string for the edit box
	int nIndex;		// For obtaining index of slider control
	int nPos;		//to obtain the slider's position

	//Is it m_slider[0]?
	if(m_slider[0].m_hWnd == hwnd)
	{
		nIndex = 0;	// Yes! then index is 0
	}

	// No, see if it's m_slider[1]?
	else if(m_slider[1].m_hWnd == hwnd)
	{
		nIndex = 1;	// Yes! then index is 1
	}

	else
	{
		nIndex = 2;	// Obviously, the index is 2
	}

	nPos = m_slider[nIndex].GetPos();	// Self explanatory
	szValue.Format("%d",nPos);	// Format it that number is a string

	m_edit[nIndex].SetWindowText(szValue);	// Again self explanatory
	m_spin[nIndex].SetPos(nPos);	//ditto
	return 0;

}



BOOL CControlArraysDemo1Dlg::StringToNumber(LPCTSTR pszText, int &nValue)
{
	if(!*pszText)		// Tests if string is empty
		return FALSE;

	while(*pszText)		// Loops shile 
	{
		nValue *= 10;	// Self explanatory

		//checks whether the characre is a digit
		if((*pszText < 48)||( *pszText > 57))	//
		{
			nValue = 0;
			return FALSE;
		}

		// Obtains its numerical representation adds to running total
		nValue += *pszText - 48;
		pszText++;		// Advances the pointer
	}

	return TRUE;

}

void CControlArraysDemo1Dlg::Initialisation()
{
	int nCounter;

	for(nCounter = 0; nCounter < 3; nCounter++)
	{
		m_edit[nCounter].ModifyStyle(0,ES_NUMBER);
		m_edit[nCounter].SetWindowText(_T("0"));
		m_edit[nCounter].SetLimitText(2);
		m_slider[nCounter].SetRange(0,99);
		m_slider[nCounter].SetTicFreq(10);
		m_slider[nCounter].SetPos(0);
		m_spin[nCounter].SetRange(0,99);
		m_spin[nCounter].SetPos(0);
	}

}