// ControlArraysDemo1Dlg.h : header file
//

#if !defined(AFX_CONTROLARRAYSDEMO1DLG_H__CA243A47_1708_11DA_8890_9248FEC6702E__INCLUDED_)
#define AFX_CONTROLARRAYSDEMO1DLG_H__CA243A47_1708_11DA_8890_9248FEC6702E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo1Dlg dialog

class CControlArraysDemo1Dlg : public CDialog
{
// Construction
public:
	CControlArraysDemo1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CControlArraysDemo1Dlg)
	enum { IDD = IDD_CONTROLARRAYSDEMO1_DIALOG };
	CSpinButtonCtrl	m_spin[3];
	CSliderCtrl	m_slider[3];
	CEdit	m_edit[3];
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlArraysDemo1Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	void Initialisation();
	BOOL StringToNumber(LPCTSTR pszText, int &nValue);

	// Generated message map functions
	//{{AFX_MSG(CControlArraysDemo1Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnUpdateEdit1();
	afx_msg void OnUpdateEdit2();
	afx_msg void OnUpdateEdit3();
	//}}AFX_MSG
	// This is declared outside the AFX_MSG scope
	// if later you decided to add more messags if will be deleted
	LRESULT OnHScrollSlider(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTROLARRAYSDEMO1DLG_H__CA243A47_1708_11DA_8890_9248FEC6702E__INCLUDED_)
