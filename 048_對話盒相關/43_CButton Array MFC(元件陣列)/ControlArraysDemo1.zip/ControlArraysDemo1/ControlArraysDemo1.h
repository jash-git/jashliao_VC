// ControlArraysDemo1.h : main header file for the CONTROLARRAYSDEMO1 application
//

#if !defined(AFX_CONTROLARRAYSDEMO1_H__CA243A45_1708_11DA_8890_9248FEC6702E__INCLUDED_)
#define AFX_CONTROLARRAYSDEMO1_H__CA243A45_1708_11DA_8890_9248FEC6702E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo1App:
// See ControlArraysDemo1.cpp for the implementation of this class
//

class CControlArraysDemo1App : public CWinApp
{
public:
	CControlArraysDemo1App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlArraysDemo1App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CControlArraysDemo1App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTROLARRAYSDEMO1_H__CA243A45_1708_11DA_8890_9248FEC6702E__INCLUDED_)
