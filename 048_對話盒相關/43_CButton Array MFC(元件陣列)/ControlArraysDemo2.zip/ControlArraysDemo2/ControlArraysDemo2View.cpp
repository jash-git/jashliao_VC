// ControlArraysDemo2View.cpp : implementation of the CControlArraysDemo2View class
//

#include "stdafx.h"
#include "ControlArraysDemo2.h"

#include "ControlArraysDemo2Doc.h"
#include "ControlArraysDemo2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo2View

IMPLEMENT_DYNCREATE(CControlArraysDemo2View, CFormView)

BEGIN_MESSAGE_MAP(CControlArraysDemo2View, CFormView)
	//{{AFX_MSG_MAP(CControlArraysDemo2View)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_EN_UPDATE(IDC_EDIT1, OnUpdateEdit1)
	ON_EN_UPDATE(IDC_EDIT2, OnUpdateEdit2)
	ON_EN_UPDATE(IDC_EDIT3, OnUpdateEdit3)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo2View construction/destruction

CControlArraysDemo2View::CControlArraysDemo2View()
	: CFormView(CControlArraysDemo2View::IDD)
{
	//{{AFX_DATA_INIT(CControlArraysDemo2View)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CControlArraysDemo2View::~CControlArraysDemo2View()
{
}

void CControlArraysDemo2View::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControlArraysDemo2View)
	DDX_Control(pDX, IDC_EDIT1, m_edit[0]);
	DDX_Control(pDX, IDC_EDIT2, m_edit[1]);
	DDX_Control(pDX, IDC_EDIT3, m_edit[2]);
	DDX_Control(pDX, IDC_SLIDER1, m_slider[0]);
	DDX_Control(pDX, IDC_SLIDER2, m_slider[1]);
	DDX_Control(pDX, IDC_SLIDER3, m_slider[2]);
	DDX_Control(pDX, IDC_SPIN1, m_spin[0]);
	DDX_Control(pDX, IDC_SPIN2, m_spin[1]);
	DDX_Control(pDX, IDC_SPIN3, m_spin[2]);
	//}}AFX_DATA_MAP
}

BOOL CControlArraysDemo2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CControlArraysDemo2View::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	Initialisation(); // Initialising the child windows

}

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo2View printing

BOOL CControlArraysDemo2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CControlArraysDemo2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CControlArraysDemo2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CControlArraysDemo2View::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo2View diagnostics

#ifdef _DEBUG
void CControlArraysDemo2View::AssertValid() const
{
	CFormView::AssertValid();
}

void CControlArraysDemo2View::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CControlArraysDemo2Doc* CControlArraysDemo2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CControlArraysDemo2Doc)));
	return (CControlArraysDemo2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CControlArraysDemo2View message handlers

void CControlArraysDemo2View::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// Let's ascertain whether or not the slider was slidden
	if(pScrollBar)
	{
		CSliderCtrl *pSlider = reinterpret_cast<CSliderCtrl *>(pScrollBar);
		int nIndex = pSlider - &m_slider[0];
		int nValue = m_slider[nIndex].GetPos();
		CString szValue;
		szValue.Format("%d",nValue);
		m_spin[nIndex].SetPos(nValue);
		m_edit[nIndex].SetWindowText(szValue);
	}

	else
	{
		// Your code for handling the conventional scroll bar
	}
	
	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CControlArraysDemo2View::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// Let's ascertain whether or not the spin (up/down) button was pressed
	if(pScrollBar)
	{
		CSpinButtonCtrl *pSpin = reinterpret_cast<CSpinButtonCtrl *>(pScrollBar);
		int nIndex = pSpin - &m_spin[0];
		CString szValue;
		szValue.Format("%d",nPos);
		m_slider[nIndex].SetPos(nPos);
		m_edit[nIndex].SetWindowText(szValue);
	}

	else
	{
		// Your code for handling the conventional scroll bar
	}
	
	CFormView::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CControlArraysDemo2View::OnUpdateEdit1() 
{
	if(GetFocus() == &m_edit[0])
	{
		int nValue = 0;
		CString szValue;
		m_edit[0].GetWindowText(szValue);

		if(!StringToNumber(szValue,nValue))
			return;

		m_slider[0].SetPos(nValue);
		m_spin[0].SetPos(nValue);
	}
	
}

void CControlArraysDemo2View::OnUpdateEdit2() 
{
	if(GetFocus() == &m_edit[1])
	{
		int nValue = 0;
		CString szValue;
		m_edit[1].GetWindowText(szValue);

		if(!StringToNumber(szValue,nValue))
			return;

		m_slider[1].SetPos(nValue);
		m_spin[1].SetPos(nValue);
	}
	
}

void CControlArraysDemo2View::OnUpdateEdit3() 
{
	if(GetFocus() == &m_edit[2])
	{
		int nValue = 0;
		CString szValue;
		m_edit[2].GetWindowText(szValue);

		if(!StringToNumber(szValue,nValue))
			return;

		m_slider[2].SetPos(nValue);
		m_spin[2].SetPos(nValue);
	}
	
}

void CControlArraysDemo2View::Initialisation()
{
	int nCounter;

	for(nCounter = 0; nCounter < 3; nCounter++)
	{
		m_edit[nCounter].ModifyStyle(0,ES_NUMBER);
		m_edit[nCounter].SetWindowText(_T("0"));
		m_edit[nCounter].SetLimitText(2);
		m_slider[nCounter].SetRange(0,99);
		m_slider[nCounter].SetTicFreq(10);
		m_slider[nCounter].SetPos(0);
		m_spin[nCounter].SetRange(0,99);
		m_spin[nCounter].SetPos(0);
	}

}

BOOL CControlArraysDemo2View::StringToNumber(LPCTSTR pszText, int &nValue)
{
	if(!*pszText)		// Tests if string is empty
		return FALSE;

	while(*pszText)		// Loops while the string has contents
	{
		nValue *= 10;	// Self explanatory

		//checks whether the characre is a digit
		if((*pszText < 48)||( *pszText > 57))	//
		{
			nValue = 0;
			return FALSE;
		}

		// Obtains its numerical representation adds to running total
		nValue += *pszText - 48;
		pszText++;		// Advances the pointer
	}

	return TRUE;

}
