// ControlArraysDemo2View.h : interface of the CControlArraysDemo2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTROLARRAYSDEMO2VIEW_H__83AA046D_1577_11DA_8890_444553540000__INCLUDED_)
#define AFX_CONTROLARRAYSDEMO2VIEW_H__83AA046D_1577_11DA_8890_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CControlArraysDemo2View : public CFormView
{
protected: // create from serialization only
	CControlArraysDemo2View();
	DECLARE_DYNCREATE(CControlArraysDemo2View)

public:
	//{{AFX_DATA(CControlArraysDemo2View)
	enum{ IDD = IDD_CONTROLARRAYSDEMO2_FORM };
	CSpinButtonCtrl	m_spin[3];
	CSliderCtrl	m_slider[3];
	CEdit	m_edit[3];
	//}}AFX_DATA

// Attributes
public:
	CControlArraysDemo2Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlArraysDemo2View)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CControlArraysDemo2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	BOOL StringToNumber(LPCTSTR pszText, int &nValue);
	void Initialisation();
	//{{AFX_MSG(CControlArraysDemo2View)
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnUpdateEdit1();
	afx_msg void OnUpdateEdit2();
	afx_msg void OnUpdateEdit3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ControlArraysDemo2View.cpp
inline CControlArraysDemo2Doc* CControlArraysDemo2View::GetDocument()
   { return (CControlArraysDemo2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTROLARRAYSDEMO2VIEW_H__83AA046D_1577_11DA_8890_444553540000__INCLUDED_)
