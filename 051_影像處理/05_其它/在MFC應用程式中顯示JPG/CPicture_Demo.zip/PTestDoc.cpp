// PTestDoc.cpp : implementation of the CPTestDoc class
//

#include "stdafx.h"
#include "PTest.h"

#include "PTestDoc.h"
#include "DlgSettings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPTestDoc

IMPLEMENT_DYNCREATE(CPTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CPTestDoc, CDocument)
	//{{AFX_MSG_MAP(CPTestDoc)
	ON_COMMAND(ID_VIEW_SETTINGS, OnViewSettings)
	ON_COMMAND(ID_IMAGE_RESOURCEIMAGE1, OnImageResourceimage1)
	ON_UPDATE_COMMAND_UI(ID_IMAGE_RESOURCEIMAGE1, OnUpdateImageResourceimage1)
	ON_COMMAND(ID_IMAGE_RESOURCEIMAGE2, OnImageResourceimage2)
	ON_UPDATE_COMMAND_UI(ID_IMAGE_RESOURCEIMAGE2, OnUpdateImageResourceimage2)
	ON_COMMAND(ID_IMAGE_RESOURCEIMAGE3, OnImageResourceimage3)
	ON_UPDATE_COMMAND_UI(ID_IMAGE_RESOURCEIMAGE3, OnUpdateImageResourceimage3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPTestDoc construction/destruction

CPTestDoc::CPTestDoc()
{
	m_nCx		= 100;
	m_nCy		= 100;		
	m_nRatio	= 1;	
	m_nX		= 0;	
	m_nY		= 0;	
	m_nSizeMode	= 1;	

	m_nLoadedImage = 0;
}

CPTestDoc::~CPTestDoc()
{
}

BOOL CPTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPTestDoc serialization

void CPTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPTestDoc diagnostics

#ifdef _DEBUG
void CPTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPTestDoc commands

BOOL CPTestDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	m_cPicture.Load(lpszPathName);
	m_nLoadedImage = 0;
	
	return TRUE;
}

void CPTestDoc::OnViewSettings() 
{
	CDlgSettings cDlg;
	cDlg.m_nCx			= m_nCx;
	cDlg.m_nCy			= m_nCy;		
	cDlg.m_nRatio		= m_nRatio;
	cDlg.m_nX			= m_nX;
	cDlg.m_nY			= m_nY;
	cDlg.m_nSizeMode	= m_nSizeMode;

	if (cDlg.DoModal() == IDOK)
	{
		m_nCx			= cDlg.m_nCx;
		m_nCy			= cDlg.m_nCy;		
		m_nRatio		= cDlg.m_nRatio;
		m_nX			= cDlg.m_nX;
		m_nY			= cDlg.m_nY;
		m_nSizeMode		= cDlg.m_nSizeMode;

		UpdateAllViews(NULL);
	}
}

void CPTestDoc::OnImageResourceimage1() 
{
	m_cPicture.Load("JPG", "IDR_IMAGE1");
	m_nLoadedImage = 1;
	UpdateAllViews(NULL);
}

void CPTestDoc::OnImageResourceimage2() 
{
	m_cPicture.Load("GIF", "IDR_IMAGE2");
	m_nLoadedImage = 2;
	UpdateAllViews(NULL);
}

void CPTestDoc::OnImageResourceimage3() 
{
	m_cPicture.Load("BMP", "IDR_IMAGE3");
	m_nLoadedImage = 3;
	UpdateAllViews(NULL);
}

void CPTestDoc::OnUpdateImageResourceimage1(CCmdUI* pCmdUI) 
{
	if (m_nLoadedImage == 1)
		pCmdUI->SetCheck();
	else
		pCmdUI->SetCheck(0);
}

void CPTestDoc::OnUpdateImageResourceimage2(CCmdUI* pCmdUI) 
{
	if (m_nLoadedImage == 2)
		pCmdUI->SetCheck();
	else
		pCmdUI->SetCheck(0);
}

void CPTestDoc::OnUpdateImageResourceimage3(CCmdUI* pCmdUI) 
{
	if (m_nLoadedImage == 3)
		pCmdUI->SetCheck();
	else
		pCmdUI->SetCheck(0);
}
