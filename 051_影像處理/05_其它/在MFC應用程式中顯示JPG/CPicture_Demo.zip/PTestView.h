// PTestView.h : interface of the CPTestView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PTESTVIEW_H__3B777805_EED4_4B86_8254_601F786CBDEB__INCLUDED_)
#define AFX_PTESTVIEW_H__3B777805_EED4_4B86_8254_601F786CBDEB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPTestView : public CView
{
protected: // create from serialization only
	CPTestView();
	DECLARE_DYNCREATE(CPTestView)

// Attributes
public:
	CPTestDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPTestView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPTestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPTestView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in PTestView.cpp
inline CPTestDoc* CPTestView::GetDocument()
   { return (CPTestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PTESTVIEW_H__3B777805_EED4_4B86_8254_601F786CBDEB__INCLUDED_)
