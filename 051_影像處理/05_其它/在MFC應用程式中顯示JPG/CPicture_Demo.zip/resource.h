//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PTESTTYPE                   129
#define IDD_DIALOG_SETTINGS             131
#define IDC_RADIO_SIZE                  1000
#define IDC_RADIO_SIZE_2                1001
#define IDC_EDIT_CY                     1002
#define IDC_EDIT_RATIO                  1003
#define IDC_EDIT_CX                     1004
#define IDC_EDIT_Y                      1006
#define IDC_EDIT_X                      1007
#define ID_VIEW_SETTINGS                32772
#define ID_IMAGE_RESOURCEIMAGE1         32773
#define ID_IMAGE_RESOURCEIMAGE2         32774
#define ID_IMAGE_RESOURCEIMAGE3         32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
