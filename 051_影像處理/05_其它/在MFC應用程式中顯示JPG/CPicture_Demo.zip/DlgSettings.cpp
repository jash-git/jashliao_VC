// DlgSettings.cpp : implementation file
//

#include "stdafx.h"
#include "PTest.h"
#include "DlgSettings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSettings dialog


CDlgSettings::CDlgSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSettings)
	m_nCx			= 0;
	m_nCy			= 0;
	m_nRatio		= 1.0;
	m_nX			= 0;
	m_nY			= 0;
	m_nSizeMode		= 1;
	//}}AFX_DATA_INIT
}


void CDlgSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSettings)
	DDX_Text(pDX, IDC_EDIT_CX, m_nCx);
	DDX_Text(pDX, IDC_EDIT_CY, m_nCy);
	DDX_Text(pDX, IDC_EDIT_RATIO, m_nRatio);
	DDX_Text(pDX, IDC_EDIT_X, m_nX);
	DDX_Text(pDX, IDC_EDIT_Y, m_nY);
	DDX_Radio(pDX, IDC_RADIO_SIZE, m_nSizeMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSettings, CDialog)
	//{{AFX_MSG_MAP(CDlgSettings)
	ON_BN_CLICKED(IDC_RADIO_SIZE, OnRadioSize)
	ON_BN_CLICKED(IDC_RADIO_SIZE_2, OnRadioSize2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSettings message handlers

void CDlgSettings::OnRadioSize() 
{
	GetDlgItem(IDC_EDIT_CX)		->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_CY)		->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_RATIO)	->EnableWindow(FALSE);
}

void CDlgSettings::OnRadioSize2() 
{
	GetDlgItem(IDC_EDIT_CX)		->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_CY)		->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_RATIO)	->EnableWindow(TRUE);
}
