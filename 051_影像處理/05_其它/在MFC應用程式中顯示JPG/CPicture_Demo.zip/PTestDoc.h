// PTestDoc.h : interface of the CPTestDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PTESTDOC_H__0FCD8CB4_1899_46B4_A637_EDAFBCD2EC70__INCLUDED_)
#define AFX_PTESTDOC_H__0FCD8CB4_1899_46B4_A637_EDAFBCD2EC70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Picture.h"

class CPTestDoc : public CDocument
{
protected: // create from serialization only
	CPTestDoc();
	DECLARE_DYNCREATE(CPTestDoc)

// Attributes
public:
	CPicture	m_cPicture;
	int			m_nCx;
	int			m_nCy;
	double		m_nRatio;
	int			m_nX;
	int			m_nY;
	int			m_nSizeMode;

private:
	int			m_nLoadedImage; // 0 = File is loaded (no resource).
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPTestDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPTestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPTestDoc)
	afx_msg void OnViewSettings();
	afx_msg void OnImageResourceimage1();
	afx_msg void OnUpdateImageResourceimage1(CCmdUI* pCmdUI);
	afx_msg void OnImageResourceimage2();
	afx_msg void OnUpdateImageResourceimage2(CCmdUI* pCmdUI);
	afx_msg void OnImageResourceimage3();
	afx_msg void OnUpdateImageResourceimage3(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PTESTDOC_H__0FCD8CB4_1899_46B4_A637_EDAFBCD2EC70__INCLUDED_)
