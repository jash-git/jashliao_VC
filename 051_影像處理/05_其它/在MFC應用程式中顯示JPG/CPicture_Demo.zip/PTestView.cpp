// PTestView.cpp : implementation of the CPTestView class
//

#include "stdafx.h"
#include "PTest.h"

#include "PTestDoc.h"
#include "PTestView.h"

#include "memdc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPTestView

IMPLEMENT_DYNCREATE(CPTestView, CView)

BEGIN_MESSAGE_MAP(CPTestView, CView)
	//{{AFX_MSG_MAP(CPTestView)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPTestView construction/destruction

CPTestView::CPTestView()
{
	// TODO: add construction code here

}

CPTestView::~CPTestView()
{
}

BOOL CPTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPTestView drawing

void CPTestView::OnDraw(CDC* pDC)
{
	CPTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CMemDC cDC(pDC);

	switch (pDoc->m_nSizeMode)
	{
	case 0:
		pDoc->m_cPicture.Draw(&cDC, CPoint(pDoc->m_nX, pDoc->m_nY), CSize(pDoc->m_nCx, pDoc->m_nCy));
		break;
	case 1:
		pDoc->m_cPicture.Draw(&cDC, CPoint(pDoc->m_nX, pDoc->m_nY), pDoc->m_nRatio);
		break;
	}
	
}

/////////////////////////////////////////////////////////////////////////////
// CPTestView printing

BOOL CPTestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPTestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPTestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPTestView diagnostics

#ifdef _DEBUG
void CPTestView::AssertValid() const
{
	CView::AssertValid();
}

void CPTestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPTestDoc* CPTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPTestDoc)));
	return (CPTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPTestView message handlers

BOOL CPTestView::OnEraseBkgnd(CDC* pDC) 
{
	return FALSE;
	return CView::OnEraseBkgnd(pDC);
}
