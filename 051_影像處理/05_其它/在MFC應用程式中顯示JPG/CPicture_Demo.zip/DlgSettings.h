#if !defined(AFX_DLGSETTINGS_H__D63A39A3_CAA4_4ABB_9920_46AC0341F25C__INCLUDED_)
#define AFX_DLGSETTINGS_H__D63A39A3_CAA4_4ABB_9920_46AC0341F25C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgSettings.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSettings dialog

class CDlgSettings : public CDialog
{
// Construction
public:
	CDlgSettings(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgSettings)
	enum { IDD = IDD_DIALOG_SETTINGS };
	int		m_nCx;
	int		m_nCy;
	double	m_nRatio;
	int		m_nX;
	int		m_nY;
	int		m_nSizeMode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSettings)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgSettings)
	afx_msg void OnRadioSize();
	afx_msg void OnRadioSize2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSETTINGS_H__D63A39A3_CAA4_4ABB_9920_46AC0341F25C__INCLUDED_)
