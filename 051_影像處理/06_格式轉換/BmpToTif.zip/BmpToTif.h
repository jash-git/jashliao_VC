// BmpToTif.h : main header file for the BMPTOTIF application
//
// this is your duty to fill value according to u...
// any problem? let me know...I may help u...
// w w w . p e c i n t . c o m  (remove space & place in internet & get my con tact)
// sumit(under-score)kapoor1980(at)hot mail(dot) com
// sumit (under-score) kapoor1980(at)ya hoo(dot) com
// sumit (under-score) kapoor1980(at)red iff mail(dot) com

#if !defined(AFX_BMPTOTIF_H__46CA0AC5_3A15_11D8_A667_0050BA8B6949__INCLUDED_)
#define AFX_BMPTOTIF_H__46CA0AC5_3A15_11D8_A667_0050BA8B6949__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CBmpToTifApp:
// See BmpToTif.cpp for the implementation of this class
//

class CBmpToTifApp : public CWinApp
{
public:
	CBmpToTifApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBmpToTifApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBmpToTifApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BMPTOTIF_H__46CA0AC5_3A15_11D8_A667_0050BA8B6949__INCLUDED_)
