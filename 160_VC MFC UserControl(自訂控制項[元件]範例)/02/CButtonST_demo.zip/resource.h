//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CButtonST_Demo.rc
//
#define IDD_CBUTTONST_DEMO_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDI_CANCEL1                     130
#define IDI_CANCEL4                     132
#define IDD_BASIC                       133
#define IDD_ADVANCED                    134
#define IDI_EOAPP                       134
#define IDD_TRANSPARENT                 135
#define IDI_HALLOWEEN1                  135
#define IDI_HALLOWEEN2                  136
#define IDD_ABOUT                       136
#define IDI_KEYMANAGER                  137
#define IDD_SHADED                      137
#define IDI_SOUND                       138
#define IDI_LAMP1                       140
#define IDI_ZIP1                        141
#define IDI_ZIP2                        142
#define IDI_JPEG                        143
#define IDI_BALOON                      144
#define IDI_CDROM                       146
#define IDI_SEARCH1                     147
#define IDB_BMPBACK                     151
#define IDI_WORKGROUP                   152
#define IDI_LOGOFF                      153
#define IDI_OPEN                        154
#define IDI_HELP                        155
#define IDI_EXPLORER                    156
#define IDI_ABOUT                       157
#define IDB_SKY                         158
#define IDB_CANNIBAL                    159
#define IDI_LEDON                       160
#define IDI_LEDOFF                      161
#define IDI_WEB2                        162
#define IDC_HAND2                       163
#define IDI_TOOLS4                      164
#define IDI_RUN                         166
#define IDB_EAGLE                       167
#define IDB_STLOGO                      168
#define IDB_FACE                        169
#define IDB_PALETTE                     170
#define IDI_OK3                         171
#define IDI_CANCEL3                     172
#define IDI_IEDOCUMENT                  173
#define IDI_HELP2                       174
#define IDI_RAZOR                       175
#define IDI_CLASSES1                    176
#define IDR_MENU                        177
#define IDI_NO3                         179
#define IDR_TOOLBAR                     184
#define IDI_RIGHT6                      186
#define IDI_LEFT6                       187
#define IDR_WAVHOVER                    188
#define IDR_WAVSTART                    189
#define IDB_BUTTON                      190
#define IDI_BUTTERFLY                   191
#define IDC_TAB                         1000
#define IDC_BTNSTANDARD                 1001
#define IDC_BTNHALLOWEEN                1002
#define IDC_BTNKEYMANAGER               1003
#define IDC_BTNDISABLED                 1004
#define IDC_BTNLAMP                     1005
#define IDC_BTNZIP                      1006
#define IDC_BTNLOGOFF                   1006
#define IDC_BTNJPEG                     1007
#define IDC_BTNCDROM                    1008
#define IDC_BTNWORKGROUP                1008
#define IDC_BTNTOOLTIP                  1009
#define IDC_BTNOPEN                     1009
#define IDC_BTNCANNIBAL                 1010
#define IDC_BTNSEARCH                   1011
#define IDC_EMAILLINK                   1012
#define IDC_BTNBACK                     1012
#define IDC_BTNEXPLORER                 1012
#define IDC_HOMEPAGELINK                1013
#define IDC_BTNNEXT                     1013
#define IDC_BTNHELP                     1013
#define IDC_BTNABOUT                    1014
#define IDC_CHECK                       1015
#define IDC_BTNDERIVED                  1016
#define IDC_BTNHYPERLINK                1017
#define IDC_BTNCURSOR                   1018
#define IDC_VERSION                     1019
#define IDC_BTNFOCUSRECT                1020
#define IDC_BTNBITMAP                   1021
#define IDC_BTNSTLOGO                   1022
#define IDC_BTNFACE                     1023
#define IDC_BTNSHADE1                   1025
#define IDC_BTNSHADE2                   1026
#define IDC_BTNSHADE3                   1027
#define IDC_BTNSHADE4                   1028
#define IDC_BTNSHADE5                   1029
#define IDC_BTNSHADE6                   1030
#define IDC_BTNSHADE7                   1031
#define IDC_BTNSHADE8                   1032
#define IDC_BTNSHADE9                   1033
#define IDM_ITEM1                       32771
#define IDM_ITEM2                       32772
#define IDM_ITEM3                       32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        192
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
