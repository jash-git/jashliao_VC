Setup Generator 

Version: 2001.1.0
Platform: Windows 95/98/Me/NT/2000.

Setup Generator is freeware.

Setup Generator is a very easy and simple installer. It's purpose is 
to create quality self-extracting installation programs for your applications.
It has a flexible user interface.

YOU CAN 
* Show license and readme information
* Run your dll and exe-file
* Make it easy to Uninstall
* Write to the Registry, to INI Files
* Install files in Windows and System directories
* Update system files
* Create shortcuts
* Many other functions...

Installation packages developed with Setup Generator may be distributed in
any manner you wish (CD-ROM, floppies,WWW etc).

Please contact <info@gentee.com> if you would like to report bugs, grammar 
mistakes, or give your opinion about the program. Any comments are welcome.

Copyright 1998-2000 Gentee, Inc., All rights reserved.
Internet: http://www.gentee.com
Email: info@gentee.com
