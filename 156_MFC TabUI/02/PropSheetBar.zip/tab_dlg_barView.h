// tab_dlg_barView.h : interface of the Ctab_dlg_barView class
//


#pragma once

#include "PropSheetBar.h"
class CPage1;
class CPage2;
class CPage3;

class Ctab_dlg_barView : public CEditView
{
protected: // create from serialization only
	Ctab_dlg_barView();
	DECLARE_DYNCREATE(Ctab_dlg_barView)

// Attributes
public:
	Ctab_dlg_barDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
protected:
	CPropSheetBar m_PropSheetBar;
	CPage1 *page1;
	CPage2 *page2;
	CPage3 *page3;

public:
	virtual ~Ctab_dlg_barView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
//	virtual void OnInitialUpdate();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};

#ifndef _DEBUG  // debug version in tab_dlg_barView.cpp
inline Ctab_dlg_barDoc* Ctab_dlg_barView::GetDocument() const
   { return reinterpret_cast<Ctab_dlg_barDoc*>(m_pDocument); }
#endif

