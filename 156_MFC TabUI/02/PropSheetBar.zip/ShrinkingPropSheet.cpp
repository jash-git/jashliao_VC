// ShrinkingPropSheet.cpp : implementation file
//

#include "stdafx.h"
#include "tab_dlg_bar.h"
#include "ShrinkingPropSheet.h"
#include ".\shrinkingpropsheet.h"


// CShrinkingPropSheet

IMPLEMENT_DYNAMIC(CShrinkingPropSheet, CPropertySheet)
CShrinkingPropSheet::CShrinkingPropSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CShrinkingPropSheet::CShrinkingPropSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
}

CShrinkingPropSheet::~CShrinkingPropSheet()
{
}


BEGIN_MESSAGE_MAP(CShrinkingPropSheet, CPropertySheet)
END_MESSAGE_MAP()


// CShrinkingPropSheet message handlers

BOOL CShrinkingPropSheet::OnInitDialog()
{
  // Inherited call
	BOOL bResult = CPropertySheet::OnInitDialog();

   // Modifying exstyle in create method doesn't seem to work :-?, I guess
   // DIALOGEX property sheets are not very well supported (if at all)
   // We cannot access here the exstyle passed at creation time (dlgprop.cpp
   // stores temporaly in AfxGetThreadState()->m_dwPropStyle, but when OnInitDialog
   // is called that variable can have been overwritten
/*
The following causes the property sheet simply not to appear??? NO, it just can't be tabbed to, and is at back
*/
//	don't need this for dlgBar
	//ModifyStyleEx(0, WS_EX_TOOLWINDOW);

   // Resize property sheet and tab ctrl to exactly fit the page, as by default
   // PropertyPages have a non-sense minimum width of 214DLUs (MS dixit) 
   // Height has also a minimum size.
   
   // There must be at least one property page, so safe accessing it is not needed
   // (if it has no pages MFC will not show the PropertySheet)
   CPropertyPage* pppg = GetActivePage();

   // Get the resource for first page (all pages are assumed to be of the same 
   // dimensions).
   HRSRC hrsrc;
   if (AfxIsValidString(pppg->m_psp.pszTemplate))
      hrsrc = FindResource(pppg->m_psp.hInstance, pppg->m_psp.pszTemplate, RT_DIALOG);
   else
      hrsrc = FindResource(pppg->m_psp.hInstance,
                           MAKEINTRESOURCE(pppg->m_psp.pszTemplate), RT_DIALOG);

   // If found, we can resize the page (which was resized at creation time by MFC's), 
   // It suffices modifying the layout here, as once the first page is added, MFC never
   // resizes the dialog again to fit MS's minimum sizes of PropertyPages (even if you add
   // new pages with AddPage() )
   if (hrsrc) {
      HGLOBAL hgbl = LoadResource(pppg->m_psp.hInstance, hrsrc);
      if (hgbl) {
         LPDLGTEMPLATE pdlgtpl;
         pdlgtpl = (LPDLGTEMPLATE) LockResource(hgbl);
         if (pdlgtpl) {
            DLGTEMPLATEEX* pdlgtplex = (DLGTEMPLATEEX*) pdlgtpl;
            CRect rcOriginal;

            // Support for DIALOGEX PropertyPages, although those aren't very well supported
            // either
            if (pdlgtplex->signature == 0xFFFF) {
               // DIALOGEX resource
               rcOriginal.SetRect(pdlgtplex->x, pdlgtplex->y, 
                  pdlgtplex->x + pdlgtplex->cx, pdlgtplex->y + pdlgtplex->cy);
            } else {
               // DIALOG resource
               rcOriginal.SetRect(pdlgtpl->x, pdlgtpl->y, pdlgtpl->x+pdlgtpl->cx, 
                  pdlgtpl->y+pdlgtpl->cy);
            }
            
            // Okay, let's retrieve original size of PropertyPage
            pppg->MapDialogRect(rcOriginal);

            CRect rcModified;
            pppg->GetClientRect(rcModified);
            // If our original PropertyPage was not modified, the follwing code
            // will make dcx = 0 and dcy = 0, so it works even for pages bigger
            // than the minimum property page
            int dcx = rcModified.Width() - rcOriginal.Width();
            int dcy = rcModified.Height() - rcOriginal.Height();
            
            // We could deflate the pages by 0 and it would work, but just
            // to be proper
            if (dcx || dcy) {
               // Resize PropertyPage
               rcModified.DeflateRect(0,0,dcx,dcy);
               pppg->SetWindowPos(NULL, 0,0,rcModified.Width(), rcModified.Height(), 
                  SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER | SWP_NOACTIVATE);

               // Resize TabControl
               GetTabControl()->GetWindowRect(rcModified);
               rcModified.DeflateRect(0,0,dcx,dcy);
               GetTabControl()->SetWindowPos(NULL, 0,0,rcModified.Width(), rcModified.Height(),
                  SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER | SWP_NOACTIVATE);

               // Resize PropertySheet
               GetWindowRect(rcModified);
               rcModified.DeflateRect(0,0,dcx,dcy);
               SetWindowPos(NULL, 0,0,rcModified.Width(), rcModified.Height(),
                  SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER | SWP_NOACTIVATE);
            }

/* HELP SAYS
It is not necessary to unlock resources because the system automatically deletes them when the process that created them terminates.
*/
			//UnlockResource(hgbl);
         }
         // We are not supposed to call GlobalFree on hgbl (see the topic on LoadResource), 
         // but MFC code does it this way (dlgprop.cpp)
         // Anyway the other alternative is to call FreeResource and that's a 16bit func
         // that doesn't seem to do anything on win32

/* HELP SAYS
The return type of LoadResource is HGLOBAL for backward compatibility, 
not because the function returns a handle to a global memory block. 
Do not pass this handle to the GlobalLock or GlobalFree function. */
//         GlobalFree(hgbl);
      }
   }
	return TRUE;
}
