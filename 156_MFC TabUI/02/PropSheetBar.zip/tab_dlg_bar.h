// tab_dlg_bar.h : main header file for the tab_dlg_bar application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// Ctab_dlg_barApp:
// See tab_dlg_bar.cpp for the implementation of this class
//

class Ctab_dlg_barApp : public CWinApp
{
public:
	Ctab_dlg_barApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern Ctab_dlg_barApp theApp;