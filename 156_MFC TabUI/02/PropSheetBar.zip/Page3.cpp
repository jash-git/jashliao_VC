// Page3.cpp : implementation file
//

#include "stdafx.h"
#include "tab_dlg_bar.h"
#include "Page3.h"
#include ".\page3.h"


// CPage3 dialog

IMPLEMENT_DYNAMIC(CPage3, CPropertyPage)
CPage3::CPage3()
	: CPropertyPage(CPage3::IDD)
	, int1(0)
{
}

CPage3::~CPage3()
{
}

void CPage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, int1);
	DDV_MinMaxInt(pDX, int1, 0, 100);
}


BEGIN_MESSAGE_MAP(CPage3, CPropertyPage)
	ON_EN_KILLFOCUS(IDC_EDIT1, OnEnKillfocusEdit1)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
END_MESSAGE_MAP()


// CPage3 message handlers

void CPage3::OnEnKillfocusEdit1()
{
	if (UpdateData()==FALSE)
		return;
	CString str;
	str.Format("page three value = %d",int1);
	m_pView->SetWindowText(str);
}

void CPage3::OnBnClickedButton1()
{
	AfxMessageBox("Doesn't do much");
}
