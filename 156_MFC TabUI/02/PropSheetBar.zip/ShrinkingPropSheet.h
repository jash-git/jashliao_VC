#pragma once

/*
Code based on:
Free size and extended styles in CPropertySheets
By Antonio Tejada Lacaci 
How to use extended styles and make Property Sheets any size.  
From CodeProject
*/

// The exact definition for this struct can be found at
// MSDN's DLGTEMPLATEEX help topic
typedef struct {
      WORD   dlgVer;
      WORD   signature;
      DWORD  helpID;
      DWORD  exStyle;
      DWORD  style; 
      WORD   cDlgItems;
      short  x;
      short  y;    
      short  cx;
      short  cy;
      // The structure has more fields but are variable length
} DLGTEMPLATEEX; 


// CShrinkingPropSheet

class CShrinkingPropSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CShrinkingPropSheet)

public:
	CShrinkingPropSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CShrinkingPropSheet(LPCTSTR pszCaption="", CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	virtual ~CShrinkingPropSheet();

protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};


