// Page2.cpp : implementation file
//

#include "stdafx.h"
#include "tab_dlg_bar.h"
#include "Page2.h"
#include ".\page2.h"


// CPage2 dialog

IMPLEMENT_DYNAMIC(CPage2, CPropertyPage)
CPage2::CPage2()
	: CPropertyPage(CPage2::IDD)
	, int1(0)
{
}

CPage2::~CPage2()
{
}

void CPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, int1);
	DDV_MinMaxInt(pDX, int1, 0, 100);
}


BEGIN_MESSAGE_MAP(CPage2, CPropertyPage)
	ON_EN_KILLFOCUS(IDC_EDIT1, OnEnKillfocusEdit1)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
END_MESSAGE_MAP()


// CPage2 message handlers

void CPage2::OnEnKillfocusEdit1()
{
	if (UpdateData()==FALSE)
		return;
	CString str;
	str.Format("page two value = %d",int1);
	m_pView->SetWindowText(str);
}

void CPage2::OnBnClickedButton1()
{
	AfxMessageBox("Doesn't do much");
}
