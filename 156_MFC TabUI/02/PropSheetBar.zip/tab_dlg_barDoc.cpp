// tab_dlg_barDoc.cpp : implementation of the Ctab_dlg_barDoc class
//

#include "stdafx.h"
#include "tab_dlg_bar.h"

#include "tab_dlg_barDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Ctab_dlg_barDoc

IMPLEMENT_DYNCREATE(Ctab_dlg_barDoc, CDocument)

BEGIN_MESSAGE_MAP(Ctab_dlg_barDoc, CDocument)
END_MESSAGE_MAP()


// Ctab_dlg_barDoc construction/destruction

Ctab_dlg_barDoc::Ctab_dlg_barDoc()
{
	// TODO: add one-time construction code here

}

Ctab_dlg_barDoc::~Ctab_dlg_barDoc()
{
}

BOOL Ctab_dlg_barDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// Ctab_dlg_barDoc serialization

void Ctab_dlg_barDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// Ctab_dlg_barDoc diagnostics

#ifdef _DEBUG
void Ctab_dlg_barDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void Ctab_dlg_barDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// Ctab_dlg_barDoc commands
