// Page1.cpp : implementation file
//

#include "stdafx.h"
#include "tab_dlg_bar.h"
#include "Page1.h"
#include ".\page1.h"


// CPage1 dialog

IMPLEMENT_DYNAMIC(CPage1, CPropertyPage)
CPage1::CPage1()
	: CPropertyPage(CPage1::IDD)
	, int1(0)
{
}

CPage1::~CPage1()
{
}

void CPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, int1);
	DDV_MinMaxInt(pDX, int1, 0, 100);
}


BEGIN_MESSAGE_MAP(CPage1, CPropertyPage)
//	ON_EN_CHANGE(IDC_EDIT1, OnEnChangeEdit1)
ON_EN_KILLFOCUS(IDC_EDIT1, OnEnKillfocusEdit1)
ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
END_MESSAGE_MAP()


// CPage1 message handlers



void CPage1::OnEnKillfocusEdit1()
{
	if (UpdateData()==FALSE)
		return;
	CString str;
	str.Format("page one value = %d",int1);
	m_pView->SetWindowText(str);
}

void CPage1::OnBnClickedButton1()
{
	AfxMessageBox("Doesn't do much");
}
