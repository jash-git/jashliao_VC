// tab_dlg_barDoc.h : interface of the Ctab_dlg_barDoc class
//


#pragma once

class Ctab_dlg_barDoc : public CDocument
{
protected: // create from serialization only
	Ctab_dlg_barDoc();
	DECLARE_DYNCREATE(Ctab_dlg_barDoc)

// Attributes
public:

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~Ctab_dlg_barDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};


