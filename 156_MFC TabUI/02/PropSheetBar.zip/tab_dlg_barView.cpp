// tab_dlg_barView.cpp : implementation of the Ctab_dlg_barView class
//

#include "stdafx.h"
#include "tab_dlg_bar.h"

#include "tab_dlg_barDoc.h"
#include "tab_dlg_barView.h"
#include ".\tab_dlg_barview.h"
#include "page1.h"
#include "page2.h"
#include "page3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Ctab_dlg_barView

IMPLEMENT_DYNCREATE(Ctab_dlg_barView, CEditView)

BEGIN_MESSAGE_MAP(Ctab_dlg_barView, CEditView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
	ON_WM_CREATE()
END_MESSAGE_MAP()

// Ctab_dlg_barView construction/destruction

Ctab_dlg_barView::Ctab_dlg_barView()
{
	// TODO: add construction code here

}

Ctab_dlg_barView::~Ctab_dlg_barView()
{
	delete page1;
	delete page2;
	delete page3;
}

BOOL Ctab_dlg_barView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CEditView::PreCreateWindow(cs);
}

// Ctab_dlg_barView drawing

void Ctab_dlg_barView::OnDraw(CDC* /*pDC*/)
{
	Ctab_dlg_barDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
}


// Ctab_dlg_barView printing

BOOL Ctab_dlg_barView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void Ctab_dlg_barView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void Ctab_dlg_barView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// Ctab_dlg_barView diagnostics

#ifdef _DEBUG
void Ctab_dlg_barView::AssertValid() const
{
	CEditView::AssertValid();
}

void Ctab_dlg_barView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

Ctab_dlg_barDoc* Ctab_dlg_barView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(Ctab_dlg_barDoc)));
	return (Ctab_dlg_barDoc*)m_pDocument;
}
#endif //_DEBUG


// Ctab_dlg_barView message handlers


int Ctab_dlg_barView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CEditView::OnCreate(lpCreateStruct) == -1)
		return -1;

	page1=new CPage1;
	page2=new CPage2;
	page3=new CPage3;
	page1->m_pView=this;
	page2->m_pView=this;
	page3->m_pView=this;

// NOTE: you MUST add pages before calling CPropSheetBar::Create, because Create needs to know size of dlgs it contains
	m_PropSheetBar.AddPage(page1);
	m_PropSheetBar.AddPage(page2);
	m_PropSheetBar.AddPage(page3);

	CFrameWnd *pFrameWnd=(CFrameWnd *)GetParent();
	if (!m_PropSheetBar.Create("test bar",pFrameWnd, AFX_IDW_CONTROLBAR_FIRST+40))
	{
		TRACE0("Failed to create PropSheetBar\n");
		return -1;      // fail to create
	}

	m_PropSheetBar.EnableDocking(CBRS_ALIGN_ANY);
	pFrameWnd->EnableDocking(CBRS_ALIGN_ANY);
	pFrameWnd->DockControlBar(&m_PropSheetBar);

	return 0;
}
