#pragma once


// CPage3 dialog

class CPage3 : public CPropertyPage
{
	DECLARE_DYNAMIC(CPage3)

public:
	CPage3();
	virtual ~CPage3();

// Dialog Data
	enum { IDD = IDD_DIALOG3 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	int int1;
	CEditView *m_pView;
	afx_msg void OnEnKillfocusEdit1();
	afx_msg void OnBnClickedButton1();
};
