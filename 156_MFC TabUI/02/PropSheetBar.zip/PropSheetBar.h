#pragma once


// CPropSheetBar
#include "ShrinkingPropSheet.h"
class CPropSheetBar : public CControlBar
{
	DECLARE_DYNAMIC(CPropSheetBar)

public:
	CPropSheetBar();
	virtual ~CPropSheetBar();
	virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);

protected:
	DECLARE_MESSAGE_MAP()

	CShrinkingPropSheet m_cPropSheet;
	CSize m_sizePropSheet;
    CBrush m_brushBkgd;
	CString m_strTitle;
	CSize m_sizeTitle;
//	CSize m_sizeTitleOffset;

public:
	virtual void DrawGripper(CDC *pDC,const CRect &rect);
    virtual CSize CalcDynamicLayout( int nLength, DWORD dwMode );
	virtual BOOL Create(LPCTSTR lpszWindowName, CWnd* pParentWnd, UINT nID);
	void AddPage(CPropertyPage * pPage) {m_cPropSheet.AddPage(pPage);}
};


