// PropSheetBar.cpp : implementation file
//

#include "stdafx.h"
#include "tab_dlg_bar.h"
#include "PropSheetBar.h"
#include ".\propsheetbar.h"

// CPropSheetBar

const CSize sizeTitleOffset(6,3);

IMPLEMENT_DYNAMIC(CPropSheetBar, CControlBar)
CPropSheetBar::CPropSheetBar()
{
	m_brushBkgd.CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
//	m_sizeTitleOffset=CSize(6,3);
}

CPropSheetBar::~CPropSheetBar()
{
}


BEGIN_MESSAGE_MAP(CPropSheetBar, CControlBar)
	ON_WM_WINDOWPOSCHANGED()
//	ON_WM_ACTIVATE()
END_MESSAGE_MAP()



// CPropSheetBar message handlers

void CPropSheetBar::OnUpdateCmdUI(CFrameWnd* /*pTarget*/, BOOL /*bDisableIfNoHndler*/)
{
}


BOOL CPropSheetBar::Create(LPCTSTR lpszWindowName, CWnd* pParentWnd, UINT nID)
{
	// create the base window
    CString lpszClassName = AfxRegisterWndClass(CS_DBLCLKS, LoadCursor(NULL, IDC_ARROW),
        m_brushBkgd, 0);
	DWORD style=WS_CHILD | WS_VISIBLE | CBRS_LEFT | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY;
    m_dwStyle = style & CBRS_ALL;
	if (!CControlBar::Create(lpszClassName, lpszWindowName, style,  CRect(0,0,0,0), pParentWnd,NULL))
		return FALSE;
	m_strTitle=lpszWindowName;

	// create the property sheet
	m_cPropSheet.Create(this,WS_CHILD|WS_VISIBLE);
	m_cPropSheet.SetTitle(lpszWindowName);

	CClientDC dc(this);
	m_sizeTitle=dc.GetTextExtent(m_strTitle);
	CRect rc;
    m_cPropSheet.GetWindowRect(rc);	// screen coordinates
    m_sizePropSheet=rc.Size();

	return TRUE;
}



CSize CPropSheetBar::CalcDynamicLayout(int nLength, DWORD dwMode)
{
	TRACE("in CPropSheetBar::CalcDynamicLayout, length = %d, dwMode = %d, bHorz = %d\nm_sizePropSheet.x=%d, y=%d\n",nLength,dwMode, dwMode&LM_HORZ,m_sizePropSheet.cx,m_sizePropSheet.cy);

	if (IsFloating())
	{
		TRACE("is floating\n");
		CRect rc(CPoint(6,6),m_sizePropSheet);
		m_cPropSheet.MoveWindow(rc);
		return m_sizePropSheet+CSize(16,16);
	}
		CRect rc(CPoint(4,m_sizeTitle.cy+sizeTitleOffset.cy),m_sizePropSheet);
		m_cPropSheet.MoveWindow(rc);
		return m_sizePropSheet+CSize(16,m_sizeTitle.cy+sizeTitleOffset.cy+10);
}

void CPropSheetBar::DrawGripper(CDC *pDC,const CRect &rect)
{
	TRACE("In CPropSheetBar::DrawGripper, r.top=%d, r.left=%d, r.bot=%d, r.right=%d\n",rect.top,rect.left,rect.bottom,rect.right);
	if (IsFloating())
	{
		CControlBar::DrawGripper(pDC,rect);
		return;
	}

//	CControlBar::DrawGripper(pDC,rect);
	CFont font;
	VERIFY(font.CreateFont(
	14,                        // nHeight
	0,                         // nWidth
	0,                         // nEscapement
	0,                         // nOrientation
	FW_NORMAL,                 // nWeight
	FALSE,                     // bItalic
	FALSE,                     // bUnderline
	0,                         // cStrikeOut
	ANSI_CHARSET,              // nCharSet
	OUT_DEFAULT_PRECIS,        // nOutPrecision
	CLIP_DEFAULT_PRECIS,       // nClipPrecision
	DEFAULT_QUALITY,           // nQuality
	DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	"Arial"));                 // lpszFacename

	CFont *oF=pDC->SelectObject(&font);
	pDC->SetBkColor(GetSysColor(COLOR_BTNFACE));
	pDC->TextOut(rect.left+sizeTitleOffset.cx,rect.top+sizeTitleOffset.cy,m_strTitle);
	CSize sz=pDC->GetTextExtent(m_strTitle);

// Draw the docking grippers 
	CRect rectGrip1(rect.left+sz.cx+2*sizeTitleOffset.cx,7,rect.right-10,7+3);
	pDC->Draw3dRect(rectGrip1, 
		RGB(255,255,255), 
		RGB(128,128,128)); 
	CRect rectGrip2(rect.left+sz.cx+2*sizeTitleOffset.cx,11,rect.right-10, 11+3); 
	pDC->Draw3dRect(rectGrip2, 
		RGB(255,255,255), 
		RGB(128,128,128)); 
}



