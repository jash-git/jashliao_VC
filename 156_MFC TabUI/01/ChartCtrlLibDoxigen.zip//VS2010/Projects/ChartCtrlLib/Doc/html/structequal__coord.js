var structequal__coord =
[
    [ "equal_coord", "structequal__coord.html#a81883426d2610a03ed09467baffbf145", null ],
    [ "operator()", "structequal__coord.html#abcc19ed4ae43f8f7ebe4235b4e33cbb6", null ],
    [ "_coord", "structequal__coord.html#aa5288f416d5e703e0f35a0dfdde7d9c9", null ]
];