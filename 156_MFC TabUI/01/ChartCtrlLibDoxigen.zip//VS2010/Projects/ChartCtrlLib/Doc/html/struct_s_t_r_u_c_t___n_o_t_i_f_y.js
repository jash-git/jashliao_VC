var struct_s_t_r_u_c_t___n_o_t_i_f_y =
[
    [ "bAdd", "struct_s_t_r_u_c_t___n_o_t_i_f_y.html#a9b8d325fc056dbb966c0d219aba7f70b", null ],
    [ "chartIdx", "struct_s_t_r_u_c_t___n_o_t_i_f_y.html#abbaa5ac7bdeb9f9fe25953fbda177f8d", null ],
    [ "dataID", "struct_s_t_r_u_c_t___n_o_t_i_f_y.html#aaaddbfd86a638458507cc6651e95a49e", null ],
    [ "dataPntD", "struct_s_t_r_u_c_t___n_o_t_i_f_y.html#ad8b7a73fd0a7f54f13585e44bd2eb2d1", null ],
    [ "nmhdr", "struct_s_t_r_u_c_t___n_o_t_i_f_y.html#a71f1855a1ef04ccad505dca369cc4941", null ]
];