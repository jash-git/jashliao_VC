var searchData=
[
  ['badd',['bAdd',['../struct_s_t_r_u_c_t___n_o_t_i_f_y.html#a9b8d325fc056dbb966c0d219aba7f70b',1,'STRUCT_NOTIFY']]],
  ['bstate',['bState',['../structtag_n_m_c_h_a_r_t.html#a283e51f912263ae80286c9b1ac50e116',1,'tagNMCHART']]]
];
