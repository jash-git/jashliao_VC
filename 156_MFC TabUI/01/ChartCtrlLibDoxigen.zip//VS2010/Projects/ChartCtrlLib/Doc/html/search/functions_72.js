var searchData=
[
  ['rectffromcenterf',['RectFFromCenterF',['../_util_8h.html#ad12a28f5ed37de8eceb17c2bfc099de8',1,'Util.h']]],
  ['rectftocrect',['RectFToCRect',['../_util_8h.html#a3932b37fc39105a22443847c75a66e02',1,'Util.h']]],
  ['refreshselcells',['RefreshSelCells',['../class_c_chart_data_view.html#ae114139a7fb9106a85fb3b6dbda912e3',1,'CChartDataView']]],
  ['refreshwnd',['RefreshWnd',['../class_c_chart_container.html#a6d03658342764c59cbc76d2c0a34ecc1',1,'CChartContainer']]],
  ['removechart',['RemoveChart',['../class_c_chart_container.html#a1976dca3b3efd0612d2e1c9c69e40517',1,'CChartContainer']]],
  ['replacechartdata',['ReplaceChartData',['../class_c_chart_container.html#a32ebaec264ffed98a945aa1a53f823e1',1,'CChartContainer::ReplaceChartData(int chartIdx, V_CHARTDATAD &amp;vData, bool bClip=false, bool bUpdate=false, bool bVerbose=false, bool bRedraw=false)'],['../class_c_chart_container.html#a9483180ea396462904960128d37eece4',1,'CChartContainer::ReplaceChartData(int chartIdx, std::vector&lt; double &gt; &amp;vTmSeries, double startX=0.0, double stepX=1.0, bool bClip=false, bool bUpdate=false, bool bVerbose=false, bool bRedraw=false)'],['../class_c_chart_container.html#a5f93fadd877da7a83c180dee4296b0fd',1,'CChartContainer::ReplaceChartData(int chartIdx, std::vector&lt; std::pair&lt; double, double &gt; &gt; &amp;vXYData, bool bClip=false, bool bUpdate=false, bool bVerbose=false, bool bRedraw=false)'],['../class_c_chart_container.html#ae2634afc9e10802f864580159c04573e',1,'CChartContainer::ReplaceChartData(int chartIdx, std::vector&lt; double &gt; &amp;vX, std::vector&lt; double &gt; &amp;vY, bool bClip=false, bool bUpdate=false, bool bVerbose=false, bool bRedraw=false)']]],
  ['replacechartsfromxmlfile',['ReplaceChartsFromXMLFile',['../class_c_charts_x_m_l_serializer.html#a8c8b6b9e1cb84d441872d8e60cf1ee49',1,'CChartsXMLSerializer']]],
  ['replacecontainercharts',['ReplaceContainerCharts',['../class_c_chart_container.html#a58f734d20645d1812668dd16a01e5d9a',1,'CChartContainer']]],
  ['resetchartcontainer',['ResetChartContainer',['../class_c_chart_container.html#a626396d79994eee5841fa35a7f204a2c',1,'CChartContainer']]],
  ['resetchartdata',['ResetChartData',['../class_c_chart.html#af6d99e22b6a355b115b7f479da3d2019',1,'CChart']]],
  ['resetcharts',['ResetCharts',['../class_c_chart_container.html#a81f2538d28834c9a993509108f41f07a',1,'CChartContainer']]],
  ['restoremodex',['RestoreModeX',['../class_c_chart_container.html#a098cb34f33c8a986bfea9b6c96bfac35',1,'CChartContainer']]],
  ['restoremodey',['RestoreModeY',['../class_c_chart_container.html#a4bd5c95272c8e5d8a55a52a08122fa96',1,'CChartContainer']]],
  ['reverse_5ftransform_5fand_5fcast_5fto_5fpntd',['reverse_transform_and_cast_to_pntD',['../structreverse__transform__and__cast__to__pnt_d.html#a9c157c1f01df4f942e5b402106742ccc',1,'reverse_transform_and_cast_to_pntD']]],
  ['rowrectfromdataid',['RowRectFromDataID',['../class_c_chart_data_view.html#a0a49a865c837b9d841bec57c1b2f1d31',1,'CChartDataView']]]
];
