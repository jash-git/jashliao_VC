var structnearest__to_3_01_t_00_01false_01_4 =
[
    [ "nearest_to", "structnearest__to_3_01_t_00_01false_01_4.html#a2457817cd228543f90aa8c2882e95d91", null ],
    [ "operator()", "structnearest__to_3_01_t_00_01false_01_4.html#a6146415c4a0c6861a64d0f56ed1a1d46", null ],
    [ "_distance", "structnearest__to_3_01_t_00_01false_01_4.html#ab4ca8ad53e2c656aad9d6978cbbe6745", null ],
    [ "_origPnt", "structnearest__to_3_01_t_00_01false_01_4.html#a61a3e11adf2651e93ffb9e86b009979b", null ]
];