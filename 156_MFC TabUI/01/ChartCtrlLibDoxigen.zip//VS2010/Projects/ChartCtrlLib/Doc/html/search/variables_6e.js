var searchData=
[
  ['nmhdr',['nmhdr',['../struct_s_t_r_u_c_t___n_o_t_i_f_y.html#a71f1855a1ef04ccad505dca369cc4941',1,'STRUCT_NOTIFY']]]
];
