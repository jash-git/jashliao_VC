var class_matrix_d =
[
    [ "MatrixD", "class_matrix_d.html#aec0626095a88c89e34389c73f9b2023b", null ],
    [ "Clone", "class_matrix_d.html#ab6c04f314c91f54dc3053107d9b0c3eb", null ],
    [ "Invert", "class_matrix_d.html#a8cdc633318170a279614ab72b1385e04", null ],
    [ "Scale", "class_matrix_d.html#a2f3e66f0094fca9ce5a11b34c53e7341", null ],
    [ "TransformToPntD", "class_matrix_d.html#a132825f17603a8328cb923b117aca054", null ],
    [ "TransformToPntF", "class_matrix_d.html#a3d0ac949d56aeda5d13ac48fbe02ba1a", null ],
    [ "Translate", "class_matrix_d.html#aa73c0644b339b6494a20893f49661b75", null ],
    [ "m_offsX", "class_matrix_d.html#ad7dda0beaee64ce3bd19a8701e2aad20", null ],
    [ "m_offsY", "class_matrix_d.html#ad763969c08792ff03cd89cc7e20b950f", null ],
    [ "m_scX", "class_matrix_d.html#a8850fe83f2ac8d5987639ac56ca467b2", null ],
    [ "m_scY", "class_matrix_d.html#af1d458c5adb10a8c8a3bd7f0b0ae1fdd", null ]
];