var structcount__in__range =
[
    [ "count_in_range", "structcount__in__range.html#a5a92cd8de0b77433dbef3b7cf6074463", null ],
    [ "operator()", "structcount__in__range.html#a9094b67ef457f0bf65746f6fa6c2f481", null ],
    [ "_left", "structcount__in__range.html#a6486c73a9213a6c3f04e7fecb1217225", null ],
    [ "_right", "structcount__in__range.html#a02ba123ee621c265d06787e02325051a", null ]
];