var searchData=
[
  ['beginzoomingx',['BeginZoomingX',['../class_c_chart_container.html#a579cdf71dfd2e62e336e7bc48593068f',1,'CChartContainer']]],
  ['beginzoomingy',['BeginZoomingY',['../class_c_chart_container.html#ad9c0c12340ec0c781aac92cb0e099298',1,'CChartContainer']]]
];
