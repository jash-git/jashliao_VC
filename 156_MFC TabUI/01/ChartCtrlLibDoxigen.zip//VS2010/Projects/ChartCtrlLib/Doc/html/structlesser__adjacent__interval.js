var structlesser__adjacent__interval =
[
    [ "lesser_adjacent_interval", "structlesser__adjacent__interval.html#a394f861cf9a59b6b17d240fd314096a5", null ],
    [ "operator()", "structlesser__adjacent__interval.html#abde85d639b4df86714baa2df8c92009e", null ],
    [ "_epsPnt", "structlesser__adjacent__interval.html#a4aa08007bae8159bcc9ab3568a370d45", null ]
];