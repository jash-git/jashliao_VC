var searchData=
[
  ['dataid',['dataID',['../struct_s_t_r_u_c_t___n_o_t_i_f_y.html#aaaddbfd86a638458507cc6651e95a49e',1,'STRUCT_NOTIFY']]],
  ['datapntd',['dataPntD',['../struct_s_t_r_u_c_t___n_o_t_i_f_y.html#ad8b7a73fd0a7f54f13585e44bd2eb2d1',1,'STRUCT_NOTIFY']]]
];
