var structless__pnt =
[
    [ "operator()", "structless__pnt.html#ae6379e54c7dca249c5033d5b5fcfd84f", null ]
];