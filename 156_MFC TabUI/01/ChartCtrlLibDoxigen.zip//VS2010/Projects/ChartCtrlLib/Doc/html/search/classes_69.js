var searchData=
[
  ['in_5fvicinity',['in_vicinity',['../structin__vicinity.html',1,'']]]
];
