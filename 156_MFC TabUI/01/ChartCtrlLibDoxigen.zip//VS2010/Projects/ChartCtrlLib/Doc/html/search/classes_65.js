var searchData=
[
  ['equal_5fcoord',['equal_coord',['../structequal__coord.html',1,'']]],
  ['equal_5fcoord_3c_20t_2c_20false_20_3e',['equal_coord&lt; T, false &gt;',['../structequal__coord_3_01_t_00_01false_01_4.html',1,'']]]
];
