var searchData=
[
  ['names',['NAMES',['../_chart_def_8h.html#a896bef5eae3ece770cb9fbffdf9ae252',1,'ChartDef.h']]]
];
