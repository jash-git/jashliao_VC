var searchData=
[
  ['move_5fdeltax',['MOVE_DELTAX',['../_chart_def_8h.html#a57fe7ffeaa2e727b8a8d644c8b2af93d',1,'ChartDef.h']]],
  ['move_5fdeltay',['MOVE_DELTAY',['../_chart_def_8h.html#ae669bfb48ae8ada8c9769eb800993dac',1,'ChartDef.h']]]
];
