var structin__vicinity =
[
    [ "in_vicinity", "structin__vicinity.html#a2f90006dc56a867a2baf83a053b6905e", null ],
    [ "operator()", "structin__vicinity.html#a8e720bfab9487750658be24cea1fae4a", null ],
    [ "_epsPntT", "structin__vicinity.html#ab2f497ed6d7eb2aa97ac5a46c2dbebe7", null ],
    [ "_origPntT", "structin__vicinity.html#a91a7c7b379e311de4b479d45f3b28880", null ]
];