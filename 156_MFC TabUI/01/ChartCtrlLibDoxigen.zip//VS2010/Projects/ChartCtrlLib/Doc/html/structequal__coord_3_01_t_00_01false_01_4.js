var structequal__coord_3_01_t_00_01false_01_4 =
[
    [ "equal_coord", "structequal__coord_3_01_t_00_01false_01_4.html#a7851f80ddfd1ef053701e90a429e3576", null ],
    [ "operator()", "structequal__coord_3_01_t_00_01false_01_4.html#a99158aa83bbd19a81da12cba4158a567", null ],
    [ "_coord", "structequal__coord_3_01_t_00_01false_01_4.html#a002c197618d9e8f883b633213af23868", null ]
];