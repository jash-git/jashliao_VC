var searchData=
[
  ['vc_5fextralean',['VC_EXTRALEAN',['../stdafx_8h.html#a0172fbace36625330d5f0f163a1ddc1a',1,'stdafx.h']]]
];
