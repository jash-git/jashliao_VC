var structxy__to__pnt =
[
    [ "xy_to_pnt", "structxy__to__pnt.html#acf3479bddc83bac6ede1ab6a56dbbc2d", null ],
    [ "operator()", "structxy__to__pnt.html#a1eac246f399b5160803e9d440a2adee1", null ]
];