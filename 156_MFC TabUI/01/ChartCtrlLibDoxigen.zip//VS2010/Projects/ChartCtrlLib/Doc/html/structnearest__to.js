var structnearest__to =
[
    [ "nearest_to", "structnearest__to.html#a7aa0b1fa289399721e4b9065b8d5b044", null ],
    [ "operator()", "structnearest__to.html#a6618c32abb86e15f717049413c574d1c", null ],
    [ "_distance", "structnearest__to.html#a9e4a1949b3e2f844e430826c9709884d", null ],
    [ "_origPnt", "structnearest__to.html#a38ed5a7de8188c481f388f7d4c69f7ef", null ]
];