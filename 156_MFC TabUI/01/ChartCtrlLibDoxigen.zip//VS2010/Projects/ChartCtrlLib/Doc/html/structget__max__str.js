var structget__max__str =
[
    [ "get_max_str", "structget__max__str.html#aa67db7b3841065fd25f62baa91aa190a", null ],
    [ "operator()", "structget__max__str.html#ad872da83a36d0350787f86c223c7b60c", null ],
    [ "_grPtr", "structget__max__str.html#af8b2398af21d5324d6c7a59c457755f2", null ],
    [ "_maxRF", "structget__max__str.html#ab1b4638a79b5cc72bf63a9a500cc9ce9", null ],
    [ "_pFont", "structget__max__str.html#a969570559a5516ef53b4336d48add373", null ]
];