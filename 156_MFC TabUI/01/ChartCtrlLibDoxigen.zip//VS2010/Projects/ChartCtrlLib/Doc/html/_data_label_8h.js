var _data_label_8h =
[
    [ "CDataWnd", "class_c_data_wnd.html", "class_c_data_wnd" ],
    [ "IDW_LABELS", "_data_label_8h.html#a37a7461ff5ad146d8af46d5d05c7e0a9", null ],
    [ "LABEL_OFFS", "_data_label_8h.html#ad85e2e7370885b6b3616eb6eeee82a6c", null ],
    [ "LB_BORDERSPACE", "_data_label_8h.html#a86e50e44c7ecc5d7837316401378dd46", null ],
    [ "LB_BULLETSZ", "_data_label_8h.html#aea12af42fd10a4300b9ed421ac39a32c", null ],
    [ "LB_FONTSIZE", "_data_label_8h.html#a713db31e6b6003fd65887ec24f0990c0", null ],
    [ "LB_STROFFSX", "_data_label_8h.html#a63a3ba108a969ea946439b1661a7af91", null ],
    [ "LB_WNDDST", "_data_label_8h.html#a41b8ddc0e19a9e68362a24d4d29ace6e", null ]
];