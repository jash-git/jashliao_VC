var searchData=
[
  ['struct_5fnotify',['STRUCT_NOTIFY',['../struct_s_t_r_u_c_t___n_o_t_i_f_y.html',1,'']]]
];
