var stdafx_8h =
[
    [ "_ATL_CSTRING_EXPLICIT_CONSTRUCTORS", "stdafx_8h.html#a137e19a46f145129447af81af06def9f", null ],
    [ "_VARIADIC_MAX", "stdafx_8h.html#ab554fc882a4bc89d872310051917d59e", null ],
    [ "VC_EXTRALEAN", "stdafx_8h.html#a0172fbace36625330d5f0f163a1ddc1a", null ],
    [ "WIN32_LEAN_AND_MEAN", "stdafx_8h.html#ac7bef5d85e3dcd73eef56ad39ffc84a9", null ]
];