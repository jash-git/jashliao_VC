var searchData=
[
  ['undohiststepx',['UndoHistStepX',['../class_c_chart_container.html#a276db0cb75ac9192eb94477fefb12620',1,'CChartContainer']]],
  ['undohiststepy',['UndoHistStepY',['../class_c_chart_container.html#aa84853844f6eb11a4c529893a67a0d3a',1,'CChartContainer']]],
  ['unwindhistx',['UnwindHistX',['../class_c_chart_container.html#a6aad64f7788c0d4ff4d61dc93c05d7d3',1,'CChartContainer']]],
  ['updatechartlocscaley',['UpdateChartLocScaleY',['../class_c_chart_container.html#afa84cfd5cc9415b3b74f169305bed55d',1,'CChartContainer']]],
  ['updatechartpenwidth',['UpdateChartPenWidth',['../class_c_chart_container.html#a8f4fc4d50388416edbfb203da31e6606',1,'CChartContainer']]],
  ['updatecontainerwnds',['UpdateContainerWnds',['../class_c_chart_container.html#ae74240f6a6e8e579c810f72d81455350',1,'CChartContainer']]],
  ['updatedataidx',['UpdateDataIdx',['../class_c_chart_data_view.html#a870526d46e49f02fe646c9dcc31798c3',1,'CChartDataView']]],
  ['updatedatalegend',['UpdateDataLegend',['../class_c_chart_container.html#a3d8fe7542b7e2e9adccd151944f90021',1,'CChartContainer::UpdateDataLegend(bool bChangeMatrix)'],['../class_c_chart_container.html#abe60584f910936dc7fef695c30c87271',1,'CChartContainer::UpdateDataLegend(MAP_SELPNTSD &amp;mapSelPntsD, MAP_LABSTR &amp;m_mapLabs)'],['../class_c_data_wnd.html#a3325df75e6a4f4b1dc0921ecec3c1864',1,'CDataWnd::UpdateDataLegend()']]],
  ['updatedataview',['UpdateDataView',['../class_c_chart_container.html#ad4034e8dc50b6f0551088ca44f01cd64',1,'CChartContainer']]],
  ['updatedataviewpnts',['UpdateDataViewPnts',['../class_c_chart_container.html#acaba29f8c696a9d65d4978ca18d99913',1,'CChartContainer::UpdateDataViewPnts(int chartIdx, size_t dataID, PointD dataPntD, bool bAdd)'],['../class_c_chart_container.html#a1d881738ee5c2274e47123715581e2f7',1,'CChartContainer::UpdateDataViewPnts(int chartIdx, const MAP_SELPNTSD &amp;mapSelPntsD)']]],
  ['updatedataviewpntsdmap',['UpdateDataViewPntsDMap',['../class_c_chart_container.html#a985bbd5f7227e83e285527928b117d8e',1,'CChartContainer']]],
  ['updateextx',['UpdateExtX',['../class_c_chart_container.html#af93a9590ff2a3b9904dbf3070f32ff83',1,'CChartContainer']]],
  ['updateexty',['UpdateExtY',['../class_c_chart_container.html#a80a4113353e8a8ec967c0f2e3c3754d9',1,'CChartContainer']]],
  ['updateparams',['UpdateParams',['../class_c_chart_data_view.html#a2f8dca7bd2d4f82c4a539badf7e39bed',1,'CChartDataView']]],
  ['updatescales',['UpdateScales',['../class_c_chart_container.html#a58e4426430f75de4522a44c3e9ecdb9e',1,'CChartContainer']]],
  ['updatescalex',['UpdateScaleX',['../class_c_chart_container.html#aa09a012f0036fe1ace0ead8cf02490ae',1,'CChartContainer']]],
  ['updatescaley',['UpdateScaleY',['../class_c_chart_container.html#a88033383ca4ff78d57b413653c4fa2c9',1,'CChartContainer']]],
  ['util_2ecpp',['Util.cpp',['../_util_8cpp.html',1,'']]],
  ['util_2eh',['Util.h',['../_util_8h.html',1,'']]]
];
