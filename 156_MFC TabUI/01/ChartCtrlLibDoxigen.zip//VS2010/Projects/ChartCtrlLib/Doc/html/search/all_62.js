var searchData=
[
  ['badd',['bAdd',['../struct_s_t_r_u_c_t___n_o_t_i_f_y.html#a9b8d325fc056dbb966c0d219aba7f70b',1,'STRUCT_NOTIFY']]],
  ['beginzoomingx',['BeginZoomingX',['../class_c_chart_container.html#a579cdf71dfd2e62e336e7bc48593068f',1,'CChartContainer']]],
  ['beginzoomingy',['BeginZoomingY',['../class_c_chart_container.html#ad9c0c12340ec0c781aac92cb0e099298',1,'CChartContainer']]],
  ['between',['BETWEEN',['../_chart_def_8h.html#a630e88db60efbd9fe383c956b2268da6a8a86033ada1240a0576a1ce24d8d307b',1,'ChartDef.h']]],
  ['bottom',['BOTTOM',['../_chart_def_8h.html#a253c12cc4f1ffb1b3c770c09d8dd668da8c371f4e766fb2c49c219bbc88989461',1,'ChartDef.h']]],
  ['bstate',['bState',['../structtag_n_m_c_h_a_r_t.html#a283e51f912263ae80286c9b1ac50e116',1,'tagNMCHART']]]
];
