var structcoord__in__range =
[
    [ "coord_in_range", "structcoord__in__range.html#a1f4111733e41749c887ab8a32e29f244", null ],
    [ "operator()", "structcoord__in__range.html#ac9b4db71cb58c2350a1add7284804433", null ],
    [ "_left", "structcoord__in__range.html#a9e857884d2f1f4c5c7430eefe0ac2161", null ],
    [ "_right", "structcoord__in__range.html#a00dc186f9d5d478822af8dd0964389d7", null ]
];