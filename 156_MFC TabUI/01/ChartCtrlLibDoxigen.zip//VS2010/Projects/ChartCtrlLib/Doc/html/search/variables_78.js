var searchData=
[
  ['x',['X',['../class_point_t.html#ae8656a84c5abd873ea65e951b89a0e18',1,'PointT']]]
];
