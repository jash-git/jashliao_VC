var structtag_n_m_c_h_a_r_t =
[
    [ "bState", "structtag_n_m_c_h_a_r_t.html#a283e51f912263ae80286c9b1ac50e116", null ],
    [ "chartIdx", "structtag_n_m_c_h_a_r_t.html#ae189c923889283095936169481aa92e4", null ],
    [ "hdr", "structtag_n_m_c_h_a_r_t.html#a2b89740924a8f91270e090fd51ab4598", null ],
    [ "maxX", "structtag_n_m_c_h_a_r_t.html#ab2249902370adcad8237db155c8f3fd0", null ],
    [ "maxY", "structtag_n_m_c_h_a_r_t.html#a2297ba48b7d4a3dad46b31a7e084211a", null ],
    [ "minX", "structtag_n_m_c_h_a_r_t.html#ab8cbbfe7495ffc176d23cf111bae2f93", null ],
    [ "minY", "structtag_n_m_c_h_a_r_t.html#a2880ec57fc38eb0e1f6ad3e64c097ff8", null ]
];