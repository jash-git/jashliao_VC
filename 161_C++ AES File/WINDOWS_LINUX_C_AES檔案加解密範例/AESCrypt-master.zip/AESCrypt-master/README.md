# AES Crypt

This is a branch of the soure repository for the AES Crypt software
available from www.aescrypt.com.  This branch has a few more build options
than the master code available from aescrypt.com directly.

AES Crypt was initially developed for Windows and then later ported to Linux.
Other versions of the software, including Mac, Java, Android, and iOS, were
created, most of which were derived from the Linux code.

The code for each platform is stored in a directory for that platform
(e.g., Windows and Linux).  A "readme" file exists in each that provides
any additional information that might be useful for that platform.

Some of the source code is not yet published here, though all source code
is still available from https://www.aescrypt.com.

The code in this repository is the current development code and
may contain code that has not been fully tested.  As a new version binary
is released and a version number associated with it, the source code and
binary will be posted to www.aescrypt.com/download.
