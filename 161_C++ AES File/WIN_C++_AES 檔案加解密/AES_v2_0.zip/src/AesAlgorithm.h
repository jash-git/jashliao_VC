#ifndef _AES_ALGORITHM_
#define _AES_ALGORITHM_



extern void  aes_encrypt( uint32 * pInput , uint32 * pOutput, uint32 * pKey );

#endif // _AES_ALGORITHM_