/*************************************************************

				EF AES Demo

Module Name: AesDemoDlg.h
Abstract: AES Demo Program
Author: robert			

  
		Copyright (c) 2008, Extreme Fast workshop.
	
	  
*************************************************************/

// AesDemoDlg.h : header file
//

#if !defined(AFX_AESDEMODLG_H__FE3B3E66_AE34_46D6_BD4E_0E0B40EDBA94__INCLUDED_)
#define AFX_AESDEMODLG_H__FE3B3E66_AE34_46D6_BD4E_0E0B40EDBA94__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CAesDemoDlg dialog

class CAesDemoDlg : public CDialog
{
// Construction
public:
	CAesDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAesDemoDlg)
	enum { IDD = IDD_AESDEMO_DIALOG };
	CProgressCtrl	m_ProgressDecode;
	CComboBox	m_FeedBackSize;
	CProgressCtrl	m_Progress;
	CComboBox	m_BlockMode;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAesDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAesDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnButtonFile();
	afx_msg void OnChangeEditFilename();
	afx_msg void OnSelchangeComboMode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AESDEMODLG_H__FE3B3E66_AE34_46D6_BD4E_0E0B40EDBA94__INCLUDED_)
