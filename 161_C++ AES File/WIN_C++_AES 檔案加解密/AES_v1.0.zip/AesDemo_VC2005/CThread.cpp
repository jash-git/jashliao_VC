/*************************************************************

				EF AES Demo

Module Name: CThread.cpp
Abstract: AES Demo Program
Author: robert			

  
		Copyright (c) 2008, Extreme Fast workshop.
	
	  
*************************************************************/

#include "StdAfx.h"
#include "CThread.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CThread::CThread()
{
	m_bRunning = false;
}

CThread::~CThread()
{
	ThreadEnd();
}


static DWORD WINAPI cThreadProc( CThread *pThis )
{
  pThis->ThreadStart();
  pThis->ThreadProc();
  pThis->ThreadEnd();
  return 0;
}




void CThread::Create()
{
	m_Thread = CreateThread(
		NULL, 
		0,
		(LPTHREAD_START_ROUTINE) cThreadProc,    // thread function
		this ,                       // thread argument
		0,                    // creation option
		NULL                        // thread identifier
		);
	m_bRunning = true;
}

void CThread::ThreadStart()
{
	m_bRunning = true;
}

void CThread::ThreadEnd()
{
	if( m_Thread != NULL)
	{
		CloseHandle(m_Thread);
		m_Thread = NULL;
	}
	m_bRunning = false;
}

BOOL CThread::isRunning()
{
	return m_bRunning;
}


DWORD CThread::ThreadProc()
{
	return 0;
}




// Notice, the 16 is AES block size , add it for padding in CFB mode
#define BUFF_SZ  (8192)
//#define BUFF_SZ  (4096)

DWORD CAESThread::ThreadProc()
{
	AesCtx context;
	CFile fSource;
	CFile fEncode;
	CFile fDecode;
	CString fmt;
	int rdsz;
	int iblock_sz=BUFF_SZ;
	// Notice, the plus 16 bytes is AES block size , add it for padding in CFB mode
	unsigned char src[BUFF_SZ + AES_PADDING ];
	unsigned char dst[BUFF_SZ + AES_PADDING ];

	if( !fSource.Open(m_FileName,CFile::modeRead) )
	{
		fmt.Format("Unable to open %s",m_FileName);
		AfxMessageBox(fmt);
		return -1;
	}
	if( !fEncode.Open(m_EncodeFilaName,CFile::modeReadWrite | CFile::modeCreate) )
	{
		fSource.Close();
		fmt.Format("Unable to open %s",m_EncodeFilaName);
		AfxMessageBox(fmt);
		return -1;
	}
	if( !fDecode.Open(m_DecodeFilaName,CFile::modeReadWrite  | CFile::modeCreate) )
	{
		fSource.Close();
		fEncode.Close();
		fmt.Format("Unable to open %s",m_DecodeFilaName);
		AfxMessageBox(fmt);
		return -1;
	}

	//SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_TIME_CRITICAL);

	

	if( m_blockMode == BLOCKMODE_CFB)
	{
		// in CFB mode , block size should be a multiply of feedback size
		iblock_sz = AesRoundSize(iblock_sz ,m_iFeedBackSize);
	}

	unsigned long iTotalSize = fSource.GetLength();
	int percent;
	unsigned long iTotal = 0;
	AesSetKey(&context,m_blockMode, m_key , m_vector );

	// This is only useful if you are using CFB Mode
	AesSetFeedbackSize( &context , m_iFeedBackSize);

	pProgress->SetPos(0);
	pDecodeProgress->SetPos(0);

	switch( m_blockMode )
	{
		case BLOCKMODE_ECB:
			while( (rdsz=fSource.Read(src,iblock_sz)) > 0 )
			{
				AesEncryptECB(&context,dst,src,rdsz);
				rdsz = AesRoundSize( rdsz , 16);

				fEncode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_CBC:
			while( (rdsz=fSource.Read(src,iblock_sz)) > 0 )
			{
				AesEncryptCBC(&context,dst,src,rdsz);
				rdsz = AesRoundSize( rdsz , 16);

				fEncode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_PCBC:
			while( (rdsz=fSource.Read(src,iblock_sz)) > 0 )
			{
				AesEncryptPCBC(&context,dst,src,rdsz);
				rdsz = AesRoundSize( rdsz , 16);

				fEncode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_OFB:
			while( (rdsz=fSource.Read(src,iblock_sz)) > 0 )
			{
				AesEncryptOFB(&context,dst,src,rdsz);
				rdsz = AesRoundSize( rdsz , 16);

				fEncode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_CFB:
			while( (rdsz=fSource.Read(src,iblock_sz)) > 0 )
			{
				AesEncryptCFB(&context,dst,src,rdsz);
				rdsz = AesRoundSize( rdsz , m_iFeedBackSize );

				fEncode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_CRT:
			while( (rdsz=fSource.Read(src,iblock_sz)) > 0 )
			{
				AesEncryptCRT(&context,dst,src,rdsz);
				rdsz = AesRoundSize( rdsz , 16);
				fEncode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pProgress->SetPos(percent);
			}
			break;
	}
	pProgress->SetPos(0);

	AesSetKey(&context,m_blockMode, m_key , m_vector );
	AesSetFeedbackSize( &context , m_iFeedBackSize);

	fEncode.Seek(0,CFile::begin);
	iTotal = 0;

    // do decode
	switch( m_blockMode )
	{
		case BLOCKMODE_ECB:
			while( (rdsz=fEncode.Read(src,iblock_sz)) > 0 )
			{
				AesDecryptECB(&context,dst,src,rdsz);
				fDecode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pDecodeProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_CBC:
			while( (rdsz=fEncode.Read(src,iblock_sz)) > 0 )
			{
				AesDecryptCBC(&context,dst,src,rdsz);
				fDecode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pDecodeProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_PCBC:
			while( (rdsz=fEncode.Read(src,iblock_sz)) > 0 )
			{
				AesDecryptPCBC(&context,dst,src,rdsz);
				fDecode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pDecodeProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_OFB:
			while( (rdsz=fEncode.Read(src,iblock_sz)) > 0 )
			{
				AesDecryptOFB(&context,dst,src,rdsz);
				fDecode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pDecodeProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_CFB:
			// when decode , the total size *must* be a multiply of feedback size
			// so we don't need to handle the round size
			while( (rdsz=fEncode.Read(src,iblock_sz)) > 0 )
			{
				AesDecryptCFB(&context,dst,src,rdsz);
				fDecode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pDecodeProgress->SetPos(percent);
			}
			break;
		case BLOCKMODE_CRT:
			while( (rdsz=fEncode.Read(src,iblock_sz)) > 0 )
			{
				AesDecryptCRT(&context,dst,src,rdsz);
				fDecode.Write( dst, rdsz );
				iTotal+=rdsz;
				percent = (iTotal * 100) / iTotalSize;
				pDecodeProgress->SetPos(percent);
			}
			break;
	}
	pDecodeProgress->SetPos(0);

#if 1
	// do checking
	fSource.Seek(0,CFile::begin);
	fDecode.Seek(0,CFile::begin);
	while((rdsz=fSource.Read(src,4096)) > 0 )
	{
		fDecode.Read(dst,4096);
		if(memcmp(src,dst,rdsz) != 0 )
		{
			fSource.Close();
			fEncode.Close();
			fDecode.Close();
			AfxMessageBox("Verify Error");
			return -1;
		}
	}

#endif

	fSource.Close();
	fEncode.Close();
	fDecode.Close();

	AfxMessageBox("Verify OK");

	return 0;
}
