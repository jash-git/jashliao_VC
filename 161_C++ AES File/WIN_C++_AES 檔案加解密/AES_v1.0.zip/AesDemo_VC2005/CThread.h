/*************************************************************

				EF AES Demo

Module Name: CThread.h
Abstract: AES Demo Program
Author: robert			

  
		Copyright (c) 2008, Extreme Fast workshop.
	
	  
*************************************************************/

#if !defined(_CTHREAD_)
#define _CTHREAD_

#include "..\AES_SSE2\efAES.h"



#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CThread 
{
public:
	CThread();
	~CThread();
	void Create();
	void ThreadStart();
	virtual DWORD ThreadProc();
	void ThreadEnd();
	BOOL isRunning();
protected:
	HANDLE m_Thread;
	BOOL m_bRunning;
	
};




class CAESThread :public CThread
{
public:
	DWORD ThreadProc();

	CString m_FileName;
	CString m_EncodeFilaName;
	CString m_DecodeFilaName;

	unsigned char m_key[16];
	unsigned char m_vector[16];
	int m_iFeedBackSize;

	int m_blockMode;
	CWnd * pParent;
	CProgressCtrl * pProgress;
	CProgressCtrl *pDecodeProgress;
	

};


#endif
