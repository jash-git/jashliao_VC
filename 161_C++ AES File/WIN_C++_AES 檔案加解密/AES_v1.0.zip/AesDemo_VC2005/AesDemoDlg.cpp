/*************************************************************

				EF AES Demo

Module Name: AesDemoDlg.cpp
Abstract: AES Demo Program
Author: robert			

  
		Copyright (c) 2008, Extreme Fast workshop.
	
	  
*************************************************************/
// AesDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AesDemo.h"
#include "AesDemoDlg.h"
#include "CThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAesDemoDlg dialog

CAesDemoDlg::CAesDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAesDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAesDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAesDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAesDemoDlg)
	DDX_Control(pDX, IDC_PROGRESS_DECODE, m_ProgressDecode);
	DDX_Control(pDX, IDC_COMBO_FBSZ, m_FeedBackSize);
	DDX_Control(pDX, IDC_PROGRESS_ENCODE, m_Progress);
	DDX_Control(pDX, IDC_COMBO_MODE, m_BlockMode);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAesDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CAesDemoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_FILE, OnButtonFile)
	ON_EN_CHANGE(IDC_EDIT_FILENAME, OnChangeEditFilename)
	ON_CBN_SELCHANGE(IDC_COMBO_MODE, OnSelchangeComboMode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAesDemoDlg message handlers

BOOL CAesDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_BlockMode.SetCurSel(0);
	m_FeedBackSize.SetCurSel(0);
	m_FeedBackSize.EnableWindow(0);

	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAesDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAesDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CAesDemoDlg::OnButtonFile() 
{
	// TODO: Add your control notification handler code here
	CFileDialog fd(TRUE);
	if( fd.DoModal() == IDOK )
	{
		SetDlgItemText(IDC_EDIT_FILENAME,fd.GetPathName());
		CString fmt;
		fmt.Format("%s.encode",fd.GetPathName());
		SetDlgItemText(IDC_STATIC_ENCODE,fmt);
		fmt.Format("%s.decode",fd.GetPathName());
		SetDlgItemText(IDC_STATIC_DECODE,fmt);
	}
}
void GenerateKey(int initOffset,unsigned char * pBuff)
{
	srand(GetTickCount() + initOffset);
	for(int i=0;i<16;i++)
	{
		pBuff[i]=rand() & 0xff;
	}
}
void ShowUp(CDialog * pDlg,int id,unsigned char * pBuff)
{
	CString fmt;
	fmt.Format(" %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X",
				pBuff[0],
				pBuff[1],
				pBuff[2],
				pBuff[3],
				pBuff[4],
				pBuff[5],
				pBuff[6],
				pBuff[7],
				pBuff[8],
				pBuff[9],
				pBuff[10],
				pBuff[11],
				pBuff[12],
				pBuff[13],
				pBuff[14],
				pBuff[15]
				);
	pDlg->SetDlgItemText( id , fmt );

}

CAESThread thr;
void CAesDemoDlg::OnOK() 
{
	// TODO: Add extra validation here


	thr.m_blockMode = m_BlockMode.GetCurSel();


	if( (thr.m_blockMode == 3) || (thr.m_blockMode == 4) ) //CFB,OFB
	{
        // just reverse it , it is just UI Issue
		thr.m_iFeedBackSize = 16-m_FeedBackSize.GetCurSel();
	}

	OnChangeEditFilename();
    CFile f;
    if( !f.Open(thr.m_FileName,CFile::modeRead) )
    {
        AfxMessageBox("Please choose a file");
        return;
    }
    f.Close();

	thr.pParent = this;
	thr.pProgress = &m_Progress;
	thr.pDecodeProgress = &m_ProgressDecode;
	GenerateKey(0x10,thr.m_key);
	ShowUp(this,IDC_STATIC_KEY,thr.m_key);
	GenerateKey(0x4f,thr.m_vector);
	ShowUp(this,IDC_STATIC_VECTOR,thr.m_vector);

	thr.Create();
    
}

void CAesDemoDlg::OnSelchangeComboMode() 
{
	// TODO: Add your control notification handler code here
    int iSel = m_BlockMode.GetCurSel();
	if( (iSel == 3) || (iSel == 4) )
	{
		m_FeedBackSize.EnableWindow(1);
	} else {
		m_FeedBackSize.EnableWindow(0);
	}
	
}


void CAesDemoDlg::OnChangeEditFilename() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	CString fname;
	GetDlgItemText(IDC_EDIT_FILENAME,fname);
	thr.m_FileName  = fname;
	thr.m_EncodeFilaName.Format("%s.encode",fname);
	thr.m_DecodeFilaName.Format("%s.decode",fname);
	SetDlgItemText(IDC_STATIC_ENCODE,thr.m_EncodeFilaName);
	SetDlgItemText(IDC_STATIC_DECODE,thr.m_DecodeFilaName);
	
}

