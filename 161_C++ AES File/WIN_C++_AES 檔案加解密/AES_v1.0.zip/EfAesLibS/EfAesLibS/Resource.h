//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EfAesLibS.RC
//

// �U�@�ӷs�W���󪺹w�]��
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE	3000
#define _APS_NEXT_CONTROL_VALUE		3000
#define _APS_NEXT_SYMED_VALUE		3000
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
