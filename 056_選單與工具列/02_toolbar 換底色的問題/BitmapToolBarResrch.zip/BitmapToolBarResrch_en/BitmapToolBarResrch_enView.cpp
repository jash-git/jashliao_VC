// BitmapToolBarResrch_enView.cpp : implementation of the CBitmapToolBarResrch_enView class
//

#include "stdafx.h"
#include "BitmapToolBarResrch_en.h"

#include "BitmapToolBarResrch_enDoc.h"
#include "BitmapToolBarResrch_enView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBitmapToolBarResrch_enView

IMPLEMENT_DYNCREATE(CBitmapToolBarResrch_enView, CEditView)

BEGIN_MESSAGE_MAP(CBitmapToolBarResrch_enView, CEditView)
	//{{AFX_MSG_MAP(CBitmapToolBarResrch_enView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBitmapToolBarResrch_enView construction/destruction

CBitmapToolBarResrch_enView::CBitmapToolBarResrch_enView()
{
	// TODO: add construction code here

}

CBitmapToolBarResrch_enView::~CBitmapToolBarResrch_enView()
{
}

BOOL CBitmapToolBarResrch_enView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapToolBarResrch_enView drawing

void CBitmapToolBarResrch_enView::OnDraw(CDC* pDC)
{
	CBitmapToolBarResrch_enDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapToolBarResrch_enView printing

BOOL CBitmapToolBarResrch_enView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CBitmapToolBarResrch_enView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing.
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CBitmapToolBarResrch_enView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapToolBarResrch_enView diagnostics

#ifdef _DEBUG
void CBitmapToolBarResrch_enView::AssertValid() const
{
	CEditView::AssertValid();
}

void CBitmapToolBarResrch_enView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CBitmapToolBarResrch_enDoc* CBitmapToolBarResrch_enView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBitmapToolBarResrch_enDoc)));
	return (CBitmapToolBarResrch_enDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBitmapToolBarResrch_enView message handlers
