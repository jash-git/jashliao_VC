// BitmapToolBarResrch_enView.h : interface of the CBitmapToolBarResrch_enView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BITMAPTOOLBARRESRCH_ENVIEW_H__61C8D2AD_6A79_4312_843C_758482DA9A6F__INCLUDED_)
#define AFX_BITMAPTOOLBARRESRCH_ENVIEW_H__61C8D2AD_6A79_4312_843C_758482DA9A6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CBitmapToolBarResrch_enView : public CEditView
{
protected: // create from serialization only
	CBitmapToolBarResrch_enView();
	DECLARE_DYNCREATE(CBitmapToolBarResrch_enView)

// Attributes
public:
	CBitmapToolBarResrch_enDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBitmapToolBarResrch_enView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBitmapToolBarResrch_enView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBitmapToolBarResrch_enView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in BitmapToolBarResrch_enView.cpp
inline CBitmapToolBarResrch_enDoc* CBitmapToolBarResrch_enView::GetDocument()
   { return (CBitmapToolBarResrch_enDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BITMAPTOOLBARRESRCH_ENVIEW_H__61C8D2AD_6A79_4312_843C_758482DA9A6F__INCLUDED_)
