// BitmapToolBarResrch_enDoc.h : interface of the CBitmapToolBarResrch_enDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BITMAPTOOLBARRESRCH_ENDOC_H__EBDCBBD8_BD6C_47D3_B81E_431E92C11B5C__INCLUDED_)
#define AFX_BITMAPTOOLBARRESRCH_ENDOC_H__EBDCBBD8_BD6C_47D3_B81E_431E92C11B5C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CBitmapToolBarResrch_enDoc : public CDocument
{
protected: // create from serialization only
	CBitmapToolBarResrch_enDoc();
	DECLARE_DYNCREATE(CBitmapToolBarResrch_enDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBitmapToolBarResrch_enDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBitmapToolBarResrch_enDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBitmapToolBarResrch_enDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BITMAPTOOLBARRESRCH_ENDOC_H__EBDCBBD8_BD6C_47D3_B81E_431E92C11B5C__INCLUDED_)
