// Copyright (C) Calum Grant 2008

#include <cppscript>
#include <dynamic/extensions.hpp>
#include "unit_tests.hpp"
#include <cstring>


void test_heap()
{
	kingsley_heap heap;

	void * p = heap.malloc(10);
	heap.free(p);
	assert( heap.malloc(10) == p );

	void * cells[1000];

	for(int i=0; i<1000; ++i) 
	{
		void * p = heap.malloc(1000);
		cells[i] = p;
		memset(p, 0, 1000);
	}

	for(int i=0; i<1000; ++i) 
	{
		heap.free(cells[i]);
	}

	p = heap.malloc(10000000);
	memset(p, 0, 10000000);
}
