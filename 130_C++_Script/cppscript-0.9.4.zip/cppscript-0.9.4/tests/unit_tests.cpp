// Copyright (C) Calum Grant 2008

#include <cppscript>
#include "unit_tests.hpp"


// Create the test set

var script_tests()
{
	return map().extend
		("string functions", test_string_functions)
		("tail", test_tail)
		("native", test_native)
		("stream", test_stream)
		("gc", test_gc)
		("global", test_global)
		("files", test_files)
		("foreach", test_foreach)
		("tls", test_tls)
		// ("heap", test_heap)  // Fails on GCC
		("queue", test_queue)
		("threads", test_threads)
		("proxy", test_proxy)
		("inheritance", test_inheritance)
		("attributes", test_attributes)
		("attribute_operators", test_attribute_operators)
		("erase_attribute", test_erase_attribute)
		("methods", test_methods)
		("instantiate", test_instantiate)
		("function", test_function)
		("void_methods", test_void_methods)
		("bind", test_bind)
		("extend", test_extend)
		("varargs", test_varargs)
		("pickle_object", test_pickle_object)
		("string_container", test_string_container)
		("op_lt", test_op_lt)
		("object_container", test_object_container)
		("array", test_array)
		("comma_lists", test_comma_lists)
		("list", test_list)
		("map", test_map)
		("set", test_set)
		("reverse", test_reverse)
		("sequence", test_sequence)
		("null", test_null)
		("bool", test_bool)
		("ch", test_ch)
		("int", test_int)
		("double", test_double)
		("string", test_string)
		("test_framework", test_test_framework)
		("named_functor", test_named_functor)
		("dispatcher", test_dispatcher)
		("filter", test_filter)
		("transform", test_transform)
		("scopeguard", test_scopeguard)
		("libs", test_libs);
}


var script_main(var args)
{
	test_exception();
	test_stack_trace();
	return run_tests( script_tests() );
}
