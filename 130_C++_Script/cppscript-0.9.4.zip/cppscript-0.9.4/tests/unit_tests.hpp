// Copyright (C) Calum Grant 2008

#include <cassert>

#define assert_throws(Ex, Stmt) try { Stmt; assert(0&&"Exception not thrown"); } catch(Ex) { } catch(...) { assert(0&&"Unknown exception thrown"); }

#undef NDEBUG

#define assert_not_supported(Stmt) assert_throws(dynamic::not_supported, Stmt);

void test_default_container(var);
void test_default_iterator(var);
void test_default_assignment(var);
void test_default_operators(var);
bool lex_equal(const var & v1, const var & v2);
void test_pickle(const var & v);
void test_lex_pickle(var v);
void test_container_basics(var c);
void assert_sequence_equals(var s0, var s1);


// Tests

/// Tests storage and retrieval of native C++ objects in a var.
/** \ingroup test */
void test_native();

void test_stream();

/// Tests the garbage collector.
/** \ingroup test */
void test_gc();

/// Tests the global() function.
/** \ingroup test */
void test_global();

/// Tests for files and steams.
/** \ingroup test */
void test_files();

/// Tests the foreach macro.
/** \ingroup test */
void test_foreach();

/// Tests exception handling.
/** \ingroup test */
void test_exception();

/// Tests stack tracing and stack_trace().
/** \ingroup test */
void test_stack_trace();

/// Tests thread-local storage.
/** \ingroup test \see cg::tls */
void test_tls();

/// Tests the Kingsley heap.
/** \ingroup test 
	\see dynamic::kingsley_heap */
void test_heap();

/// Tests message queues.
/** \ingroup test
	\see dynamic::queue()
	\see dynamic::message_queue()
	*/
void test_queue();

/// Tests threading
/** \ingroup test
	\see dynamic::thread()
	*/
void test_threads();

/// Tests cross-apartment proxy.
/** \ingroup test
	\see proxy()
	\see dynamic::types::proxy_impl
	*/
void test_proxy();

/// Tests object inheritance.
/** \ingroup test
	\see object()
	*/
void test_inheritance();

/// Tests object attributes.
/** \ingroup test */
void test_attributes();

/// Tests operators on attributes.
/** \ingroup test */
void test_attribute_operators();

/// Tests erasing an attribute.
/** \ingroup test
	\see dynamic::var_impl::erase() */
void test_erase_attribute();

/// Tests methods
/** \ingroup test
	\see dynamic::bind()
	\see dynamic::object()
	\see dynamic::internal::extender
	*/
void test_methods();

/// Tests object cloning.
/** \ingroup test */
void test_instantiate();

/// Tests functors.
/** \ingroup test */
void test_function();

/// Tests methods returning void.
/** \ingroup test */
void test_void_methods();

/// Tests the bind() function.
/** \ingroup test */
void test_bind();

/// Tests the var::extend() method.
/** \ingroup test */
void test_extend();

/// Tests the varargs() function.
/** \ingroup test */
void test_varargs();

/// Tests the pickle() function.
/** \ingroup test */
void test_pickle_object();

/// Tests strings.
/** \ingroup test */
void test_string_container();

/// Tests comparison.
/** \ingroup test */
void test_op_lt();

/// Tests object().
/** \see object()
	\ingroup test */
void test_object_container();

/// Tests array().
/** \ingroup test */
void test_array();

/// Tests C-style lists.
/** \ingroup test */
void test_comma_lists();

/// Tests list().
/** \ingroup test */
void test_list();

/// Tests map().
/** \ingroup test */
void test_map();

/// Tests set().
/** \ingroup test */
void test_set();

/// Tests reverse().
/** \ingroup test */
void test_reverse();

/// Tests range() and other functions.
/** \ingroup test */
void test_sequence();

/// Tests the \ref dynamic::null object and dynamic::var::var().
/** \ingroup test */
void test_null();

/// Tests the functionality of the \ref dynamic::types::bool_impl class.
/** \ingroup test */
void test_bool();

/// Tests  dynamic::types::int_impl.
/** \ingroup test */
void test_ch();

/// Tests dynamic::types::int_impl.
/** \ingroup test */
void test_int();

/// Tests dynamic::types::double_impl.
/** \ingroup test */
void test_double();

/// Tests dynamic::types::string_impl.
/** \ingroup test */
void test_string();

/// Tests test_framework() function.
/** \ingroup test */
void test_test_framework();

void test_named_functor();

/// Tests the dispatcher() function.
/** \ingroup test */
void test_dispatcher();

/// Tests the filter() function.
/** \ingroup test */
void test_filter();

/// Tests the transform() function.
/** \ingroup test */
void test_transform();

/// Tests dynamic::scopeguard.
/** \ingroup test */
void test_scopeguard();

/// Tests the tail() function.
/** \ingroup test */
void test_tail();

/// Tests functions on strings.
/** \ingroup test */
void test_string_functions();

/// Tests various library functions.
/** \ingroup test */
void test_libs();
