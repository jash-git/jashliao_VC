// Copyright (C) Calum Grant 2008

#include "cppscript"
#include "dynamic/extensions.hpp"

static_call( register_pickle_type( cmp_null, null ) );


/// \todo Move classes into header files

namespace dynamic
{
	namespace types
	{
		/// Implements the null variable.
		/** \ingroup impl */
		class null_impl : public dynamic::var_impl
		{
		public:
			void output(ostream &  os) 
			{ 
				os << "null"; 
			}

			void output(wostream & os) 
			{ 
				os << L"null"; 
			}
			
			std::string class_name() 
			{ 
				return "null"; 
			}
			
			var_cmp_index comparison_index() 
			{ 
				return cmp_null; 
			}
			
			void copy_to(void * dest) const
			{
				new(dest) null_impl();
			}

			var op_add(const var & v) 
			{ 
				return v; 
			}
			
			var op_sub(const var & v) 
			{ 
				return -v; 
			}
			
			var op_mul(const var & ) 
			{ 
				return var(); 
			}
			
			var op_div(const var & ) 
			{ 
				return var(); 
			}
			
			var op_mod(const var & ) 
			{ 
				return var(); 
			}
			
			var op_neg() 
			{ 
				return var(); 
			}
			
			var op_lshift(const var &) 
			{ 
				return var(); 
			}
			
			var op_rshift(const var &) 
			{ 
				return var(); 
			}
			
			var op_and(const var &) 
			{ 
				return var(); 
			}
			
			var op_or(const var & v) 
			{ 
				return v; 
			}
			
			var op_xor(const var & v) 
			{ 
				return v; 
			}

			void pickle(pickler & p)
			{ 
				p.write_object_type(cmp_null); 
			}

			void unpickle(unpickler & u)
			{ 
			}
		};
	}
}


var::var() : m_variant(types::null_impl()) 
{ 
}
