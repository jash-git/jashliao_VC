// Copyright (C) Calum Grant 2008

#ifndef DYNAMIC_HPP
#define DYNAMIC_HPP

#include <stdexcept>
#include <iostream>
#include <string>

#if defined(_MSC_VER)		// Visual C++ version
	#ifdef DYNAMIC_EXPORTS
	#define DYNAMIC_API __declspec(dllexport)
	#else
	#define DYNAMIC_API __declspec(dllimport)
	#endif
#else
	#define DYNAMIC_API
#endif

#include "max_aligned.hpp"
#include "static_assert.hpp"
#include "class_traits.hpp"

#include "var_methods.hpp"
#include "var_variant.hpp"
#include "var_impl.hpp"
#include "var.hpp"
#include "var_member.hpp"
#include "exceptions.hpp"
#include "lib.hpp"
#include "extend.hpp"
#include "inline_impl.hpp"

#endif
