// Copyright (C) Calum Grant 2008

namespace dynamic
{
#pragma warning(push)
#pragma warning(disable:4275)

	/// The base class of C++Script's exceptions.
	/** \ingroup exceptions */
	class DYNAMIC_API exception : public std::runtime_error, public var
	{
	public:
		exception();
		exception(const char * class_name);
		exception(const char * class_name, const var & message);
		exception(const char * class_name, const var & message, const var & extra);
		~exception() throw();
	};

#pragma warning(pop)

	/// Creates an exception string from an exception.
	/** \ingroup exceptions */
	DYNAMIC_API var exception_description(const var & ex);


	/// Exception indicating that a member has not been found in an object.
	/** \ingroup exceptions */
	class DYNAMIC_API not_found : public exception
	{
	public:
		not_found(var const &);
		~not_found() throw();
	};


	/// Exception indicating that an operation attempted on an object is not supported.
	/** \ingroup exceptions */
	class DYNAMIC_API not_supported : public exception
	{
	public:
		not_supported(const var & object, const std::string & operation);
		not_supported(var_impl * object, const std::string & operation);
		~not_supported() throw();
	};


	/// Exception indicating that the wrong number of arguments has been passed to a functor.
	/** \ingroup exceptions */
	class DYNAMIC_API wrong_number_of_args : public exception
	{
	public:
		wrong_number_of_args(int expected, int actual);
		~wrong_number_of_args() throw();
	};


	/// Exception indicating that too many arguments has been passed to a functor.
	/** \ingroup exceptions */
	class DYNAMIC_API too_many_arguments : public exception
	{
	public:
		too_many_arguments();
		~too_many_arguments() throw();
	};


	/// Exception when a string is in the wrong format.
	/** \ingroup exceptions */
	class DYNAMIC_API invalid_string : public exception
	{
	public:
		invalid_string();
		~invalid_string() throw();
	};


	/// Exception when an iterator is used after its underlying object has been modified.
	/** The reason for this exception is that C++ iterators are only valid for certain durations.
		For example you might have an iterator pointing at a deleted item.
		\ingroup exceptions
	*/
	class DYNAMIC_API expired_iterator : public exception
	{
	public:
		expired_iterator();
		~expired_iterator() throw();
	};
}
