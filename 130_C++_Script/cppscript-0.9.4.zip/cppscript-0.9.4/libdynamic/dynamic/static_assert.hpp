// Copyright (C) Calum Grant 2006
// http://calumgrant.net

#ifndef CG_STATIC_ASSERT_HPP
#define CG_STATIC_ASSERT_HPP

namespace cg
{
	/// Assert conditions at compile time.
	template<bool x> struct static_assert;
	template<> struct static_assert<true> { };
}

#endif
