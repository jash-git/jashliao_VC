// Copyright (C) Calum Grant 2008

namespace dynamic
{
	namespace internal
	{
		/// A helper data structure to extend an object.
		/** This is the result of var_methods::extend()
			\ingroup  syntax */
		class extender : public var_methods<extender, const var&>
		{
		public:
			extender(const var & obj) : m_object(obj) 
			{ 
			}

			/// Extend the object with the specified name/value pair.
			template<typename T>
			extender & operator()(const char *m, T v)
			{
				m_object[m]=v;
				return *this;
			}

			const var & deref() const 
			{ 
				return m_object; 
			}

		private:
			var m_object;
		};
	}
}
