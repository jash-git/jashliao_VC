// Copyright (C) Calum Grant 2006 
// http://calumgrant.net

/** \todo Rename file to max_aligned */

#ifndef CG_MAXALIGNED_HPP
#define CG_MAXALIGNED_HPP

namespace cg
{
	/// A data structure with maximum alignment.
	/**	This is really a hack since it's not possible to implement this in C++98 
		\ingroup mem */
	union max_aligned
	{
	   char c;
	   int i;
	   double d;
	   float f;
	   short s;
	   void *p;
	   long l;
	   wchar_t w;
	};
}

#endif
