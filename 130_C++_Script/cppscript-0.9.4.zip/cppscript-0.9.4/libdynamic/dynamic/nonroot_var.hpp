// Copyright (C) Calum Grant 2008

namespace dynamic
{
	namespace internal
	{
		/// A class containing a non-root variable.
		class nonroot_var
		{
			var m_value;
		public:
			/// Default constructor gives a null variable.
			nonroot_var() 
			{ 
			}

			/// Assign from a root or a non-root variable.
			nonroot_var(const var & v) : m_value(v.impl().as_nonroot()) 
			{ 
			}

			/// Access the variable.
			/** This is less efficient than \ref ref() because this converts
				the value to a root variable */
			var get() const 
			{ 
				return m_value.impl().as_root(); 
			}

			/// Access the variable.
			/** This variable is a non-root variable so must not be
				returned from a function */
			const var & ref() const 
			{ 
				return m_value; 
			}

			/// Access the variable.
			/** This variable is a non-root variable so must not be
				returned from a function */
			var & ref() 
			{ 
				return m_value; 
			}

			/// Comparison for use in containers.
			bool operator<(const var&v) const 
			{ 
				return m_value<v; 
			}
		};
	}
}
