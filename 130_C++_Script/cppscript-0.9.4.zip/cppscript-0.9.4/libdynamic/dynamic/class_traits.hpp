// Copyright (C) Calum Grant 2008

/// Namespace for private utils.
namespace cg
{
	/// A class trait to indicate that a class has a virtual destructor.
	/** Inherit from this to give your class a virtual destructor. */
	class DYNAMIC_API virtual_destructor
	{
	public:
		virtual ~virtual_destructor() { }
	};


	/// A class trait to indicate that a class does not have a copy constructor.
	/** Inherit from this to disable the default copy constructor */
	class DYNAMIC_API not_copyable
	{
		not_copyable(const not_copyable&);
	public:
		not_copyable() { }
	};


	/// A class trait to indicate that a class is not assignable.
	/** Inherit from this class to make any class non-assignable. */
	class DYNAMIC_API not_assignable
	{
		not_assignable & operator=(const not_assignable&);
	public:
		/// Default constructor to keep some compilers happy.
		not_assignable() { }
	};
}
