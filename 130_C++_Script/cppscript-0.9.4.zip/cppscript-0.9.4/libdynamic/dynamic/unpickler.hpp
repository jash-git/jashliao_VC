// Copyright (C) Calum Grant 2008

namespace dynamic
{
	/// A helper class used by the \ref unpickle() function.
	class unpickler
	{
	public:
		/// Defines where to read the bytes from.
		unpickler(std::istream & input);

		/// Reads a single object from the stream.
		var read_object();

		/// Reads an integer from the stream.
		int read_int();

		/// Reads a size from the stream.
		std::size_t read_size();

		/// Reads a double from the stream.
		double read_double();

		/// Reads a string from the stream.
		std::string read_string();

		/// Reads a function from the stream.
		void * read_function_pointer();

	private:
		typedef std::vector<shared_var_impl*> object_list;
		object_list m_objects;	///< The list of objects we've read.
		std::istream & m_input;	///< The stream to read from.
	};
}

