// Copyright (C) Calum Grant 2008

#if defined _WIN32 || defined __WIN32__
#include "win32/thread.hpp"
#else
#include "posix/thread.hpp"
#endif
