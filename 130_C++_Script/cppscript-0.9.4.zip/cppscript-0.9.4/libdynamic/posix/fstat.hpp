// Copyright (C) Calum Grant 2008

#include <sys/types.h>
#include <sys/stat.h>

namespace dynamic
{
	/// Wrapper for platform-specific function calls.
	namespace api
	{
		typedef struct stat stat;

		inline int fstat(const char * file, stat * buf)
		{
			return ::stat(file, buf);
		}

		inline int execv(const char *cmd, char * const * argv)
		{
			return int(::execv(cmd, argv));
		}
	}
}
