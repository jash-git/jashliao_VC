// Copyright (C) Calum Grant 2008

#include "cppscript"
#include "dynamic/extensions.hpp"


var_impl::~var_impl() 
{ 
}


var var_impl::get_member(var const &) 
{ 
	throw not_supported(this, "get_member"); 
}


void var_impl::set_member(var const &, var const &) 
{ 
	throw not_supported(this, "set_member"); 
}


var var_impl::get_member(const char *m) 
{ 
	return get_member(var(m)); 
}


var var_impl::get_member(int m) 
{ 
	return get_member(var(m)); 
}


void var_impl::set_member(const char * m, const var & d) 
{ 
	set_member(var(m), d); 
}


void var_impl::set_member(int m, const var & d) 
{ 
	set_member(var(m), d); 
}


var var_impl::begin() 
{ 
	return var(); 
}


var var_impl::end() 
{ 
	return var(); 
}


int var_impl::size() 
{ 
	return 0; 
}


bool var_impl::empty() 
{ 
	return true; 
}


var var_impl::rbegin() 
{ 
	return var(); 
}


var var_impl::rend() 
{ 
	return var(); 
}


void var_impl::output(ostream&) 
{ 
}


void var_impl::output(wostream&) 
{
}


void var_impl::short_output(ostream & os) 
{ 
	output(os); 
}


void var_impl::short_output(wostream & os) 
{ 
	output(os); 
}


int var_impl::as_int() 
{ 
	return 0; 
}


double var_impl::as_double() 
{ 
	return as_int(); 
}


bool var_impl::as_bool() 
{ 
	return false; 
}


void * var_impl::as_ptr() 
{ 
	return 0; 
}


var var_impl::deref() 
{ 
	return value(); 
}


var shared_var_impl::clone() 
{ 
	return this; 
}


void var_impl::resize(std::size_t) 
{ 
	throw not_supported(this, "resize"); 
}


bool var_impl::contains(const var&) 
{ 
	return false; 
}


void var_impl::erase(const var&) 
{ 
}


void var_impl::mixin(const var&) 
{ 
	throw not_supported(this, "mixin"); 
}


var var_impl::key() 
{ 
	throw not_supported(this, "key"); 
}


var var_impl::value() 
{ 
	throw not_supported(this, "value"); 
}


void var_impl::push_back(const var&)  
{ 
	throw not_supported(this, "push_back"); 
}


void var_impl::push_front(const var&)  
{ 
	throw not_supported(this, "push_front"); 
}


var var_impl::pop_back() 
{ 
	throw not_supported(this, "pop_back"); 
}


var var_impl::pop_front() 
{ 
	throw not_supported(this, "pop_front"); 
}


void var_impl::insert(const var&) 
{ 
	throw not_supported(this, "insert"); 
}


void var_impl::insert(const var&,const var&) 
{ 
	throw not_supported(this, "insert"); 
}


var var_impl::front() 
{ 
	throw not_supported(this, "front"); 
}


var var_impl::back() 
{ 
	throw not_supported(this, "back"); 
}


void var_impl::clear() 
{ 
	throw not_supported(this, "clear"); 
}


var_cmp_index var_impl::comparison_index() 
{ 
	return cmp_null; 
}


var_cmp_result var_impl::compare(const var & other) 
{ 
	int index_diff = comparison_index() - other.impl().comparison_index();
	if(index_diff<0) return cmp_lt;
	if(index_diff>0) return cmp_gt;
	return compare2(other);
}


var_cmp_result var_impl::compare2(const var & other)
{
	return cmp_equal;
}


var_cmp_result shared_var_impl::compare2(const var & other) 
{ 
	std::ptrdiff_t diff = this - other.impl().shared_var();
	if(diff<0) return cmp_lt;
	if(diff>0) return cmp_gt;
	return cmp_equal;
}


var var_impl::op_add(const var &) 
{ 
	throw not_supported(this, "+"); 
}


var var_impl::op_neg() 
{ 
	throw not_supported(this, "-"); 
}


var var_impl::op_pos() 
{ 
	return clone(); 
}


var var_impl::op_sub(const var &) 
{ 
	throw not_supported(this, "-"); 
}


var var_impl::op_mul(const var &) 
{ 
	throw not_supported(this, "*"); 
}


var var_impl::op_div(const var &) 
{ 
	throw not_supported(this, "/"); 
}


var var_impl::op_mod(const var &) 
{ 
	throw not_supported(this, "%");
}


var var_impl::op_lshift(const var&) 
{ 
	throw not_supported(this, "<<"); 
}


var var_impl::op_rshift(const var&) 
{ 
	throw not_supported(this, ">>"); 
}


var var_impl::op_and(const var &) 
{ 
	throw not_supported(this, "&"); 
}


var var_impl::op_or(const var &) 
{
	throw not_supported(this, "|"); 
}


var var_impl::op_xor(const var &) 
{
	throw not_supported(this, "^");
}


var var_impl::op_inv() 
{
	throw not_supported(this, "~");
}


void var_impl::op_inc() 
{ 
	throw not_supported(this, "++"); 
}


void var_impl::op_dec() 
{ 
	throw not_supported(this, "--"); 
}


void var_impl::assign_add(const var&) 
{ 
	throw not_supported(this, "+="); 
}


void var_impl::assign_sub(const var&) 
{ 
	throw not_supported(this, "-="); 
}


void var_impl::assign_mul(const var&) 
{ 
	throw not_supported(this, "*="); 
}


void var_impl::assign_div(const var&) 
{ 
	throw not_supported(this, "/="); 
}


void var_impl::assign_mod(const var&) 
{ 
	throw not_supported(this, "%="); 
}


void var_impl::assign_lshift(const var&) 
{ 
	throw not_supported(this, "<<="); 
}


void var_impl::assign_rshift(const var&) 
{ 
	throw not_supported(this, ">>="); 
}


void var_impl::assign_and(const var&) 
{ 
	throw not_supported(this, "&="); 
}


void var_impl::assign_or(const var&) 
{ 
	throw not_supported(this, "|="); 
}


void var_impl::assign_xor(const var&) 
{ 
	throw not_supported(this, "^="); 
}


std::string var_impl::class_name() 
{ 
	return "(none)"; 
}


var var_impl::keys() 
{ 
	return var(); 
}


var var_impl::values()
{ 
	return var(); 
}


var var_impl::as_root() 
{ 
	return clone(); 
}


var var_impl::as_nonroot() 
{ 
	return clone(); 
}


void shared_var_impl::copy_to(void * dest) const
{
	// This is really a quirk of the inheritance scheme.
	// shared_var_impl inherits from variant_base, yet doesn't actually
	// need copy_to, since you shouldn't copy a shared var into a var
	// The design is a little wrong on this point.
	throw not_supported( const_cast<shared_var_impl*>(this), "copy_to" );
}


void var_impl::mark_reachable(gc::garbage_collector & gc)
{
}


void shared_var_impl::mark_reachable(gc::garbage_collector & gc)
{
	gc.mark_reachable(this);
}


shared_var_impl * var_impl::shared_var() 
{ 
	return 0; 
}


var var_impl::call()
{ 
	throw not_supported(this, "call with 0 arguments"); 
}


var var_impl::call(const var &)
{ 
	throw not_supported(this, "call with 1 arguments"); 
}


var var_impl::call(const var &, const var&)
{ 
	throw not_supported(this, "call with 2 arguments"); 
}


var var_impl::call(const var &, const var&, const var&)
{ 
	throw not_supported(this, "call with 3 arguments"); 
}


var var_impl::call(const var &, const var&, const var&, const var&)
{ 
	throw not_supported(this, "call with 4 arguments"); 
}


var var_impl::call(const var &, const var&, const var&, const var&, const var&)
{ 
	throw not_supported(this, "call with 5 arguments"); 
}


var var_impl::call(const var &, const var&, const var&, const var&, const var&, const var&)
{ 
	throw not_supported(this, "call with 6 arguments"); 
}


var var_impl::call(const var &, const var&, const var&, const var&, const var&, const var&, const var&)
{ 
	throw not_supported(this, "call with 7 arguments"); 
}


var var_impl::call(const var &, const var&, const var&, const var&, const var&, const var&, const var&, const var&)
{ 
	throw not_supported(this, "call with 8 arguments"); 
}


var var_impl::call(const var &, const var&, const var&, const var&, const var&, const var&, const var&, const var&, const var&)
{ 
	throw not_supported(this, "call with 9 arguments"); 
}


var var_impl::call(const var &, const var&, const var&, const var&, const var&, const var&, const var&, const var&, const var&, const var&)
{ 
	throw not_supported(this, "call with 10 arguments"); 
}


var var_impl::member_inc(const char * str)
{ 
	throw not_supported(this, "member_inc"); 
}


var var_impl::member_dec(const char * str)
{ 
	throw not_supported(this, "member_dec"); 
}


var var_impl::member_inc(const char * str, int)
{ 
	throw not_supported(this, "member_inc"); 
}


var var_impl::member_dec(const char * str, int)
{ 
	throw not_supported(this, "member_dec"); 
}


var var_impl::member_add(const char * str, const var&)
{ 
	throw not_supported(this, "member_add"); 
}


var var_impl::member_sub(const char * str, const var&)
{ 
	throw not_supported(this, "member_sub"); 
}


int var_impl::max_args() 
{ 
	return -1; 
}


int var_impl::bind_args() 
{ 
	return -1; 
}


var var_impl::member_call(const char*m)
{ 
	return get_member(m)(); 
}


var var_impl::member_call(const char*m, const var & a0)
{ 
	return get_member(m)(a0); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1)
{ 
	return get_member(m)(a0,a1); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2)
{ 
	return get_member(m)(a0,a1,a2); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2, const var & a3)
{ 
	return get_member(m)(a0,a1,a2,a3); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2, const var & a3, const var & a4)
{ 
	return get_member(m)(a0,a1,a2,a3,a4); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2, const var & a3, const var & a4, const var & a5)
{ 
	return get_member(m)(a0,a1,a2,a3,a4,a5); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2, const var & a3, const var & a4, const var & a5, const var & a6)
{ 
	return get_member(m)(a0,a1,a2,a3,a4,a5,a6); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2, const var & a3, const var & a4, const var & a5, const var & a6, const var & a7)
{ 
	return get_member(m)(a0,a1,a2,a3,a4,a5,a6,a7); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2, const var & a3, const var & a4, const var & a5, const var & a6, const var & a7, const var & a8)
{ 
	return get_member(m)(a0,a1,a2,a3,a4,a5,a6,a7,a8); 
}


var var_impl::member_call(const char*m, const var & a0, const var & a1, const var & a2, const var & a3, const var & a4, const var & a5, const var & a6, const var & a7, const var & a8, const var & a9)
{ 
	return get_member(m)(a0,a1,a2,a3,a4,a5,a6,a7,a8,a9); 
}


var var_impl::proxy()
{ 
	return clone(); 
}


var shared_var_impl::proxy()
{ 
	return dynamic::internal::proxy(this); 
}


var var_impl::enumerator() 
{ 
	return var(); 
}


var var_impl::reverse_enumerator()
{ 
	return var(); 
}


void var_impl::reserve(std::size_t) 
{ 
}


std::size_t var_impl::capacity() 
{ 
	return 0; 
}


void var_impl::get_range(std::size_t container_size, std::pair<std::size_t,std::size_t> & out)
{
	throw not_supported( this, "get_range" );
}


var var_impl::clone()
{
	return var( *this, var::assign_impl() );
}

