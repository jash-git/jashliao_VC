// Copyright (C) Calum Grant 2008

#include "cppscript"
#include "dynamic/extensions.hpp"

static_call( register_pickle_type( cmp_true, true ) ); 
static_call( register_pickle_type( cmp_false, false ) );


namespace dynamic
{
	/// Contains implementations of all variable types.
	namespace types
	{
		/// Implements a boolean.
		/** @param b is the value 
			\see test_bool for unit tests.
			\ingroup impl
			*/
		template<bool b>
		class bool_impl : public dynamic::var_impl
		{
		public:

			void output(ostream & os)
			{
				os << (b ? "true" : "false");
			}

			std::string class_name() { return "bool"; }

			void output(wostream & os)
			{
				os << (b ? L"true" : L"false");
			}

			int as_int()
			{
				return b ? 1 : 0;
			}

			double as_double()
			{
				return b ? 1.0 : 0.0;
			}

			bool as_bool()
			{
				return b;
			}

			var op_add(const var & x)
			{
				return b||x;
			}

			var op_mul(const var & x)
			{
				return b&&x;
			}

			var op_and(const var & x)
			{ 
				return b && x; 
			}

			var op_or(const var & x)
			{ 
				return b || x; 
			}

			var op_inv() 
			{ 
				return !b; 
			}

			var op_xor(const var & x)
			{ 
				return b != x.as_bool(); 
			}

			var_cmp_index comparison_index() 
			{ 
				return b ? cmp_true : cmp_false; 
			}

			void pickle(pickler & p)
			{ 
				p.write_object_type(b ? cmp_true : cmp_false); 
			}

			void unpickle(unpickler & u) 
			{ 
			}

			var as_root() 
			{ 
				return b; 
			}

			var as_nonroot() 
			{ 
				return b; 
			}

			void copy_to(void*dest) const
			{
				new(dest) bool_impl(*this);
			}
		};
	}
}


var::var(bool b) : 
	m_variant( b ? 
		var_variant(types::bool_impl<true>()) : 
		var_variant(types::bool_impl<false>())
		) 
{ 
}
