#include "cppscript"
#include "dynamic/extensions.hpp"

extern var script_main(var);

extern "C" int main(int argc, char *argv[])
{
	internal::use_new_apartment a;

	try
	{
		stack_trace_entry e("script_main");
		return script_main(array_it(argv+1, argv+argc)).as_int();
	}
	catch(dynamic::exception & ex)
	{
		std::cerr << "An uncaught exception occurred:\n" << exception_description(ex) << std::endl;
		return 100;
	}
	catch(var & ex)
	{
		std::cerr << "Uncaught exception: " << ex.as_string() << std::endl;
		return 101;
	}
	catch(std::exception & ex)
	{
		std::cerr << "Uncaught exception: " << ex.what() << std::endl;
		return 102;
	}
	catch(...)
	{
		std::cerr << "Uncaught exception: unknown\n";
		return 103;
	}
}
