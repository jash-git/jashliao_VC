// Copyright (C) Calum Grant 2008

#include <sys/types.h>
#include <sys/stat.h>
#include <process.h>

namespace dynamic
{
	namespace api
	{
		typedef struct _stat stat;

		inline int fstat(const char * file, stat * buf)
		{
			return ::_stat(file, buf);
		}

		inline int execv(const char *cmd, char *argv[])
		{
			return int(::_execv(cmd, argv));
		}
	}
}
