// Copyright (C) Calum Grant 2008

#include <windows.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/stat.h>

namespace dynamic
{
	const int dir_separator = '\\';

	class win32_filesystem_api
	{
	public:
		static int dir_separator() { return '\\'; }

		struct dir_iterator
		{
			HANDLE find_handle;
			WIN32_FIND_DATAA find_data;
			dir_iterator() : find_handle(INVALID_HANDLE_VALUE) { }
			~dir_iterator() { FindClose(find_handle); }
		};

		static bool first_file(std::string name, dir_iterator & data)
		{
			name += "\\*";
			data.find_handle = FindFirstFileA(name.c_str(), &data.find_data);
			return data.find_handle != INVALID_HANDLE_VALUE;
		}

		static bool find_next(dir_iterator & data)
		{
			return FindNextFileA(data.find_handle, &data.find_data)!=0;
		}

		static const char * get_filename(const dir_iterator & data)
		{
			return data.find_data.cFileName;
		}

		static bool is_directory(const dir_iterator & data, std::string const & filename)
		{
			return (data.find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)!=0;
		}

		static bool is_directory(std::string const & filename)
		{
			struct stat mstat;
			return stat(filename.c_str(), &mstat) == 0 && (mstat.st_mode & _S_IFDIR);
		}
	};

	typedef win32_filesystem_api filesystem_api;
}
