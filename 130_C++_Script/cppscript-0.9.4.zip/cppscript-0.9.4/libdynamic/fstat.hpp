
#if defined _WIN32 || defined __WIN32__
#include "win32/fstat.hpp"
#else
#include "posix/fstat.hpp"
#endif
