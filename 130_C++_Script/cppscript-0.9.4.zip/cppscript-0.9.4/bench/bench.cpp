// Copyright (C) Calum Grant 2008

#include <cppscript>

var tests();

var test(var test_description, var test_fn)
{
	return object("test").extend
		("description", test_description)
		("fn", test_fn);
}

void run_test(var name, var test)
{
	var t0 = timer();
	var check = test["fn"]();
	var t1 = timer();

	writeln( 
		pad(name,20) + 
		pad("" + (t1-t0), 15) + 
		check
		);
}

var script_main(var tests_to_run)
{
	var t = tests();

	if(!tests_to_run)
	{
		writeln("Usage: bench [test_name...]\nPossible tests are:\n");
		writeln(pad("Test name", 20) + "Description");
		foreach( test, t )
		{
			writeln(pad(test, 20) + t[test]["description"]);
		}
		writeln(pad("all",20) + "Run all tests");
		return 1;
	}

	var t0 = timer();

	writeln( pad("Test name",20) + pad("Time (s)",15) + "Result");
	foreach(test, tests_to_run)
	{
		if(test == "all")
		{
			foreach(test, t) run_test(test, t[test]);
		}
		else if(t.contains(test))
			run_test(test, t[test]);
		else
			writeln("No such test: " + test);
	}

	var t1 = timer();
	writeln( pad("Total time",20) + (t1-t0) );

	return 0;
}
