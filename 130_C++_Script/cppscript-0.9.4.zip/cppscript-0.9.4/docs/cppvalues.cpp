#include <cppscript>
#include <dynamic/extensions.hpp>

var script_main(var)
{
	var two = create(2);
	writeln( two.as<int>() ); // Output: 2
	writeln( two.as<std::string>() ); // Throws "not_supported"
	return 0;
}
