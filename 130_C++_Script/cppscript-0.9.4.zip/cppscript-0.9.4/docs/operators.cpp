#include <cppscript>

var script_main(var)
{
	var x=12, y=4, z="10";
	writeln(x-y);	// 8
	writeln(x+"8");	// 20
	writeln(z+20);	// 1020
	return 0;
}
