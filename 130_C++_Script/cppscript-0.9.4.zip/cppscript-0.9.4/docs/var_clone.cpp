#include <cppscript>

var script_main(var)
{
    var a = "abc", b=+a;
    b += "def";
    writeln(a);    // abc
    return 0;
}

