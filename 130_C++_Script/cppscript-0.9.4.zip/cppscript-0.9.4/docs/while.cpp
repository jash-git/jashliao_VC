#include <cppscript>

var script_main(var args)
{
	var i=0;
	while(i++<10) writeln(i);
	return 0;
}
