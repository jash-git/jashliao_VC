#include <cppscript>

var script_main(var)
{
	var a=12, b=3.14, c="Hi";
	a=true;
	writeln(a);
	return 0;
}
