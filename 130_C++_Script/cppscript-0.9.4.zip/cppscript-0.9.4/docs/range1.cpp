#include <cppscript>

var script_main(var) 
{ 
    foreach( i, range(1,12) ) 
    {
        foreach( j, range(1,12) ) 
            writeln( "" + i + " * " + j + " = " + i*j ); 
    }
    return 0;
} 

