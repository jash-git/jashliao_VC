#include <cppscript>

void say_goodbye() { writeln("Goodbye"); }

var script_main(var)
{
	writeln("Hello");
	finally( say_goodbye );
	throw exception();
	return 0;
}
