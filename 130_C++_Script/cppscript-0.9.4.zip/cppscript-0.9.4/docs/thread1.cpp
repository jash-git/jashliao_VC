#include <cppscript>

void thread_fn(var r)
{
	foreach(i,r) writeln(i);
}

var script_main(var)
{
	thread( bind( thread_fn, range(0,100) ) );
	thread( bind( thread_fn, range(100,200) ) );
	sleep(1);
	return 0;
}

