#include <cppscript>
 
var create_a_tree(var species, var height) // Constructor function
{
	var tree = object(); 
	tree["species"] = species;
	tree["height"] = height;
	return tree;
}

var script_main(var)
{
	var oak = create_a_tree("oak", 12.2), maple = create_a_tree("maple", 15.0);
	writeln( "The height of the oak is " + oak["height"] );
	return 0;
}
