#include <cppscript>

var script_main(var)
{
	var text = "The cat sat on the mat";
	var is_not_space = bind( is_not_one_of, " \t\r\n" );
	foreach( word, split_chars( is_not_space, text ) )
		writeln(word);
	return 0;
}
