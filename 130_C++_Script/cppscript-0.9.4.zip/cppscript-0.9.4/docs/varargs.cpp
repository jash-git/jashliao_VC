#include <cppscript>

void greet_list(var greeting, var people) 
{ 
    foreach(i, people) writeln(greeting + " " + i); 
}

var script_main(var args)
{
    var hello = varargs( bind(greet_list, "Hello") );
    hello("cat", "dog", "horse");
    return 0;
}
