#include <cppscript>

var f(); 

var script_main(var) 
{ 
    return f();
} 

var f() 
{ 
    return 2; 
}
