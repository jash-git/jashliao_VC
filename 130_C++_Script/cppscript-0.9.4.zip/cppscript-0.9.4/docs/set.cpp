#include <cppscript>
 
var script_main(var)
{
	var s1 = set();
	s1.insert(1);
	s1.insert(2);
	s1.insert(3);
	writeln( s1.contains(2) ); // true
	s1.erase(2);
	writeln( s1.contains(2) ); // false
	return 0;
}
