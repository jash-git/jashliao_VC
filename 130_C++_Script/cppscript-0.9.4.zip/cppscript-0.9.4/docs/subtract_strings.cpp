#include <cppscript>

var script_main(var)
{
	writeln("We are about to throw an exception");
	var("abc") - var("def");
	return 0;
}
