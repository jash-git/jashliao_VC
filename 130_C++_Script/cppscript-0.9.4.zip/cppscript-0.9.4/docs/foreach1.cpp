#include <cppscript> 

var script_main(var args) 
{ 
      foreach(i, args) writeln("Hello "+i); 
      return 0; 
}
