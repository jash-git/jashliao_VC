#include <cppscript> 

var sum(var a, var b) { return a+b; } 

var script_main(var) 
{ 
    var sum_fn = sum; 
    writeln( sum_fn(2,3) );    // 5
    return 0;
}
