#include <cppscript>

var script_main(var)
{
	writeln("Hello world!");
	return 0;
}
