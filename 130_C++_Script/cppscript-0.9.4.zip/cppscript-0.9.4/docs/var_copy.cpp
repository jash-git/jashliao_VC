#include <cppscript>

var script_main(var)
{
    var a = "abc", b=a;
    b += "def";
    writeln(a);    // abcdef
    return 0;
}

