#include <cppscript> 

var add(var a, var b) { return a+b; } 

var script_main(var) 
{ 
    writeln( add(2,3) );    // 5
    return 0;
}

