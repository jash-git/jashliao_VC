//////////////////////////////////////////////////
//������CDownloadAddress
//���ܣ�������ҳ����
//���ߣ��쾰��(jingzhou_xu@163.net)
//��֯��δ��������(Future Studio)
//���ڣ�2001.12.1
//////////////////////////////////////////////////
#if !defined(AFX_DOWNLOADADDRESS_H__144A5480_5518_11D6_AA35_BE8B1831D90B__INCLUDED_)
#define AFX_DOWNLOADADDRESS_H__144A5480_5518_11D6_AA35_BE8B1831D90B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DownloadAddress.h : header file
//
#include "FlatEdit.h"				//ƽ��༭����
#include "xShadeButton.h"			//�����Ի�ʽ��Ӱλͼ��ť��
/////////////////////////////////////////////////////////////////////////////
// CDownloadAddress dialog

class CDownloadAddress : public CDialog
{
// Construction
public:
	CDownloadAddress(CWnd* pParent = NULL);   // standard constructor

	CString GetDownloadAddress();   //��ȡ��ǰ��ҳ���ص�ַ
	CString m_strAddress;           //��ŵ�ǰ��ҳ���ص�ַ

// Dialog Data
	//{{AFX_DATA(CDownloadAddress)
	enum { IDD = IDD_DOWNLOAD_ADDRESS };
	CFlatEdit	m_Address;			 //��ʾΪƽ��༭��
	CxShadeButton	m_Cancel;
	CxShadeButton	m_Download;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDownloadAddress)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDownloadAddress)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWNLOADADDRESS_H__144A5480_5518_11D6_AA35_BE8B1831D90B__INCLUDED_)
