//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HelpTip.rc
//
#define IDD_HELPTIP_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       158
#define IDB_CHECK                       160
#define IDD_DOWNLOAD_ADDRESS            161
#define IDD_ABOUT                       162
#define IDC_DROP                        172
#define IDC_MAIL                        1000
#define IDC_DOWNLOAD                    1001
#define IDC_COPYRIGHT                   1002
#define ID_MORE                         1003
#define IDC_DYCREDITS                   1004
#define IDR_SHOWHIDE                    32771
#define IDR_FULLSCREEN_WALK             32772
#define IDR_EXIT                        32773
#define IDR_DOWNLOAD                    32774
#define IDR_ACTION                      32775
#define IDR_ACTION_RUN                  32776
#define IDR_ACTION_WALK                 32777
#define IDR_ACTION_IDLE                 32778
#define IDR_ABOUT                       32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        173
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
