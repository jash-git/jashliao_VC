// P2PConnection.cpp: implementation of the P2PConnection class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "P2PConnection.h"
#include <process.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
/////////////////listen class
CP2PConnection::CListenSocket::CListenSocket()
{
	m_hThread		= NULL;
	m_hKillAcceptEvent	= CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&m_Accepcs);
	m_bTimeToKill=NULL;

}
CP2PConnection::CListenSocket::~CListenSocket()
{
	stop();
	DeleteCriticalSection(&m_Accepcs);

}

bool CP2PConnection::CListenSocket::BindSocket(int nConnections, int nPort)
{
	m_socListen = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	
	if (m_socListen == INVALID_SOCKET)
	{
		ReportError(_T("Could not create listen socket"));
		return false;
	}

	// Event for handling Network IO
	m_hAcceptEvent = WSACreateEvent();
	if (m_hAcceptEvent == WSA_INVALID_EVENT)
	{
		TRACE(_T("WSACreateEvent() error "));
		closesocket(m_socListen);
		return false;
	}

	// The listener is ONLY interested in FD_ACCEPT
	// That is when a client connects to or IP/Port
	// Request async notification
	int nRet = WSAEventSelect(m_socListen,
						  m_hAcceptEvent,
						  FD_ACCEPT);
	
	if (nRet == SOCKET_ERROR)
	{
		ReportError(_T("WSAAsyncSelect() error"));
		closesocket(m_socListen);
		return false;
	}

	SOCKADDR_IN		saServer;		
	// Listen on our designated Port#
	saServer.sin_port = htons(nPort);

	// Fill in the rest of the address structure
	saServer.sin_family = AF_INET;
	saServer.sin_addr.s_addr = INADDR_ANY;

	// bind our name to the socket
	nRet = bind(m_socListen, 
				(LPSOCKADDR)&saServer, 
				sizeof(struct sockaddr));

	if (nRet == SOCKET_ERROR)
	{
		ReportError(_T("Error in bind()"));
		closesocket(m_socListen);
		return false;
	}

	// Set the socket to listen
	nRet = listen(m_socListen, nConnections);
	if (nRet == SOCKET_ERROR)
	{
		ReportError(_T("listen()"));
		closesocket(m_socListen);
		return false;
	}
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	UINT	dwThreadId = 0;

	m_hThread =
			(HANDLE)_beginthreadex(NULL,				// Security
									 0,					// Stack size - use default
									 ListenThreadProc,  // Thread fn entry point
									 (void*) this,	    
									 0,					// Init flag
									 &dwThreadId);	// Thread address
	return true;
}

/////////////////////
unsigned CP2PConnection::CListenSocket::ListenThreadProc(LPVOID lParam)
{
	CListenSocket* pThis = reinterpret_cast<CListenSocket*>(lParam);
	WSANETWORKEVENTS events;
	while(TRUE)
	{
        if (WaitForSingleObject(pThis->m_hKillAcceptEvent, 100) == WAIT_OBJECT_0)
            break;

		DWORD dwRet;
		dwRet = WSAWaitForMultipleEvents(1,
									 &pThis->m_hAcceptEvent,
									 FALSE,
									 100,
									 FALSE);
		if (dwRet == WSA_WAIT_TIMEOUT)
			continue;
		//
		// Figure out what happened
		//
		int nRet = WSAEnumNetworkEvents(pThis->m_socListen,
								 pThis->m_hAcceptEvent,
								 &events);
		
		if (nRet == SOCKET_ERROR)
		{
			pThis->ReportError(_T("WSAEnumNetworkEvents"));
			break;
		}

		// Handle Network events //
		// ACCEPT
		if (events.lNetworkEvents & FD_ACCEPT)
		{
			if (events.iErrorCode[FD_ACCEPT_BIT] == 0)
				pThis->OnAccept();
			else
			{
				pThis->ReportError(_T("Unknown network event error"));
				break;
			}
		}
	} // while....
	return 0; // Normal Thread Exit Code...
}
void CP2PConnection::CListenSocket::OnAccept()
{
	CLock cs(m_Accepcs, "CListenSocket::OnAccept" );


	SOCKADDR_IN	SockAddr;
	int			nRet;
	int			nLen;

	if (m_bTimeToKill)
		return;


	//
	// accept the new socket descriptor
	//
	nLen = sizeof(SOCKADDR_IN);
	clientSocket = accept(m_socListen,
					    (LPSOCKADDR)&SockAddr,
						&nLen); 

	if (clientSocket == SOCKET_ERROR)
	{
		nRet = WSAGetLastError();
		if (nRet != WSAEWOULDBLOCK)
		{
			//
			// Just log the error and return
			//
			ReportError(_T("accept()"));
			return;
		}
	}
	pP2P->StateChange(ACCEPT_EVENT,"state change :connection accept");


}


//////////////////listen class

void CP2PConnection::CListenSocket::ReportError(char *ErrorDes)
{
	pP2P->ReportError(ErrorDes);
	return;
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM | 
        FORMAT_MESSAGE_IGNORE_INSERTS,
       NULL,
	   WSAGetLastError(),
	   0, // Default language
	   (LPTSTR) &lpMsgBuf,
	   0,
	   NULL 
	   );
	CString StrError;
	StrError.Format("%s---%s",ErrorDes,(LPCTSTR)lpMsgBuf);
// Display the string.
MessageBox( NULL,StrError, "Error", MB_OK | MB_ICONINFORMATION );
// Free the buffer.
LocalFree( lpMsgBuf );

}


void CP2PConnection::CListenSocket::stop()
{
    ::SetEvent(m_hKillAcceptEvent);
    WaitForSingleObject(m_hThread, INFINITE);
	CloseHandle(m_hThread);
    CloseHandle(m_hKillAcceptEvent);
	m_bTimeToKill=true;
	closesocket(m_socListen);	

}


///////////////
CString CP2PConnection::GetHostName(SOCKET socket)
{
	sockaddr_in  sockAddr;
	memset(&sockAddr, 0, sizeof(sockAddr));

	int nSockAddrLen = sizeof(sockAddr);
	
	BOOL bResult = getpeername(socket,(SOCKADDR*)&sockAddr, &nSockAddrLen);
	
	return bResult != INVALID_SOCKET ? inet_ntoa(sockAddr.sin_addr) : "";
}

CP2PConnection::CP2PConnection(NOTIFYPROC pNotifyProc,LPVOID  pNotifyProcCalss)
{
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2,2), &wsaData);
	m_state=not_connect;
//	m_hConnectEvent=NULL;
	m_Connect_Sock=NULL;
	m_Active_Sock=NULL;
	m_hTActivehread=NULL;
	m_dwThreadId=0;
	m_hActiveKillEvent=NULL;
	m_hActiveEvent=NULL;
	InitializeCriticalSection(&m_statecs);
	m_hActiveKillEvent	= CreateEvent(NULL, TRUE, FALSE, NULL);

	m_pNotifyProc = pNotifyProc ;	
	m_pNotifyProcCalss = pNotifyProcCalss;	



	
}

CP2PConnection::~CP2PConnection()
{
	stop();
	DeleteCriticalSection(&m_statecs);
	WSACleanup();

}

BOOL CP2PConnection::Connect(CString StrAddr)
{
	int noneBlockConnect=0;
	if (m_Connect_Sock)
	{
		closesocket(m_Connect_Sock);
		m_Connect_Sock = NULL;
	}
	
	m_Connect_Sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (m_Connect_Sock == INVALID_SOCKET)
	{
		ReportError("Could not create  socket");
		return FALSE;
	}

	SOCKADDR_IN		saServer;		
	memset(&saServer,0,sizeof(saServer));
	saServer.sin_family = AF_INET;
	saServer.sin_addr.s_addr = inet_addr(StrAddr);
	saServer.sin_port = htons(PORT);
	if(saServer.sin_addr.s_addr==INADDR_NONE)
	{
		hostent *host;
		host=gethostbyname(StrAddr);
		if(host==NULL)
		{
			ReportError("unable to resolve server ip");
			return FALSE;
		}
		memcpy(&saServer.sin_addr,host->h_addr_list[0],host->h_length);
	}

	int nRet = connect(m_Connect_Sock,(sockaddr*)&saServer, sizeof(saServer));
	if (nRet != SOCKET_ERROR)
		noneBlockConnect=1;


	if (nRet == SOCKET_ERROR &&
		WSAGetLastError() != WSAEWOULDBLOCK)
	{
		ReportError("connect() error");
		closesocket(m_Connect_Sock);
		return FALSE;
	}
	
	m_bInProgress = TRUE;
	if(noneBlockConnect==1)
		StateChange(CONNECT_EVENT,"state change :connected");

	return TRUE;
}

void CP2PConnection::ReportError(char *ErrorDes)
{

	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM | 
        FORMAT_MESSAGE_IGNORE_INSERTS,
       NULL,
	   WSAGetLastError(),
	   0, // Default language
	   (LPTSTR) &lpMsgBuf,
	   0,
	   NULL 
	   );
	m_pNotifyProc(m_pNotifyProcCalss,ErrorDes,(LPCTSTR)NULL,0);
	CString StrError;
	StrError.Format("%s---%s",ErrorDes,(LPCTSTR)lpMsgBuf);
// Display the string.
//MessageBox( NULL,StrError, "Error", MB_OK | MB_ICONINFORMATION );
//	AfxGetApp()->GetMainWnd()->SetWindowText(StrError);
// Free the buffer.
LocalFree( lpMsgBuf );

}

unsigned CP2PConnection::SocketThreadProc(LPVOID lParam)
{

	CP2PConnection* pThis = reinterpret_cast<CP2PConnection*>(lParam);

	WSANETWORKEVENTS events;
	bool bExit = false;
	while(!bExit)
	{
		//
		// Wait for something to happen
		//
        if (WaitForSingleObject(pThis->m_hActiveKillEvent, 100) == WAIT_OBJECT_0)
            break;
		
		DWORD dwRet;
		dwRet = WSAWaitForMultipleEvents(1,
									 &pThis->m_hActiveEvent,
									 FALSE,
									 100,
									 FALSE);

		if (dwRet == WSA_WAIT_TIMEOUT)
			continue;

		//
		// Figure out what happened
		//
		int nRet = WSAEnumNetworkEvents(pThis->m_Active_Sock,
								 pThis->m_hActiveEvent,
								 &events);
		
		if (nRet == SOCKET_ERROR)
		{
			pThis->ReportError("WSAEnumNetworkEvents error");
			pThis->StateChange(NETEVENT_ERROR,"state change :netwrok error");
			pThis->m_hTActivehread=(void*)100;
			break;
		}

		//				 //
		// Handle events //
		//				 //

		if (events.lNetworkEvents & FD_READ)
		{
			if (events.iErrorCode[FD_READ_BIT] == 0)
				pThis->OnRead();
			else
			{
				pThis->ReportError(_T("Unknown network event error FD_READ_BIT error"));
				pThis->StateChange(READ_ERROR,"state change :read error");
				pThis->m_hTActivehread=(void*)100;
				break;
			}
		}
		if (events.lNetworkEvents & FD_CONNECT)
		{
			if (events.iErrorCode[FD_CONNECT_BIT] == 0)
				pThis->OnConnect();
			else
			{
				pThis->ReportError(_T("Unknown network event error FD_CONNECT_BIT error"));
				pThis->StateChange(CONNECT_ERROR,"state change :connection error");
				pThis->m_hTActivehread=(void*)100;
				break;
			}
		}
			
		if (events.lNetworkEvents & FD_CLOSE)
		{
			if (events.iErrorCode[FD_CLOSE_BIT] == 0)
			{
				pThis->OnClose();
				pThis->m_hTActivehread=(void*)100;
			}
			else
			{
				pThis->ReportError(_T("Unknown network event error FD_CLOSE error"));
				pThis->StateChange(CLOSE_ERROR,"state change :disconnected");
				pThis->m_hTActivehread=(void*)100;
				break;
			}
		}

		
	} // while....

	return 0; // Normal Thread Exit Code...
}

bool CP2PConnection::OnRead()
{
//	CLock cs(m_statecs, "CP2PConnection::OnRead" );
	DWORD dwSize = 0;
	int nRet = ioctlsocket(m_Active_Sock, FIONREAD, &dwSize);
	if (nRet == -1)
		return true;

	if (dwSize == 0)
		return false;


	BYTE* pData = new BYTE[dwSize+1];
	
	int nRead = recv(m_Active_Sock, (char*) pData, dwSize, 0);
	if (nRead == -1)
		return true;


	m_recvBuff.Write(pData, nRead);
	delete [] pData;

	while (m_recvBuff.GetBufferLen() > (sizeof(int)*1))
	{
		int nSize = 0;
		int nCommand = 0;
		int nPageId = 0;
		CopyMemory(&nSize, m_recvBuff.GetBuffer(), sizeof(int));
		

		if (nSize && m_recvBuff.GetBufferLen() >= (UINT) nSize)
		{
			// Read off header
			m_recvBuff.Read((PBYTE) &nSize, sizeof(int));

		////////////////////////////////////////////////////////
			////////////////////////////////////////////////////////
			// SO you would process your data here
			// 
			// I'm just going to post message so we can see the data
		//	nSize -= sizeof(int);

			int nTrueSize = nSize+1;
			PBYTE pData = new BYTE[nTrueSize];
			
			CString str;

			m_recvBuff.Read(pData,nSize);
			pData[nTrueSize-1] =  NULL;
			str = pData;
			//::PostMessage(m_hWnd, WM_REC_MSG, 0, (LPARAM) AllocBuffer(str));
		//	AfxGetApp()->GetMainWnd()->SetWindowText(str);
			m_pNotifyProc(m_pNotifyProcCalss,str,(CString)"",1 );
	//		Sleep(1000);
			//((CScoketApp *)AfxGetApp())->DataReceived(str);

			// Clean Up
			delete [] pData;
		}
		else
			break;
	}

	return false;

}
bool CP2PConnection::OnConnect()
{
	StateChange(CONNECT_EVENT,NULL);
	return 1;
}
bool CP2PConnection::OnClose()
{
	StateChange(CLOSE_EVENT,"state change :disconnected");
	return 1;
}

void CP2PConnection::RemoveStaleSocket(SOCKET m_socket)
{
	CString strHost = GetHostName(m_socket);
	if (strHost.IsEmpty())
		return;
	CancelIo((HANDLE)m_socket);
	closesocket(m_socket);
	m_socket= INVALID_SOCKET;
}

void CP2PConnection::StateChange(int NewCondition,char * log)
{
	CLock cs(m_statecs, "CP2PConnection::StateChange" );

	if(log)	ReportError(log);

	switch(m_state)
	{
		////////////////////////////////////////////////////////////////
	case not_connect:  //in this state key is off and mouse isn't over the key
		{
			switch(NewCondition)
			{
			case CONNECT_EVENT:
				{
					m_Active_Sock=m_Connect_Sock;
					m_state=estab_connect;
					InitSocketThread();
				}
				break;
			case ACCEPT_EVENT:
				{
					m_Active_Sock=m_ClistenSock.clientSocket;					
					m_state=estab_accept;
					InitSocketThread();
				}
				break;
			default:
				m_Active_Sock=NULL;
				break;
			}
		}
		break;
		//////////////////////////////////////////////////////////////////
	case estab_connect:
		{
			switch(NewCondition)
			{
			case CONNECT_EVENT:
				break;
			case ACCEPT_EVENT:
				{
					stop();
					m_Active_Sock=m_ClistenSock.clientSocket;					
					m_state=estab_accept;
					InitSocketThread();
				}
				break;
			case NETEVENT_ERROR:
			case READ_ERROR:
			case CONNECT_ERROR:
			case CLOSE_ERROR:
			case CLOSE_EVENT:
			case WRITE_ERROR:

				{
					stop();
					m_state=not_connect;
					m_Active_Sock=NULL;
				}
				break;
			}
		}
		break;
		//////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////
	case estab_accept:
		{
			switch(NewCondition)
			{
			case CONNECT_EVENT:
				{
					stop();
					m_Active_Sock=m_Connect_Sock;
					m_state=estab_connect;
					InitSocketThread();
				}
				break;
			case ACCEPT_EVENT:
				{
					stop();
					m_Active_Sock=m_ClistenSock.clientSocket;					
					m_state=estab_accept;
					InitSocketThread();
				}
				break;
			case NETEVENT_ERROR:
			case READ_ERROR:
			case CONNECT_ERROR:
			case CLOSE_ERROR:
			case CLOSE_EVENT:
			case WRITE_ERROR:
			case CONNON_ERROR:
			//case default:
				{
					stop();
					m_state=not_connect;
					m_Active_Sock=NULL;
				}
				break;
			}
		}
		break;
		//////////////////////////////////////////////////////////////////
	}

}
void  CP2PConnection::stop()
{
	::SetEvent(m_hActiveKillEvent);
    WaitForSingleObject(m_hTActivehread, 200);
	if (m_hActiveEvent)
	{
		WSACloseEvent(m_hActiveEvent);
		m_hActiveEvent = NULL;
	}
	
	CloseHandle(m_hTActivehread);
//    CloseHandle(m_hConnectEvent);
	closesocket(m_Active_Sock);
	m_hActiveKillEvent=NULL;
	m_Active_Sock=NULL;
}
void CP2PConnection::SendData(CString strData)
{

	if(m_Active_Sock==NULL)
		return;
	CLock cs(m_statecs, "CP2PConnection::SendData" );
	CString strHdr;
	CString strPkt;


	int nSize = strData.GetLength();

	m_sendBuff.Write((PBYTE) &nSize, sizeof(nSize));
	m_sendBuff.Write((PBYTE) strData.GetBuffer(nSize), nSize);

	DoAsyncSendBuff();
}

void CP2PConnection::DoAsyncSendBuff()
{
	
	int nSendDataLen = m_sendBuff.GetBufferLen();
	PBYTE pData = m_sendBuff.GetBuffer();

	
	int m_nBytesSent = 0;
	
	while (m_nBytesSent < nSendDataLen)  
	{
		int nBytes;

		if ((nBytes = send(m_Active_Sock, (LPCTSTR)pData, nSendDataLen - m_nBytesSent,0))
			== SOCKET_ERROR)
		{
			if (GetLastError() == WSAEWOULDBLOCK) 
			{
				TRACE("Blocking\n");
				Sleep(100);
				break;
			}
			else
			{
				ReportError(_T("Server Socket failed to send"));
				m_nBytesSent = 0;				
				StateChange(WRITE_ERROR,"state change :write error");
				return;
			}
		}
		else
		{
			m_nBytesSent += nBytes;
			m_sendBuff.Delete(nBytes);
		}
	}
}

bool CP2PConnection::InitSocketThread()
{
	m_hActiveEvent = WSACreateEvent();
	if (m_hActiveEvent == WSA_INVALID_EVENT)
	{
		ReportError("WSACreateEvent() error");
		StateChange(CONNON_ERROR,"state change :error in connection");
		return FALSE;
	}

	//
	// Request async notification
	//
	int nRet = WSAEventSelect(m_Active_Sock,
						  m_hActiveEvent,
						  FD_CONNECT|FD_CLOSE|FD_READ);
	
	if (nRet == SOCKET_ERROR)
	{
		ReportError("WSAEventSelect() error");
		StateChange(CONNON_ERROR,"state change :error in connection");
		return FALSE;
	}


	m_hTActivehread=
			(HANDLE)_beginthreadex(NULL,									// Security
				 0,											// Stack size - use default
				 SocketThreadProc,     			// Thread fn entry point
				 (void*) this,	      
				 0,											// Init flag
				 &m_dwThreadId);					// Thread address
	


	return TRUE;
}

bool CP2PConnection::BindSocket()
{
	m_ClistenSock.pP2P=this;
	return m_ClistenSock.BindSocket(10,PORT);

}

void CP2PConnection::DisConnect()
{
	OnClose();
}