// P2PConnection.h: interface for the P2PConnection class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_P2PCONNECTION_H__329225BC_25B5_4CB3_B55F_34C352D18CC2__INCLUDED_)
#define AFX_P2PCONNECTION_H__329225BC_25B5_4CB3_B55F_34C352D18CC2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define		NETEVENT_ERROR		100
#define		READ_ERROR			101
#define		CONNECT_ERROR		102
#define		CLOSE_ERROR			103
#define		WRITE_ERROR			104
#define		CONNON_ERROR		105


#define		CONNECT_EVENT		0
#define		ACCEPT_EVENT		1
#define		CLOSE_EVENT  		2


#define PORT 999

#include "Buffer.h"
#include <winsock2.h>
#pragma comment(lib,"ws2_32.lib")

typedef void (CALLBACK* NOTIFYPROC) (LPVOID, CString, CString, UINT);

enum connection_state	{ not_connect,estab_accept,estab_connect};
class CLock
{
public:
	CLock(CRITICAL_SECTION& cs, const CString& strFunc)
	{
		m_strFunc = strFunc;
		m_pcs = &cs;
		Lock();
	}
	~CLock()
	{
		Unlock();

	}
	
	void Unlock()
	{
		LeaveCriticalSection(m_pcs);
		TRACE(_T("LC %d %s\n") , GetCurrentThreadId() , m_strFunc);
	}

	void Lock()
	{
		TRACE(_T("EC %d %s\n") , GetCurrentThreadId(), m_strFunc);
		EnterCriticalSection(m_pcs);
	}


protected:
	CRITICAL_SECTION*	m_pcs;
	CString				m_strFunc;

};


class CP2PConnection  
{
public:
	class CListenSocket
	{
	public:
		CListenSocket();
		virtual ~CListenSocket();
		bool BindSocket(int nConnections, int nPort);
	public:
		CP2PConnection * pP2P;
		SOCKET		clientSocket;
		
	protected:
		void ReportError(char * ErrorDes);
		static unsigned __stdcall ListenThreadProc(LPVOID lpVoid);
		void OnAccept();
	protected:
		SOCKET m_socListen;
		WSAEVENT m_hAcceptEvent;
		HANDLE	 m_hKillAcceptEvent;
		HANDLE	 m_hThread;
		bool	 m_bTimeToKill;

		CRITICAL_SECTION	m_Accepcs;
	public:
		void stop();
	}m_ClistenSock;
	
public:
	friend class CListenSocket;
	CP2PConnection(NOTIFYPROC pNotifyProc,LPVOID  pNotifyProcCalss);
	virtual ~CP2PConnection();
public:
	CString GetHostName(SOCKET socket);
	bool BindSocket();
	void SendData(CString strData);
	connection_state GetConnectionstate(){ return m_state;}
protected:
	void ReportError(char * ErrorDes);
	bool InitSocketThread();
	void DoAsyncSendBuff();
	void  stop();
	
	static unsigned __stdcall SocketThreadProc(LPVOID lParam);
	//network event maps
	bool OnRead();
	bool OnConnect();
	bool OnClose();

public:
	void StateChange(int NewCondition,char * log);
	void RemoveStaleSocket(SOCKET m_socket);
	BOOL Connect(CString StrAddr);
	void DisConnect();
protected:
	SOCKET m_Connect_Sock;
	SOCKET m_Active_Sock;
	
	BOOL   m_bInProgress;
	CRITICAL_SECTION	m_statecs;



	HANDLE			  m_hActiveKillEvent;
	WSAEVENT          m_hActiveEvent;


//	WSAEVENT          m_hConnectEvent;

	HANDLE				m_hTActivehread;
	UINT				m_dwThreadId;
	//////////////////////////////////////////////////
	CBuffer	m_sendBuff;
	CBuffer	m_recvBuff;
	connection_state m_state;

	NOTIFYPROC m_pNotifyProc;	
	LPVOID     m_pNotifyProcCalss;	


	


};

#endif // !defined(AFX_P2PCONNECTION_H__329225BC_25B5_4CB3_B55F_34C352D18CC2__INCLUDED_)
