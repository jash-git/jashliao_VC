// Peer2PeerDlg.h : header file
//

#if !defined(AFX_PEER2PEERDLG_H__31E5ED60_4433_470F_AE4A_A37B88F152DD__INCLUDED_)
#define AFX_PEER2PEERDLG_H__31E5ED60_4433_470F_AE4A_A37B88F152DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPeer2PeerDlg dialog
#include "P2PConnection.h"
class CPeer2PeerDlg : public CDialog
{
// Construction
public:
	CP2PConnection p2p;
	CPeer2PeerDlg(CWnd* pParent = NULL);	// standard constructor
	static void CALLBACK NotifyProc(LPVOID lpParam, CString LogMsg, CString LogMsgDes, UINT nCode);


// Dialog Data
	//{{AFX_DATA(CPeer2PeerDlg)
	enum { IDD = IDD_PEER2PEER_DIALOG };
	CStatic	m_staticState;
	CListCtrl	m_ListCtrlLOg;
	CEdit	m_EditPeerIP;
	CEdit	m_EditSendPkt;
	CEdit	m_EditRecPkt;

	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPeer2PeerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	BOOL m_bFlood;
	int SendMessageCount;

	// Generated message map functions
	//{{AFX_MSG(CPeer2PeerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSocketBind();
	afx_msg void OnSocketConnect();
	afx_msg void OnSocketDisconnect();
	afx_msg void OnSocketSend();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSocketFlood();
	afx_msg void OnButtonConnect();
	afx_msg void OnButtonDisconnect();
	afx_msg void OnCheckFlood();
	afx_msg void OnButtonSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PEER2PEERDLG_H__31E5ED60_4433_470F_AE4A_A37B88F152DD__INCLUDED_)
