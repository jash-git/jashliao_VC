// Peer2PeerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Peer2Peer.h"
#include "Peer2PeerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPeer2PeerDlg dialog

CPeer2PeerDlg::CPeer2PeerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPeer2PeerDlg::IDD, pParent) ,p2p(NotifyProc,this) 
{
	//{{AFX_DATA_INIT(CPeer2PeerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bFlood = 0;
	SendMessageCount = 0;
}

void CPeer2PeerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPeer2PeerDlg)
	DDX_Control(pDX, IDC_STATIC_SOCKETSTATE, m_staticState);
	DDX_Control(pDX, IDC_LISTCONTROL_LOG, m_ListCtrlLOg);
	DDX_Control(pDX, IDC_EDIT_PEERIP, m_EditPeerIP);
	DDX_Control(pDX, IDC_EDITSENDPKT, m_EditSendPkt);
	DDX_Control(pDX, IDC_EDITREPKT, m_EditRecPkt);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPeer2PeerDlg, CDialog)
	//{{AFX_MSG_MAP(CPeer2PeerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_SOCKET_BIND, OnSocketBind)
	ON_COMMAND(ID_SOCKET_CONNECT, OnSocketConnect)
	ON_COMMAND(ID_SOCKET_DISCONNECT, OnSocketDisconnect)
	ON_COMMAND(ID_SOCKET_SEND, OnSocketSend)
	ON_WM_TIMER()
	ON_COMMAND(ID_SOCKET_FLOOD, OnSocketFlood)
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, OnButtonConnect)
	ON_BN_CLICKED(IDC_BUTTON_DISCONNECT, OnButtonDisconnect)
	ON_BN_CLICKED(IDC_CHECK_FLOOD, OnCheckFlood)
	ON_BN_CLICKED(IDC_BUTTON_SEND, OnButtonSend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPeer2PeerDlg message handlers

BOOL CPeer2PeerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_ListCtrlLOg.InsertColumn(0,"log",LVCFMT_LEFT,600);

	m_EditPeerIP.SetWindowText("127.0.0.1");
	m_EditSendPkt.SetWindowText("this is a test message");

	p2p.BindSocket();
	SetTimer(1,500,NULL);
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPeer2PeerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPeer2PeerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPeer2PeerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPeer2PeerDlg::OnSocketBind() 
{
	if(!p2p.BindSocket())
		AfxMessageBox("cannot bind");
	
	
}

void CPeer2PeerDlg::OnSocketConnect() 
{
	OnButtonConnect();
	
	
}

void CPeer2PeerDlg::OnSocketDisconnect() 
{
	OnButtonDisconnect();
	
}

void CPeer2PeerDlg::OnSocketSend() 
{
	OnButtonSend();
	
}

void CPeer2PeerDlg::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent == 1)
	{
		int state =p2p.GetConnectionstate();
		switch(state) {
		case not_connect:
			m_staticState.SetWindowText("not_connect");
			break;
		case estab_accept:
			m_staticState.SetWindowText("estab_accept");
			break;
		case estab_connect:
			m_staticState.SetWindowText("estab_connect");
			break;
		}
	}
	
	if(nIDEvent == 0)
	{
		
		CString s,str_send;
		m_EditSendPkt.GetWindowText(str_send);
		s.Format("message count=%d %s",SendMessageCount++,str_send);
		p2p.SendData(s);
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CPeer2PeerDlg::OnSocketFlood() 
{
	OnCheckFlood();
}

void CPeer2PeerDlg::OnButtonConnect() 
{
	CString PeerIP ="";
	m_EditPeerIP.GetWindowText(PeerIP);
	p2p.Connect(PeerIP);
	
}

void CPeer2PeerDlg::NotifyProc(LPVOID lpParam, CString LogMsg, CString LogMsgDes, UINT nCode)
{
	CPeer2PeerDlg* pthis = (CPeer2PeerDlg*) lpParam;
	if(pthis==NULL) return;
	if(nCode == 0)
	{
	
	CString str;
	if(LogMsgDes != "")
		str.Format("%s --- des:%s",LogMsg,LogMsgDes);
	else
		str = LogMsg;
	TRACE(str);
	pthis->m_ListCtrlLOg.InsertItem(pthis->m_ListCtrlLOg.GetItemCount(),str);
	}

	if(nCode == 1)
	{
		if(pthis->m_EditRecPkt.m_hWnd && IsWindow(pthis->m_EditRecPkt.m_hWnd))
			pthis->m_EditRecPkt.SetWindowText(LogMsg);
		//AfxGetApp()->GetMainWnd()->SetWindowText(str);

	}
	


	//pthis->m_EditError.


/*
	CMabnaPardazServerDlg* pthis = (CMabnaPardazServerDlg*) lpParam;
	if(pthis==NULL) return;

	switch (nCode)
	{
	case NC_CLIENT_CONNECT:
		pthis->AddToList(pContext);
		break;
	case NC_CLIENT_DISCONNECT:
		pthis->RemoveFromList(pContext);
		break;
	case NC_TRANSMIT:
		break;
	case NC_RECEIVE:
		pthis->AddMsgtoList(pContext);
		break;

	}
*/
}


void CPeer2PeerDlg::OnButtonDisconnect() 
{
	p2p.DisConnect();
}

void CPeer2PeerDlg::OnCheckFlood() 
{
	m_bFlood = !m_bFlood;
	if (m_bFlood)
	{
		UpdateData(TRUE);
		SetTimer(0, 10, NULL);
	}
	else
	{
		KillTimer(0);
		SendMessageCount = 0;
	}
	
	((CButton *)GetDlgItem(IDC_CHECK_FLOOD))->SetCheck(m_bFlood);

	if(m_bFlood)
		GetMenu()->CheckMenuItem(ID_SOCKET_FLOOD,MF_CHECKED);
	else
		GetMenu()->CheckMenuItem(ID_SOCKET_FLOOD,MF_UNCHECKED);
	
}

void CPeer2PeerDlg::OnButtonSend() 
{
		CString str_send;
		m_EditSendPkt.GetWindowText(str_send);
		p2p.SendData(str_send);
	
}
