//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SimpleChat.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SIMPLECHAT_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_ABOUT                       131
#define IDI_ABOUT                       132
#define IDR_MAINFRAME_OLD               133
#define IDI_ABOUT_OLD                   134
#define IDM_TRAY                        135
#define IDB_ABOUT_OLD                   138
#define IDB_BACK                        140
#define IDRB_CONNECT                    1002
#define IDRB_LISTEN                     1003
#define IDED_ADDRESS                    1005
#define IDC_IPADDRESS                   1006
#define IDED_PORT                       1007
#define IDED_TEXT                       1008
#define IDBT_SEND                       1009
#define IDBT_GO                         1011
#define IDBT_CLEAR                      1012
#define IDBT_DISCONNECT                 1013
#define IDRE_MESSAGES                   1014
#define IDST_NICK_NAME                  1015
#define IDCB_WELCOME_MESSAGE            1017
#define IDCH_USE_THIS                   1018
#define IDST_WELCOME                    1019
#define IDST_GOODBYE                    1021
#define IDCB_GOODBYE_MESSAGE            1022
#define IDCB_NICK_NAME                  1023
#define IDST_CONNECT_STATUS             1025
#define IDBT_CLEAR_CHAT                 1026
#define IDBT_SEND_FILE                  1027
#define IDST_COMPLETE                   1028
#define IDBT_SEND_CANCEL                1028
#define IDC_PROGRESS1                   1029
#define IDC_PROGRESS_RECEIVED           1029
#define IDST_RECEIVED                   1031
#define IDST_PERCENTAGE_RECEIVED        1032
#define IDC_PROGRESS_SENT               1033
#define IDST_SENT                       1035
#define IDST_PERCENTAGE_SENT            1036
#define IDBT_RECEIVE_CANCEL             1037
#define IDBT_RECEIVE_ACCEPT             1038
#define IDBT_RECEIVE_REJECT             1039
#define IDC_QUEUE_SIZE                  1040
#define IDST_SEND                       1041
#define IDST_RECEIVE                    1042
#define IDST_STATUS                     1043
#define IDST_USE_NAMES                  1044
#define IDST_PIN_POINT                  1045
#define IDCH_SHOW_BK                    1047
#define IDM_RESTORE                     32771
#define IDM_EXIT                        32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
