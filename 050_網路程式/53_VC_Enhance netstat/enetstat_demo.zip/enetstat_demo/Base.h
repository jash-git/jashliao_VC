// Base.h: interface for the CBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASE_H__7781CAF1_E76D_11D6_91CB_000039E099AC__INCLUDED_)
#define AFX_BASE_H__7781CAF1_E76D_11D6_91CB_000039E099AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBase  
{
	public:
		CBase();
		virtual ~CBase();
		static DWORD m_dwLastError;
		CString GetProcById(DWORD dwPid);
		CString GetSysPath(void);

	//methods
	private:
		CString GetProcById4NT(DWORD dwPid);
		CString GetProcById4Other(DWORD dwPid);
		int GetSysVer(void);		
};

#endif // !defined(AFX_BASE_H__7781CAF1_E76D_11D6_91CB_000039E099AC__INCLUDED_)
