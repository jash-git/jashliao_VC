// TCPTable.h: interface for the CTCPTable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TCPTABLE_H__79B29239_E26B_11D6_B451_0030052162DB__INCLUDED_)
#define AFX_TCPTABLE_H__79B29239_E26B_11D6_B451_0030052162DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "StdAfx.h"

class CTCPTable  
{
	public:
		CTCPTable();
		virtual ~CTCPTable();

	private:
		//vars
		static MIB_TCPTABLE* m_pTcpTable;
		static MIB_TCPTABLE_EX* m_pTcpTableEx;
		static BYTE* m_pBuff;
		static BYTE* m_pBuffEx;

		TCPTABLE m_tcpTab;

	private:
		//methods
		bool		GetMatchingConn(u_long ulRemAdr, u_short usLocPort, u_long* ulLocAdr, u_short* usRemPort);
		CString		Convert2State(DWORD dwState);
		void		Conn2Console(DWORD dwPid, \
								 CString strProcName, \
								 CString strLocAddress, \
								 u_short usLocalPort, \
								 CString strRemAddress, \
								 u_short usRemotePort);

	public:
		//methods
		DWORD		PrintTable(void);
		DWORD		PrintTableEx(void);
		u_int		GetRecordsNumber(void);		
		TCPTABLE	GetTableAtIndex(int nIndex);
		bool		KillConnection(u_long ulRemIP, u_short usLocalPort);
		
		bool		m_bEstb;
};

#endif // !defined(AFX_TCPTABLE_H__79B29239_E26B_11D6_B451_0030052162DB__INCLUDED_)
