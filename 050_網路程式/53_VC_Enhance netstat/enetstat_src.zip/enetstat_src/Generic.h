// Generic.h: interface for the CGeneric class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GENERIC_H__79B2923B_E26B_11D6_B451_0030052162DB__INCLUDED_)
#define AFX_GENERIC_H__79B2923B_E26B_11D6_B451_0030052162DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGeneric  
{
public:
	CGeneric();
	virtual ~CGeneric();

};

#endif // !defined(AFX_GENERIC_H__79B2923B_E26B_11D6_B451_0030052162DB__INCLUDED_)
