// UDPClass.cpp: implementation of the CUDPClass class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ENetStat.h"
#include "UDPClass.h"
#include "Base.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
//init static members
MIB_UDPTABLE*	 CUDPClass::m_pUdpTable = NULL;
MIB_UDPTABLE_EX* CUDPClass::m_pUdpTableEx = NULL;
BYTE*			 CUDPClass::m_pBuff = NULL;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUDPClass::CUDPClass()
{

}

CUDPClass::~CUDPClass()
{
	delete [] m_pBuff;
}
//////////////////////////////////////////////////////////////////////
//
u_int CUDPClass::GetRecordsNumber()
{
	return 1;
}
//////////////////////////////////////////////////////////////////////
//
UDPTABLE CUDPClass::GetTableAtIndex(int nIndex)
{
	return m_udpTab;
}
//////////////////////////////////////////////////////////////////////
//
DWORD CUDPClass::GetTable(void)
{
	return 1;
}
//////////////////////////////////////////////////////////////////////
//
DWORD CUDPClass::PrintTable(void)
{
	//vars
	DWORD dwSize = 0;
	in_addr stAddr;

		//get the buff size
		 GetUdpTable(NULL, &dwSize, FALSE);

		//alloc buffer
		m_pBuff = new BYTE[dwSize];

		//gathering info
		if (GetUdpTable((PMIB_UDPTABLE)m_pBuff, &dwSize, TRUE) != NO_ERROR)
		{
			TRACE("Error: %d, gathering udp info");
			return GetLastError();
		}
		
		//manage the buffer
		m_pUdpTable = (PMIB_UDPTABLE)m_pBuff;

	//print the info
	printf("\n Proto \tLocal Address \tLocal Port ");
	for (int i = 0; i < m_pUdpTable->dwNumEntries; i++)
	{
		//prepare the local address field
		u_long ulLocalAddress = static_cast<u_long>(m_pUdpTable->table[i].dwLocalAddr);
		stAddr.s_addr = ulLocalAddress;	//stAddr.S_un.S_addr = stAddr.s_addr
		char *strLocAddress = inet_ntoa(stAddr);

		//prepare the local port field
		u_short usLocalPort = ntohs(m_pUdpTable->table[i].dwLocalPort);

		//print info for locals
		printf("\n UDP \t%s \t%u", strLocAddress, usLocalPort);
	}

	return 1;
}
//////////////////////////////////////////////////////////////////////
//
DWORD CUDPClass::PrintTableEx(void)
{
	//vars
	HMODULE hmModule = NULL;
	in_addr stAddr;
	DWORD dwSize = 0;
	CBase *pBase = new CBase();

	//imported method
	pAllocateAndGetUdpExTableFromStack pGetUdpTableEx = NULL;
	
	//prepare the path
	CString strPath = pBase->GetSysPath() + "\\system32\\iphlpapi.dll";
	
	//load "iphlpapi.dll"
	hmModule = ::LoadLibrary(strPath);
	if(hmModule == NULL)
		return ::GetLastError();

	//alloc buff
	PMIB_UDPTABLE_EX m_pBuffUdpTableEx;

	//point to the magic method
	pGetUdpTableEx = (pAllocateAndGetUdpExTableFromStack) GetProcAddress(
		hmModule, "AllocateAndGetUdpExTableFromStack");
	if(pGetUdpTableEx == NULL)
		return ::GetLastError();

	//gathering info
	(pGetUdpTableEx) (&m_pBuffUdpTableEx, TRUE, GetProcessHeap(), 0, 2);

	//print the info
	printf("\n Proto \tPid \tProcess Name \tLocal Address \tLocal Port ");
	for (int i = 0; i < m_pBuffUdpTableEx->dwNumEntries; i++)
	{
		//prepare the local address field
		u_long ulLocalAddress = static_cast<u_long>(m_pBuffUdpTableEx->table[i].dwLocalAddr);
		stAddr.s_addr = ulLocalAddress;	//stAddr.S_un.S_addr = stAddr.s_addr
		char *strLocAddress = inet_ntoa(stAddr);

		//prepare the local port field
		u_short usLocalPort = ntohs(m_pBuffUdpTableEx->table[i].dwLocalPort);

		//prepare the Pid
		DWORD dwPid = m_pBuffUdpTableEx->table[i].dwProcessId;

		//print info for locals
		printf("\n UDP \t%d \t%s  \t%s \t%u", dwPid, pBase->GetProcById(dwPid) ,strLocAddress, usLocalPort);
	}

	if (0 == FreeLibrary(hmModule))
		return ::GetLastError();

	return 1;
}
//////////////////////////////////////////////////////////////////////
//