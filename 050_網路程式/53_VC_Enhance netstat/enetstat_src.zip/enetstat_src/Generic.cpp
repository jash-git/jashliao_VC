// Generic.cpp: implementation of the CGeneric class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ENetStat.h"
#include "Generic.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGeneric::CGeneric()
{

}

CGeneric::~CGeneric()
{

}
