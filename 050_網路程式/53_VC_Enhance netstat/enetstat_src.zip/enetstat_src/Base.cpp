// Base.cpp: implementation of the CBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ENetStat.h"
#include "Base.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//init static members
DWORD CBase::m_dwLastError = 0; //default

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CBase::CBase()
{
}
/////////////////////////////////////////////////////////////////////////
//
CBase::~CBase()
{
}
/////////////////////////////////////////////////////////////////////////
//
CString CBase::GetSysPath(void)
{
	//vars
	char buffPath[MAX_PATH];
	memset(buffPath, '0', sizeof(buffPath));
	
	//get windows path
	//UINT uiPathLen = ::GetSystemWindowsDirectory(buffPath, MAX_PATH+1);
	UINT uiPathLen = ::GetWindowsDirectory(buffPath, MAX_PATH+1);
	if(uiPathLen == 0)
	{
		m_dwLastError = ::GetLastError();
		return "error ";
	}
	
	//prepare the path
	CString strPath = buffPath;
	strPath.TrimRight();
	return strPath;
}
/////////////////////////////////////////////////////////////////////////
//
int CBase::GetSysVer(void)
{
	OSVERSIONINFO stOsVer;
	stOsVer.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	GetVersionEx(&stOsVer);
	if(stOsVer.dwMajorVersion == 4)
		return WIN_NT;	
	else
		return WIN_XX;
}
/////////////////////////////////////////////////////////////////////////
//
CString CBase::GetProcById(DWORD dwPid)
{
	switch(GetSysVer())
	{
		case WIN_NT:
			return GetProcById4NT(dwPid);

		case WIN_XX:
			return GetProcById4Other(dwPid);

		default:
			return "Unknown OS";
	}
}
/////////////////////////////////////////////////////////////////////////
//
CString CBase::GetProcById4Other(DWORD dwPid)
{
	//vars
	HMODULE hmModule = NULL;
	HANDLE hProcSnap = NULL;
	CString strProcName(L"Unknown");
	PROCESSENTRY32 stProc32Entry;
	stProc32Entry.dwSize = sizeof(PROCESSENTRY32);
	CString strPath = GetSysPath() + "\\system32\\kernel32.dll";

	//init imported method
	pCreateToolhelp32Snapshot pToolhelp = NULL;
	pProcess32First pProc32First = NULL;
	pProcess32Next pProc32Next = NULL;

	//load "psapi.dll"
	hmModule = ::LoadLibrary(strPath);
	if(hmModule == NULL)
	{
		m_dwLastError = ::GetLastError();
		return "error ";
	}

	//get address of imported functions
	pToolhelp = (pCreateToolhelp32Snapshot) GetProcAddress(
		hmModule, "CreateToolhelp32Snapshot");
	if(pToolhelp == NULL)
	{
		m_dwLastError = ::GetLastError();
		return "error ";
	}

	pProc32First = (pProcess32First) GetProcAddress(
		hmModule, "Process32First");
	if(pProc32First == NULL)
	{
		m_dwLastError = ::GetLastError();
		return "error ";
	}
	
	pProc32Next = (pProcess32Next) GetProcAddress(
		hmModule, "Process32Next");
	if(pProc32Next == NULL)
	{
		m_dwLastError = ::GetLastError();
		return "error ";
	}

	//get a snapshoot of the running proc
	hProcSnap = pToolhelp(TH32CS_SNAPPROCESS, 0);
	if (hProcSnap == INVALID_HANDLE_VALUE)
	{
		m_dwLastError = ::GetLastError();
		return "error ";
	}	

	//gathering info
	if (FALSE == pProc32First(hProcSnap, &stProc32Entry))
	{
		m_dwLastError = ::GetLastError();
		return "error ";
	}

	if(dwPid == stProc32Entry.th32ProcessID)
	{
		return strProcName = stProc32Entry.szExeFile;
	}
	else
	{
		do
		{
			if (stProc32Entry.th32ProcessID == dwPid)
				return strProcName = stProc32Entry.szExeFile;
		}while(pProc32Next(hProcSnap, &stProc32Entry));
	}
	return strProcName;
}
/////////////////////////////////////////////////////////////////////////
//
CString CBase::GetProcById4NT(DWORD dwPid)
{
	HANDLE hProc = NULL;
	HMODULE hMod = NULL;
	DWORD dwSize2 = 0;
	DWORD dwSize = 0;
	DWORD dwIndex = 0;
	CString strPName (L"");
	char szFileName[MAX_PATH];
	memset(szFileName, 0x00, MAX_PATH);
	LPDWORD lpdwPIDs = NULL;

	//get the correct size for dwSize
	dwSize2 = 256 * sizeof(DWORD);
	do {
		if(lpdwPIDs)
		{
			HeapFree(GetProcessHeap(), 0, lpdwPIDs);
			dwSize2 *= 2;
		}

		lpdwPIDs = (LPDWORD) HeapAlloc(GetProcessHeap(), 0, dwSize2);
		if(lpdwPIDs == NULL)
			break;
		
		if(::EnumProcesses(lpdwPIDs, dwSize2, &dwSize))
			break;

	} while(dwSize == dwSize2);

	//the numbers of proc we get
	dwSize /= sizeof(DWORD);

	//open the process if the security permit
	hProc = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, dwPid);
	if (hProc == NULL)
	{
		m_dwLastError = ::GetLastError();
		return "unknown ";
	}

	//get the exe name proc
	if (FALSE == EnumProcessModules(hProc, &hMod, sizeof(hMod), &dwSize2))
	{
		m_dwLastError = ::GetLastError();
		return "unknown ";
	}

	//get the module name
	DWORD rez =::GetModuleBaseName(hProc, hMod, szFileName, sizeof(szFileName));
	if (rez > 0)
	{
		//clean up
		if(hProc != NULL)
			CloseHandle(hProc);
		if(lpdwPIDs != NULL)
			HeapFree(GetProcessHeap(), 0, lpdwPIDs);

	    //get the result
		strPName = szFileName;
		strPName.TrimLeft();
		return strPName;
	}
	else 
	{
		m_dwLastError = ::GetLastError();
		return "unknown ";
	}
}


