// UDPClass.h: interface for the CUDPClass class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UDPCLASS_H__79B2923A_E26B_11D6_B451_0030052162DB__INCLUDED_)
#define AFX_UDPCLASS_H__79B2923A_E26B_11D6_B451_0030052162DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "StdAfx.h"

class CUDPClass  
{
	public:
		CUDPClass();
		virtual ~CUDPClass();

	private:
		//vars
		static MIB_UDPTABLE* m_pUdpTable;
		static MIB_UDPTABLE_EX* m_pUdpTableEx;
		static BYTE* m_pBuff;
		static BYTE* m_pBuffEx;

		UDPTABLE m_udpTab;

	private:
		//methods
		DWORD		GetTable(void);

	public:
		//methods
		DWORD		PrintTable(void);
		DWORD		PrintTableEx(void);

		u_int		GetRecordsNumber(void);		
		UDPTABLE	GetTableAtIndex(int nIndex);	
};

#endif // !defined(AFX_UDPCLASS_H__79B2923A_E26B_11D6_B451_0030052162DB__INCLUDED_)
