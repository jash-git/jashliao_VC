// DlgIEDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DlgIE.h"
#include "DlgIEDlg.h"
#include <Mshtml.h>		//DHTML ʹ�õ�ͷ�ļ�

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgIEDlg dialog

CDlgIEDlg::CDlgIEDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgIEDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgIEDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDlgIEDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgIEDlg)
	DDX_Control(pDX, IDC_EXPLORER1, m_ie);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgIEDlg, CDialog)
	//{{AFX_MSG_MAP(CDlgIEDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_BN_CLICKED(IDC_MUSIC, OnMusic)
	ON_BN_CLICKED(IDC_WORD, OnWord)
	ON_BN_CLICKED(IDC_PDF, OnPdf)
	ON_BN_CLICKED(IDC_IMAGE, OnImage)
	ON_BN_CLICKED(IDC_PRINT, OnPrint)
	ON_BN_CLICKED(IDC_FORM, OnForm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgIEDlg message handlers

BOOL CDlgIEDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	char szPath[MAX_PATH];
	::GetModuleFileName(AfxGetInstanceHandle(),szPath,sizeof(szPath));
	m_sPath=szPath;		int id=m_sPath.ReverseFind('\\');
	ASSERT(id!=-1);		m_sPath=m_sPath.Left(id);

	OnClear();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDlgIEDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDlgIEDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDlgIEDlg::OnClear() 
{
	m_ie.Navigate("about:blank",NULL,NULL,NULL,NULL);
}

void CDlgIEDlg::OnMusic() 
{
	m_ie.Navigate(m_sPath+"\\music.htm",NULL,NULL,NULL,NULL);	
}

void CDlgIEDlg::OnWord() 
{
	m_ie.Navigate(m_sPath+"\\word.doc",NULL,NULL,NULL,NULL);	
}

void CDlgIEDlg::OnPdf() 
{
	m_ie.Navigate(m_sPath+"\\reader.pdf",NULL,NULL,NULL,NULL);
}

void CDlgIEDlg::OnImage() 
{
	m_ie.Navigate(m_sPath+"\\image.htm",NULL,NULL,NULL,NULL);
}

void CDlgIEDlg::OnPrint() 
{
	m_ie.ExecWB(OLECMDID_PRINT,OLECMDEXECOPT_DONTPROMPTUSER,NULL,NULL);
}
////////////////// �����Ǵ����������룬�����������ύ���Ի��� ////////////////
void CDlgIEDlg::OnForm() 
{
	m_ie.Navigate(m_sPath+"\\form.htm",NULL,NULL,NULL,NULL);	
}

BEGIN_EVENTSINK_MAP(CDlgIEDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CDlgIEDlg)
	ON_EVENT(CDlgIEDlg, IDC_EXPLORER1, 250 /* BeforeNavigate2 */, OnBeforeNavigate2Explorer1, VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PBOOL)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CDlgIEDlg::OnBeforeNavigate2Explorer1(	//�ú�����HTML������ǰ����
		LPDISPATCH pDisp,
		VARIANT FAR* URL,					//׼�������URL���޸�������ʵ��ת��
		VARIANT FAR* Flags,
		VARIANT FAR* TargetFrameName,
		VARIANT FAR* PostData,
		VARIANT FAR* Headers,
		BOOL FAR* Cancel)					//TRUE��ֹͣ FALSE������
{
	CString sURL(URL->bstrVal);
	int id=sURL.ReverseFind('\\');		//�������"\��/"
	if(id==-1)	sURL.ReverseFind('/');

	try
	{
		if(sURL.Mid(id+1).CompareNoCase("ToDialog"))
			throw(0);	//����Ԥ�����URL
		if(((PostData->vt) & (VT_VARIANT | VT_BYREF))==0)
			throw(0);
		VARIANT * v=PostData->pvarVal;
		if(((v->vt) & (VT_UI1 | VT_ARRAY))==0)
			throw(0);
		SAFEARRAY *pArr=v->parray;
		CString sData=(LPCSTR)pArr->pvData;		//���ˣ��õ����͵�������

		////////////// �������Ľṹ //////////////
		// ����1=ֵ1&����2=ֵ2&......����n=ֵn  //
		//////////////////////////////////////////

		CStringArray arrPart;
		while(TRUE)		//���� '&' ���в��
		{
			id=sData.Find('&');
			if(id==-1){	arrPart.Add(sData);	break;	}
			arrPart.Add(sData.Left(id));
			sData=sData.Mid(id+1);
		}
		CString sResult;
		for(int nPart=0;nPart<arrPart.GetSize();nPart++)
		{	//ѭ������ÿ��������=ֵ���Ĳ���
			CString sPart=arrPart.GetAt(nPart);	//ȡ��
			id=sPart.Find('=');
			ASSERT(id!=-1);
			CString sName = sPart.Left(id);		//������
			CString sValue= sPart.Mid(id+1);	//ֵ

			sName = WebStr2Str(sName);		//ת��Web�ַ�������׼�ַ���
			sValue= WebStr2Str(sValue);

			sResult += sName+" = "+sValue+"<br>";
		}
		//////////// ��������ʾʹ��DHTML //////////////
		IHTMLDocument2 *pDoc=(IHTMLDocument2 *)m_ie.GetDocument();
		VARIANT *param;
		SAFEARRAY *sfArray;
		BSTR bstr = sResult.AllocSysString();
		sfArray = SafeArrayCreateVector(VT_VARIANT, 0, 1);
		if(sfArray && pDoc)
		{
			if(S_OK == SafeArrayAccessData(sfArray,(LPVOID*) & param))
			{
				param->vt = VT_BSTR;
				param->bstrVal = bstr;
				SafeArrayUnaccessData(sfArray);
				pDoc->write(sfArray);
			}
			SysFreeString(bstr);
			if (sfArray)	SafeArrayDestroy(sfArray);
		}
		pDoc->Release();

		*Cancel=TRUE;
	}
	catch(...)
	{
		*Cancel=FALSE;
	}
}

CString CDlgIEDlg::WebStr2Str(LPCSTR lpBuf)
{
	int nLen;
	if(!lpBuf)	nLen=0;
	else		nLen=::lstrlen(lpBuf);

	CString s;	int i=0;
	while(i<nLen)
	{
		if(lpBuf[i]=='%')
		{
			BYTE c1=lpBuf[i+1];
			BYTE c2=lpBuf[i+2];
			i+=2;
			if(c1>='0' && c1<='9')		c1=(c1-'0')*16;
			else if(c1>='A' && c1<='Z')	c1=(c1-'A'+10)*16;
			else if(c1>='a' && c1<='a') c1=(c1-'a'+10)*16;
			if(c2>='0' && c2<='9')		c2=c2-'0';
			else if(c2>='A' && c2<='Z')	c2=c2-'A'+10;
			else if(c2>='a' && c2<='z')	c2=c2-'a'+10;

			char szStr[2];	szStr[0]=c1+c2;	szStr[1]=0;
			s+=szStr;
		}
		else if(lpBuf[i]=='+')	s+=" ";
		else s+=CString(&lpBuf[i],1);
		i++;
	}
	return s;
}
