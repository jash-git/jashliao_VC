// DlgIE.h : main header file for the DLGIE application
//

#if !defined(AFX_DLGIE_H__65DAE73B_62C9_45AC_8203_B6CD991FF8FE__INCLUDED_)
#define AFX_DLGIE_H__65DAE73B_62C9_45AC_8203_B6CD991FF8FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDlgIEApp:
// See DlgIE.cpp for the implementation of this class
//

class CDlgIEApp : public CWinApp
{
public:
	CDlgIEApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgIEApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDlgIEApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGIE_H__65DAE73B_62C9_45AC_8203_B6CD991FF8FE__INCLUDED_)
