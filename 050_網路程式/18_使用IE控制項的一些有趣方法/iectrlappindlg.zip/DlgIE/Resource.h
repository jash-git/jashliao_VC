//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DlgIE.rc
//
#define IDD_DLGIE_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDC_EXPLORER1                   1000
#define IDC_MUSIC                       1001
#define IDC_CLEAR                       1002
#define IDC_WORD                        1003
#define IDC_PDF                         1004
#define IDC_FORM                        1005
#define IDC_PRINT                       1006
#define IDC_IMAGE                       1007
#define IDC_TEXT                        1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
