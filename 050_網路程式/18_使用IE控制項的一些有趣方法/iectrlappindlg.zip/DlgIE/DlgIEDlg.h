// DlgIEDlg.h : header file
//
//{{AFX_INCLUDES()
#include "webbrowser2.h"
//}}AFX_INCLUDES

#if !defined(AFX_DLGIEDLG_H__E4107598_E2CE_4770_8428_44AA284828F3__INCLUDED_)
#define AFX_DLGIEDLG_H__E4107598_E2CE_4770_8428_44AA284828F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDlgIEDlg dialog

class CDlgIEDlg : public CDialog
{
// Construction
public:
	CDlgIEDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgIEDlg)
	enum { IDD = IDD_DLGIE_DIALOG };
	CWebBrowser2	m_ie;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgIEDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDlgIEDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClear();
	afx_msg void OnMusic();
	afx_msg void OnWord();
	afx_msg void OnPdf();
	afx_msg void OnImage();
	afx_msg void OnPrint();
	afx_msg void OnForm();
	afx_msg void OnBeforeNavigate2Explorer1(LPDISPATCH pDisp, VARIANT FAR* URL, VARIANT FAR* Flags, VARIANT FAR* TargetFrameName, VARIANT FAR* PostData, VARIANT FAR* Headers, BOOL FAR* Cancel);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_sPath;
	CString WebStr2Str(LPCSTR lpBuf);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGIEDLG_H__E4107598_E2CE_4770_8428_44AA284828F3__INCLUDED_)
