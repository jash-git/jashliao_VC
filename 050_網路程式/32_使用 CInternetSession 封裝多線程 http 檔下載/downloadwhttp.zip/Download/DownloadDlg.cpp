// DownloadDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Download.h"
#include "DownloadDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDownloadDlg dialog

CDownloadDlg::CDownloadDlg(CWnd* pParent /*=NULL*/)
	: MainDlgBase(CDownloadDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDownloadDlg)
	m_strURL = _T("");
	m_strStatus = _T("");
	m_strAverage = _T("");
	m_strCurrent = _T("");
	m_nSelTask = -1;
	m_nDownload = 0;
	m_strTotal = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDownloadDlg::DoDataExchange(CDataExchange* pDX)
{
	MainDlgBase::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDownloadDlg)
	DDX_Control(pDX, IDC_PROGRESS, m_Progress);
	DDX_Text(pDX, IDC_FILE_URL, m_strURL);
	DDX_Text(pDX, IDC_STATUS, m_strStatus);
	DDX_Text(pDX, IDC_AVERAGE_SPEED, m_strAverage);
	DDX_Text(pDX, IDC_CURRENT_SPEED, m_strCurrent);
	DDX_LBIndex(pDX, IDC_TASK_LIST, m_nSelTask);
	DDX_Text(pDX, IDC_DOWNLOAD_BYTE, m_nDownload);
	DDX_Text(pDX, IDC_TOTAL_BYTE, m_strTotal);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDownloadDlg, MainDlgBase)
	//{{AFX_MSG_MAP(CDownloadDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_LBN_SELCHANGE(IDC_TASK_LIST, OnSelchangeTaskList)
	ON_LBN_DBLCLK(IDC_TASK_LIST, OnDblclkTaskList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDownloadDlg message handlers

BOOL CDownloadDlg::OnInitDialog()
{
	MainDlgBase::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_Progress.SetRange (0, 100) ;
	UpdateShowInfo() ;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDownloadDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		MainDlgBase::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDownloadDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		MainDlgBase::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDownloadDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDownloadDlg::OnOK() 
{
    UpdateData() ;
    ((CEdit*)GetDlgItem(IDC_FILE_URL))->SetSel(0,-1) ;
    GetDlgItem(IDC_FILE_URL)->SetFocus() ;
    if (m_strURL.IsEmpty())
        return ;

    if (FindTask(m_strURL))
    {
        AfxMessageBox (_T("The URL task has exist.")) ;
        return ;
    }

    DownloadFile(m_strURL) ;
}

BOOL CDownloadDlg::DownloadFile_OnCheckTime (CString strFileURL, CString strTime)
{
    TaskPack   * p = new TaskPack ;
    p->strURL = strFileURL ;
    m_Task.push_back (p) ;

    CListBox   * pList = (CListBox*)GetDlgItem(IDC_TASK_LIST) ;
    pList->SetCurSel (pList->AddString (strFileURL)) ;
    return TRUE ;
}

void CDownloadDlg::DownloadFile_OnFinished (CString strFileURL, char* pBuffer, int nLength)
{
    TaskPack   * p = FindTask (strFileURL) ;
    p->nDownload = p->nTotal = nLength ;
    p->strStatus = _T("Finished") ;
    p->tickEnd = ::GetTickCount() ;

    ASSERT(!p->pContext) ;
    p->pContext = new BYTE[nLength+8] ;
    ZeroMemory (p->pContext, nLength+8) ;
    CopyMemory (p->pContext, pBuffer, nLength) ;

    UpdateShowInfo() ;
    IMFlashWindow(GetSafeHwnd()) ;
}

void CDownloadDlg::DownloadFile_OnProgress (CString strFileURL, int nNow, int nTotal)
{
    TaskPack   * p = FindTask (strFileURL) ;
    p->nDownDelta = nNow - p->nDownload ;
    p->tickDelta = GetTickCount() - p->tickEnd ;

    p->nDownload = nNow ;
    p->nTotal = nTotal ;
    p->tickEnd = GetTickCount() ;

    UpdateShowInfo() ;
}

void CDownloadDlg::DownloadFile_OnError (CString strFileURL)
{
    TaskPack   * p = FindTask (strFileURL) ;
    if (!p)
        return ;

    p->strStatus = _T("Error") ;
    UpdateShowInfo() ;
}

void CDownloadDlg::OnSelchangeTaskList() 
{
    UpdateShowInfo() ;
}

void CDownloadDlg::UpdateShowInfo()
{
    UpdateData() ;
    if (m_nSelTask == -1)
    {
        m_nDownload = 0 ;
        m_strStatus = m_strCurrent = m_strAverage = _T("---") ;
        m_Progress.SetPos(0) ;
        UpdateData(FALSE) ;
        return ;
    }

    TaskPack   * p = m_Task[m_nSelTask] ;

    // set progress
    int   nPos = 0 ;
    if (p->nTotal)
        nPos = p->nDownload * 100 / p->nTotal ;
    m_Progress.SetPos (nPos) ;

    m_strStatus = p->strStatus ;
    m_nDownload = p->nDownload ;
    if (p->nTotal)
    {
        m_strTotal.Format (_T("%d"), p->nTotal) ;
    }
    else
    {
        m_strTotal = _T("unknown") ;
    }

    if (m_strStatus == _T("Downloading"))
    {
        int   n = p->tickDelta ? (p->nDownDelta / p->tickDelta) : 9999 ;
        m_strCurrent.Format (_T("%d Kb/s"), n) ;
    }
    else
    {
        m_strCurrent = _T("---") ;
    }

    DWORD   dw = (p->tickEnd - p->tickStart) ;
    int     n = dw ? (p->nDownload / dw) : 9999 ;
    m_strAverage.Format (_T("%d Kb/s"), n) ;
    UpdateData(FALSE) ;
}

void CDownloadDlg::OnDblclkTaskList() 
{
    UpdateData() ;
    if (m_nSelTask != -1)
    {
        TaskPack   * p = m_Task[m_nSelTask] ;
        if (p->pContext)
        {
            CFileDialog   dlg (FALSE) ;
            if (dlg.DoModal() == IDOK)
            {
                CFile   outFile (dlg.GetPathName(), CFile::modeCreate|CFile::modeReadWrite) ;
                outFile.Write (p->pContext, p->nTotal) ;
            }
        }
    }
}
