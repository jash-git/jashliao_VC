// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__2D39D853_4A84_45B2_AFA3_8CF705D6BD70__INCLUDED_)
#define AFX_STDAFX_H__2D39D853_4A84_45B2_AFA3_8CF705D6BD70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

inline void WINAPI IMFlashWindow (HWND hWnd)
{
    const FARPROC   pFunc = GetProcAddress (GetModuleHandle(_T("user32.dll")), "FlashWindowEx") ;
    struct
    {
        UINT  cbSize;
        HWND  hwnd;
        DWORD dwFlags;
        UINT  uCount;
        DWORD dwTimeout;
    } flInfo ;
    flInfo.cbSize = sizeof(flInfo) ;
    flInfo.hwnd = hWnd ;
    flInfo.dwFlags = 14 ; // FLASHW_TIMERNOFG|FLASHW_TRAY
    flInfo.uCount = 25 ;
    flInfo.dwTimeout = 666 ;
    const int    nAddressStru = (int)&flInfo ;
    __asm
    {
        push   nAddressStru
        call   pFunc
    }
}

#include "Controller_DownloadFile.h"

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__2D39D853_4A84_45B2_AFA3_8CF705D6BD70__INCLUDED_)
