// DownloadDlg.h : header file
//

#if !defined(AFX_DOWNLOADDLG_H__09AE7F17_01A6_4901_A3C7_28E01505C8A0__INCLUDED_)
#define AFX_DOWNLOADDLG_H__09AE7F17_01A6_4901_A3C7_28E01505C8A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct TaskPack
{
    TaskPack()
    {
        strStatus = _T("Downloading") ;
        tickStart = tickEnd = ::GetTickCount() ;
        tickDelta = 0 ;
        nDownDelta = 0 ;
        nDownload = 0 ;
        nTotal = 0 ;
        pContext = NULL ;
    }
    ~TaskPack()
    {
        if (pContext)
            delete[] pContext ;
    }

    CString strURL ;
    CString strStatus ;
    DWORD   tickStart ;
    DWORD   tickEnd ;
    DWORD   tickDelta ;
    int     nDownDelta ;
    int     nDownload ;
    int     nTotal ;
    BYTE    * pContext ;
};

#define MainDlgBase FCDownloadFileWndBase<CDialog>  

/////////////////////////////////////////////////////////////////////////////
// CDownloadDlg dialog

class CDownloadDlg : public MainDlgBase
{
// Construction
public:
	CDownloadDlg(CWnd* pParent = NULL);	// standard constructor

    ~CDownloadDlg()
    {
        for (size_t i=0 ; i < m_Task.size() ; i++)
            delete m_Task[i] ;
    }

// Dialog Data
	//{{AFX_DATA(CDownloadDlg)
	enum { IDD = IDD_DOWNLOAD_DIALOG };
	CProgressCtrl	m_Progress;
	CString	m_strURL;
	CString	m_strStatus;
	CString	m_strAverage;
	CString	m_strCurrent;
	int		m_nSelTask;
	int		m_nDownload;
	CString	m_strTotal;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDownloadDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
    TaskPack* FindTask (LPCTSTR strURL) const
    {
        for (size_t i=0 ; i < m_Task.size() ; i++)
            if (m_Task[i]->strURL == strURL)
                return m_Task[i] ;
        return NULL ;
    }

    std::deque<TaskPack*>   m_Task ;

	HICON m_hIcon;

    virtual BOOL DownloadFile_OnCheckTime (CString strFileURL, CString strTime) ;
    virtual void DownloadFile_OnFinished (CString strFileURL, char* pBuffer, int nLength) ;
    virtual void DownloadFile_OnProgress (CString strFileURL, int nNow, int nTotal) ;
    virtual void DownloadFile_OnError (CString strFileURL) ;

    void UpdateShowInfo() ;

	// Generated message map functions
	//{{AFX_MSG(CDownloadDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnSelchangeTaskList();
	afx_msg void OnDblclkTaskList();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWNLOADDLG_H__09AE7F17_01A6_4901_A3C7_28E01505C8A0__INCLUDED_)
