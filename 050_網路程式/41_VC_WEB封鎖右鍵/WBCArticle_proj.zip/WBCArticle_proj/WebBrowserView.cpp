// WebBrowserView.cpp : implementation of the CWebBrowserView class
//

#include "stdafx.h"
#include "WebBrowser.h"

#include "WebBrowserDoc.h"
#include "WebBrowserView.h"
#include "WebCtrlInterFace.h"
//#include <mshtmcid.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView

IMPLEMENT_DYNCREATE(CWebBrowserView, CHtmlView)

BEGIN_MESSAGE_MAP(CWebBrowserView, CHtmlView)
	//{{AFX_MSG_MAP(CWebBrowserView)
	ON_COMMAND(ID_CMM_NOCONTEXTMENU, On_CMM_NoContextMenu)
	ON_UPDATE_COMMAND_UI(ID_CMM_NOCONTEXTMENU, OnUpdate_CMM_NoContextMenu)
	ON_COMMAND(ID_CMM_NOVIEWSOURCE, On_CMM_NoViewSource)
	ON_UPDATE_COMMAND_UI(ID_CMM_NOVIEWSOURCE, OnUpdate_CMM_NoViewSource)
	ON_COMMAND(ID_CMM_TEXTSELECTIONMENU, On_CMM_TextSelectionMenu)
	ON_UPDATE_COMMAND_UI(ID_CMM_TEXTSELECTIONMENU, OnUpdate_CMM_TextSelectionMenu)
	ON_COMMAND(ID_CMM_FULLSUPPORT, On_CMM_FullSupport)
	ON_UPDATE_COMMAND_UI(ID_CMM_FULLSUPPORT, OnUpdate_CMM_FullSupport)
	ON_COMMAND(ID_CMM_CUSTOM, On_CMM_CustomMenu)
	ON_UPDATE_COMMAND_UI(ID_CMM_CUSTOM, OnUpdate_CMM_CustomMenu)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CHtmlView::OnFilePrint)
	ON_WM_NCDESTROY()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView construction/destruction

CWebBrowserView::CWebBrowserView()
{
	m_iClientSite = new CWebCtrlInterFace;
	
	if (m_iClientSite != NULL)
		m_iClientSite->AddRef();

	{
		HINSTANCE tstInstance = LoadLibrary(TEXT("SHDOCLC.DLL"));

		m_SHDOCLC_DLL_Found = (tstInstance != NULL);

		if (! m_SHDOCLC_DLL_Found)
		{
			::AfxMessageBox(_T("Cannot Load Library SHDOCLC.DLL.\n"
				"The \"No View Source Choice\" mode will not work."));
		}

		FreeLibrary(tstInstance);
	}
}

CWebBrowserView::~CWebBrowserView()
{
	//m_iClientSite must have been already released
	ASSERT(m_iClientSite == NULL);

	if (m_iClientSite != NULL)
	{
		m_iClientSite->Release();
		m_iClientSite = NULL;
	}
}

BOOL CWebBrowserView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CHtmlView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView drawing

void CWebBrowserView::OnDraw(CDC* pDC)
{
	CWebBrowserDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CWebBrowserView::OnInitialUpdate()
{
IOleObject *pIOleObj = NULL;

	CHtmlView::OnInitialUpdate();

	if (m_iClientSite != NULL)
	{
		if (m_pBrowserApp != NULL)
			m_pBrowserApp->QueryInterface(IID_IOleObject, (void**)&pIOleObj);

		if (pIOleObj != NULL)
		{
		IOleClientSite *oldClientSite = NULL;

			if (pIOleObj->GetClientSite(&oldClientSite) == S_OK)
			{
				m_iClientSite->SetDefaultClientSite(oldClientSite);
				oldClientSite->Release();
			}

			pIOleObj->SetClientSite(m_iClientSite);
		}
	}

	Navigate2(_T("http://www.codeproject.com/") ,NULL,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView printing


/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView diagnostics
 
#ifdef _DEBUG
void CWebBrowserView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CWebBrowserView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CWebBrowserDoc* CWebBrowserView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWebBrowserDoc)));
	return (CWebBrowserDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView message handlers

void CWebBrowserView::OnUpdate_CMM_FullSupport(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		if (m_iClientSite != NULL)
		{
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(m_iClientSite->GetContextMenuMode() == kDefaultMenuSupport);
		}
		else
		{
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
}

void CWebBrowserView::OnUpdate_CMM_NoContextMenu(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		if (m_iClientSite != NULL)
		{
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(m_iClientSite->GetContextMenuMode() == kNoContextMenu);
		}
		else
		{
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
}

void CWebBrowserView::OnUpdate_CMM_TextSelectionMenu(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		if (m_iClientSite != NULL)
		{
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(m_iClientSite->GetContextMenuMode() == kTextSelectionOnly);
		}
		else
		{
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
}

void CWebBrowserView::OnUpdate_CMM_NoViewSource(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		if ( (m_iClientSite != NULL) && m_SHDOCLC_DLL_Found)
		{
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(m_iClientSite->GetContextMenuMode() == kAllowAllButViewSource);
		}
		else
		{
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
}

void CWebBrowserView::OnUpdate_CMM_CustomMenu(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		if (m_iClientSite != NULL)
		{
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(m_iClientSite->GetContextMenuMode() == kCustomMenuSupport);
		}
		else
		{
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
}

//---------------------------------------------------------------------------

void CWebBrowserView::On_CMM_FullSupport() 
{
	if (m_iClientSite != NULL)
		m_iClientSite->SetContextMenuMode(kDefaultMenuSupport);
}

void CWebBrowserView::On_CMM_NoContextMenu() 
{
	if (m_iClientSite != NULL)
		m_iClientSite->SetContextMenuMode(kNoContextMenu);
}

void CWebBrowserView::On_CMM_TextSelectionMenu() 
{
	if (m_iClientSite != NULL)
		m_iClientSite->SetContextMenuMode(kTextSelectionOnly);
}

void CWebBrowserView::On_CMM_NoViewSource() 
{
	if (m_iClientSite != NULL)
		m_iClientSite->SetContextMenuMode(kAllowAllButViewSource);
}

void CWebBrowserView::On_CMM_CustomMenu() 
{
	if (m_iClientSite != NULL)
		m_iClientSite->SetContextMenuMode(kCustomMenuSupport);
}

void CWebBrowserView::OnNcDestroy()
{
	if (m_iClientSite != NULL)
	{
		m_iClientSite->Release();
		m_iClientSite = NULL;
	}

	CHtmlView::OnNcDestroy();
}
