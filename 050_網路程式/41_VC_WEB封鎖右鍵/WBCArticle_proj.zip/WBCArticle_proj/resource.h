//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WebBrowser.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_WEBBROTYPE                  129
#define IDR_CUSTOM_POPUP                130
#define ID_CMM_NOCONTEXTMENU            32771
#define ID_CMM_TEXTSELECTIONMENU        32772
#define ID_CMM_NOVIEWSOURCE             32773
#define ID_CMM_FULLSUPPORT              32774
#define ID_CMM_CUSTOM                   32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
