// WebCtrlInterFace.h: interface for the CWebCtrlInterFace class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WEBCTRLINTERFACE_H__3170A5B8_8021_4DDD_92B2_46BD14F3FAE7__INCLUDED_)
#define AFX_WEBCTRLINTERFACE_H__3170A5B8_8021_4DDD_92B2_46BD14F3FAE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <mshtmhst.h>

enum WebContextMenuMode
{
	kDefaultMenuSupport = 0,
	kNoContextMenu,
	kTextSelectionOnly,
	kAllowAllButViewSource,
	kCustomMenuSupport,
	kWebContextMenuModeLimit
};

class CWebCtrlInterFace : public IOleClientSite, public IDocHostUIHandler
{
public:
	CWebCtrlInterFace();
	virtual ~CWebCtrlInterFace();

	VOID SetDefaultClientSite(IOleClientSite *pClientSite);
	IOleClientSite *GetDefaultClientSite()
				{ return m_defaultClientSite; }
	IDocHostUIHandler *GetDefaultDocHostUIHandler()
				{ return m_defaultDocHostUIHandler; }
	ULONG GetContextMenuMode()
				{ return m_contextMenuMode; }

	VOID SetContextMenuMode(ULONG inMode);

// *** IUnknown ***
	STDMETHOD(QueryInterface)(
		/* [in] */ REFIID riid,
		/* [iid_is][out] */ VOID **ppvObject);

	STDMETHOD_(ULONG, AddRef)();
	STDMETHOD_(ULONG, Release)();

// *** IOleClientSite ***        
	STDMETHOD(SaveObject)();
	STDMETHOD(GetMoniker)(
		/* [in] */ DWORD dwAssign,
		/* [in] */ DWORD dwWhichMoniker,
		/* [out] */ IMoniker **ppmk);

	STDMETHOD(GetContainer)(
		/* [out] */ IOleContainer **ppContainer);

	STDMETHOD(ShowObject)();
	STDMETHOD(OnShowWindow)(
		/* [in] */ BOOL fShow);

	STDMETHOD(RequestNewObjectLayout)();

// *** IDocHostUIHandler ***

STDMETHOD(ShowContextMenu)( 
    /* [in] */ DWORD dwID,
    /* [in] */ POINT *ppt,
    /* [in] */ IUnknown *pcmdtReserved,
    /* [in] */ IDispatch *pdispReserved);
STDMETHOD(GetHostInfo)( 
    /* [out][in] */ DOCHOSTUIINFO *pInfo);
STDMETHOD(ShowUI)( 
    /* [in] */ DWORD dwID,
    /* [in] */ IOleInPlaceActiveObject *pActiveObject,
    /* [in] */ IOleCommandTarget *pCommandTarget,
    /* [in] */ IOleInPlaceFrame *pFrame,
    /* [in] */ IOleInPlaceUIWindow *pDoc);
STDMETHOD(HideUI)();
STDMETHOD(UpdateUI)();
STDMETHOD(EnableModeless)( 
    /* [in] */ BOOL fEnable);
STDMETHOD(OnDocWindowActivate)( 
    /* [in] */ BOOL fActivate);
STDMETHOD(OnFrameWindowActivate)( 
    /* [in] */ BOOL fActivate);
STDMETHOD(ResizeBorder)( 
    /* [in] */ LPCRECT prcBorder,
    /* [in] */ IOleInPlaceUIWindow *pUIWindow,
    /* [in] */ BOOL fRameWindow);
STDMETHOD(TranslateAccelerator)( 
    /* [in] */ LPMSG lpMsg,
    /* [in] */ const GUID *pguidCmdGroup,
    /* [in] */ DWORD nCmdID);
STDMETHOD(GetOptionKeyPath)( 
    /* [out] */ LPOLESTR *pchKey,
    /* [in] */ DWORD dw);
STDMETHOD(GetDropTarget)( 
    /* [in] */ IDropTarget *pDropTarget,
    /* [out] */ IDropTarget **ppDropTarget);
STDMETHOD(GetExternal)( 
    /* [out] */ IDispatch **ppDispatch);
STDMETHOD(TranslateUrl)( 
    /* [in] */ DWORD dwTranslate,
    /* [in] */ OLECHAR *pchURLIn,
    /* [out] */ OLECHAR **ppchURLOut);
STDMETHOD(FilterDataObject)( 
    /* [in] */ IDataObject *pDO,
    /* [out] */ IDataObject **ppDORet);

private:
	LONG				m_cRef;
	ULONG				m_contextMenuMode;
	IOleClientSite		*m_defaultClientSite;
	IDocHostUIHandler	*m_defaultDocHostUIHandler;
};

#endif // !defined(AFX_WEBCTRLINTERFACE_H__3170A5B8_8021_4DDD_92B2_46BD14F3FAE7__INCLUDED_)
