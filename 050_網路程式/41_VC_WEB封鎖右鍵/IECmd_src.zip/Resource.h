//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DEMOTYPE                    129
#define ID_IE_FILE_SAVEAS               258
#define ID_IE_FILE_PAGESETUP            259
#define ID_IE_FILE_PRINT                260
#define ID_IE_FILE_NEWWINDOW            275
#define ID_IE_FILE_PRINTPREVIEW         277
#define ID_IE_FILE_NEWMAIL              279
#define ID_IE_FILE_SENDPAGE             282
#define ID_IE_FILE_SENDLINK             283
#define ID_IE_FILE_SENDDESKTOPSHORTCUT  284
#define ID_IE_HELP_ABOUTIE		        336
#define ID_IE_HELP_HELPINDEX            337
#define ID_IE_HELP_WEBTUTORIAL          338
#define ID_IE_HELP_FREESTUFF            341
#define ID_IE_HELP_PRODUCTUPDATE        342
#define ID_IE_HELP_FAQ                  343
#define ID_IE_HELP_ONLINESUPPORT        344
#define ID_IE_HELP_FEEDBACK             345
#define ID_IE_HELP_BESTPAGE             346
#define ID_IE_HELP_SEARCHWEB            347
#define ID_IE_HELP_MSHOME               348
#define ID_IE_HELP_VISITINTERNET        349
#define ID_IE_HELP_STARTPAGE            350
#define ID_IE_HELP_NETSCAPEUSER         351
#define ID_IE_FILE_IMPORTEXPORT         374
#define ID_IE_HELP_ENHANCEDSECURITY     375
#define ID_IE_FILE_ADDTRUST             376
#define ID_IE_FILE_ADDLOCAL             377
#define ID_IE_FILE_NEWPUBLISHINFO       387
#define ID_IE_FILE_NEWPEOPLE            390
#define ID_IE_FILE_NEWCALL              395
#define ID_IE_CONTEXTMENU_VIEWSOURCE    2139
#define ID_IE_CONTEXTMENU_ADDFAV        2261
#define ID_IE_CONTEXTMENU_REFRESH       6042
#define ID_FILE_SAVEAS                  32771
#define ID_FILE_PAGESETUP               32772
#define ID_FILE_IMPORTEXPORT            32774
#define ID_FAV_ADDTOFAV                 32775
#define ID_FILE_PRINTPREVIEW            32776
#define ID_EDIT_REFRESH                 32777
#define ID_VIEW_REFRESH                 32777
#define ID_VIEW_VIEWSOURCE              32778
#define ID_FILE_NEWIE                   32779
#define ID_FILE_NEWMAIL                 32780
#define ID_FILE_NEWINTERNETCALL         32781
#define ID_FILE_ADDTRUST                32782
#define ID_FILE_ADDLOCAL                32783
#define ID_HELP_ABOUTIE                 32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
