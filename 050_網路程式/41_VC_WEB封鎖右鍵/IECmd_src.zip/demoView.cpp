// demoView.cpp : implementation of the CDemoView class
//

#include "stdafx.h"
#include "demo.h"

#include "demoDoc.h"
#include "demoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2003
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio .NET on Windows XP. Tab size=3.
//
// ---
// This class encapsulates the process of finding a window with a given class name
// as a descendant of a given window. To use it, instantiate like so:
//
//		CFindWnd fw(hwndParent,classname);
//
// fw.m_hWnd will be the HWND of the desired window, if found.
//
class CFindWnd {
private:
	//////////////////
	// This private function is used with EnumChildWindows to find the child
	// with a given class name. Returns FALSE if found (to stop enumerating).
	//
	static BOOL CALLBACK FindChildClassHwnd(HWND hwndParent, LPARAM lParam) {
		CFindWnd *pfw = (CFindWnd*)lParam;
		HWND hwnd = FindWindowEx(hwndParent, NULL, pfw->m_classname, NULL);
		if (hwnd) {
			pfw->m_hWnd = hwnd;	// found: save it
			return FALSE;			// stop enumerating
		}
		EnumChildWindows(hwndParent, FindChildClassHwnd, lParam); // recurse
		return TRUE;				// keep looking
	}

public:
	LPCSTR m_classname;			// class name to look for
	HWND m_hWnd;					// HWND if found

	// ctor does the work--just instantiate and go
	CFindWnd(HWND hwndParent, LPCSTR classname)
		: m_hWnd(NULL), m_classname(classname)
	{
		FindChildClassHwnd(hwndParent, (LPARAM)this);
	}
};

/////////////////////////////////////////////////////////////////////////////
// CDemoView

IMPLEMENT_DYNCREATE(CDemoView, CHtmlView)

BEGIN_MESSAGE_MAP(CDemoView, CHtmlView)
	//{{AFX_MSG_MAP(CDemoView)
	ON_COMMAND(ID_FILE_SAVEAS, OnFileSaveas)
	ON_COMMAND(ID_FILE_PAGESETUP, OnFilePagesetup)
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINTPREVIEW, OnFilePrintpreview)
	ON_COMMAND(ID_FAV_ADDTOFAV, OnFavAddtofav)
	ON_COMMAND(ID_FILE_NEWIE, OnFileNewie)
	ON_COMMAND(ID_FILE_NEWMAIL, OnFileNewmail)
	ON_COMMAND(ID_FILE_NEWINTERNETCALL, OnFileNewinternetcall)
	ON_COMMAND(ID_HELP_ABOUTIE, OnHelpAboutie)
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	ON_COMMAND(ID_VIEW_VIEWSOURCE, OnViewViewsource)
	ON_COMMAND(ID_FILE_ADDTRUST, OnFileAddtrust)
	ON_COMMAND(ID_FILE_ADDLOCAL, OnFileAddlocal)
	ON_COMMAND(ID_FILE_IMPORTEXPORT, OnFileImportexport)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CHtmlView::OnFilePrint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoView construction/destruction

CDemoView::CDemoView()
{
	// TODO: add construction code here

}

CDemoView::~CDemoView()
{
}

BOOL CDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CHtmlView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDemoView drawing

void CDemoView::OnDraw(CDC* pDC)
{
	CDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CDemoView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();

	// TODO: This code navigates to a popular spot on the web.
	//  change the code to go where you'd like.
	Navigate2(_T("http://www.codeproject.com"),NULL,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CDemoView printing


/////////////////////////////////////////////////////////////////////////////
// CDemoView diagnostics

#ifdef _DEBUG
void CDemoView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CDemoView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CDemoDoc* CDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDemoDoc)));
	return (CDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDemoView message handlers

void CDemoView::InvokeShellDocObjCommand(int nID)
{
	CFindWnd FindIEWnd( m_wndBrowser.m_hWnd, "Shell DocObject View");
	::SendMessage( FindIEWnd.m_hWnd, WM_COMMAND, MAKEWPARAM(LOWORD(nID), 0x0), 0 );
}

void CDemoView::InvokeIEServerCommand(int nID)
{
	CFindWnd FindIEWnd( m_wndBrowser.m_hWnd, "Internet Explorer_Server");
	::SendMessage( FindIEWnd.m_hWnd, WM_COMMAND, MAKEWPARAM(LOWORD(nID), 0x0), 0 );
}

void CDemoView::OnFileSaveas() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_SAVEAS);
}

void CDemoView::OnFilePagesetup() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_PAGESETUP);
}

void CDemoView::OnFilePrint() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_PRINT);
}

void CDemoView::OnFilePrintpreview() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_PRINTPREVIEW);
}

void CDemoView::OnFileNewie() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_NEWWINDOW);
}

void CDemoView::OnFileNewmail() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_NEWMAIL);
}

void CDemoView::OnFileNewinternetcall() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_NEWCALL);
}

void CDemoView::OnHelpAboutie() 
{
	InvokeShellDocObjCommand(ID_IE_HELP_ABOUTIE);
}

void CDemoView::OnViewRefresh() 
{
	InvokeIEServerCommand(ID_IE_CONTEXTMENU_REFRESH);
}

void CDemoView::OnViewViewsource() 
{
	InvokeIEServerCommand(ID_IE_CONTEXTMENU_VIEWSOURCE);
}

void CDemoView::OnFavAddtofav() 
{
	InvokeIEServerCommand(ID_IE_CONTEXTMENU_ADDFAV);
}

void CDemoView::OnFileAddtrust() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_ADDTRUST);
}

void CDemoView::OnFileAddlocal() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_ADDLOCAL);
}

void CDemoView::OnFileImportexport() 
{
	InvokeShellDocObjCommand(ID_IE_FILE_IMPORTEXPORT);
}
