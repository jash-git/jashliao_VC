// WebBrowserView.h : interface of the CWebBrowserView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WEBBROWSERVIEW_H__2AAC70ED_5757_4FC2_B818_CC83E07E7904__INCLUDED_)
#define AFX_WEBBROWSERVIEW_H__2AAC70ED_5757_4FC2_B818_CC83E07E7904__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CWebBrowserView : public CHtmlView
{
protected: // create from serialization only
	CWebBrowserView();
	DECLARE_DYNCREATE(CWebBrowserView)

// Attributes
public:
	CWebBrowserDoc* GetDocument();

#ifndef USE_MFC7_HTMLVIEW_FEATURES
#if _MFC_VER >= 0x0700
	virtual BOOL CreateControlSite(COleControlContainer* pContainer, 
	   COleControlSite** ppSite, UINT nID, REFCLSID clsid);
#endif
#endif

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWebBrowserView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	BOOL					m_SHDOCLC_DLL_Found;
	ULONG					m_WebContextMenuMode;

// Generated message map functions
protected:
	//{{AFX_MSG(CWebBrowserView)
	afx_msg void On_CMM_NoContextMenu();
	afx_msg void OnUpdate_CMM_NoContextMenu(CCmdUI* pCmdUI);
	afx_msg void On_CMM_NoViewSource();
	afx_msg void OnUpdate_CMM_NoViewSource(CCmdUI* pCmdUI);
	afx_msg void On_CMM_TextSelectionMenu();
	afx_msg void OnUpdate_CMM_TextSelectionMenu(CCmdUI* pCmdUI);
	afx_msg void On_CMM_FullSupport();
	afx_msg void OnUpdate_CMM_FullSupport(CCmdUI* pCmdUI);
	afx_msg void On_CMM_CustomMenu();
	afx_msg void OnUpdate_CMM_CustomMenu(CCmdUI* pCmdUI);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

#ifdef USE_MFC7_HTMLVIEW_FEATURES

#if _MFC_VER >= 0x0700
	virtual HRESULT OnShowContextMenu(DWORD dwID, LPPOINT ppt,
					LPUNKNOWN pcmdtReserved, LPDISPATCH pdispReserved);
#endif

#else
	afx_msg LRESULT OnCustomControlSiteMsg(WPARAM wParam, LPARAM lParam);
#endif

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
};

#ifndef _DEBUG  // debug version in WebBrowserView.cpp
inline CWebBrowserDoc* CWebBrowserView::GetDocument()
   { return (CWebBrowserDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WEBBROWSERVIEW_H__2AAC70ED_5757_4FC2_B818_CC83E07E7904__INCLUDED_)
