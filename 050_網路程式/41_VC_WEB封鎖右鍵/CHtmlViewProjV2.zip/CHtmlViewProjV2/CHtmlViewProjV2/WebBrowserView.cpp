// WebBrowserView.cpp : implementation of the CWebBrowserView class
//

#include "stdafx.h"
#include "WebBrowser.h"

#include "WebBrowserDoc.h"
#include "WebBrowserView.h"
#include "CustomMenus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView

#ifndef USE_MFC7_HTMLVIEW_FEATURES
const UINT WM_CUSTOM_CONTROLSITE_MSG  = RegisterWindowMessage(_T("CustomControlSiteMsg"));
#endif

IMPLEMENT_DYNCREATE(CWebBrowserView, CHtmlView)

BEGIN_MESSAGE_MAP(CWebBrowserView, CHtmlView)
	//{{AFX_MSG_MAP(CWebBrowserView)
	ON_COMMAND(ID_CMM_NOCONTEXTMENU, On_CMM_NoContextMenu)
	ON_UPDATE_COMMAND_UI(ID_CMM_NOCONTEXTMENU, OnUpdate_CMM_NoContextMenu)
	ON_COMMAND(ID_CMM_NOVIEWSOURCE, On_CMM_NoViewSource)
	ON_UPDATE_COMMAND_UI(ID_CMM_NOVIEWSOURCE, OnUpdate_CMM_NoViewSource)
	ON_COMMAND(ID_CMM_TEXTSELECTIONMENU, On_CMM_TextSelectionMenu)
	ON_UPDATE_COMMAND_UI(ID_CMM_TEXTSELECTIONMENU, OnUpdate_CMM_TextSelectionMenu)
	ON_COMMAND(ID_CMM_FULLSUPPORT, On_CMM_FullSupport)
	ON_UPDATE_COMMAND_UI(ID_CMM_FULLSUPPORT, OnUpdate_CMM_FullSupport)
	ON_COMMAND(ID_CMM_CUSTOM, On_CMM_CustomMenu)
	ON_UPDATE_COMMAND_UI(ID_CMM_CUSTOM, OnUpdate_CMM_CustomMenu)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CHtmlView::OnFilePrint)

#ifndef USE_MFC7_HTMLVIEW_FEATURES
	ON_REGISTERED_MESSAGE( WM_CUSTOM_CONTROLSITE_MSG, OnCustomControlSiteMsg)
#endif

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView construction/destruction

CWebBrowserView::CWebBrowserView()
{
	m_WebContextMenuMode = kDefaultMenuSupport;

	{
		HINSTANCE tstInstance = LoadLibrary(TEXT("SHDOCLC.DLL"));

		m_SHDOCLC_DLL_Found = (tstInstance != NULL);

		if (! m_SHDOCLC_DLL_Found)
		{
			::AfxMessageBox(_T("Cannot Load Library SHDOCLC.DLL.\n"
				"The \"No View Source Choice\" mode will not work."));
		}

		FreeLibrary(tstInstance);
	}
}

BOOL CWebBrowserView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CHtmlView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView drawing

void CWebBrowserView::OnDraw(CDC* pDC)
{
	CWebBrowserDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CWebBrowserView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();

	Navigate2(_T("http://www.codeproject.com/") ,NULL,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView printing


/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView diagnostics
 
#ifdef _DEBUG
void CWebBrowserView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CWebBrowserView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CWebBrowserDoc* CWebBrowserView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWebBrowserDoc)));
	return (CWebBrowserDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserView message handlers

void CWebBrowserView::OnUpdate_CMM_FullSupport(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(m_WebContextMenuMode == kDefaultMenuSupport);
	}
}

void CWebBrowserView::OnUpdate_CMM_NoContextMenu(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(m_WebContextMenuMode == kNoContextMenu);
	}
}

void CWebBrowserView::OnUpdate_CMM_TextSelectionMenu(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(m_WebContextMenuMode == kTextSelectionOnly);
	}
}

void CWebBrowserView::OnUpdate_CMM_NoViewSource(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		if ( m_SHDOCLC_DLL_Found )
		{
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(m_WebContextMenuMode == kAllowAllButViewSource);
		}
		else
		{
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
}

void CWebBrowserView::OnUpdate_CMM_CustomMenu(CCmdUI* pCmdUI) 
{
	if (pCmdUI != NULL)
	{
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(m_WebContextMenuMode == kCustomMenuSupport);
	}
}

//---------------------------------------------------------------------------

void CWebBrowserView::On_CMM_FullSupport() 
{
	m_WebContextMenuMode = kDefaultMenuSupport;
}

void CWebBrowserView::On_CMM_NoContextMenu() 
{
	m_WebContextMenuMode = kNoContextMenu;
}

void CWebBrowserView::On_CMM_TextSelectionMenu() 
{
	m_WebContextMenuMode = kTextSelectionOnly;
}

void CWebBrowserView::On_CMM_NoViewSource() 
{
	m_WebContextMenuMode = kAllowAllButViewSource;
}

void CWebBrowserView::On_CMM_CustomMenu() 
{
	m_WebContextMenuMode = kCustomMenuSupport;
}

BOOL CWebBrowserView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	//return CHtmlView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	//CHtmlView::Create() calls AfxEnableControlContainer() internally and alters our customization.
	//To avoid this we copy here all the CHtmlView::Create() implementation and then we comment-out the
	//AfxEnableControlContainer() call.

// create the view window itself
	m_pCreateContext = pContext;
	if (!CView::Create(lpszClassName, lpszWindowName,
				dwStyle, rect, pParentWnd,  nID, pContext))
	{
		return FALSE;
	}

	// assure that control containment is on
	//AfxEnableControlContainer(); // <- this alters our customization.

	RECT rectClient;
	GetClientRect(&rectClient);

	// create the control window
	// AFX_IDW_PANE_FIRST is a safe but arbitrary ID
	if (!m_wndBrowser.CreateControl(CLSID_WebBrowser, lpszWindowName,
				WS_VISIBLE | WS_CHILD, rectClient, this, AFX_IDW_PANE_FIRST))
	{
		DestroyWindow();
		return FALSE;
	}

	LPUNKNOWN lpUnk = m_wndBrowser.GetControlUnknown();
	HRESULT hr = lpUnk->QueryInterface(IID_IWebBrowser2, (void**) &m_pBrowserApp);
	if (!SUCCEEDED(hr))
	{
		m_pBrowserApp = NULL;
		m_wndBrowser.DestroyWindow();
		DestroyWindow();
		return FALSE;
	}

	return TRUE;
}

#ifdef USE_MFC7_HTMLVIEW_FEATURES

#if _MFC_VER >= 0x0700

HRESULT CWebBrowserView::OnShowContextMenu(DWORD dwID, LPPOINT ppt,
					LPUNKNOWN pcmdtReserved, LPDISPATCH pdispReserved)
{
	return CustomShowContextMenu(m_WebContextMenuMode, dwID, ppt,
											pcmdtReserved, pdispReserved);
}

#endif //#if _MFC_VER >= 0x0700

#else //#ifdef USE_MFC7_HTMLVIEW_FEATURES

#if _MFC_VER >= 0x0700

BOOL CWebBrowserView::CreateControlSite(COleControlContainer * pContainer,
										 COleControlSite ** ppSite,
										 UINT nID,
										 REFCLSID clsid)
{
	//return CHtmlView::CreateControlSite(pContainer, ppSite, nID, clsid);
	return CWnd::CreateControlSite(pContainer, ppSite, nID, clsid);
}

#endif //#if _MFC_VER >= 0x0700

LRESULT CWebBrowserView::OnCustomControlSiteMsg(WPARAM wParam, LPARAM lParam)
{
LRESULT hasBeenHandled = FALSE;

	ASSERT((wParam > kCCSN_NoMessage) && (wParam < kCCSN_MessageLimit));

	switch (wParam)
	{
	case kCCSN_CreateSite:

		if (lParam != NULL)
		{
			kCCSN_CreateSiteParams *params = (kCCSN_CreateSiteParams *)lParam;

			if (params->pCtrlCont != NULL)
			{
				params->pSite = new CCustomControlSite(params->pCtrlCont);
				hasBeenHandled = TRUE;
			}
		}

		break;

	case kCCSN_ShowContextMenu:

		if (lParam != NULL)
		{
			kCCSN_ShowContextMenuParams *params = (kCCSN_ShowContextMenuParams *)lParam;

			params->result = CustomShowContextMenu(m_WebContextMenuMode, params->dwID,
						params->pptPosition, params->pCommandTarget, params->pDispatchObjectHit);

			hasBeenHandled = TRUE;
		}

		break;
	}

	return hasBeenHandled;
}

#endif //#ifdef USE_MFC7_HTMLVIEW_FEATURES
