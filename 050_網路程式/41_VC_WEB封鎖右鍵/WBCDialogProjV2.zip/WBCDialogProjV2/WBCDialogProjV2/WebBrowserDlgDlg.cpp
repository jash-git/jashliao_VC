// WebBrowserDlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WebBrowserDlg.h"
#include "WebBrowserDlgDlg.h"

#include "CustomMenus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserDlgDlg dialog

CWebBrowserDlgDlg::CWebBrowserDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWebBrowserDlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWebBrowserDlgDlg)
	m_MenuMode = -1;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_MenuMode = 0;
}

void CWebBrowserDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWebBrowserDlgDlg)
	DDX_CBIndex(pDX, IDC_MENU_MODE, m_MenuMode);
	DDX_Control(pDX, IDC_EXPLORER1, m_WebBrowser);
	//}}AFX_DATA_MAP
}

const UINT WM_CUSTOM_CONTROLSITE_MSG  = RegisterWindowMessage(_T("CustomControlSiteMsg"));

BEGIN_MESSAGE_MAP(CWebBrowserDlgDlg, CDialog)
	//{{AFX_MSG_MAP(CWebBrowserDlgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_MENU_MODE, OnSelchangeMenuMode)
	//}}AFX_MSG_MAP

	ON_REGISTERED_MESSAGE( WM_CUSTOM_CONTROLSITE_MSG, OnCustomControlSiteMsg)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebBrowserDlgDlg message handlers

BOOL CWebBrowserDlgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	ASSERT(m_WebBrowser.m_hWnd != NULL);

	if ( m_WebBrowser.m_hWnd != NULL )
		m_WebBrowser.Navigate("www.codeproject.com", NULL, NULL, NULL, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWebBrowserDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWebBrowserDlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWebBrowserDlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CWebBrowserDlgDlg::OnSelchangeMenuMode() 
{
	//We need m_MenuMode to always reflect the current state of the comboBox
	this->UpdateData(TRUE);
}

LRESULT CWebBrowserDlgDlg::OnCustomControlSiteMsg(WPARAM wParam, LPARAM lParam)
{
LRESULT hasBeenHandled = FALSE;

	ASSERT((wParam > kCCSN_NoMessage) && (wParam < kCCSN_MessageLimit));

	switch (wParam)
	{
	case kCCSN_CreateSite:

		if (lParam != NULL)
		{
			kCCSN_CreateSiteParams *params = (kCCSN_CreateSiteParams *)lParam;

			if (params->pCtrlCont != NULL)
			{
				params->pSite = new CCustomControlSite(params->pCtrlCont);
				hasBeenHandled = TRUE;
			}
		}

		break;

	case kCCSN_ShowContextMenu:

		if (lParam != NULL)
		{
		WebContextMenuMode menuModeMap[] = {kDefaultMenuSupport, kNoContextMenu, 
					kTextSelectionOnly, kAllowAllButViewSource, kCustomMenuSupport};
		
			WebContextMenuMode	menuMode = kDefaultMenuSupport;

			if ( (m_MenuMode > 0) && (m_MenuMode < sizeof menuModeMap) )
				menuMode = menuModeMap[m_MenuMode];

			kCCSN_ShowContextMenuParams *params = (kCCSN_ShowContextMenuParams *)lParam;

			params->result = CustomShowContextMenu(menuMode, params->dwID, params->pptPosition, 
						params->pCommandTarget, params->pDispatchObjectHit);

			hasBeenHandled = TRUE;
		}

		break;
	}

	return hasBeenHandled;
}
