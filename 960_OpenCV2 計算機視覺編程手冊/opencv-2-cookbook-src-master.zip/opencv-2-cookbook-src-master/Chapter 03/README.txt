This directory contains material supporting chapter 3 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
by Robert Laganiere, Packt Publishing, 2011.

Files:
	colorDetection.h
	colorDetection.cpp
	colordetector.cpp
correspond to Recipe:
Using the Strategy Pattern in Algorithm Design

Files:
	colorDetectContoller.h
	colorDetectContoller.cpp
correspond to Recipes:
Using the Controller Pattern to Communicate with Processing Modules
Using the Singleton Design Pattern

Directory:
	color_detector
correspond to Recipes:
Using the Model-View-Controller Pattern to Design an Application
Converting Color Spaces
