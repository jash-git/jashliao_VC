This directory contains material supporting chapter 10 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
by Robert Laganiere, Packt Publishing, 2011.

Files:
	videoprocessing.cpp
        videoprocessor.h
correspond to Recipes:
Reading Video Sequences
Processing the Video Frames
Writing Video Sequences

Files:
	featuretracker.h
	tracking.cpp
correspond to Recipe:
Tracking Feature Points in Video

Files:
	BGFGSegmentor.h
	foreground.cpp
correspond to Recipe:
Extracting the Foreground Objects in Video
