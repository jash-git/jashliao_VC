This directory contains material supporting chapter 1 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
by Robert Laganiere, Packt Publishing, 2011.


File:
	main1.cpp
correspond to Recipes:
Creating an OpenCV project with MS Visual C++
Creating an OpenCV project with Qt

File:
	main2.cpp
correspond to Recipe:
Loading, displaying and saving images

Files in :
	myQtGUIApp
	anotherQtGUI
correspond to Recipe:
Creating a GUI application using Qt
