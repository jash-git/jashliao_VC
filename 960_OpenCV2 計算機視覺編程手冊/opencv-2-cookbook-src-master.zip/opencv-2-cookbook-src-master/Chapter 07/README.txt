This directory contains material supporting chapter 7 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
by Robert Laganiere, Packt Publishing, 2011.

Files:
	edgedetector.h
	linefinder.h
	contours.cpp
correspond to Recipes:
Detecting Image Contours with the Canny Operator
Detecting Lines in Images with the Hough Transform
Fitting a Line to a Set of Points

File:
	blobs.cpp
correspond to Recipes:
Extracting the Components� Contours
Computing Components� Shape Descriptors
