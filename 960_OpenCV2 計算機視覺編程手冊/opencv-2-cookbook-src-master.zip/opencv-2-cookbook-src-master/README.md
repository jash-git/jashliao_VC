opencv-2-cookbook 中文版配套源代码
=====================

[原书 OpenCV 2 Computer Vision Application Programming Cookbook](http://www.amazon.cn/OpenCV-2-Computer-Vision-Application-Programming-Cookbook-Laganiere-Robert/dp/1849513244/)<br>
[豆瓣网条目](http://book.douban.com/subject/24846303/)<br>
[亚马逊购买链接](http://www.amazon.cn/OpenCV2%E8%AE%A1%E7%AE%97%E6%9C%BA%E8%A7%86%E8%A7%89%E7%BC%96%E7%A8%8B%E6%89%8B%E5%86%8C-Robert-Laganiere/dp/B00DO9TC6C/)<br>
[京东购买链接](http://item.jd.com/11267855.html)<br>

[第一版勘误整理](https://github.com/vinjn/opencv-2-cookbook-src/issues/62)
<br>
[#我想要OpenCV新书#活动说明（已结束）](https://github.com/vinjn/opencv-2-cookbook-src/issues/1) 及 [获奖者名单](https://github.com/vinjn/opencv-2-cookbook-src/issues?labels=%E8%8E%B7%E5%A5%96%E8%80%85&page=1&state=closed)

----


![](https://raw.github.com/vinjn/vinjn.github.io/master/images/opecv-cookbook-face.jpg)

