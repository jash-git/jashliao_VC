#ifndef GRCONFIG_H
#define GRCONFIG_H

#define GR_MAX_SATURATIONS  8
#define GR_MAX_CONVERSIONS  16

#define GR_MAX_DEVICES  8

#endif /* GRCONFIG_H */
