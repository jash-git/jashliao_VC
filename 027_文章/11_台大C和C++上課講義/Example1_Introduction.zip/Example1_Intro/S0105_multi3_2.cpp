#include <stdio.h>
#include <stdlib.h>
int main()
{
	int integer1;
	int integer2;
	int integer3;

	printf("Please enter the first integer: ");
	scanf("%d", &integer1);
	printf("Please enter the second integer: ");
	scanf("%d", &integer2);
	printf("Please enter the third integer: ");
	scanf("%d", &integer3);

	printf("Product is %d\n",
		integer1 * integer2 * integer3);
	system("pause");
	return 0;
}
