#include <stdio.h>
#include <stdlib.h>

int main() {
	printf("H    H    A\n");
	printf("H    H   A A\n");
	printf("HHHHHH  A   A\n");
	printf("H    H AAAAAAA\n");
	printf("H    H A     A\n");
	system("pause");
	return 0;
}

