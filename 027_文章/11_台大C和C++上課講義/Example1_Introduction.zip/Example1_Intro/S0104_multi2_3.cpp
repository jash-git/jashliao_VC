#include <stdio.h>
#include <stdlib.h>
int main() {
	int integer;
	int product;

	printf("Please enter the first integer: ");
	scanf("%d", &integer);
  product = integer;

	printf("Please enter the second integer: ");
	scanf("%d", &integer);
  product = product * integer;

	printf("Product is %d\n", product);
	system("pause");
	return 0;
}
