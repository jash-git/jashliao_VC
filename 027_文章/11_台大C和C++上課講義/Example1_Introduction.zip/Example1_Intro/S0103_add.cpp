/* Addition program */
#include <stdio.h>
#include <stdlib.h>
int main() {
	int integer1;
	int integer2;
	int sum;

	printf("Please enter the first integer: ");
	scanf("%d", &integer1);
	printf("Please enter the second integer: ");
	scanf("%d", &integer2);

  printf("%d\n", &integer1);
  printf("%d\n", &integer2);
  printf("%d\n", &sum);
	sum = integer1 + integer2;
	printf("Sum is %d\n", sum);
	system("pause");
	return 0;
}
