/**********************************************************
 * File  : calc (�p��M�B�����ȻP���nv2)
 * Author: Ken-Yi Lee (feis.tw@gmail.com)
 * Note  : ���оǤ�K�ڭ̨ϥΤ������, ����ȤW���קK�ϥ� 
 *********************************************************/
#include <stdio.h>
#include <stdlib.h>
int main() {
  int integer1;
  int integer2;
  int integer3;

  printf("Please enter the first integer: ");
  scanf("%d", &integer1);
  printf("Please enter the second integer: ");
  scanf("%d", &integer2);
  printf("Please enter the third integer: ");
  scanf("%d", &integer3);

  printf("Sum is %d\n",
    integer1 + integer2 + integer3);
  printf("Average is %d\n",
    (integer1 + integer2 + integer3) / 3);
	printf("Product is %d\n",
    integer1 * integer2 * integer3);
  system("pause");
  return 0;
}
