#include <stdio.h>
#include <stdlib.h>
int main() {
	int integer1;
	int integer2;

	printf("Please enter the first integer: ");
	scanf("%d", &integer1);
	printf("Please enter the second integer: ");
	scanf("%d", &integer2);

	printf("Product is %d\n", integer1*integer2);
	system("pause");
	return 0;
}
