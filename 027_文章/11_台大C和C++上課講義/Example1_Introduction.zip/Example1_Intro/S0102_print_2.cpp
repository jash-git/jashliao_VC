#include <stdio.h>
#include <stdlib.h>

int main() {
	printf("H    H    A\nH    H   A A\nHHHHHH  A   A\nH    H AAAAAAA\nH    H A     A\n");
	system("pause");
	return 0;
}

