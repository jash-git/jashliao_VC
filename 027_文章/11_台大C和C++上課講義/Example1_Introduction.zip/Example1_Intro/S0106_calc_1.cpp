/**********************************************************
 * File  : calc (�p��M�B�����ȻP���nv1)
 * Author: Ken-Yi Lee (feis.tw@gmail.com)
 * Note  : ���оǤ�K�ڭ̨ϥΤ������, ����ȤW���קK�ϥ� 
 *********************************************************/
#include <stdio.h>
#include <stdlib.h>
int main() {
  int integer1;
  int integer2;
  int integer3;
  int sum;
  int avg;
  int pdt;

  printf("Please enter the first integer: ");
  scanf("%d", &integer1);
  printf("Please enter the second integer: ");
  scanf("%d", &integer2);
  printf("Please enter the third integer: ");
  scanf("%d", &integer3);

  sum = integer1 + integer2 + integer3;
  avg = sum / 3;
  pdt = integer1 * integer2 * integer3;
  printf("Sum is %d\n"    , sum);
  printf("Average is %d\n", avg);
  printf("Product is %d\n", pdt);
  system("pause");
  return 0;
}
