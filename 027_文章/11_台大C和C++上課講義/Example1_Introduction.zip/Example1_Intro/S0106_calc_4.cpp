/**********************************************************
 * File  : calc (�p��M�B�����ȻP���nv4:
 *               �ϥ� printf �L�X�h���ܼƭ�)
 * Author: Ken-Yi Lee (feis.tw@gmail.com)
 * Note  : ���оǤ�K�ڭ̨ϥΤ������, ����ȤW���קK�ϥ� 
 *********************************************************/
#include <stdio.h>
#include <stdlib.h>
int main() {
  int integer1;
  int integer2;
  int integer3;
  int sum;
  int avg;
  int pdt;

  printf("Please enter the first integer: ");
  scanf("%d", &integer1);
  printf("Please enter the second integer: ");
  scanf("%d", &integer2);
  printf("Please enter the third integer: ");
  scanf("%d", &integer3);

  sum = integer1 + integer2 + integer3;
  pdt = integer1 * integer2 * integer3;
  avg = sum/3;
  printf("Sum is %d\nAverage is %d\nProduct is %d\n",
    sum, avg, pdt);
  system("pause");
  return 0;
}
