/**********************************************************
 * File  : calc (�p��M�B�����ȻP���nv3: �ֶi��)
 * Author: Ken-Yi Lee (feis.tw@gmail.com)
 * Note  : ���оǤ�K�ڭ̨ϥΤ������, ����ȤW���קK�ϥ� 
 *********************************************************/
#include <stdio.h>
#include <stdlib.h>
int main() {
  int integer;
  int sum;
  int pdt;

  printf("Please enter the first integer: ");
  scanf("%d", &integer);
  sum = integer;
  pdt = integer;

  printf("Please enter the second integer: ");
  scanf("%d", &integer);
  sum = sum + integer;
  pdt = pdt * integer;
 
  printf("Please enter the third integer: ");
  scanf("%d", &integer);
  sum = sum + integer;
  pdt = pdt * integer;

  printf("Sum is %d\n", sum);
  printf("Average is %d\n", sum / 3);
  printf("Product is %d\n", pdt);
  system("pause");
  return 0;
}
