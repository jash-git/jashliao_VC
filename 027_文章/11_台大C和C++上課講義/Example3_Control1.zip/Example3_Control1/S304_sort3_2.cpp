#include <stdio.h>
#include <stdlib.h>

int main() {
  int num1, num2, num3;

  printf("Please enter the first number  : ");
  scanf("%d", &num1);

  printf("Please enter the second number : ");
  scanf("%d", &num2);

  printf("Please enter the third number  : ");
  scanf("%d", &num3);

  int m1, m2, m3;
  if (num1 <= num2) {
    /* num1 <= num2 */
    if (num2 <= num3) {
      /* num1 <= num2 <= num3 */
      m1 = num1; m2 = num2; m3 = num3;
    } else if (num1 <= num3) {
      /* num1 <= num3 <  num2 */
      m1 = num1; m2 = num3; m3 = num2;
    } else {
      /* num3 <  num1 <= num2 */
      m1 = num3; m2 = num1; m3 = num2;
    }
  } else {
    /* num1 > num2 */
    if (num1 <= num3) {
      /* num2 <  num1 <= num3 */
      m1 = num2; m2 = num1; m3 = num3;
    } else if (num2 <= num3) {
      /* num2 <= num3 < num1 */
      m1 = num2; m2 = num3; m3 = num1;
    } else {
      /* num3 <  num2 < num1 */
      m1 = num3; m2 = num2; m3 = num1;
    }
  }
  printf("%d %d %d\n", m1, m2, m3);
  system("pause");
  return 0;
}
