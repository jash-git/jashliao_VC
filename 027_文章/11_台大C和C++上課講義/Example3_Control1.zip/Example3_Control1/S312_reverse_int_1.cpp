#include <stdio.h>
#include <stdlib.h>

int main() {
  int i = 100;
  while (i >= 1) {
    printf("%d\n", i);
    --i;
  }

  system("pause");
  return 0;
}
