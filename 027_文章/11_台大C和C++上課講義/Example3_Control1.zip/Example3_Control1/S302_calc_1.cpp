#include <stdio.h>
#include <stdlib.h>

int main() {
  int n1, n2;
  char op;
  scanf("%d%c%d", &n1, &op, &n2);

  double ans;
  if (op == '+') {
    ans = n1 + n2;
  }
  if (op == '-') {
    ans = n1 - n2;
  } 
  if (op == '*') {
    ans = n1 * n2;
  }
  if (op == '/') {
    ans = (double)n1 / n2;
  } 
  printf("ANS: %.2f\n", ans);
  system("pause");
  return 0;
}
