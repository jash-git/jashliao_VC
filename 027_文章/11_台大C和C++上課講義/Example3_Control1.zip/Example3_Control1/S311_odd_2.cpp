#include <stdio.h>
#include <stdlib.h>

int main() {
  int N;
  printf("�п�J�@�ӥ����: ");
  scanf("%d", &N);

  int i = 1;
  while (i <= N) {
    printf("%d\n", i);
    i += 2;
  }
  system("pause");
  return 0;
}
