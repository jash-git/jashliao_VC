#include <stdio.h>
#include <stdlib.h>

int main() {
  int num1, num2, num3;

  printf("Please enter the first number  : ");
  scanf("%d", &num1);

  printf("Please enter the second number : ");
  scanf("%d", &num2);

  printf("Please enter the third number  : ");
  scanf("%d", &num3);

  int m1 = num1;
  int m2 = num2;
  int m3 = num3;

  if (m2 < m1) {
    int t = m1;
    m1 = m2;
    m2 = t;
  }
  /* m2 >= m1 */

  if (m3 < m1) {
    int t = m1;
    m1 = m3;
    m3 = t;
  }
  /* m2 >= m1 && m3 >= m1  
     m1 �{�b�O�T�Ƥ��̤p�� */

  if (m3 < m2) {
    int t = m2;
    m2 = m3;
    m3 = t;
  }
  /* m3 >= m2 >= m1 */ 

  printf("%d %d %d\n", m1, m2, m3);
  system("pause");
  return 0;
}
