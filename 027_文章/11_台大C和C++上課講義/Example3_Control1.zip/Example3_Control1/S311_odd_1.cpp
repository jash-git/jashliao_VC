#include <stdio.h>
#include <stdlib.h>

int main() {
  int N;
  printf("�п�J�@�ӥ����: ");
  scanf("%d", &N);

  int i = 1;
  while (i <= N) {
    if (i % 2 == 1) {
      printf("%d\n", i);
    }
    ++i;
  }
  system("pause");
  return 0;
}
