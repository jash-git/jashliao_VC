#include <stdio.h>
#include <stdlib.h>

int main() {
  int N;
  scanf("%d", &N);
  
  int i = 1;
  while (i <= N) {
    printf("*");
    ++i;
  }
  printf("\n");
  system("pause");
  return 0;
}
