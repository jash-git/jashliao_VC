#include <stdio.h>
#include <stdlib.h>

int main() {
    int dist;

    printf("�п�J�Z�� (����) : ");
    scanf("%d", &dist);

    int money = 70;
    if (dist > 1250) {
        int bonus = dist - 1250;
        money += bonus/250*5;
        if (bonus % 250 != 0) {
            money += 5;
        }
    }
    printf("NT$%d\n", money);  
    system("pause");
    return 0;
}
