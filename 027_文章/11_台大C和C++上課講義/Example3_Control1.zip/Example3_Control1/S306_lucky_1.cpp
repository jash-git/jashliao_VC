#include <stdio.h>
#include <stdlib.h>

int main() {
  int num;
  int n1, n2, n3, n4, n5, n6;
  int count = 0;	
  printf("�п�J�@�Ӥ�����: ");
  scanf("%6d", &num);
  n1 = num / 100000     ;
  n2 = num / 10000  % 10;
  n3 = num / 1000   % 10;
  n4 = num / 100    % 10;
  n5 = num / 10     % 10;
  n6 = num          % 10;

  if (n1 == 7) { count = count + 1; }
  if (n2 == 7) { count = count + 1; }
  if (n3 == 7) { count = count + 1; }
  if (n4 == 7) { count = count + 1; }
  if (n5 == 7) { count = count + 1; }
  if (n6 == 7) { count = count + 1; }

  printf("�@�� %d �� 7.\n", count);  
  system("pause");
  return 0;
}
