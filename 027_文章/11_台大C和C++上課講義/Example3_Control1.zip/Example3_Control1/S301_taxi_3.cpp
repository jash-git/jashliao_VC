#include <stdio.h>
#include <stdlib.h>

int main() {
  double dist;

  printf("�п�J�Z�� (����) : ");
  scanf("%lf", &dist);

  int money = 70;
  if (dist > 1.25) {
    double extra = dist-1.25;
    int count = (int)(extra/0.25);
    if ( extra - count*0.25 > 0 ) {
      count = count + 1;
    }  
    money += count * 5;
  }
  printf("NT$%d\n", money);  
  system("pause");
    return 0;
}
