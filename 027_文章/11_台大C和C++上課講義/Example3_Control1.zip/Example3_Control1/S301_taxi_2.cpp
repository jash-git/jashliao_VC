#include <stdio.h>
#include <stdlib.h>

int main() {
    int dist;

    printf("�п�J�Z�� (����) : ");
    scanf("%d", &dist);

    int money = 70;
    if (dist > 1250) {
        money +=(dist-1250+(250-1))/250*5;
    }
    printf("NT$%d\n", money);  
    system("pause");
    return 0;
}
