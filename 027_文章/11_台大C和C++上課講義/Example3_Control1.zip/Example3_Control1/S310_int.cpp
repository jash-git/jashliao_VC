#include <stdio.h>
#include <stdlib.h>

int main() {
  int num;
  printf("�п�J�@�ӥ���� : ");
  scanf("%d", &num);
  int i = 1;
  while (i <= num) {
    printf("%d\n", i);
    i = i + 1;
  }
  system("pause");
  return 0;
}
