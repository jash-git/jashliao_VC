#include <stdio.h>
#include <stdlib.h>

int main() {
    int num1, num2, num3;

    printf("Please enter the first number  : ");
    scanf("%d", &num1);

    printf("Please enter the second number : ");
    scanf("%d", &num2);

    printf("Please enter the third number  : ");
    scanf("%d", &num3);

    int max = num1;
    if (max < num2) {
        max = num2;
    }
    if (max < num3) {
        max = num3;
    }

    printf("The largest number is %d.\n", max);		
    system("pause");
    return 0;
}
