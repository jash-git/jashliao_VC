#include <stdio.h>
#include <stdlib.h>

int main() {
	int ans = 4;
	
	int guess;
    printf("Please enter your guess : ");
    scanf("%d", &guess);
	while (guess != ans) {
        if (guess > ans) {
            printf("It is too large.\n");
        } else if (guess < ans) {
            printf("It is too small.\n");
        }		
        printf("Please enter your guess : ");
        scanf("%d", &guess);
    }
    printf("You are a genius !\n");
    system("pause");
    return 0;
}
