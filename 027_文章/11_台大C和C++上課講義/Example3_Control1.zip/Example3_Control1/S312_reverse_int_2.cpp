#include <stdio.h>
#include <stdlib.h>

int main() {
  int i = 1;
  while (i <= 100) {
    int v = 100 - i + 1;
    printf("%d\n", v);
    ++i;
  }

  system("pause");
  return 0;
}
