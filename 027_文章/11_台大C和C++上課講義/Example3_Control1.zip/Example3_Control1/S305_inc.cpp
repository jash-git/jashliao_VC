#include <stdio.h>
#include <stdlib.h>

int main() {
  printf("int a = 3;\n");
  printf("int b = 4;\n");
  int a = 3;
  int b = 4;
  /* pause > NUL �O MS-DOS �����O, �\��� pause �@�� * 
   * ���O���|�������r��ܦb�ù��W (�ɦV NUL)       */ 
  system("pause > NUL"); 
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("a = a + 1;\n");
  a = a + 1;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("a += 1;\n");
  a += 1;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("b = ++a;\n");
  b = ++a;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);
  
  printf("b = a++;\n");
  b = a++;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("\n�H�U�O�����d��, ���ǵ��G��sĶ����@����:\n"); 

  printf("a = a++;\n");
  a = a++;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("a = a++ + 1;\n");
  a = a++ + 1;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("b = a - ++a;\n");
  b = a - ++a;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("b = a - a++;\n");
  b = a - a++;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);


  printf("b = a++-++a;\n");
  b = a++-++a;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  printf("a = a++-++a;\n");
  a = a++-++a;
  system("pause > NUL");
  printf("[STATUS] a = %d, b = %d\n", a, b);

  system("pause");
}
