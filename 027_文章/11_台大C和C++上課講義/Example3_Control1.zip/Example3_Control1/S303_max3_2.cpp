#include <stdio.h>
#include <stdlib.h>

int main() {
  int num1, num2, num3;

  printf("Please enter the first integer  : ");
  scanf("%d", &num1);

  printf("Please enter the second integer : ");
  scanf("%d", &num2);

  printf("Please enter the third integer  : ");
  scanf("%d", &num3);

  int max;

  if (num1 >= num2 && num1 >= num3) {
    max = num1;
  } else if (num2 >= num1 && num2 >= num3) {
    max = num2;
  } else /* if (num3 >= num1 && num3 >= num2) */ {
    max = num3;
  }

  printf("The largest number is %d.\n", max);		
  system("pause");
  return 0;
}
