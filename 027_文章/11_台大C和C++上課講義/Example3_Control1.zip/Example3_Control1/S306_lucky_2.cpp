#include <stdio.h>
#include <stdlib.h>

int main() {
  int num;
  int count = 0;	
  char ch;

  printf("�п�J�@�Ӥ�����: ");
  scanf("%c", &ch);
  if (ch == '7') { count = count + 1; }
  scanf("%c", &ch);
  if (ch == '7') { count = count + 1; }
  scanf("%c", &ch);
  if (ch == '7') { count = count + 1; }
  scanf("%c", &ch);
  if (ch == '7') { count = count + 1; }
  scanf("%c", &ch);
  if (ch == '7') { count = count + 1; }
  scanf("%c", &ch);
  if (ch == '7') { count = count + 1; }

  printf("�@�� %d �� 7.\n", count);  
  system("pause");
  return 0;
}
