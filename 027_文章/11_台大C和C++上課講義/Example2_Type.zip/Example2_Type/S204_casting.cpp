/**********************************************************
 * File  : casting (�૬���d��)
 * Author: Ken-Yi Lee (feis.tw@gmail.com)
 * Note  : ���оǤ�K�ڭ̨ϥΤ������, ����ȤW���קK�ϥ� 
 *********************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
  int    a;
  float  b;
  int    c;
  float  d;
 
  a = 4 / 3  ; /* int   to int    */
  b = 4 / 3  ; /* int   to float */
  c = 4 / 3.f; /* float to int    */
  d = 4 / 3.f; /* float to float */

  printf("4 / 3   == %d\n", a);
  printf("4 / 3   == %f\n", a); /* Wrong format! */
  printf("4 / 3   == %d\n", b); /* Wrong format! */
  printf("4 / 3   == %f\n", b);
  printf("4 / 3.f == %d\n", c);  
  printf("4 / 3.f == %f\n", c); /* Wrong format! */
  printf("4 / 3.f == %d\n", d); /* Wrong format! */
  printf("4 / 3.f == %f\n", d);
  system("pause");
  return 0;
}
