#include <stdio.h>
#include <stdlib.h>

int main() {
  int N;
  printf("Please enter a positive integer: ");
  scanf("%d", &N);
  
  int sum = 0;
  for (int i = 1; i <= N; i++) {
    sum = sum + i;
  }
  printf("The sum from 1 to %d is %d\n", N, sum);
  system("pause");
  return 0;
}
