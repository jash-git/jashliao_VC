#include <stdio.h>
#include <stdlib.h>

int main() {
  for (int i = 1; i <= 100; ++i) {
    if (i % 5 == 0) {
      continue;
    }
    printf("%d ", i);
  }
  printf("\n");
  system("pause");
  return 0;
}
