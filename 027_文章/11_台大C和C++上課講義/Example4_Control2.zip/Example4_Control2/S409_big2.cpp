#include <stdio.h>
#include <stdlib.h>

int main() {
	int max1, max2;
	printf("Please enter a number (%2d/10) : ", 1);
	scanf("%d", &max1);
	printf("Please enter a number (%2d/10) : ", 2);
	scanf("%d", &max2);
  if (max2 > max1) {
    int t = max2;
    max2 = max1;
    max1 = t;
  }

	for (int i = 3; i <= 10; ++i) {
		int num;
		printf("Please enter a number (%2d/10) : ", i);
		scanf("%d", &num);
		if (num > max1) {
			max2 = max1;
			max1 = num;
		} else if (num > max2) {
			max2 = num;
		}
	}
	printf("%d %d\n", max1, max2);
	system("pause");
	return 0;
}
