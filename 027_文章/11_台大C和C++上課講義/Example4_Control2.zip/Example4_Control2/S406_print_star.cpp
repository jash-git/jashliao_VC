#include <stdio.h>
#include <stdlib.h>

int main() {
  int N;
  scanf("%d", &N);
  
  for (int i = 1; i <= N; i++) {
    printf("*");
  }
  printf("\n");
  system("pause");
  return 0;
}
