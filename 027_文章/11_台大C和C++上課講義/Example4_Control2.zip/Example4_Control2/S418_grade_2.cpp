#include <stdio.h>
#include <stdlib.h>

int main() {
  int countA = 0;
  int countB = 0;
  int countC = 0;
  int countErr = 0;  
  char ch;
  printf("�п�J���Z [AaBbCc][Qq]: ");
  scanf(" %c", &ch);
  while (ch != 'Q' && ch != 'q') {
    switch(ch) {
      case 'A':
      case 'a':
        countA++;
        break;
      case 'B':
      case 'b':
        countB++;
        break;
      case 'C':
      case 'c':
        countC++;
        break;
      default:
        countErr++;
    }
    printf("�п�J���Z [AaBbCc][Qq]: ");
    scanf(" %c", &ch);
  } 
  printf("A ���Ӽ�: %d\n", countA);
  printf("B ���Ӽ�: %d\n", countB);
  printf("C ���Ӽ�: %d\n", countC);
  printf("���~���Ӽ�: %d\n", countErr); 
	system("pause");
	return 0;
}
