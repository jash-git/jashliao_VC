#include <stdio.h>
#include <stdlib.h>

int main() {
  for (int i = 1; i <=100; i++) {
    int n = 100 - i + 1;
    printf("%d\n", n);
  }

  system("pause");
  return 0;
}
