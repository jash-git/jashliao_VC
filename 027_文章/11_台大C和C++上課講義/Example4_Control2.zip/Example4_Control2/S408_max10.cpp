#include <stdio.h>
#include <stdlib.h>

int main() {
	int max;
	printf("Please enter a number (%2d/10) : ", 1);
	scanf("%d", &max);

	for (int i = 2; i <= 10; ++i) {
		int num;
		printf("Please enter a number (%2d/10) : ", i);
		scanf("%d", &num);
		if (num > max) {
			max = num; 
		}
	}
	printf("%d\n", max);
	system("pause");
	return 0;
}
