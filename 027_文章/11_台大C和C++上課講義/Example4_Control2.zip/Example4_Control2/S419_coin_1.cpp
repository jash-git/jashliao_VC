#include <stdio.h>
#include <stdlib.h>

int main() {
  int num;
  printf("Please enter the number of goods : ");
  scanf("%d", &num);

  int sum = 0;
  for (int i = 1; i <= num; ++i) {
    int label;
    scanf("%d", &label);
    if (label == 1) {
      sum += 90;
    } else if (label == 2) {
      sum += 75;
    } else if (label == 3) {
      sum += 83;
    } else if (label == 4) {
      sum += 89;
    } else if (label == 5) {
      sum += 71;
    } else {
      printf("The label is not valid.\n");
    }
  }
  printf("The amount is %d.\n", sum);
  system("pause");
  return 0;
}
