#include <stdio.h>
#include <stdlib.h>

int main() {
  int num;
  printf("Please enter the number of goods : ");
  scanf("%d", &num);

  int sum = 0;
  for (int i = 1; i <= num; ++i) {
    int label;
    scanf("%d", &label);
    switch(label) {
      case 1: sum += 90; break;
      case 2: sum += 75; break; 
      case 3: sum += 83; break;
      case 4: sum += 89; break;
      case 5: sum += 71; break;
      default: printf("The label is not valid.\n"); 
    }
  }
  printf("The amount is %d.\n", sum);
  system("pause");
  return 0;
}
