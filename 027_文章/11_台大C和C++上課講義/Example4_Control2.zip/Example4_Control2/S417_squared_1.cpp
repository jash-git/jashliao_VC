#include <stdio.h>
#include <stdlib.h>

int main() {
  int num;
  do {
    printf("Please enter a positive integer : ");
    scanf("%d", &num);
    if (num >= 0) {
      printf("%d\n", num*num);
    }
  } while (num >= 0);
  system("pause");
  return 0;
}
