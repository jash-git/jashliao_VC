#include <stdio.h>
#include <stdlib.h>

int main() {
  int countA = 0;
  int countB = 0;
  int countC = 0;
  int countErr = 0;  
  char ch;
  printf("�п�J���Z [AaBbCc][Qq]: ");
  scanf(" %c", &ch);
  while (ch != 'Q' && ch != 'q') {
    if (ch == 'A' || ch == 'a') {
      countA++;
    } else if (ch == 'B' || ch =='b') {
      countB++;
    } else if (ch == 'C' || ch == 'c') {
      countC++;
    } else {
      countErr++;
    }
    printf("�п�J���Z [AaBbCc][Qq]: ");
    scanf(" %c", &ch);
  } 
  printf("A ���Ӽ�: %d\n", countA);
  printf("B ���Ӽ�: %d\n", countB);
  printf("C ���Ӽ�: %d\n", countC);
  printf("���~���Ӽ�: %d\n", countErr); 
	system("pause");
	return 0;
}
