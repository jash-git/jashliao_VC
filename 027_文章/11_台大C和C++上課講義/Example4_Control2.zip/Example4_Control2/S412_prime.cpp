#include <stdio.h>
#include <stdlib.h>

int main() {
  for (int num = 1; num <= 1000; ++num) { 
    int found = 0; 
    for (int test = 2; test <= num-1; ++test) {
      if (num % test == 0) {
        found = 1;
      }
    }
    if (found == 0) {
      printf("%d\n", num);
    }
  }
  system("pause");
  return 0;
}
