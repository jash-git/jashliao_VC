#include <stdio.h>
#include <stdlib.h>

int main() {
  int N;
  printf("Please enter a positive integer : ");
  scanf("%d", &N);

  for (int i = 1; i <= N; i += 2) {
    printf("%d\n", i);
  }

  system("pause");
  return 0;
}
