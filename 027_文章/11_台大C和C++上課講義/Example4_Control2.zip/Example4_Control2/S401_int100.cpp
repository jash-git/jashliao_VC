#include <stdio.h>
#include <stdlib.h>

int main() {
  for (int i = 1; i <= 100; i++) {
    printf("%d\n", i);
  }
  system("pause");
  return 0;
}
