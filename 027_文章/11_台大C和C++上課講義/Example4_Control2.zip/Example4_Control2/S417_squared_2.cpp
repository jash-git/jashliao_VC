#include <stdio.h>
#include <stdlib.h>

int main() {
  while (1) {
    int num;
    printf("Please enter a positive integer : ");
    scanf("%d", &num);
    if (num < 0) {
      break;
    }
    printf("%d\n", num*num);
  }
  system("pause");
  return 0;
}
