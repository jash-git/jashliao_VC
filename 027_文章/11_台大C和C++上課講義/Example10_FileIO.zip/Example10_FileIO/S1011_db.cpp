/************************************************
 *  NOTE: �]���оǥت�, �o�̧ڭ̨ϥΤ������.
 *        ����ĳ�b�@��{���X���ϥΤ���
 *  Author: Ken-Yi Lee (feis.tw@gmail.com)
 ************************************************/
#include <stdio.h>
#include <stdlib.h>

struct Student {
  char name[100];
  int  grade;
};

int read(Student **, const char*);
void show(const Student *, const int);

int main() {
  Student *sts;
  int num = read(&sts, "db.txt");
  show(sts, num);
  free(sts);
  system("pause");
  return 0;
}

int read(Student **sts, const char* filename) {
  FILE *fp = fopen(filename, "r");
  if (fp == NULL) {
    return 0;
  }
  int num;
  fscanf(fp, "%d", &num);
  Student *ret = 
        (Student *)malloc( sizeof(Student)* num); 
  for (int i = 0; i < num; ++i) {
    fscanf(fp, "%s", ret[i].name);
    fscanf(fp, "%d", &ret[i].grade);
  }
  fclose(fp);
  *sts = ret;
  return num;
}


void show(const Student *sts, const int num) {
  for (int i = 0; i < num; ++i) {
    printf("No. %3d: %s (%d)\n",
      (i+1), sts[i].name, sts[i].grade);
  }
}
