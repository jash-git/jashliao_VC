struct Record {
  char username[100];
  int  grade;
};
