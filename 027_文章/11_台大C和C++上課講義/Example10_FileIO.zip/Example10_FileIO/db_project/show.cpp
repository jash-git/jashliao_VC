#include <stdio.h>
#include "student.h"

void show(const Student *sts, const int num) {
  for (int i = 0; i < num; ++i) {
    printf("No. %3d: %s (%d)\n",
      (i+1), sts[i].name, sts[i].grade);
  }
}
