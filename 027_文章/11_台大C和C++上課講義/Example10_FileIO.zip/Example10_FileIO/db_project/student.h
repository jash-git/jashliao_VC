struct Student {
  char name[100];
  int  grade;
};
