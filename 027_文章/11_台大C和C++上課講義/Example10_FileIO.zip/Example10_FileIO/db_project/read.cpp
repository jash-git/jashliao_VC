#include <stdio.h>
#include <stdlib.h>

#include "student.h"

int read(Student **sts, const char* filename) {
  FILE *fp = fopen(filename, "r");
  if (fp == NULL) {
    return 0;
  }
  int num;
  fscanf(fp, "%d", &num);
  Student *ret = 
        (Student *)malloc( sizeof(Student)* num); 
  for (int i = 0; i < num; ++i) {
    fscanf(fp, "%s", ret[i].name);
    fscanf(fp, "%d", &ret[i].grade);
  }
  fclose(fp);
  *sts = ret;
  return num;
}
