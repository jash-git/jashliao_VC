#include <stdio.h>
#include <stdlib.h>

class Grade {
  private:
    int _grade;
    
  public:
    int setTo(int new_grade) {
      if (new_grade >= 0 && new_grade <= 100) {
        _grade = new_grade;
      }
      return _grade; 
    }
    
    /* �o�̪� const �O�O�� get() �禡���|����� */ 
    int get() const { return _grade; }
};

int main() {
  const int NUM_OF_STUDENTS = 5;
  Grade grades[NUM_OF_STUDENTS];
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    int g;
    printf("Grade[%d] = ", i);
    scanf("%d", &g);
    grades[i].setTo(g);
    /* grades[i]._grade = g; */
  }
  
  printf("Result:\n");
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    printf("Grades[%d] = %d\n", i, grades[i]);
  }
  /* ��l�� ?? */
   
  system("pause");
  return 0;
}
