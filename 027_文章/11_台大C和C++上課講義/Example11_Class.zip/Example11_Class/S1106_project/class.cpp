#include <stdio.h>

#include "class.hpp"

/* �����禡�w�q */ 
void Student::read() {
  printf("Please enter your name: ");
  scanf("%s", _name);
  printf("Please enter your grade (Chinese): ");
  scanf("%d", &_chinese);
  printf("Please enter your grade (English): ");
  scanf("%d", &_english);
  return;
}

void Student::print() {
	printf("%s (%f)\n", _name, avg());
  return;
}

