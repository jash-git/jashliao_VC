/* ���O�w�q */ 
class Student {
  private:
    char _name[20];
    int _chinese;
    int _english;

  public:
    float avg() { return (_chinese + _english)/2.f; }
    void read();
    void print();
};
