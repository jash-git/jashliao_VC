#include <stdlib.h>
#include "class.hpp"

/* �D�{�� */ 
int main() {
  Student sts[3];
  for (int i = 0; i < 3; ++i) {
    sts[i].read();
  }
  for (int i = 0; i < 3; ++i) {
    sts[i].print();
  }
	system("pause");
	return 0;
}
