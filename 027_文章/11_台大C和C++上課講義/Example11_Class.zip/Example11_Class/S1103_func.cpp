#include <stdio.h>
#include <stdlib.h>

/* �禡�ŧi */ 
float avg(int, int);
void read(char *, int *, int *);
void print(char *, int, int);

/* �D�{�� */ 
int main() {
  char name[3][20];
  int chinese[3];
  int english[3];
  for (int i = 0; i < 3; ++i) {
    read(name[i], &chinese[i], &english[i]);
  }
  for (int i = 0; i < 3; ++i) {
    print(name[i], chinese[i], english[i]);
  }
	system("pause");
	return 0;
}

/* �禡�w�q */ 
void read(
  char *name,
  int *chinese,
  int *english) {
  printf("Please enter your name: ");
  scanf("%s", name);
  printf("Please enter your grade (Chinese): ");
  scanf("%d", chinese);
  printf("Please enter your grade (English): ");
  scanf("%d", english);
  return;
}

float avg(int chinese, int english) {
	return (chinese + english)/2.f;
}

void print(char *name, int chinese, int english) {
	printf("%s (%f)\n", name, avg(chinese, english));
  return;
}
