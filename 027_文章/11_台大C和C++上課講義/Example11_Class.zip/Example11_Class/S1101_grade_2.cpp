#include <stdio.h>
#include <stdlib.h>
#define NUM_OF_STUDENTS 5
 
int setTo(int *grade, int new_grade) {
  if (new_grade >= 0 && new_grade <= 100) {
    *grade = new_grade;
  } 
  return *grade;
}

int main() {
  int grades[NUM_OF_STUDENTS] = {0};
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    int g;
    printf("Grade[%d] = ", i);
    scanf("%d", &g);
    setTo(&grades[i], g);
    /* grades[i] = g; */
  }

  printf("Result:\n");
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    printf("Grades[%d] = %d\n", i, grades[i]);
  }

  system("pause");
  return 0;
}
