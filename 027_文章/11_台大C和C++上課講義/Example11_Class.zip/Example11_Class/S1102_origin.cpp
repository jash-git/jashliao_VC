/************************************************
 *  NOTE: �]���оǥت�, �o�̧ڭ̨ϥΤ������.
 *        ����ĳ�b�@��{���X���ϥΤ���
 *  Author: Ken-Yi Lee (feis.tw@gmail.com)
 ************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
  char name[3][20];
  int chinese[3];
  int english[3];
  for (int i = 0; i < 3; ++i) {
    printf("Please enter your name: ");
    scanf("%s", name[i]);
    printf("Please enter your grade (Chinese): ");
    scanf("%d", &chinese[i]);
    printf("Please enter your grade (English): ");
    scanf("%d", &english[i]);
  }

  for (int i = 0; i < 3; ++i) {
    float avg = (chinese[i]+english[i])/2.f;
	  printf("%s (%f)\n", name[i], avg);
  }
	system("pause");
	return 0;
}
