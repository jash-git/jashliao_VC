#include <stdio.h>
#include <stdlib.h>
#define NUM_OF_STUDENTS 5
int main() {
  int grades[NUM_OF_STUDENTS] = {0};
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    int g;
    printf("Grade[%d] = ", i);
    scanf("%d", &g);
    if (g >= 0 && g <= 100) {
      grades[i] = g;
    }
  }

  printf("Result:\n");
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    printf("Grades[%d] = %d\n", i, grades[i]);
  }
  
  system("pause");
  return 0;
}
