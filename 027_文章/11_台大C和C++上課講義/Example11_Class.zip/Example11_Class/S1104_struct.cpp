#include <stdio.h>
#include <stdlib.h>

/* ���c�w�q */ 
struct Student {
  char name[20];
  int chinese;
  int english;
};

/* �禡�ŧi */ 
float avg(Student);
void read(Student *);
void print(Student);

/* �D�{�� */ 
int main() {
  Student sts[3];
  for (int i = 0; i < 3; ++i) {
    read(&sts[i]);
  }
  for (int i = 0; i < 3; ++i) {
    print(sts[i]);
  }
	system("pause");
	return 0;
}

/* �禡�w�q */ 
void read(Student *s) {
  printf("Please enter your name: ");
  scanf("%s", s->name);
  printf("Please enter your grade (Chinese): ");
  scanf("%d", &s->chinese);
  printf("Please enter your grade (English): ");
  scanf("%d", &s->english);
  return;
}

float avg(Student s) {
	return (s.chinese + s.english)/2.f;
}

void print(Student s) {
	printf("%s (%f)\n", s.name, avg(s));
  return;
}
