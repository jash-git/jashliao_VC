#include <stdio.h>
#include <stdlib.h>

/* ���O�w�q */ 
class Student {
  private:
    char _name[20];
    int _chinese;
    int _english;

  public:
    float avg() { return (_chinese + _english)/2.f; }
    void read();
    void print();
};

/* �D�{�� */ 
int main() {
  Student sts[3];
  for (int i = 0; i < 3; ++i) {
    sts[i].read();
  }
  for (int i = 0; i < 3; ++i) {
    sts[i].print();
  }
	system("pause");
	return 0;
}

/* �����禡�w�q */ 
void Student::read() {
  printf("Please enter your name: ");
  scanf("%s", _name);
  printf("Please enter your grade (Chinese): ");
  scanf("%d", &_chinese);
  printf("Please enter your grade (English): ");
  scanf("%d", &_english);
  return;
}

void Student::print() {
	printf("%s (%f)\n", _name, avg());
  return;
}

