#include <stdio.h>
#include <stdlib.h>

class Grade {
  private:
    int _grade;

  /* �غc�l */    
  public:
    Grade() {
      setTo(0);
    }
       
  /* �B��l�h�� */ 
  public:
    Grade operator=(int new_grade) {
      setTo(new_grade);
      return *this;
    }
    
  public:
    int setTo(int new_grade) {
      if (new_grade >= 0 && new_grade <= 100) {
        _grade = new_grade;
      }
      return _grade; 
    }
    
    int get() const { return _grade; }
};

int main() {
  const int NUM_OF_STUDENTS = 5;
  Grade grades[NUM_OF_STUDENTS];
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    int g;
    printf("Grade[%d] = ", i);
    scanf("%d", &g);
    grades[i] = g;
    /* grades[i]._grade = g; */
  }
  
  printf("Result:\n");
  for (int i = 0; i < NUM_OF_STUDENTS; i++) {
    printf("Grades[%d] = %d\n", i, grades[i]);
  }
  
  system("pause");
  return 0;
}
