#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
  char firstName[20];
  char lastName[20];
  int age;
  char gender;
  int grade;
};

int main() {
    Student s[3];
    for (int i = 0; i < 3; ++i) {
        printf("[�� %d ��ǥ�]\n", (i+1));
        printf("�^��W�r : ");
        scanf("%s", s[i].firstName);
        printf("�^��m�� : ");
        scanf("%s", s[i].lastName);
        printf("�~��     : ");
        scanf("%d", &s[i].age);
        fflush(stdin); // �o�̬O�n�M����J���h�l�r�� 
        printf("�ʧO(M/F): ");
        scanf("%c", &s[i].gender);
        printf("���Z     : ");
        scanf("%d", &s[i].grade);       
        system("cls");
    }

    while (1) { 
        int no = 0;
        printf("�аݧA�n�d�߲ĴX��ǥ� [0:exit]: ");
        scanf("%d", &no);
        if (no == 0) {
            break;
        }
        if (! (no >= 1 && no <= 3)) {
            printf("�d�L���H!\n"); 
        } else {  
            printf("[�� %d ��ǥ�]\n", no);
            const Student *cur_s = &s[no-1];  
            printf("�^��W�r : %s\n", cur_s->firstName);
            printf("�^��m�� : %s\n", cur_s->lastName);
            printf("�~��     : %d\n", cur_s->age);
            printf("�ʧO     : %c\n", cur_s->gender);
            printf("���Z     : %d\n", cur_s->grade);
            printf("\n");
        }
        system("pause");
        system("cls");
    }
    return 0;
}
