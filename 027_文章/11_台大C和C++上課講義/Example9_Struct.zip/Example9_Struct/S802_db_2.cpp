#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
  char firstName[20];
  char lastName[20];
  int age;
  char gender;
  int grade;
};

void read(Student *s);
void show(const Student *s); 

int main() {
    Student s[3];
    for (int i = 0; i < 3; ++i) {
        printf("[�� %d ��ǥ�]\n", (i+1));
        read(&s[i]);
        system("cls");
    }

    while (1) { 
        int no = 0;
        printf("�аݧA�n�d�߲ĴX��ǥ� [0:exit]: ");
        scanf("%d", &no);
        if (no == 0) {
            break;
        }
        if (! (no >= 1 && no <= 3)) {
            printf("�d�L���H!\n"); 
        } else {  
            printf("[�� %d ��ǥ�]\n", no);
            show(&s[no-1]);
            printf("\n");
        }
        system("pause");
        system("cls");
    }
    return 0;
}

void read(Student *s) {
    printf("�^��W�r : ");
    scanf("%s", s->firstName);
    printf("�^��m�� : ");
    scanf("%s", s->lastName);
    printf("�~��     : ");
    scanf("%d", &s->age);
    fflush(stdin); // �o�̬O�n�M����J���h�l�r�� 
    printf("�ʧO(M/F): ");
    scanf("%c", &s->gender);
    printf("���Z     : ");
    scanf("%d", &s->grade);       
}

void show(const Student *s) { 
    printf("�^��W�r : %s\n", s->firstName);
    printf("�^��m�� : %s\n", s->lastName);
    printf("�~��     : %d\n", s->age);
    printf("�ʧO     : %c\n", s->gender);
    printf("���Z     : %d\n", s->grade);
}
