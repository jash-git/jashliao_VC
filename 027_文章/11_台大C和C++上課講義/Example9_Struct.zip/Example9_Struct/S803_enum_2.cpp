#include <stdio.h>
#include <stdlib.h>

enum Department {
    CHINESE, MATH, COMPUTER_SCIENCE
};

struct Student {
  int id;
  Department dep;  
  int grade;
};

void print(Student);

int main() {
  Student me = {1, COMPUTER_SCIENCE, 90};
  print(me);
  system("pause");
  return 0;
}

void print(Student s) {
  printf("�Ǹ�: %d\n", s.id);
  printf("�t��: ");
  switch(s.dep) {
    case CHINESE:          printf("����"); break;
    case MATH:             printf("�ƾ�"); break;
    case COMPUTER_SCIENCE: printf("��u"); break;
  }; 
  printf("\n");
  printf("���Z: %d\n", s.grade); 
}
