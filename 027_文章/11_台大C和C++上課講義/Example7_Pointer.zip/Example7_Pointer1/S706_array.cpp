#include <stdio.h>
#include <stdlib.h>

int main() {
  int v[5] = {1, 2, 3, 4, 5}; 
  int *vptr = v;

  // �C�L�}�C�U�������� 
  for (int i = 0; i < 5; i++) {
    printf("v[%d]      == %d\n", i, v[i]);
    printf("vptr[%d]   == %d\n", i, vptr[i]);
    printf("*(vptr+%d) == %d\n", i, *(vptr+i));
    printf("*(v+%d)    == %d\n", i, *(v+i));
    printf("\n");
  }  


  // �C�L�}�C�U��������m 
  for (int i = 0; i < 5; i++) {
    printf("&v[%d]    == %p\n", i, &v[i]);
    printf("&vptr[%d] == %p\n", i, &vptr[i]);
    printf("vptr+%d   == %p\n", i, vptr+i);
    printf("v+%d      == %p\n", i, v+i);
    printf("\n");
  }  
  system("pause");
  return 0;
}


