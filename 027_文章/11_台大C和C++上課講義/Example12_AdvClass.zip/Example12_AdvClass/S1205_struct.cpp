#include <stdio.h>
#include <stdlib.h>

struct student {
  char name[20];
  int chinese;
  int english;
};

typedef struct student Student;

int menu();
void query(Student sts[]);

int max(int chinese, int english);
double avg(int chinese, int english);
void show(Student s);
void read(Student *s);

int main() {
  int N;
  printf("Enter the number of students: ");
  scanf("%d", &N);
  Student sts[N];

  /* Ū�� N �Ӿǥ͸�� */
  for (int i = 0; i < N; ++i) {
    int no = i+1;
	  printf("No. %d:\n", no);
    read(&sts[i]);
    printf("\n");
  }

  int cmd = menu();
  while (cmd != 2) {
    switch(cmd) {
      case 1: query(sts); break;
      default:
        printf("Please enter a number between 1 and 2.\n");
        break;
    }
    cmd = menu();
  }
	system("pause");
	return 0;
}

/* �Щw�q menu, read, max, avg �M show �禡��U�� */
