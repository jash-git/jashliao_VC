#include <stdio.h>
#include <stdlib.h>

class Student {
  private:
    char _name[20];
    int  _chinese;
    int  _english;
  public:
    int    max();
    double avg();
    void   show();
    void   read();
};

int menu();
void query(Student sts[]);

int main() {
  int N;
  printf("Enter the number of students: ");
  scanf("%d", &N);
  Student sts[N];

  /* Ū�� N �Ӿǥ͸�� */
  for (int i = 0; i < N; ++i) {
    int no = i+1;
	  printf("No. %d:\n", no);
    sts[i].read();
    printf("\n");
  }

  int cmd = menu();
  while (cmd != 2) {
    switch(cmd) {
      case 1: query(sts); break;
      default:
        printf("Please enter a number between 1 and 2.\n");
        break;
    }
    cmd = menu();
  }
	system("pause");
	return 0;
}

/* �Щw�q Student �����禡�� menu, query �禡��U�� */
