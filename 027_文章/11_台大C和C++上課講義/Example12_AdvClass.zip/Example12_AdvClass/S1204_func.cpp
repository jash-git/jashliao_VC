#include <stdio.h>
#include <stdlib.h>

int menu();
void query(char name[][20], int chinese[], int english[]);

int max(int chinese, int english);
double avg(int chinese, int english);
void show(char *name, int chinese, int english);
void read(char *name, int *chinese, int *english);

int main() {
  int N;
  printf("Enter the number of students: ");
  scanf("%d", &N);
  char name[N][20];
  int chinese[N];
  int english[N];

  /* Ū�� N �Ӿǥ͸�� */
  for (int i = 0; i < N; ++i) {
    int no = i+1;
	  printf("No. %d:\n", no);
    read(name[i], &chinese[i], &english[i]);
    printf("\n");
  }

  int cmd = menu();
  while (cmd != 2) {
    switch(cmd) {
      case 1: query(name, chinese, english); break;
      default:
        printf("Please enter a number between 1 and 2.\n");
        break;
    }
    cmd = menu();
  }
	system("pause");
	return 0;
}

/* �Щw�q menu, query, read, max, avg �M show �禡��U�� */
