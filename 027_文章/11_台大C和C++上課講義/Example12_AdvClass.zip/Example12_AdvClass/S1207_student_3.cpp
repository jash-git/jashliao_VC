/*****************************************************
 * [�ɮ�] student_3.cpp
 *        (�ϥ� class)
 ****************************************************/
  
#include <stdio.h>
#include <stdlib.h>

class GeneralStudent {
  private:
    char _name[20];
    int  _chinese;
    int  _english;
    
  public:
    void read();
    void show();
};

class ScienceStudent {
  private:
    char _name[20];
    int  _chinese;
    int  _english;
    int  _math;
  
  public:
    void read();
    void show();
};

int main() {
  GeneralStudent s1;
  ScienceStudent s2;
  
  s1.read();
  printf("\n");
  s2.read();
  printf("\n");
  
  s1.show();
  printf("\n");
  s2.show();
  printf("\n");
    
  system("pause");
  return 0;
}

void GeneralStudent::read() {
  printf("�п�J�m�W: ");
  scanf("%s", _name);
  printf("�п�J���妨�Z: ");
  scanf("%d", &_chinese);
  printf("�п�J�^�妨�Z: ");
  scanf("%d", &_english);
  return; 
}

void ScienceStudent::read() {
  printf("�п�J�m�W: ");
  scanf("%s", _name);
  printf("�п�J���妨�Z: ");
  scanf("%d", &_chinese);
  printf("�п�J�^�妨�Z: ");
  scanf("%d", &_english);
  printf("�п�J�ƾǦ��Z: ");
  scanf("%d", &_math);
  return; 
}

void GeneralStudent::show() {
  printf("�m�W: %s\n", _name);
  printf("����: %d\n", _chinese);
  printf("�^��: %d\n", _english); 
  return;
}

void ScienceStudent::show() {
  printf("�m�W: %s\n", _name);
  printf("����: %d\n", _chinese);
  printf("�^��: %d\n", _english); 
  printf("�ƾ�: %d\n", _math); 
  return;
}
