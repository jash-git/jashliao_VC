/************************************************
 *  NOTE: �]���оǥت�, �o�̧ڭ̨ϥΤ������.
 *        ����ĳ�b�@��{���X���ϥΤ���
 *  Author: Ken-Yi Lee (feis.tw@gmail.com)
 ************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
  int N;
  printf("Enter the number of students: ");
  scanf("%d", &N);
  char name[N][20];
  int chinese[N];
  int english[N];

  /* Ū�� N �Ӿǥ͸�� */
  for (int i = 0; i < N; ++i) {
    int no = i+1;
	  printf("No. %d:\n", no);
    printf("Please enter the name: ");
    scanf("%s", name[i]);
    printf("Please enter the grade of Chinese: ");
    scanf("%d", &chinese[i]);
    printf("Please enter the grade of English: ");
    scanf("%d", &english[i]);
    printf("\n");
  }

  int cmd;
  system("cls");
  printf("1. Query\n");
  printf("2. Quit\n");
  printf("Please enter your request: ");
  scanf("%d", &cmd);
  while (cmd != 2) {
    switch(cmd) {
      case 1: /* Query */
      {
        int no;
        printf("Please enter the No: ");
        scanf("%d", &no);

        int i = no-1;
        /* ��ܬY�Ӿǥ͸�� */
        printf("Name: %s\n", name[i]);
        printf("Chiense: %d\n", chinese[i]);
        printf("English: %d\n", english[i]);
        printf("Average: %lf\n", (english[i]+chinese[i])/2.);
        int max = english[i];
        if (max < chinese[i]) {
          max = chinese[i];
        }
        printf("Max: %d\n", max);
        system("pause");
        break;
      }
      default:
        printf("Please enter a number between 1 and 2.\n");
        break;
    }

    system("cls");
    printf("1. Query\n");
    printf("2. Quit\n");
    printf("Please enter your request: ");
    scanf("%d", &cmd);
  }
	system("pause");
	return 0;
}
