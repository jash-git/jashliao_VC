/*****************************************************
 * [�ɮ�] student_2.cpp
 *        (�ǲΥΪk: �ϥβΤ@�� struct)
 ****************************************************/
  
#include <stdio.h>
#include <stdlib.h>
 
enum StudentType { GENERAL, SCIENCE };
// #define GENERAL 0
// #define SCIENCE 1

struct Student {
  char name[20];
  int  chinese;
  int  english;
  int  math;
  StudentType type;
};

void read(Student *s);
void show(const Student *s);

int main() {
  Student sts[2];
  sts[0].type = GENERAL;
  sts[1].type = SCIENCE;
  
  for (int i = 0; i < 2; i++) { 
    read(&sts[i]);
    printf("\n");
  }

  for (int i = 0; i < 2; i++) {
    show(&sts[i]);
    printf("\n");
  }
      
  system("pause");
  return 0;
}

void read(Student *s) {
  printf("�п�J�m�W: ");
  scanf("%s", s->name);
  printf("�п�J���妨�Z: ");
  scanf("%d", &s->chinese);
  printf("�п�J�^�妨�Z: ");
  scanf("%d", &s->english);

  if (s->type == SCIENCE) {
    printf("�п�J�ƾǦ��Z: ");
    scanf("%d", &s->math);    
  }
  return; 
}

void show(const Student *s) {
  printf("�m�W: %s\n", s->name);
  printf("����: %d\n", s->chinese);
  printf("�^��: %d\n", s->english); 
  
  if (s->type == SCIENCE) {
    printf("�ƾ�: %d\n", s->math);
  }
  return;
}
