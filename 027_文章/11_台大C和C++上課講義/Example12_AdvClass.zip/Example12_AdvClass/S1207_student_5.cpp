/*****************************************************
 * [�ɮ�] student_5.cpp
 ****************************************************/
  
#include <stdio.h>
#include <stdlib.h>

class GeneralStudent {
  protected:
    char _name[20];
    int  _chinese;
    int  _english;
    
  public:
    virtual void read();
    virtual void show();
};

class ScienceStudent : public GeneralStudent {
  private:
    int  _math;
  
  public:
    void read();
    void show();
};

int main() {
  GeneralStudent *sts[2];
  sts[0] = new GeneralStudent;
  sts[1] = new ScienceStudent;
  
  for (int i = 0; i < 2; i++) {
    sts[i]->read();
    printf("\n");
  }
  
  for (int i = 0; i < 2; i++) {
    sts[i]->show();
    printf("\n");
  }
    
  system("pause");
  return 0;
}

void GeneralStudent::read() {
  printf("�п�J�m�W: ");
  scanf("%s", _name);
  printf("�п�J���妨�Z: ");
  scanf("%d", &_chinese);
  printf("�п�J�^�妨�Z: ");
  scanf("%d", &_english);
  return; 
}

void GeneralStudent::show() {
  printf("�m�W: %s\n", _name);
  printf("����: %d\n", _chinese);
  printf("�^��: %d\n", _english); 
  return;
}

void ScienceStudent::read() {
  GeneralStudent::read();
  printf("�п�J�ƾǦ��Z: ");
  scanf("%d", &_math);
  return; 
}

void ScienceStudent::show() {
  GeneralStudent::show();
  printf("�ƾ�: %d\n", _math); 
  return;
}
