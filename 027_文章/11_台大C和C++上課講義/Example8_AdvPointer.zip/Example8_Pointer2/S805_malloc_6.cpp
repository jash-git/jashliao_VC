/* ���c�� */ 
#include <stdio.h>
#include <stdlib.h>

// �ڭ̷s�W�@�� struct Array �h�]�� 
struct Array {
    int size;
    int *items;
};

Array createArray();
void releaseArray(Array);
 
void append(Array *, int);
void print(Array);

int main() {
    Array grade = createArray(); 
    while (1) {
        int input;
        printf(
            "�п�J�� %d ��ǥͪ����Z: ",
            grade.size+1);
        scanf("%d", &input);
        if (input < 0) { break;}
        append(&grade, input);
    }
    printf("�`�@�� %d ��ǥ�\n", grade.size);
    print(grade);
    releaseArray(grade); 
    system("pause");
    return 0;
}

Array createArray() {
    Array ret;
    ret.size = 0;
    ret.items = NULL;
    return ret;
}

void releaseArray(Array arr) {
    free(arr.items);
    return;
} 
  
 
void append(Array *arr, int item) {
    int *new_arr =
        (int *)malloc(sizeof(int)*(arr->size+1));
 
    for (int i = 0; i < arr->size; i++) {
        new_arr[i] = arr->items[i];
    }
    new_arr[arr->size] = item;
    free(arr->items);
    arr->items = new_arr;
    arr->size++; 
    return;
}


void print(Array arr) {
    for (int i = 0; i < arr.size; i++) {
        printf(
            "�� %d �즨�Z�� %d.\n", 
            i+1,
            arr.items[i]);
    }
    return;
}
