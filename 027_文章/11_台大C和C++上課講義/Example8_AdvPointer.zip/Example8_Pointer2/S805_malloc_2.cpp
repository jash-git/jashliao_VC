#include <stdio.h>
#include <stdlib.h>

int main() {
    int size = 0;
    int *grade; // �N grade �ŧi������ 
    while (1) {
        int input;
        printf("�п�J�� %d ��ǥͪ����Z: ", size+1);
        scanf("%d", &input);
        if (input < 0) { break;}

        int new_grade[size+1];
        
        for (int i = 0; i < size; i++) {
            new_grade[i] = grade[i];
        }
        
        new_grade[size] = input;
        grade = new_grade;
        // (int*) = (int []) �O�X�k�� ! 
        size++; 
    }
    printf("�`�@�� %d ��ǥ�\n", size);
    for (int i = 0; i < size; i++) {
        printf("�� %d �즨�Z�� %d.\n", i+1, grade[i]);
    } 
    system("pause");
    return 0;
}
