/* �禡�� */ 
#include <stdio.h>
#include <stdlib.h>

void append(int **, int *, int);
void print(int *, int);

int main() {
    int size = 0;
    int *grade = NULL;
 
    while (1) {
        int input;
        printf("�п�J�� %d ��ǥͪ����Z: ", size+1);
        scanf("%d", &input);
        if (input < 0) { break; }

        // �`�N���O append �|�ק� grade �x�s���� (��}) 
        // �ҥH�ݭn�N grade ����}�ǵ� append 
        append(&grade, &size, input);
    }
    printf("�`�@�� %d ��ǥ�\n", size);
    print(grade, size);
    free(grade);
    system("pause");
    return 0;
}
 
void append(int **grade, int *size, int item) {
    int *new_grade =
        (int *)malloc(sizeof(int)*(*size+1));
 
    for (int i = 0; i < *size; i++) {
        new_grade[i] = (*grade)[i];
    }
    new_grade[*size] = item;
    free(*grade);
    *grade = new_grade; 
    (*size)++; 
    return;
}


void print(int *grade, int size) {
    for (int i = 0; i < size; i++) {
        printf("�� %d �즨�Z�� %d.\n", i+1, grade[i]);
    } 
    return;
}
