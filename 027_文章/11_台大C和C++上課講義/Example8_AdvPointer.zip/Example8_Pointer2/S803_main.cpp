#include <stdio.h>
#include <stdlib.h>

int max(int N, int *v) {
  int m = v[0];
  for (int i = 1; i < N; ++i) {
    if (v[i] > m) {
      m = v[i];
    }
  }
  return m;
}

int main(int argc, char* argv[]) {
  int N = argc-1;
  if (N == 0) {
    printf("Usage: main integer1 integer2 integer3 ...");
    return -1;
  }
  int v[argc-1];
  for (int i = 1; i < argc; ++i) {
    v[i-1] = atoi(argv[i]); // atoi �|�N�r���ഫ����� 
  }
  printf("%d\n", max(N, v));
  system("pause");
  return 0;
}
