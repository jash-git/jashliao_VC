#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
  if (argc == 1) {
    printf("Usage: Please drag-and-drop file on the executable file.\n");
    return 0;
  }
  printf("File: %s\n", argv[1]);
  system("pause");
  return 0;
}
