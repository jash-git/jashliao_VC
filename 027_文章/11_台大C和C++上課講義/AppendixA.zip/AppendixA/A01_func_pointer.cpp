#include <stdio.h>
#include <stdlib.h>

int add(int a, int b) {
  return a + b;
}

int main() {
  int (*f)(int, int) = add;
  printf("���G��: %d\n", (*f)(3, 4));
  printf("���G��: %d\n", f(3, 4));
  system("pause");
  return 0;
}
