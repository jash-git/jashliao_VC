/* �ϥΨ禡�ӥ]�˵{���X */
#include <stdio.h>
#include <stdlib.h>
void swap(int *, int *);
void input(int *, int);
void print(int *, int);
void sort(int *, int);

int main() {
  const int NUM_DATA = 5;
  int data[NUM_DATA];
  /* ��J */ 
  input(data, NUM_DATA);

  /* �C�L */ 
  printf("�Ƨǫe, �̧ǬO: \n"); 
  print(data, NUM_DATA);

  /* �Ƨ� */ 
  sort(data, NUM_DATA);

  /* �C�L */ 
  printf("�Ƨǫ�, �̧ǬO:\n");
  print(data, NUM_DATA);

  system("pause");
  return 0;
}

void swap(int *a, int *b) {
  int t = *a;
  *a = *b;
  *b = t;
}

void input(int *data, int N) {
  for (int i = 1; i <= N; i++) {
    printf("�п�J�� %d �ӼƦr: ", i);
    scanf("%d", &data[i-1]); 
  }
}

void print(int *data, int N) {
  for (int i = 0; i < N; i++) {
    printf("%d ", data[i]);
  }
  printf("\n");
}

void sort(int *data, int N) {
   for (int i = 0; i < N-1; i++) {
    for (int j = i+1; j < N; j++) {
      if (data[i] > data[j]) {
        swap(&data[i], &data[j]);
      }
    } 
  }
} 
