/* �N�禡�@���ѼƶǤJ�禡 */ 
#include <stdio.h>
#include <stdlib.h>
int add(int a, int b) { return a+b; }
int mul(int a, int b) { return a*b; }
int acc(int *, int, int (*)(int, int) );
 
int main() {
  const int NUM_DATA = 5;
  int data[NUM_DATA];
  for (int i = 1; i <= NUM_DATA; i++) {
    printf("�п�J�� %d �ӼƦr: ", i);
    scanf("%d", &data[i-1]);
  }
  printf("�M�� %d\n", acc(data, NUM_DATA, add));
  printf("�s���n�� %d\n", acc(data, NUM_DATA, mul)); 
  system("pause");
  return 0;
}

int acc(int *data, int N, int (*f)(int, int) ) {
  int ret = data[0];
  for (int i = 1; i < N; i++) {
    ret = f(ret, data[i]);
  } 
  return ret;
}
