#include <stdio.h>
#include <stdlib.h>
int sum(int *, int);
int fac(int *, int);
 
int main() {
  const int NUM_DATA = 5;
  int data[NUM_DATA];
  for (int i = 1; i <= NUM_DATA; i++) {
    printf("�п�J�� %d �ӼƦr: ", i);
    scanf("%d", &data[i-1]);
  }
  printf("�M�� %d\n", sum(data, NUM_DATA));
  printf("�s���n�� %d\n", fac(data, NUM_DATA)); 
  system("pause");
  return 0;
}

int sum(int *data, int N) {
  int ret = data[0];
  for (int i = 1; i < N; i++) {
    ret = ret + data[i];
  } 
  return ret;
}

int fac(int *data, int N) {
  int ret = data[0];
  for (int i = 1; i < N; i++) {
    ret = ret * data[i]; 
  }
  return ret;
}
