/* �ϥ� const �өw�q�ϰ�`�� (C++ style) */
#include <stdio.h>
#include <stdlib.h>
void swap(int *, int *);

int main() {
  const int NUM_DATA = 5;
  int data[NUM_DATA];
  /* ��J */ 
  for (int i = 1; i <= NUM_DATA; i++) {
    printf("�п�J�� %d �ӼƦr: ", i);
    scanf("%d", &data[i-1]); 
  }

  /* �C�L */ 
  printf("�Ƨǫe, �̧ǬO: \n"); 
  for (int i = 0; i < NUM_DATA; i++) {
    printf("%d ", data[i]);
  }
  printf("\n");

  /* �Ƨ� */ 
  for (int i = 0; i < NUM_DATA-1; i++) {
    for (int j = i+1; j < NUM_DATA; j++) {
      if (data[i] > data[j]) {
        swap(&data[i], &data[j]);
      }
    } 
  }
  /* �C�L */ 
  printf("�Ƨǫ�, �̧ǬO:\n");
  for (int i = 0; i < NUM_DATA; i++) {
    printf("%d ", data[i]);
  }
  printf("\n");
  system("pause");
  return 0;
}

void swap(int *a, int *b) {
  int t = *a;
  *a = *b;
  *b = t;
}
