#include <windows.h>
#include <stdio.h> 
#include <stdlib.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int CALLBACK WinMain(
  HINSTANCE h,
  HINSTANCE,
  LPSTR,
  int nCmdShow) {

  WNDCLASS wc = {0};
  wc.lpszClassName = TEXT( "Window" );
  wc.hInstance     = h;
  wc.hbrBackground = GetSysColorBrush(COLOR_3DFACE);
  wc.lpfnWndProc   = WndProc;
  wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
  
  RegisterClass(&wc);

  HWND hwnd = CreateWindow(
    wc.lpszClassName,
    TEXT("�[�k��"),
    WS_OVERLAPPEDWINDOW | WS_VISIBLE,
    100, 100,
    250, 80,
    NULL, NULL, h,NULL); 
  ShowWindow(hwnd, nCmdShow);
  UpdateWindow(hwnd);
  
  MSG  msg;
  while( GetMessage(&msg, NULL, 0, 0)) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  return (int) msg.wParam;
}


LRESULT CALLBACK WndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
  static HWND edit1;
  static HWND edit2;
  static HWND result;

  switch(msg)  
  {
    case WM_CREATE:
    {
      edit1 = CreateWindow(
        TEXT("edit"),
        NULL,
        WS_VISIBLE | WS_CHILD | WS_BORDER,
				10, 10, 50, 20,
        hwnd, (HMENU) 1, NULL, NULL);

      CreateWindow(
        TEXT("static"),
        TEXT("+"), 
		    WS_VISIBLE | WS_CHILD | SS_CENTER,
		    60, 10, 20, 20,
		    hwnd, NULL, NULL, NULL);

      edit2 = CreateWindow(
        TEXT("edit"),
        NULL,
        WS_VISIBLE | WS_CHILD | WS_BORDER,
				80, 10, 50, 20,
        hwnd, (HMENU) 2, NULL, NULL);

	    CreateWindow(
        TEXT("button"),
        TEXT("="),    
		    WS_VISIBLE | WS_CHILD ,
		    130, 10, 20, 20,        
		    hwnd, (HMENU) 3, NULL, NULL);    

      result = CreateWindow(
        TEXT("static"),
        TEXT("0"), 
		    WS_VISIBLE | WS_CHILD | SS_RIGHT,
		    150, 10, 40, 20,
		    hwnd, NULL, NULL, NULL);
	    break;
    }
  
    case WM_COMMAND:
    {
      if (LOWORD(wParam) == 3 &&
        HIWORD(wParam) == BN_CLICKED) {
        int len1 = GetWindowTextLength(edit1) + 1;
        char text1[len1];
        GetWindowText(edit1, text1, len1);
        
        int len2 = GetWindowTextLength(edit2) + 1;
        char text2[len2];
        GetWindowText(edit2, text2, len2); 
         
        char output[255];
        sprintf(output, "%d", atoi(text1)+atoi(text2));
        SetWindowText(result, output);  
     } 
      break;
    }
    case WM_DESTROY:
      {
        PostQuitMessage(0);
        return 0;
      }
  }
  return DefWindowProc(hwnd, msg, wParam, lParam);
}
