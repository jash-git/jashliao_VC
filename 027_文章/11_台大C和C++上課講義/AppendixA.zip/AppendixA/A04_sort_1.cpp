/* �ϥΪw�j�ƧǪk�Ƨǡ@*/
#include <stdio.h>
#include <stdlib.h>
void swap(int *, int *);
int main() {
  int data[5];
  /* ��J */ 
  for (int i = 1; i <= 5; i++) {
    printf("�п�J�� %d �ӼƦr: ", i);
    scanf("%d", &data[i-1]); 
  }

  /* �C�L */ 
  printf("�Ƨǫe, �̧ǬO: \n"); 
  for (int i = 0; i < 5; i++) {
    printf("%d ", data[i]);
  }
  printf("\n");

  /* �Ƨ� */ 
  for (int i = 0; i < 4; i++) {
    for (int j = i+1; j < 5; j++) {
      if (data[i] > data[j]) {
        swap(&data[i], &data[j]);
      }
    } 
  }
  /* �C�L */ 
  printf("�Ƨǫ�, �̧ǬO:\n");
  for (int i = 0; i < 5; i++) {
    printf("%d ", data[i]);
  }
  printf("\n");
  system("pause");
  return 0;
}

void swap(int *a, int *b) {
  int t = *a;
  *a = *b;
  *b = t;
}
