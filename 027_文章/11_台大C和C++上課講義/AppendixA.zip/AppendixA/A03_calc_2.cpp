/* �禡���а}�C */
#include <stdio.h>
#include <stdlib.h>
double add(int a, int b) { return a+b; }
double sub(int a, int b) { return a-b; }
double mul(int a, int b) { return a*b; }
double divide(int a, int b) { return (double)a/b; }
 
int main() {
  int n1, n2;
  char op;
  double ans;
  scanf("%d%c%d", &n1, &op, &n2);
  const int NUM_ACTIONS = 4;
  char ops[NUM_ACTIONS] = {'+', '-', '*', '/'};

  /* actions �O�@�Ө禡���Ъ��}�C */ 
  double (*actions[NUM_ACTIONS])(int, int) = {
    add, sub, mul, divide};

  for (int i = 0; i < NUM_ACTIONS; i++) {
    if (ops[i] == op) {
       ans = actions[i](n1, n2);
    }
  }

  printf("ANS: %.2f\n", ans);
  system("pause");
  return 0;
}
/* �����m��: �յۥ[�J�D��ƪ��禡 */ 
