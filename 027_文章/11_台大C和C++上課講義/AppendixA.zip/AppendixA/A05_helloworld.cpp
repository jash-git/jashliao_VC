#include <windows.h>

int CALLBACK WinMain(
  HINSTANCE,
  HINSTANCE,
  LPSTR,
  int) {
  MessageBox(
    NULL,
    TEXT("Hello world!"),
    TEXT("My First Program"),
    MB_OK); 
  return 0;
}
