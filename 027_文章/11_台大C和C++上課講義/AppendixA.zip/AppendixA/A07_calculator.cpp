#include <windows.h>
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int CALLBACK WinMain(
  HINSTANCE h,
  HINSTANCE,
  LPSTR,
  int nCmdShow) {

  WNDCLASS wc = {0};
  wc.lpszClassName = TEXT( "Window" );
  wc.hInstance     = h;
  wc.hbrBackground = GetSysColorBrush(COLOR_3DFACE);
  wc.lpfnWndProc   = WndProc;
  wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
  
  RegisterClass(&wc);

  HWND hwnd = CreateWindow(
    wc.lpszClassName,
    TEXT("�[�k��"),
    WS_OVERLAPPEDWINDOW | WS_VISIBLE,
    100, 100,
    250, 80,
    NULL, NULL, h,NULL); 
  ShowWindow(hwnd, nCmdShow);
  UpdateWindow(hwnd);
  
  MSG  msg;
  while( GetMessage(&msg, NULL, 0, 0)) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  return (int) msg.wParam;
}


LRESULT CALLBACK WndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
  switch(msg)  
  {
    case WM_CREATE:
    {
      CreateWindow(
        TEXT("edit"),
        NULL,
        WS_VISIBLE | WS_CHILD | WS_BORDER,
				10, 10, 50, 20,
        hwnd, NULL, NULL, NULL);

      CreateWindow(
        TEXT("static"),
        TEXT("+"), 
		    WS_VISIBLE | WS_CHILD | SS_CENTER,
		    60, 10, 20, 20,
		    hwnd, NULL, NULL, NULL);

      CreateWindow(
        TEXT("edit"),
        NULL,
        WS_VISIBLE | WS_CHILD | WS_BORDER,
				80, 10, 50, 20,
        hwnd, NULL, NULL, NULL);

	    CreateWindow(
        TEXT("button"),
        TEXT("="),    
		    WS_VISIBLE | WS_CHILD ,
		    130, 10, 20, 20,        
		    hwnd, NULL, NULL, NULL);    

      CreateWindow(
        TEXT("static"),
        TEXT("0"), 
		    WS_VISIBLE | WS_CHILD | SS_RIGHT,
		    150, 10, 40, 20,
		    hwnd, NULL, NULL, NULL);

	    break;
	}

    case WM_DESTROY:
      {
        PostQuitMessage(0);
        return 0;
      }
  }
  return DefWindowProc(hwnd, msg, wParam, lParam);
}
