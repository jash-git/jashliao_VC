#include <stdio.h>
#include <stdlib.h>

void test() {
  test();
  return;
}

int main() {
  test(); 
	system("pause");
	return 0;
}
