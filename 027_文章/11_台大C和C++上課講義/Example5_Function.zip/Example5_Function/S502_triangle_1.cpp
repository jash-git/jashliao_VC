#include <stdio.h>
#include <stdlib.h>

void draw_stars(int len);

int main() {
	int num;

	printf("Please enter an integer  : ");
	scanf("%d", &num);

	for (int i = 1; i <= num; i++) {
		draw_stars(i);
	}
	system("pause");
	return 0;
}

void draw_stars(int len) {
	for (int i = 1; i <= len; i++) {
		printf("*");
	}
	printf("\n");
	return;
}
