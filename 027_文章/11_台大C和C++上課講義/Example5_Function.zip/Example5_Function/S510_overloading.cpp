#include <stdio.h>
#include <stdlib.h>

void print(int v) { printf("%d\n", v); }
void print(double v) { printf("%f\n", v); }

int main() {
  print(3);    // �I�s print(int) 
  print(3.0);  // �I�s print(double) 
  system("pause");
  return 0;
}
