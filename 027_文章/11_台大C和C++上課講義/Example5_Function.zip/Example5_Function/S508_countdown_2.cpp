#include <stdio.h>
#include <stdlib.h>
void countdown(int count) {
  if (count != 0) {
    countdown(count-1);
  }
  printf("%d\n", count);
  return;
}

int main() {
  countdown(10);
  system("pause");
  return 0;
} 
