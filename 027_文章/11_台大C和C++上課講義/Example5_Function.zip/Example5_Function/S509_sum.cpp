#include <stdio.h>
#include <stdlib.h>

int sum(int N) {
  if (N == 1) {
    return 1;
  } else {
    return N + sum(N-1);
  }
}

int main() {
  int N;
  printf("N = ");
  scanf("%d", &N);
  printf("Sum = %d\n", sum(N));
  system("pause");
  return 0;
}
