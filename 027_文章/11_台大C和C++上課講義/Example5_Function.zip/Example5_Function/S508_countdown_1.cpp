#include <stdio.h>
#include <stdlib.h>
void countdown(int count) {
  printf("%d\n", count);
  if (count != 0) {
    countdown(count-1);
  }
  return;
}

int main() {
  countdown(10);
  system("pause");
  return 0;
} 
