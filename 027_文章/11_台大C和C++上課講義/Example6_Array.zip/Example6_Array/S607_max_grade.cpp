/**********************************************************
 * [�ɮ�] max_grade (���Z��J) 
 * [�@��] Ken-Yi Lee (feis.tw@gmail.com) 
 * [�`�N] �]���оǻݭn, �ڭ̨ϥΤ�����ѨӸ����{���X
 *        �@���ȤW���קK�ϥΤ��� 
 *********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    const int MAX_LEN = 80;
    char name[MAX_LEN+1];
    char max_name[MAX_LEN+1] = {"Empty"};
    int max_grade = 0;
    int grade;

    printf("Please enter the name: ");
    scanf("%s", name);
    if (strcmp(name, "quit") != 0) {
        printf("Please enter the grade: ");
        scanf("%d", &grade);
        strcpy(max_name, name);
        max_grade = grade;

        while(1) {
            printf("Please enter the name: ");
            scanf("%s", name);
            if (strcmp(name, "quit") == 0) break;
            printf("Please enter the grade: ");
            scanf("%d", &grade);
            if (grade > max_grade) {
                strcpy(max_name, name);
                max_grade = grade;
            }
        } 
    }
    printf("Best: %s (%d)\n", max_name, max_grade);
    system("pause");
    return 0;
}
