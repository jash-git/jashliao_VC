#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int fib(int);
  int s;
  printf("Please input 'n' of fib(n)=? ");
  scanf("%d",&s);
  printf("fib(%d)=%d",s,fib(s));
  system("pause");
  return 0;
}
int fib(int n)
{
  if(n==0) return(0);
  else if(n==1) return(1);
  else return (fib(n-1)+fib(n-2));
}
