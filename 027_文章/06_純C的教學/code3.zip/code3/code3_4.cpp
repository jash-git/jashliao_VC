#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int fact(int);
  int s;
  printf("Please input a number : ");
  scanf("%d",&s);
  printf("%d!=%d\n",s,fact(s));
  system("pause");
  return 0;
}
int fact(int n)
{
  if(n==0) return(1);
  else return(n*fact(n-1));
}
