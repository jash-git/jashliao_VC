#include <stdio.h>
#include <stdlib.h>

int main()
{
  int sum(int);
  int s;
  printf("Please input a number : ");
  scanf("%d",&s);
  printf("sum(%d)=%d",s,sum(s));
  system("pause");
  return 0;
}
int sum(int n)
{
  if(n==1) return(n);
  else return(n+sum(n-1));
}
