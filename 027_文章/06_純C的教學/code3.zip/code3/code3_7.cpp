#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main( )
{
  double a,b,c,d,x=-100.0;
  a=fabs(x);
  b=exp(1.0);
  c=sqrt(a);
  d=log10(a);
  printf("fabs(-100.0)  =%f\n",a);
  printf("exp(1.0)      =%f\n",b);
  printf("log(2.718282) =%f\n",log(b));
  printf("sqrt(100.0)   =%f\n",c);
  printf("log10(10.0)   =%f\n",log10(c));
  printf("pow(10,2)     =%f\n",pow(c,d));
  system("pause");
  return 0;
}
