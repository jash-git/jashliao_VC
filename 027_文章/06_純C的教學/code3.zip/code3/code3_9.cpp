#include <stdio.h>
#include <stdlib.h>

static int a=1;
void fun(void);
int main( )
{
  int i;
  printf("static extern a=%d\n",a);
  printf("\n");
  for(i=0;i<3;i++)
	 fun( );
  system("pause");
  return 0;
}
void fun(void)
{
  static int b=1;
  int c=1;
  printf("static extern a=%d\n",a);
  printf("static auto b=%d\n",b);
  printf("auto c=%d\n",c);
  printf("\n");
  a++;
  b++;
  c++;
}

