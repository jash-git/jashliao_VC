#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(){
    int i,j,a;
    unsigned seed;
    time_t t;
    t=time(NULL);
    
    printf("time1=%d\t", t);

    for (i=0;i<10000;i++)
        for (j=0;j<30000;j++)
                a=0;    
    
    t=time(NULL);
    printf("time2=%d\t", t);

   system("pause");
   return 0;

}
