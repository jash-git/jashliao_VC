#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int x=10,y=5,z;
  int sum(int,int);
  z=sum(x,y);
  printf("sum(%d,%d)=%d\n",x,y,z);
  system("pause");
  return 0;
}
int sum(int a,int b)
{
  int c;
  c=a+b;
  return c;
}


