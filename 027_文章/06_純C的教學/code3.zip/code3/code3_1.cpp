#include <stdio.h>
#include <stdlib.h>

int main( )
{
  void test(void);
  test( );
  system("pause");
  return 0;
}
void test(void)
{
  printf("This is a test!\n");
}

