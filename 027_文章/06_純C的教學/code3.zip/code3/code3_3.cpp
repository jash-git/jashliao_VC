#include <stdio.h>
#include <stdlib.h>

int sum(int a,int b)
{
  int c;
  c=a+b;
  return c;
}
int main( )
{
  int x=10,y=5,z;
  z=sum(x,y);
  printf("sum(%d,%d)=%d\n",x,y,z);
  system("pause");
  return 0;
}

