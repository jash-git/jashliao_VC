#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(){
int i,j;
unsigned seed;

for (j=0;j<3;j++){
    printf("Enter seed:");
    scanf("%u", &seed);
    srand(seed); 
   for (i=0;i<10;i++)
        printf("%d\t", rand());
    printf("\n");
}
system("pause");
return 0;

}
