#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct student{  
char   stu_id[12]; 
int    ScoreComputer;  
int    ScoreMath; 
 int    ScoreEng;  
 float  ScoreAvg;
};
 
int main(){ 
  int score[3][3]={{89,84,75},{77,69,87},{65,68,77}};
  struct student CSIE[3]; 
  struct student tmpStu; 
  int i,Total;  
  strcpy(CSIE[0].stu_id,"u92922001"); 
  strcpy(CSIE[1].stu_id,"u92922002"); 
  strcpy(CSIE[2].stu_id,"u92922003");
  
   for(i=0;i<3;i++) {     
   Total=0;     
   CSIE[i].ScoreComputer=score[i][0];     
   CSIE[i].ScoreMath    =score[i][1];     
   CSIE[i].ScoreEng     =score[i][2];     
   Total=score[i][0]+score[i][1]+score[i][2];     
   CSIE[i].ScoreAvg=((float)Total)/3; 
   }  
   printf("�Ǹ�\t\t�p��\t�ƾ�\t�^��\t����\n"); 
   printf("---------------------------------------------------\n"); 
   for(i=0;i<3;i++) {    
    tmpStu=CSIE[i];     
    printf("%s\t%d\t%d\t%d\t%.4f\n",\            
    tmpStu.stu_id,tmpStu.ScoreComputer,tmpStu.ScoreMath,\            
    tmpStu.ScoreEng,tmpStu.ScoreAvg); 
   } 
    system("pause");
    return 0;
}


