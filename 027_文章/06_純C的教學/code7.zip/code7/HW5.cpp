#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

    int i=0;
    void create(void);
    void listall(void);
    void sort(void);
    int query(void);
    
    struct employee
    {    char name[11];
         int  age;
         char address[31];
         int  salary;
         char phone[11];  
    }data[10];

int main()
{
    printf("\t*******************************\n");
    printf("\t*          NOTICE             *\n");
    printf("\t* 1.���u�m�W���o�W�L10�Ӧr��  *\n");
    printf("\t* 2.���u���}���o�W�L30�Ӧr��  *\n");
    printf("\t* 3.���u�q�ܤ��o�W�L10��Ʀr  *\n");
    printf("\t*******************************\n");
    
    char input;
    do{
         printf("\n");
         printf("----------------------------------------------\n");
         printf(" �إ߭��u��� ----------->�Ы� 1 \n");
         printf(" �C�X�Ҧ����u��� ------->�Ы� 2 \n");
         printf(" �d�߭��u��� ----------->�Ы� 3 \n");
         printf(" ���} ------------------->�Ы� 4 \n"); 
      
         do{
            printf("\n �п�J : ");
            scanf(" %c",&input);
           }
         while(input!='1'&&input!='2'&&input!='3'&&input!='4');
         if (input!='4')
         {
            switch(input)
            {  case '1':
                   create();
                   break;
               case '2':
                   listall();
                   break;
               case '3':
                   query();
                   break;
             }
         }
          else
             printf("\n Bye Bye ^^ \n\n");
      }while(input!='4');     
    
    system("pause");
    return 0;
}

void create(void)
{
      printf(" Please input the name : ");
      scanf(" %s",&data[i].name);
      printf("\n Please input the age : ");
      scanf(" %d",&data[i].age);
      printf("\n Please input the address : ");
      scanf(" %s",&data[i].address);
      printf("\n Please input the salary : ");
      scanf(" %d",&data[i].salary);
      printf("\n Please input the phone No. :");
      scanf(" %s",&data[i].phone);
      i++;
}

void listall(void)
{    
     int j;
     sort();
     for(j=0;j<i;j++)
     {  
        printf("\temployee's name : %s \n",data[j].name);
        printf("\t            age : %d \n",data[j].age);
        printf("\t        address : %s \n",data[j].address);
        printf("\t         salary : %d \n",data[j].salary);
        printf("\t      phone No. : %s \n\n",data[j].phone);
     }
}

void sort(){
int k,m;
employee temp;


for(k=(i-1);k>0;k--) 
{  
  for(m=0;m<k;m++)
  {
       if(strcmp(data[m].name,data[m+1].name)>0)
        {
         temp=data[m];
         data[m]=data[m+1];
         data[m+1]=temp;   
    }   
  }
}
}

int query(void)
{    
     char query_name[11];
     int high=i, low=0, a;
     int k;
     printf("�п�J�z�n�d�ߪ����u�m�W : ");
     scanf(" %s",query_name);

   while (low<=high) {
       k= (low+high)/2;
	  if (!strcmp(query_name,data[k].name)) {
        printf("\temployee's name : %s \n",data[k].name);
        printf("\t            age : %d \n",data[k].age);
        printf("\t        address : %s \n",data[k].address);
        printf("\t         salary : %d \n",data[k].salary);
        printf("\t      phone No. : %s \n\n",data[k].phone);
	     return 1;
      }
      else if(strcmp(query_name,data[k].name)< 0)
            high=k-1;
      else low=k+1;

    }      
    printf("\n �d�L���u��� \n");  
    return 0;
     
}

