#include <stdio.h>
#include <stdlib.h>

int main()
{
  struct
  {
	 char name[20];
	 int num;
  }stud,*ptr;
  ptr=&stud;
  printf("�п�J�m�W:");
  scanf("%s",&ptr->name);
  printf("�п�J�y��:");
  scanf("%d",&ptr->num);

  printf("�m�W: %s\n",ptr->name);
  printf("�y��: %d\n",ptr->num);
  system("pause");
  return 0;
}
