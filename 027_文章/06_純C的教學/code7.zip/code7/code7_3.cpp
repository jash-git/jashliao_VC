#include <stdio.h>
#include <stdlib.h>

int main( )
{
 struct student
 {
  int year;
  int mon;
  int day;
  char name[20];
  int num;
 }stud;
 
 printf("Please input name : ");
 gets(stud.name);
 printf("Please input the number :");
 scanf("%d",&stud.num);
 printf("Please input the year :");
 scanf("%d",&stud.year);
 printf("Please input the month :");
 scanf("%d",&stud.mon);
 printf("Please input the day :");
 scanf("%d",&stud.day);
 
 printf("No. :%d\n",stud.num);
 printf("Name :%s\n" ,stud.name);
 printf("Year\\Month\\day :%d\\%d\\%d\n", stud.year, stud.mon, stud.day);
 system("pause");
 return 0;
}
