#include<stdio.h>
#include<stdlib.h>

struct grade
{
  int math;
  int engl;
};
  struct all
{
  struct grade mem1;
  struct grade mem2;
};

int main()
{
  struct all member={76,67,78,87};
  printf("mem1:%4d%4d\n",member.mem1.math,member.mem1.engl);
  printf("mem2:%4d%4d\n",member.mem2.math,member.mem2.engl);
  system("pause");
  return 0;
}


