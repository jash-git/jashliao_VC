#include <stdio.h>
#include <stdlib.h>

int main( )
{
 struct student
 {
  int year;
  int mon;
  int day;
  char name[20];
  int num;
 }stud;
 
 struct student *pstud;    
 printf("Please input name : ");
 gets(stud.name);
 printf("Please input the number :");
 scanf("%d",&stud.num);
 printf("Please input the year :");
 scanf("%d",&stud.year);
 printf("Please input the month :");
 scanf("%d",&stud.mon);
 printf("Please input the day :");
 scanf("%d",&stud.day);
 pstud=&stud;
 
 printf("No. :%d\n",pstud->num);
 printf("Name :%s\n" ,pstud->name);
 printf("Year\\Month\\day :%d\\%d\\%d\n", pstud->year, pstud->mon, pstud->day);
 system("pause");
 return 0;
}
