#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main( )
{
 struct student
 {
	char name[10];
	int num;
 }information;
 strcpy(information.name,"Bill Lin");
 information.num=49;
 printf("The student's name is %s \n",information.name);
 printf("The student's number is %d \n",information.num);
 system("pause");
 return 0;
}
