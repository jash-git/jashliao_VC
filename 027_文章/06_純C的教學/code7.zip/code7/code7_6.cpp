#include<stdio.h>
#include<stdlib.h>

struct student
{
   char name[20];
   int num;
}stud;
  
void print(char name_f[20],int num_f);

int main()
{
  
  printf("��J�ǥͩm�W:");
  gets(stud.name);
  printf("��J�ǥͮy��:");
  scanf("%d",&stud.num);
  print(stud.name,stud.num);
  system("pause");
  return 0;
}

void print(char name_f[20],int num_f)
{
  printf("�m�W :%s\n",name_f);
  printf("�y�� :%d\n",num_f);
}
