#include <stdio.h>
#include <stdlib.h>

struct typeall
{
  char ch;
  int i;
  float f;
};
int main()
{
  struct typeall test={'a',123,1.23456};
  printf("test.ch=%c\n",test.ch);
  printf("test.i=%d\n",test.i);
  printf("test.f=%f",test.f);
  system("pause");
  return 0;
}
