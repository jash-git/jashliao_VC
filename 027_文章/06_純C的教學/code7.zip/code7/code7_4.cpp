#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct
{
  char num[10];
  char name[10];
  int grade;
}stud[5];

int main()
{
  int i;
  for(i=0;i<5;i++)
  {
	 printf("\n Input %dth student's number:",i+1);
	 scanf("%s",stud[i].num);
	 if(strcmp("exit",stud[i].num)==0)
		 break;
	 printf("\n Input %dth student's name:",i+1);
	 scanf("%s",stud[i].name);
	 printf("\n Input %dth student's grade:",i+1);
	 scanf("%d",&stud[i].grade);
  }
  for(i=0;i<5;i++)
  {
	 if(strcmp("exit",stud[i].num)==0)
	 break;
	 printf("\n number:%s\n",stud[i].num);
	 printf("name=%s\n",stud[i].name);
	 printf("trade=%d\n",stud[i].grade);
  }
  system("pause");
  return 0; 
}
