#include <stdio.h>
#include <stdlib.h>

int main()
{
  char input[25];
  puts("�п�J�r��: ");
  gets(input);
  puts(input);
  system("pause");
  return 0;
}

