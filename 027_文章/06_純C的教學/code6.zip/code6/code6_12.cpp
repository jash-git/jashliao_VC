#include <stdio.h>
#include <stdlib.h>

int count[52];
char test[53]="AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz";
char a[100];
int main()
{
  int i=0,k=0 ;
  printf("please input letters: ");
  gets (a);
  for ( i=0 ; a[i]!='\0';i++ )
	 for ( k=0;k<=51;k++ )
		if (a[i]==test[k])
		{
		  count[k] = count[k] + 1;
		  break;
		}
  for ( i=0;i<=51;i++ )
  {
	 printf("%c=%2d ",test[i],count[i]);
	 if((i+1)%7==0)
		printf ( "\n" );
  }
  system("pause");
  return 0;
}
