#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i=0;
  char str[]="C language";
  while(str[i]!='\0')
  {
	 printf("%c ",str[i]);
	 printf("%d\n",&str[i]);
	 i++;
  }
  system("pause");
  return 0;
}
