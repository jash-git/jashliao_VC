#include <stdio.h>
#include <stdlib.h>
int main(){   
 char *string;   
 double d;   
 int i;   
 long l;
 string = "2468";   
 l = atol( string );   
 printf("%s \t�ഫ��long=>%d\n",string,l);      
 string = "246jhchen";   
 l = atol( string );   
 printf("%s \t�ഫ��long=>%d\n",string,l);   
 string = "24689persons";   
 i = atoi( string );   
 printf("%s \t�ഫ��int=>%d\n",string,i);      
 string = "-2468.123E-7";   
 d = atof( string );   
 printf("%s \t�ഫ��double=>%.9f\n",string,d);   
 system("pause");
 return 0;
 }

