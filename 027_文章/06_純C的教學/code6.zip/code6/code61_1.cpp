#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){ 
char string1[]="Word:Excel:PowerPointer:C;Java;C++"; 

char delim1[]=":,;";   
char *Token;                    

printf("��l�r�ꬰ%s\n",string1); 
printf("�}�l����..........\n"); 
printf("Tokens(�y��)�p�U:\n");  
Token = strtok(string1,delim1); 
/* �N�Ĥ@�ӥy���s�JToken */ 

while(Token != NULL) {    
printf("%s\n",Token);    
Token = strtok(NULL,delim1); 
}   
 system("pause");  
 return 0;
}

