#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i;
  char str[7][10]={"SUNDAY","MONDAY","TUESDAY","WEDNESDAY",
				  "THURSDAY","FRIDAY","SATURDAY"};
  for(i=0;i<7;i++)
	 printf("%s\n",str[i]);
  system("pause");
  return 0;
}
