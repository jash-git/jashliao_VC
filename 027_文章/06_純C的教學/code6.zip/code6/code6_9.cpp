#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
  char first[20]="Hello ";
  char last[]="Bill";
  printf("�X�֫e  first: %s  last : %s\n",first,last);
  strcat(first,last);
  printf("�X�֫�  first: %s  last : %s",first,last);
  system("pause");
  return 0;
}

