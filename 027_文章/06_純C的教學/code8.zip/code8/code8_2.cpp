#include<stdio.h>
#include <stdlib.h>

int main( )
{
  FILE *fp;
  char c;
  fp=fopen("test.dat", "w");
  while((c=getchar())!=EOF)
	 putc(c,fp);
  fclose(fp);
  system("pause");
  return 0;
}
