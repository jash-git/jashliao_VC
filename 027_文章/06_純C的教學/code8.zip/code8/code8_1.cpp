#include <stdio.h>
#include <stdlib.h>

int main( )
{
  FILE *fp;
  int ret;
  if((fp=fopen("test.dat","r"))==NULL)
  {
	 printf("open file error!");
	 system("pause");
	 return 0;
  }
  else
    printf("open file success!");
  if((ret=fclose(fp))==0)
    printf("\nclose file success!");
  else
    printf("\nclose file error!");
  system("pause");
  return 0;  
}
