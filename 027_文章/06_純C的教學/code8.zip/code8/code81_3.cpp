#include <stdlib.h>
#include <stdio.h>
#include <string.h>
struct student{  
char   stu_id[12];  
int    ScoreComputer;  
int    ScoreMath; 
int    ScoreEng; 
 float  ScoreAvg;
 };
 FILE *fp;

int main(void){ 
  int score[3][3]={{90,74,76},                  
  {74,69,97},                  
  {65,64,67}}; 
  struct student CSIE[3]; 
  int i,Total,num;  
  strcpy(CSIE[0].stu_id,"d9292201"); 
  strcpy(CSIE[1].stu_id,"d9292202"); 
  strcpy(CSIE[2].stu_id,"d9292203"); 
  for(i=0;i<3;i++) {     
  Total=0;     
  CSIE[i].ScoreComputer=score[i][0];     
  CSIE[i].ScoreMath    =score[i][1];     
  CSIE[i].ScoreEng     =score[i][2];     
  Total=score[i][0]+score[i][1]+score[i][2];     
  CSIE[i].ScoreAvg=((float)Total)/3; 
  } 
  if((fp = fopen("data4", "w+b")) == NULL) {   
  printf("�ɮ׿��~\n");   exit(0);  }  
  num = fwrite(CSIE,sizeof(struct student),3,fp);  
  printf("�G�i���ɼg�J����\n"); 
  fclose(fp); 
  system("pause");

  return 0;
}


