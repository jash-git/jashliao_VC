#include<stdio.h>
#include<stdlib.h>

int main( )
{
  int c,r;
  char filename[20];
  FILE *stream;
  printf("please input a filename :" );
  scanf("%s", filename);
  if((stream=fopen(filename,"r"))==NULL)
	 printf("Can't open file ! \n");
  else
  while((c=fgetc(stream))!=EOF)
	 putchar(c);
  if((r=fclose(stream))!=NULL)
	 printf("Can't close file ! \n");
  system("pause");
  return 0;
}
