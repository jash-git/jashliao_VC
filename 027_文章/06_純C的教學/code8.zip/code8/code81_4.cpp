#include <stdlib.h>
#include <stdio.h>
struct student{  
char   stu_id[12];  
int    ScoreComputer;  
int    ScoreMath;  
int    ScoreEng;  
float  ScoreAvg;
};

FILE *fp;
void listall(struct student);
void listall(struct student tempStu){ 
 printf("%s\t%d\t%d\t%d\t%.4f\n",\           
  tempStu.stu_id,tempStu.ScoreComputer,tempStu.ScoreMath,\            
  tempStu.ScoreEng,tempStu.ScoreAvg);
}
 
int main(void){   
  struct student CSIE[50]; 
  int i,num;  
  if((fp = fopen("data4", "rb")) == NULL) {   
  printf("�ɮ׿��~\n");   
  exit(0);  
  }  
  num = fread(CSIE,sizeof(struct student),2,fp);  
  printf("�G�i����Ū������,�e�ⵧ�ǥ͸�Ʀp�U\n"); 
  fclose(fp);  
  for(i=0;i<2;i++)    
  listall(CSIE[i]); 
  system("pause"); 
  return 0;  
}


