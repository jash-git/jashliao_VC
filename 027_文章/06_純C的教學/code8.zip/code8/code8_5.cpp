#include<stdio.h>
#include<stdlib.h>

int main( )
{
  char s[20];
  FILE *fp;
  fp=fopen("test.dat","r+");
  fseek(fp,-10,2);
  gets(s);
  fputs(s,fp);
  fclose(fp);
  system("pause");
  return 0;
}
