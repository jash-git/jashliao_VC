#include<stdio.h>
#include<stdlib.h>

int main( )
{
  int i, eng, math;
  char file[15], num[5], name[20];
  FILE *fp;
  printf("Filename to output :");
  scanf("%s", file);
  fp=fopen(file,"w");
  for(i=0; i<3; i++)
  {
	 printf("\nNumber=");
	 scanf("%s",num);
	 printf("\nName=");
	 scanf("%s", name);
	 printf("\nEnglish score=");
	 scanf("%d", &eng);
	 printf("\nMath score=");
	 scanf("%d", &math);
	 fprintf(fp,"%s  %s  %d  %d\n", num, name, eng, math);
  }
  fclose(fp);
  system("pause");
  return 0;
}
