#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m=10,n=21;
  printf("m=%d n=%d\n",m,n);
  if(m>n)
	 printf("m>n\n");
  else
	 printf("m<=n\n");
  system("pause");
  return 0; 
}
