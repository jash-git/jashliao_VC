#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m=1,n;
  while(m<=9)
  {
	 for(n=1;n<=9;n++)
		printf("%4d",m*n);
	 printf("\n");
	 m++;
  }
  system("pause");
  return 0;
}
