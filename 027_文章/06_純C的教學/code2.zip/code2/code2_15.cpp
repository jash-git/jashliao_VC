#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m=0,n=0;
  printf("Enter 10 intergers(enter 0 for quit):\n");
  while(m++<10)
  {
	 printf("%d. ",m);
	 scanf("%d",&n);
	 if(n==0)
		break;
  }
  system("pause");
  return 0;
}
