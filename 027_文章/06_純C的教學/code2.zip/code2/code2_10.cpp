#include <stdio.h>
#include <stdlib.h>

int main()
{
 int i,k;
 for(i=6;i>=0;i--)
 {
   for(k=1;k<=i;k++)
   {
    printf("*");
   }
    printf("\n");
  }
  system("pause");
  return 0;
}
