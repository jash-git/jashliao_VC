#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m,sum=0;
  for(m=1;m<=100;m++)
	 sum+=m;
  printf("sum=%d\n",sum);
  system("pause");
  return 0;
}
