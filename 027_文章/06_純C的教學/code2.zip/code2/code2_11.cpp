#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m=1,sum=0;
  while(m<=100)
  {
	 sum+=m;
	 m++;
  }
  printf("sum=%d\n",sum);
  system("pause");
  return 0;
}
