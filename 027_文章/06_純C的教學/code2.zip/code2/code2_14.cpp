#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m,sum;
  sum=0;
  for(m=1;m<=99;m++)
  {
	 if((m%2)==0)
	   continue;
	 sum+=m;
  }
  printf("sum=%d\n",sum);
  system("pause");
  return 0;
}
