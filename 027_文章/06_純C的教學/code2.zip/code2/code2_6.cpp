#include <stdio.h>
#include <stdlib.h>

int main()
{
  char chemistry_element='m';
  switch(chemistry_element)
  {
	 case 'h': printf("Hydrogen\n") ; break;
	 case 'm': printf("Magnesium\n") ; break;
	 case 's': printf("Selenium\n") ; break;
  }
  printf("The end.\n");
  system("pause");
  return 0;
}
