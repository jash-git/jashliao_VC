#include <stdio.h>
#include <stdlib.h>

int main()
{
  int year;
  printf("Input a year:");
  scanf("%d",&year);
  if((year%4==0)&&(year%100!=0))
  {
	 printf("It is leap year�I\n");
  }
  else if(year%400==0)
  {
	 printf("It is leap year�I\n");
  }
  else
  {
	 printf("It is not leap year�I\n");
  }
  system("pause");
  return 0;
}
