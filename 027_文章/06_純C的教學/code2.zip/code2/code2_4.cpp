#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m,n;
  printf("Enter an integer for testing: ");
  scanf("%d",&n);
  m=n%2;
  if(m==1)
	 printf("%d is odd \n",n);
  else
    printf("%d is even \n",n);
  system("pause");
  return 0;
}
