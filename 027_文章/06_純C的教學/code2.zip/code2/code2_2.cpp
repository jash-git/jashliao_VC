#include <stdio.h>
#include <stdlib.h>

int main()
{
 int m=0;
 if(m==1)
 {
  printf("Information Engineering.\n");
  printf("Da Yeh University.\n");
 }
 system("pause");
 return 0;
}
