#include <stdio.h>
#include <stdlib.h>

int main()
{
  char chemistry_element='n';
  switch(chemistry_element)
  {
	 case 'h': printf("Hydrogen\n") ; break;
	 case 'm': printf("Magnesium\n") ; break;
	 case 's': printf("Selenium\n") ; break;
	 default : printf("Missing\n") ;
  }
  printf("The end.\n");
  system("pause");
  return 0;
}
