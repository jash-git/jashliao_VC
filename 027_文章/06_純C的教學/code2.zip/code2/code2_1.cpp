#include <stdio.h>
#include <stdlib.h>

int main()
{
  int x;
  printf("Enter an integer: ");
  scanf("%d",&x);
  if(x>0)
    printf("%d �O�����\n",x);
  system("pause");
  return 0;
}
