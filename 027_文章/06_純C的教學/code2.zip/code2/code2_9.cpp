#include <stdio.h>
#include <stdlib.h>

int main()
{
 int m,n;
 for(m=1,n=0;m<7;m++,n+=6)
 printf("%2d%4d\n",m,n);
 system("pause");
 return 0;
}
