#include <stdio.h>
#include <stdlib.h>

int main()
{
  int m,sum;
  m=1;
  sum=0;
  do
  {
	 sum+=m++;
  }
  while(m<=10);
  printf("1+2+...+10=%d\n",sum);
  system("pause");
  return 0;
}
