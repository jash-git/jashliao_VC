#include <stdio.h>
#include <stdlib.h>
int main(){ 
    char name[4]; 
    int score[5]; 
    double	avg[5];  
    printf("name[4] %dbytes\n",sizeof(name)); 
    printf("score[5] %dbytes\n",sizeof(score));
    printf("avg[5] %dbytes\n",sizeof(avg)); 
    system("pause");  
    return 0;
 }

