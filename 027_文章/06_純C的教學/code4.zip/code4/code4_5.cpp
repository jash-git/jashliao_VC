#include <stdio.h>
#include <stdlib.h>

int main()
{
   int num1[2][2],num2[2][2],num3[2][2]; 
   int i,j;

   printf("Input first 2 dimension array.\n"); 
   for ( i = 0; i < 2; i++ )
      for ( j = 0; j <2 ; j++ ) 
         scanf("%d",&num1[i][j]); 
   printf("Input second 2 dimension array.\n");
   for ( i = 0; i < 2; i++ )
      for ( j = 0; j < 2; j++ )
         scanf("%d",&num2[i][j]); 
   for ( i = 0; i < 2; i++ ) 
      for ( j = 0; j < 2; j++ ) 
	     num3[i][j] = num1[i][j] + num2[i][j];
   printf("The result 2 dimension array is as following:\n");
   for ( i = 0; i < 2; i++ ) 
      printf("%3d  %3d\n",num3[i][0],num3[i][1]); 
   system("pause");
   return 0;
}
