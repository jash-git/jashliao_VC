#include <stdio.h>
#include <stdlib.h>

int print1(int array[ ][3]);
int main( )
{
	int i,j;
	int arr[2][3]={{1,2,3},{4,5,6}};
	print1(arr);

	printf("\n");

	for(i=0;i<2;i++)
	  for (j=0;j<3;j++)
		printf("\narray[%d][%d]=%d  &arr[%d][%d]=%d",i,j,arr[i][j],i,j,&arr[i][j]);
	system("pause");
	return 0;
}
int print1(int array[ ][3])
{
	int i,j;
	for(i=0;i<2;i++)
	  for (j=0;j<3;j++)
		printf("\na[%d][%d]=%d  &arr[%d][%d]=%d",i,j,array[i][j],i,j,&array[i][j]);
	array[0][0]=2;	  
}


