#include <stdio.h>
#include <stdlib.h>
#define Sum(a,b) a+b

int main(void){ 
 int a=5,b=10,c;
 c=Sum(a,b); 
 printf("c=%d\n",c); 
 system("pause"); 
 return 0;
}

