#include <stdio.h>
#include <stdlib.h>

int main(void)
{

   int data[5]={10,7,13,5,1};

   int tmp,i,j;

   printf("Before sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);

   for (j=4;j>=0;j--){
      for (i=0;i<j;i++){
      	 if (data[i]>data[i+1]){
	        	   tmp = data[i]; 
	        	   data[i]=data[i+1]; 
	        	   data[i+1]=tmp;
   	  	 }
      }
   }

   printf("\n After sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);
   printf("\n");
   system("pause");
   return 0;

}
