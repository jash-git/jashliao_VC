#include <stdio.h>
#include <stdlib.h>

int print1(int array[ ]);
int print2(int *array);
int print3(int array[6]);
int main( )
{
	int i;
	int arr[6]={1,2,3,4,5,6};
	print1(arr);

	printf("\n");
	print2(arr);

	printf("\n");
	print3(arr);

	for(i=0;i<6;i++)
		printf("\narray[%d]=%d  &arr[%d]=%d",i,arr[i],i,arr+i);
	system("pause");
	return 0;
}
int print1(int array[ ])
{
	int i;
	for(i=0;i<6;i++)
	  printf("a[%d]=%d	    &array[%d]=%d\n",i,array[i],i,array+i);
	array[0]=2;	  
}

int print2(int *array)
{
	int i;
	for(i=0;i<6;i++)
	  printf("ar[%d]=%d	    &array[%d]=%d\n",i,array[i],i,array+i);
	array[1]=3;	  
}

int print3(int array[2])
{
	int i;
	for(i=0;i<6;i++)
	  printf("arr[%d]=%d    &array[%d]=%d\n",i,array[i],i,array+i);
	array[2]=4;	  
}
