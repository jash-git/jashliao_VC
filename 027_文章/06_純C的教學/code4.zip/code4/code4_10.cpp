#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>
#include <stdlib.h>

void bubble_sort(int data[],int n);
int main(void)
{

   int data[5]={10,7,13,5,1};

   int i;
      printf("Before sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);
   bubble_sort(data,5);
   printf("\n After sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);
   printf("\n");
   system("pause");
   return 0;
} 

   

void bubble_sort(int data[], int n){
   int i,j,tmp;
   for (j=n;j>=0;j--){
      for (i=0;i<j;i++){
      	 if (data[i]>data[i+1]){
	        	   tmp = data[i]; 
	        	   data[i]=data[i+1]; 
	        	   data[i+1]=tmp;
   	  	 }
      }
   }
}

