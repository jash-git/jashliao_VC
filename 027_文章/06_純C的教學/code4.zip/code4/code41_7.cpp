#include <stdio.h>
#include <stdlib.h>
int main(void){ 
    char string[]="I like C"; 
    int i;  
    i=0; 
    while (string[i]!='\0') {   
        i++; 
    } 
    printf("Length of String %s is %d\n",string,i); 
    system("pause");  
    return 0;
 }

