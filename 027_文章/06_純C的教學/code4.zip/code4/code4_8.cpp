#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int i;
  char str[12];
  printf("Please input a string: ");
  gets(str);
  printf("Your input is ");
  for(i=0;str[i]!='\0';i++)
	 printf("%c",str[i]);
  system("pause");
  return 0;
}
