#include <stdio.h>
#include <stdlib.h>

int main(void)
{

   int data[5]={20,15,17,5,1};

   int i,j,k;
   int smallest,index;

   printf("Before sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);

   for (j=0;j<5;j++){
      smallest=data[j];
      index=j;
      for (i=j;i<4;i++){
      	 if (smallest > data[i+1]){
              smallest=data[i+1];
	          index=i+1;
         }
      }
	  data[index]=data[j]; 
	  data[j]=smallest;
    }

   printf("\n After sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);
   printf("\n");
   system("pause");
   return 0;

}
