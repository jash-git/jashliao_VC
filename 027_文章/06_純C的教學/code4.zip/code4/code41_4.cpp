#include <stdio.h>
#include <stdlib.h>

int main(){
 float score[4][4] = { {85,78,65,0},{75,85,69,0},{63,67,95,0},{94,92,88,0}};
  int i,j;  printf("\tComputer\t  Math\t       English\t      Average\n"); 
   printf("===============================================================\n"); 
   for(i=0;i<4;i++) {   
      score[i][3] = (score[i][0]+score[i][1]+score[i][2])/3;  
      for(j=0;j<4;j++){       
          printf("\t%.2f\t",score[i][j]);   
      }   
      printf("\n"); } 
      system("pause");  
   return 0;
 }

