#include <stdio.h>
#include <stdlib.h>

int main( )
{
   float num[10],sum=0;
   int i; 
   for(i=0;i<100;i++)
     num[i]=i;
   for(i=0;i<100;i++)
     sum=sum+num[i];
   printf("\nThe sum is %f\n",sum);
   printf("\nThe average is %f\n",sum/i);
   system("pause");
   return 0;
}
