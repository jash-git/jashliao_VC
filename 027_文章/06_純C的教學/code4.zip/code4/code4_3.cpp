#include <stdio.h>
#include <stdlib.h>

int main()
{
   int arr[6]={20,21,23,19,17,25};
   int num;
   printf("Please input a number(0-5):");
   scanf("%d",&num);
   printf("The content of number %d is %d\n",num,arr[num]);
   system("pause");
   return 0;	
}
