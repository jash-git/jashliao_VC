#include <stdio.h>
#include <stdlib.h>

int search(int data[], int key, int size);
int main(void)
{

   int data[5]={20,15,17,5,1};

   int j,key,find;

   printf("Enter the search key\n");
   scanf("%d",&key);

   find=search(data,key,5);
    
  if (!find)
    printf("Not find the key %d", key);
        
   system("pause");
   return 0;

}


int search(int data[], int key, int size){
    int j;
    for (j=0;j<size;j++){
	  if (data[j]==key) {
	     printf("Found the key %d in element %d", key, j);
	     return 1;
      }
    }
    return 0;
}
