#include <stdio.h>
#include <stdlib.h>

int main(void)
{
   int i,j;
   int arr[2][3];
	for(i=0;i<2;i++)
     for(j=0;j<3;j++)
      printf("&arr[%d][%d]=%4d\n",i,j,&arr[i][j]);
   system("pause");
   return 0;
}
