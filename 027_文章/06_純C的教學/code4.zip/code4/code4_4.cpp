#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int arr[1][2][3]={{{1,2,3},{4,5,6}}};
  printf("arr[0][0][0]=%d\n",arr[0][0][0]);
  printf("arr[0][0][1]=%d\n",arr[0][0][1]);
  printf("arr[0][0][2]=%d\n",arr[0][0][2]);
  printf("arr[0][1][0]=%d\n",arr[0][1][0]);
  printf("arr[0][1][1]=%d\n",arr[0][1][1]);
  printf("arr[0][1][2]=%d\n",arr[0][1][2]);
  system("pause");
  return 0;
}
