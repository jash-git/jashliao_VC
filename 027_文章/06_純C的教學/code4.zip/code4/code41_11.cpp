#include <stdio.h>
#include <stdlib.h>

int main(void)
{

   int data[5]={20,15,17,5,1};

   int j,key, find=0;

   printf("Enter the search key\n");
   scanf("%d",&key);

    for (j=0;j<5;j++){
	  if (data[j]==key) {
	     printf("Found the key %d in element %d", key, j);
	     find=1;
      }
    }
    
  if (!find)
    printf("Not find the key %d", key);
        
   system("pause");
   return 0;

}
