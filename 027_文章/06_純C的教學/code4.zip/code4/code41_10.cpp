#include <stdio.h>
#include <stdlib.h>

void selection_sort(int data[],int n);
int main(void)
{

   int data[6]={10,25,17,5,11,2};

   int i,j,k;
      printf("Before sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);
   selection_sort(data,6);
   printf("\n After sorting...>");
   for (i=0;i<5;i+=1)
      printf("%d ",data[i]);
   printf("\n");
   system("pause");
   return 0;
} 

   

void selection_sort(int data[], int n){
   int i,j;
   int smallest,index;
   for (j=0;j<n;j++){
      smallest=data[j];
      index=j;
      for (i=j;i<(n-1);i++){
      	 if (smallest > data[i+1]){
              smallest=data[i+1];
	          index=i+1;
         }
      }
	  data[index]=data[j]; 
	  data[j]=smallest;
    }
}
