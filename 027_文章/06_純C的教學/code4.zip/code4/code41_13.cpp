#include <stdio.h>
#include <stdlib.h>

int binary_search(int data[], int key, int size);
int main(void)
{

   int data[5]={1,5,15,17,20};

   int j,key,find;

   printf("Enter the search key\n");
   scanf("%d",&key);

   find=binary_search(data,key,5);
    
  if (!find)
    printf("Not find the key %d", key);
        
   system("pause");
   return 0;

}


int binary_search(int data[], int key, int size){
    int low, middle, high;
    low=0;
    high=size;
    
    while (low<=high) {
       middle= (low+high)/2;
	  if (key==data[middle]) {
	     printf("Found the key %d in element %d", key, middle);
	     return 1;
      }
      else if(key < data[middle])
            high=middle-1;
      else low=middle+1;

    }      
    return 0;
}
