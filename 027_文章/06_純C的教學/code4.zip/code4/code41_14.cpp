#include <stdio.h>
#include <stdlib.h>
#define WelcomeString "�w��ϥΥ��{��\n"
#define Running "�{�����椤"

int main(){ 
    int i; 
    printf(WelcomeString); 
    printf(Running);
    printf("\n"); 
    system("pause");  
    return 0;
}

