#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv[])
{
  int I;
  printf("Numbers of argument is %d\n",argc);
  for(I=0;I<argc;I++)
    printf("arg[%d]:%s\n",I,*(argv+I));
  system("pause");
  return 0;
}
