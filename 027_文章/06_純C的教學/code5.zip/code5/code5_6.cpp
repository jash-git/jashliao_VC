#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int i , *ptr;
  int array[3][4]={{1,2,3,4},{4,5,6,7},{8,9,10,11}};
  ptr=(int *)array;
  for(i=0;i<6;i++)
  	 printf("*(ptr+%d)=%d\n",i,*(ptr+i));
  printf("%d\n",array[1][2]);	 
  array[1][2]=16;
  printf("%d\n",array[1][2]);
  ptr[4*1+2]=19;
  printf("%d\n",array[1][2]);
  
  printf("%d\n %d\n",(*(array+1))[1],*((array+1)[1]));
  system("pause");
  return 0;
}
