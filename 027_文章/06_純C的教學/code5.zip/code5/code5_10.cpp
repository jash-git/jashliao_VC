#include <stdio.h>
#include <stdlib.h>

int *func(int);
int main( )
{
  int i;
  for(i=0;i<4;i++)
    printf("%d\n",*func(i));
  system("pause");
  return 0;
}
int *func(int j)
{
  int arr[ ]={1,2,3,4};
  return(arr+j);
}
