#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x[5]={2,4,6,8,10},*p,**pp;
    p=x;
    pp=&p;
    printf("%d\n",*(p));
    p++;
    printf("%d\n",**pp);
    system("pause");
    return 0;
}
