#include <stdio.h>
#include <stdlib.h>


void swap_by_value(int a, int b)
{
    int temp;
    
    temp=a;
    a=b;
    b=temp;
}

void swap_by_address(int *a, int *b)
{
    int temp;
        
    temp=*a;
    *a=*b;
    *b=temp;
}

int main()
{
    int a=10,b=20;
    printf("a=%d b=%d\n",a,b);
    swap_by_value(a,b);
    printf("call swap_by_value: a=%d b=%d\n",a,b);
    swap_by_address(&a,&b);
    printf("call swap_by_address: a=%d b=%d\n",a,b);
    system("pause");
    return 0;
}

