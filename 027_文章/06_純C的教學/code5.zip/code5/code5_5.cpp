#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int i,*ptr,array[6]={11,12,13,14,15,16};
  ptr=array;
  for(i=0;i<6;i++)
    printf("array[%d]=%d,*(ptr+%d)=%d\n",i,array[i],i,*(ptr+i));
  system("pause");
  return 0;
}
