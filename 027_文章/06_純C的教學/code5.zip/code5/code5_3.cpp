#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int x=10;
  int *ptr1;
  int **ptr2;
  ptr1=&x;
  ptr2=&ptr1;
  printf("x=%d &x=%d\n",x,&x);
  printf("*ptr1=%d ptr1=%d\n",*ptr1,ptr1);
  printf("**ptr2=%d *ptr2=%d\n",**ptr2,*ptr2);
  printf("&ptr2=%d ptr2=%d &ptr1=%d\n",&ptr2,ptr2,&ptr1);
  system("pause");
  return 0;
}
