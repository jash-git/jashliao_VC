#include <stdio.h>
#include <stdlib.h>

int main ( )
{
  int count=10,x;
  int *ptr;
  ptr=&count;
  x=*ptr;
  printf("*ptr=%d x=%d\n",*ptr,x);
  printf("&ptr=%d ptr=%d &count=%d\n",&ptr,ptr,&count);
  system("pause");
  return 0;
}
