#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *num[2];
    int i,j;
    
    i=10;
    j=20;
    
    num[0]=&i;
    num[1]=&j;
    
    printf("i=%d j=%d\n",i,j);
    printf("num[0]=%d num[1]=%d\n",*(num[0]),*(num[1]));
    system("pause");
    return 0;
}
