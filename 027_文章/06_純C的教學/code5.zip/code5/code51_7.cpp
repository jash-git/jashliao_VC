#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int i,**ptr;
  int array[2][3]={{1,2,3},{4,5,6}};

  *ptr=(int *)&array[0];
  *(ptr+1)=(int *)&array[1];
  for(i=0;i<3;i++)
  	 printf("*(*ptr+%d)=%d,*(*(ptr+1)+%d)=%d\n",i,*(*ptr+i),i,*(*(ptr+1)+i));


  system("pause");
  return 0;
}
