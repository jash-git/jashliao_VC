#include <stdio.h>
#include <stdlib.h>

int main( )
{
  int i=0,array[6]={11,12,13,14,15,16};
  for(i=0;i<6;i++)
    printf("array[%d]=%d, *(array+%d)=%d\n",i,array[i],i,*(array+i));
  system("pause");
  return 0;
}
