#include <stdio.h>
#include <stdlib.h>

void(*func)(void);
void pri(void);
int main( )
{
  func=pri;
  func( );
  system("pause");
  return 0;
}
void pri(void)
{
  printf("%s\n","Test this pointer function");
}
