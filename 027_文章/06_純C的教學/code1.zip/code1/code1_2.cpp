
#include <stdio.h>
#include <stdlib.h>

int main()
{
   int num1, num2;
   int result;

   /* Ask users to input the data  */
   printf("Please input two integers...>");
   scanf("%d %d",&num1, &num2);


   printf("%5d + %5d = %5d\n", num1, num2, num1 + num2);
   printf("%5d - %5d = %5d\n", num1, num2, num1 - num2);
   printf("%5d * %5d = %5d\n", num1, num2, num1 * num2);
   printf("%5d / %5d = %5d\n", num1, num2, num1 / num2);
   printf("%5d %% %5d = %5d\n", num1, num2, num1 % num2);
   system("pause");
   
   return 0; 
}
