#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main( )
{
  char a;
  printf("Input a letter:");
  a=getche();
  printf("\n");
  putch(a);
  printf("\n");
  putchar(a);
  system("pause");
  return 0;
}
