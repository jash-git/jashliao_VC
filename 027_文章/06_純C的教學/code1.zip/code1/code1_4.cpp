#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main()
{
  char ch1,ch2;
  printf("Input a letter:");
  ch1=getchar();
  putchar(ch1);
  printf("\nInput a letter:");
  ch2=getche();
  printf("\n");
  putch(ch2);
  system("pause");
  return 0;
}
