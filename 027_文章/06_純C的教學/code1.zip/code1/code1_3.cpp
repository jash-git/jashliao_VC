#include<stdio.h>
#include<conio.h>
#include <stdlib.h>

int main( )
{
  printf("Input a character:");
  getche( );
  printf("\nInput a character:");
  getch( );
  system("pause");
  return 0;
}
