using System;
using System.Drawing;
using System.Collections;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Text;
using System.Runtime.InteropServices;


namespace CadImage
{
	public class fmCADImage : System.Windows.Forms.Form
	{
		private const long FILE_SHARE_READ = 0x00000001;
		private const long CREATE_NEW = 1;
		private const long OPEN_EXISTING = 3;
		private const long GENERIC_READ = 0x80000000;
		private const long GENERIC_WRITE = 0x40000000;
		private const long CREATE_ALWAYS = 2;
		private const long FILE_ATTRIBUTE_NORMAL = 0x00000080;

		private float KX, KY;

		private System.Windows.Forms.OpenFileDialog dlgOpenDXFFile;
		private System.Windows.Forms.Panel panel1;
		private lForm layerForm = new lForm();
		private int fScale = 100;
		internal System.Windows.Forms.MainMenu MainMenu1;
		internal System.Windows.Forms.MenuItem MenuItem1;
		internal System.Windows.Forms.MenuItem MenuItem3;
		internal System.Windows.Forms.MenuItem MenuItem11;
		internal System.Windows.Forms.MenuItem MenuItem4;
		internal System.Windows.Forms.MenuItem MenuItem10;
		internal System.Windows.Forms.MenuItem MenuItem2;
		internal System.Windows.Forms.MenuItem MenuItem5;
		internal System.Windows.Forms.MenuItem MenuItem6;
		internal System.Windows.Forms.MenuItem MenuItem7;
		internal System.Windows.Forms.MenuItem MenuItem8;
		internal System.Windows.Forms.MenuItem MenuItem9;
		internal System.Windows.Forms.MenuItem MenuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		internal System.Windows.Forms.SaveFileDialog CD;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public fmCADImage()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dlgOpenDXFFile = new System.Windows.Forms.OpenFileDialog();
			this.panel1 = new System.Windows.Forms.Panel();
			this.MainMenu1 = new System.Windows.Forms.MainMenu();
			this.MenuItem1 = new System.Windows.Forms.MenuItem();
			this.MenuItem3 = new System.Windows.Forms.MenuItem();
			this.MenuItem11 = new System.Windows.Forms.MenuItem();
			this.MenuItem4 = new System.Windows.Forms.MenuItem();
			this.MenuItem10 = new System.Windows.Forms.MenuItem();
			this.MenuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.MenuItem5 = new System.Windows.Forms.MenuItem();
			this.MenuItem6 = new System.Windows.Forms.MenuItem();
			this.MenuItem7 = new System.Windows.Forms.MenuItem();
			this.MenuItem8 = new System.Windows.Forms.MenuItem();
			this.MenuItem9 = new System.Windows.Forms.MenuItem();
			this.MenuItem12 = new System.Windows.Forms.MenuItem();
			this.CD = new System.Windows.Forms.SaveFileDialog();
			this.SuspendLayout();
			// 
			// dlgOpenDXFFile
			// 
			this.dlgOpenDXFFile.DefaultExt = "*.dxf";
			this.dlgOpenDXFFile.Filter = "*.dxf; *.dwg|*.dxf;*.dwg|����� hpgl (*.plt; *.hgl; *.hg; *.hpg;*.plo; *.hp; *.hp1" +
				"; *.hp2;*.hpgl; *.hpgl2; *.gl2;*.prn;*.spl)|*.plt;*.hgl;*.hg;*.hpg;*.plo;*.hp;*." +
				"hp1;*.hp2;*.hpgl; *.hpgl2; *.gl2;*.prn;*.spl";
			this.dlgOpenDXFFile.RestoreDirectory = true;
			this.dlgOpenDXFFile.Title = "OpenDXFFile";
			// 
			// panel1
			// 
			this.panel1.AutoScroll = true;
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(664, 326);
			this.panel1.TabIndex = 4;
			this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
			this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
			// 
			// MainMenu1
			// 
			this.MainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuItem1,
																					  this.MenuItem2,
																					  this.MenuItem12});
			// 
			// MenuItem1
			// 
			this.MenuItem1.Index = 0;
			this.MenuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuItem3,
																					  this.MenuItem11,
																					  this.MenuItem4,
																					  this.MenuItem10});
			this.MenuItem1.Text = "File";
			// 
			// MenuItem3
			// 
			this.MenuItem3.Index = 0;
			this.MenuItem3.Text = "Load";
			this.MenuItem3.Click += new System.EventHandler(this.button1_Click);
			// 
			// MenuItem11
			// 
			this.MenuItem11.Index = 1;
			this.MenuItem11.Text = "Save as BMP";
			this.MenuItem11.Click += new System.EventHandler(this.MenuItem11_Click);
			// 
			// MenuItem4
			// 
			this.MenuItem4.Index = 2;
			this.MenuItem4.Text = "Save as JPG";
			this.MenuItem4.Click += new System.EventHandler(this.MenuItem4_Click);
			// 
			// MenuItem10
			// 
			this.MenuItem10.Index = 3;
			this.MenuItem10.Text = "Exit";
			this.MenuItem10.Click += new System.EventHandler(this.MenuItem10_Click);
			// 
			// MenuItem2
			// 
			this.MenuItem2.Index = 1;
			this.MenuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem14,
																					  this.menuItem13,
																					  this.MenuItem5,
																					  this.MenuItem6,
																					  this.MenuItem7,
																					  this.MenuItem8,
																					  this.MenuItem9});
			this.MenuItem2.Text = "Scale";
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 0;
			this.menuItem14.Text = "10";
			this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 1;
			this.menuItem13.Text = "25";
			this.menuItem13.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// MenuItem5
			// 
			this.MenuItem5.Index = 2;
			this.MenuItem5.Text = "50";
			this.MenuItem5.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// MenuItem6
			// 
			this.MenuItem6.Checked = true;
			this.MenuItem6.Index = 3;
			this.MenuItem6.Text = "100";
			this.MenuItem6.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// MenuItem7
			// 
			this.MenuItem7.Index = 4;
			this.MenuItem7.Text = "200";
			this.MenuItem7.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// MenuItem8
			// 
			this.MenuItem8.Index = 5;
			this.MenuItem8.Text = "500";
			this.MenuItem8.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// MenuItem9
			// 
			this.MenuItem9.Index = 6;
			this.MenuItem9.Text = "1000";
			this.MenuItem9.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// MenuItem12
			// 
			this.MenuItem12.Index = 2;
			this.MenuItem12.Text = "Layers";
			this.MenuItem12.Click += new System.EventHandler(this.button2_Click);
			// 
			// fmCADImage
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(664, 326);
			this.Controls.Add(this.panel1);
			this.Menu = this.MainMenu1;
			this.Name = "fmCADImage";
			this.Text = "DemoCADImage";
			this.Resize += new System.EventHandler(this.fmCADImage_Resize);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			this.ResumeLayout(false);

		}
		#endregion
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new fmCADImage());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{	
			if(DLLWin32Import.CADFile != IntPtr.Zero)
			{
				DLLWin32Import.CloseCAD(DLLWin32Import.CADFile);
				DLLWin32Import.CADFile = IntPtr.Zero;
			}
            dlgOpenDXFFile.ShowDialog();
			DLLWin32Import.CADFile = DLLWin32Import.CreateCAD(panel1.Handle, dlgOpenDXFFile.FileName);
			if(DLLWin32Import.CADFile != IntPtr.Zero)
			{
				panel1.Visible = true;
				panel1.Invalidate();
			}
			//Layers
			int Cnt = DLLWin32Import.CADLayerCount(DLLWin32Import.CADFile);
			int I;
			int Layer;
			DXFData EData = new DXFData();
			layerForm.layerList.Items.Clear();
			for(I = 0; I < Cnt; I++)
			{
				Layer = DLLWin32Import.CADLayer(DLLWin32Import.CADFile, I, ref EData);
				layerForm.layers.Add(Layer);
				layerForm.layerList.Items.Add(EData.Text, true);
			}
		}

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if(DLLWin32Import.CADFile != IntPtr.Zero) { 
				DLLWin32Import.CloseCAD(DLLWin32Import.CADFile);
				DLLWin32Import.CADFile = IntPtr.Zero;
			}
		}

		private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			if(DLLWin32Import.CADFile == IntPtr.Zero) return;
			Rect R = new Rect();
			float AbsWidth = 0;
			float AbsHeight = 0;
			float K;
			if(DLLWin32Import.CADFile != IntPtr.Zero) 
				DLLWin32Import.GetBoxCAD(DLLWin32Import.CADFile, ref AbsWidth, ref AbsHeight);
			if(AbsHeight != -1)
				GetClientRect(panel1, ref R);
			if(AbsWidth == 0) K = 1;
			else K = AbsHeight / AbsWidth;
			R.Bottom = (int)(R.Top + (R.Right - R.Left) * K);
			R.Left = (R.Left * fScale / 100) + DLLWin32Import.FX;
			R.Right = (R.Right * fScale / 100) + DLLWin32Import.FX;
			R.Top = (R.Top * fScale / 100) + DLLWin32Import.FY;
			R.Bottom = (R.Bottom * fScale / 100) + DLLWin32Import.FY;
			Graphics g1 = Graphics.FromHwnd(panel1.Handle);
			DLLWin32Import.DrawCAD(DLLWin32Import.CADFile, g1.GetHdc(), ref R);
		}

		public void GetClientRect(Control acl, ref Rect R)
		{
			R.Left = acl.Left;
			R.Top = acl.Top;
			R.Right = acl.Size.Width;
			R.Bottom = acl.Size.Height;
		}

		private void cbStretch_CheckedChanged(object sender, System.EventArgs e)
		{
			panel1.Invalidate();
		}

		private void fmCADImage_Resize(object sender, System.EventArgs e)
		{
			panel1.Invalidate();
		}

		private void panel1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(e.Button == MouseButtons.Right) 
			{
				DLLWin32Import.fStart = new Point(e.X, e.Y);
				DLLWin32Import.fOld =  new Point(DLLWin32Import.FX, DLLWin32Import.FY);
				panel1.Cursor = Cursors.Hand;
			}
		}

		private void panel1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(panel1.Cursor == Cursors.Hand) {
				DLLWin32Import.FX = DLLWin32Import.fOld.X + e.X - DLLWin32Import.fStart.X;
				DLLWin32Import.FY = DLLWin32Import.fOld.Y + e.Y - DLLWin32Import.fStart.Y;
				panel1.Invalidate();
			} else {
				if(DLLWin32Import.CADFile == IntPtr.Zero) {
					return;
				}
			}
  		}

		private void panel1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if((e.Button == MouseButtons.Right)&&(panel1.Cursor == Cursors.Hand)) {
				panel1.Cursor = Cursors.Default;
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			layerForm.layerList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chLay_ItemCheck);
			layerForm.ShowDialog();
		}

		private void chLay_ItemCheck(Object sender, System.Windows.Forms.ItemCheckEventArgs e)
		{
			if(e.NewValue == CheckState.Checked)
				DLLWin32Import.CADLayerVisible(((int)layerForm.layers[e.Index]), 1);
			if(e.NewValue == CheckState.Unchecked)
				DLLWin32Import.CADLayerVisible(((int)layerForm.layers[e.Index]), 0);
			panel1.Invalidate();
		}

		private void menuItem14_Click(object sender, System.EventArgs e)
		{
			for(int i = 0; i < MainMenu1.MenuItems[1].MenuItems.Count; i++)
				MainMenu1.MenuItems[1].MenuItems[i].Checked = false;
			(sender as MenuItem).Checked = ! (sender as MenuItem).Checked;
			fScale = Convert.ToInt32((sender as MenuItem).Text);
			panel1.Invalidate();
		}

		private void MenuItem10_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void MenuItem11_Click(object sender, System.EventArgs e)
		{
			CADDRAW CrDraw = new CADDRAW();
			float K;
			float AbsWidth = 0;
			float AbsHeight = 0;
			CD.FileName = "";
			CD.Filter = "Bmp files (bmp)|*.bmp";
			CD.ShowDialog();
			DLLWin32Import.GetBoxCAD(DLLWin32Import.CADFile, ref AbsWidth, ref AbsHeight);
			if(AbsWidth == 0)
				K = 1;
			else K = AbsHeight / AbsWidth;
			CrDraw.Size = Marshal.SizeOf(CrDraw); //size of CADDRAW
			CrDraw.R = new Rect();
			GetClientRect(panel1, ref CrDraw.R);
			CrDraw.R.Bottom = (int)(CrDraw.R.Right * K);
			CrDraw.R.Right = CrDraw.R.Right * fScale / 100;
			CrDraw.R.Bottom = CrDraw.R.Bottom * fScale / 100;
			CrDraw.DrawMode = 0; // color mode
			int i = DLLWin32Import.SaveCADtoBitmap(DLLWin32Import.CADFile, ref CrDraw, CD.FileName);
		}

		private void MenuItem4_Click(object sender, System.EventArgs e)
		{
			CADDRAW CrDraw = new CADDRAW();
			float K;
			float AbsWidth = 0;
			float AbsHeight = 0;
			CD.FileName = "";
			CD.Filter = "Jpg files (jpg)|*.jpg";
			CD.ShowDialog();
			DLLWin32Import.GetBoxCAD(DLLWin32Import.CADFile, ref AbsWidth, ref AbsHeight);
			if(AbsWidth == 0) K = 1;
			else K = AbsHeight / AbsWidth;
            CrDraw.Size = Marshal.SizeOf(CrDraw); //size of CADDRAW
			CrDraw.R = new Rect();
			GetClientRect(panel1, ref CrDraw.R);
			CrDraw.R.Bottom = (int)(CrDraw.R.Right * K);
			CrDraw.R.Right = CrDraw.R.Right * fScale / 100;
			CrDraw.R.Bottom = CrDraw.R.Bottom * fScale / 100;
			CrDraw.DrawMode = 0; // color mode
			int i = DLLWin32Import.SaveCADtoJpeg(DLLWin32Import.CADFile, ref CrDraw, CD.FileName);
		}																									 																										
	}

	public class DLLWin32Import
	{
		public static IntPtr CADFile = new IntPtr();
		public static float fAbsHeight, fAbsWidth;
		public static int FX, FY;
		public static FPoint fScaleRect = new FPoint();
		public static Point fStart = new Point();
		public static Point fOld = new Point();

		[DllImport("CADImage")]
		public static extern IntPtr CreateCAD(IntPtr hWindow, string lpFileName);		
		[DllImport("CADImage")]
		public static extern int CloseCAD(IntPtr hObject);
		[DllImport("CADImage")]
		public static extern int DrawCAD(IntPtr hObject, IntPtr hDC, ref Rect lprc);
		[DllImport("CADImage")]
		public static extern int GetExtentsCAD(IntPtr handle, ref FRect fRect);	
		[DllImport("CADImage")] 
		public static extern int CADLayerCount(IntPtr hObject);
		[DllImport("CADImage")] 
		public static extern int CADLayer(IntPtr hObject, int nIndex, ref DXFData lpData);
		[DllImport("CADImage")] 
		public static extern int GetLastErrorCAD([MarshalAs(UnmanagedType.LPStr)]string lbBuf);
		[DllImport("CADImage")] 
		public static extern int DrawCADEx(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage")] 
		public static extern int CADLayerVisible(int Handle, int Visible);
		[DllImport("CADImage")] 
		public static extern int CADVisible(IntPtr hObject, [MarshalAs(UnmanagedType.LPStr)] string lpLayerName);				
		[DllImport("CADImage")] 
		public static extern IntPtr DrawCADtoBitmap(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage")] 
		public static extern IntPtr DrawCADtoGif(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage")] 
		public static extern IntPtr DrawCADtoJpeg(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage")]
		public static extern int GetBoxCAD(IntPtr Handle, ref float AbsWidth, ref float AbsHeight);
		[DllImport("CADImage")]
		public static extern int SetProcessMessagesCAD(IntPtr hObject, int AIsProcess);
		[DllImport("CADImage")]
		public static extern int SaveCADtoBitmap(IntPtr Handle, ref CADDRAW cADDraw, string FileName);
		[DllImport("CADImage")]
		public static extern int SaveCADtoJpeg(IntPtr Handle, ref CADDRAW cADDraw, string FileName);
        
		[DllImport("kernel32.dll")]
		public static extern long WriteFile (long hFile, long lpBuffer ,
											   long nNumberOfBytesToWrite, long lpNumberOfBytesWritten, int lpOverlapped);
		[DllImport("kernel32.dll")]
		public static extern long CreateFile(string lpFileName, long dwDesiredAccess, long dwShareMode, IntPtr SecurityAttributes, long
											   dwCreationDisposition , long dwFlagsAndAttributes, long hTemplateFile);
		[DllImport("kernel32.dll")] 
		public static extern long CloseHandle(long hObject);
		[DllImport("kernel32.dll")]
		public static extern long GlobalAlloc(long wFlags, long dwBytes);
		[DllImport("kernel32.dll")]
		public static extern long GlobalFree(long hMem);
		[DllImport("kernel32.dll")]
		public static extern long GlobalLock (long hMem);
		[DllImport("kernel32.dll")]
		public static extern long GlobalUnlock(long hMem);
		[DllImport("kernel32.dll")]
		public static extern long GlobalSize(long hMem);
	}	

	public struct FRect 
	{
		public float Left, Top, Z1, Right, Bottom, Z2;
		public FPoint TopLeft, BottomRight;
	}

	public struct FPoint
	{
		public float X, Y, Z;
	}

	public struct RPoint
	{
		public float X, Y;
		public RPoint(float x, float y)
		{
			X = x;
			Y = y;
		}
	}

    public struct CADDraw
	{
		public long Size;
		public IntPtr DC;
		public Rect R;
		public byte DrawMode;
	}

	public struct POINTAPI
	{
		public long X;
		public long Y;
	}

	public struct Rect
	{
		public int Left, Top, Right, Bottom;

		public Rect(Rectangle val)
		{
			Left = val.Left;
			Top = val.Top;
			Right = val.Right;
			Bottom = val.Bottom;
		}
	}

	public struct CADDRAW
	{
		public Single Size;
		public int DC; //single
		public Rect R;
		public byte DrawMode;
	}

	public struct DXFPoint
	{
		public int X; //As Single
		public int Y; //As Single
		public int Z; //As Single

		public  DXFPoint(int aX, int aY, int aZ)
		{
			X = aX;
			Y = aY;
			Z = aZ;
		}
	}

	public struct DXFData
	{
		public char Tag;
		public char count;
		public char TickCount;
		public byte flags;
		public byte Style;
		public int Dimension;
		public int DashDots;	// As Single
		public int DashDotsCount;
		public int Color;
		public int Ticks;
		public int Thickness;
		public int Rotation;
		public string Layer;
		public string Text;
		public string FontName;
		public int Handle;
		public int Unused;
		public DXFPoint Point;
		public DXFPoint Point1;
		public DXFPoint Point2;
		public DXFPoint Point3;
		public int FHeight, FScale, RWidth, RHeight;
		public byte HAlign, VAlign;
	}
}
