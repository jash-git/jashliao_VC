using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
//using System.Text;

namespace CadImage
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class fmCADImage : System.Windows.Forms.Form
	{
		private System.Windows.Forms.OpenFileDialog dlgOpenDXFFile;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.CheckBox cbStretch;
		protected System.Windows.Forms.ComboBox cbScale;
		private System.Windows.Forms.Button btnLoadFile;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public fmCADImage()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dlgOpenDXFFile = new System.Windows.Forms.OpenFileDialog();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.cbStretch = new System.Windows.Forms.CheckBox();
			this.cbScale = new System.Windows.Forms.ComboBox();
			this.btnLoadFile = new System.Windows.Forms.Button();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// dlgOpenDXFFile
			// 
			this.dlgOpenDXFFile.DefaultExt = "*.dxf";
			this.dlgOpenDXFFile.Filter = "*.dxf;*.dwg |*.dxf;*.dwg";
			this.dlgOpenDXFFile.InitialDirectory = "C:\\";
			this.dlgOpenDXFFile.RestoreDirectory = true;
			this.dlgOpenDXFFile.Title = "OpenDXFFile";
			// 
			// panel1
			// 
			this.panel1.AutoScroll = true;
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(664, 326);
			this.panel1.TabIndex = 4;
			this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
			this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.cbStretch);
			this.panel2.Controls.Add(this.cbScale);
			this.panel2.Controls.Add(this.btnLoadFile);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(664, 48);
			this.panel2.TabIndex = 5;
			// 
			// cbStretch
			// 
			this.cbStretch.Location = new System.Drawing.Point(240, 16);
			this.cbStretch.Name = "cbStretch";
			this.cbStretch.TabIndex = 7;
			this.cbStretch.Text = "Stretch";
			this.cbStretch.CheckedChanged += new System.EventHandler(this.cbStretch_CheckedChanged);
			// 
			// cbScale
			// 
			this.cbScale.DisplayMember = "0";
			this.cbScale.Items.AddRange(new object[] {
														 "10",
														 "25",
														 "50",
														 "100",
														 "200",
														 "400",
														 "1000"});
			this.cbScale.Location = new System.Drawing.Point(104, 16);
			this.cbScale.Name = "cbScale";
			this.cbScale.Size = new System.Drawing.Size(121, 21);
			this.cbScale.TabIndex = 6;
			this.cbScale.Text = "Scale";
			this.cbScale.SelectedIndexChanged += new System.EventHandler(this.cbScale_SelectedIndexChanged);
			// 
			// btnLoadFile
			// 
			this.btnLoadFile.Location = new System.Drawing.Point(16, 16);
			this.btnLoadFile.Name = "btnLoadFile";
			this.btnLoadFile.TabIndex = 4;
			this.btnLoadFile.Text = "Load File...";
			this.btnLoadFile.Click += new System.EventHandler(this.button1_Click);
			// 
			// fmCADImage
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(664, 326);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "fmCADImage";
			this.Text = "DemoCADImage";
			this.Resize += new System.EventHandler(this.fmCADImage_Resize);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			this.Load += new System.EventHandler(this.fmCADImage_Load);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new fmCADImage());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{	
			ActiveForm.Enabled = false;
			if(DLLWin32Import.CADFile != IntPtr.Zero) { 
				DLLWin32Import.CloseCAD(DLLWin32Import.CADFile);
				DLLWin32Import.CADFile = IntPtr.Zero;
			}
			dlgOpenDXFFile.ShowDialog();
			if(dlgOpenDXFFile.FileName != "") {
				DLLWin32Import.CADFile = DLLWin32Import.CreateCAD(panel1.Handle, dlgOpenDXFFile.FileName);
				if(DLLWin32Import.CADFile == IntPtr.Zero) {
					MessageBox.Show("Error open file:" + dlgOpenDXFFile.FileName);	
					ActiveForm.Enabled = true;
					return;
				}
				FRect fRectExtentsCAD = new FRect();
				DLLWin32Import.GetExtentsCAD(DLLWin32Import.CADFile, ref fRectExtentsCAD);
				DLLWin32Import.fAbsHeight = fRectExtentsCAD.Top - fRectExtentsCAD.Bottom;
				DLLWin32Import.fAbsWidth  = fRectExtentsCAD.Right - fRectExtentsCAD.Left;
				int cnt =  DLLWin32Import.CADLayerCount(DLLWin32Import.CADFile);
				DXFData aData = new DXFData();
				IntPtr Layer;
				long C;
				for (int i = 0; i < cnt; i++) {
					Layer = DLLWin32Import.CADLayer(DLLWin32Import.CADFile, i, ref aData);
					C = aData.Color;
					if((aData.Flags & 1) != 0) {
						C = C | 0x80000000;
					}
					if(aData.Text != null) {
						MessageBox.Show("["+i+"] "+aData.Text);			
						//cbLayers.Items.Add(aData.Text); //??
					}
				}
			}
			ActiveForm.Enabled = true;
		}

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if(DLLWin32Import.CADFile != IntPtr.Zero) { 
				DLLWin32Import.CloseCAD(DLLWin32Import.CADFile);
				DLLWin32Import.CADFile = IntPtr.Zero;
			}
		}


		private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			if(DLLWin32Import.CADFile == IntPtr.Zero) return;
			Graphics g1 = Graphics.FromHwnd(panel1.Handle);
			Rect fRect = new Rect();
			fRect.Left = panel1.ClientRectangle.Left;
			fRect.Top = panel1.ClientRectangle.Top;
			fRect.Right = panel1.ClientRectangle.Right;
			fRect.Bottom = panel1.ClientRectangle.Bottom;	
			fRect.BottomRight = new RPoint(fRect.Right, fRect.Bottom);
			fRect.TopLeft = new RPoint(fRect.Left, fRect.Top);
			if(cbStretch.Checked) {	
				DLLWin32Import.DrawCAD(DLLWin32Import.CADFile, g1.GetHdc(), ref fRect);
				return;
			}
			if(DLLWin32Import.fAbsHeight == -1) {
				return;
			}
			float Koef = DLLWin32Import.fAbsHeight / DLLWin32Import.fAbsWidth;
			fRect.Bottom = (int)Math.Round(fRect.Top  + (fRect.Right - fRect.Left) * Koef);
			fRect.Left = fRect.Left * DLLWin32Import.fScale / 100 + DLLWin32Import.FX;
			fRect.Top = fRect.Top * DLLWin32Import.fScale / 100 + DLLWin32Import.FY;
			fRect.Right = fRect.Right * DLLWin32Import.fScale / 100 + DLLWin32Import.FX;;
			fRect.Bottom = fRect.Bottom * DLLWin32Import.fScale / 100 + DLLWin32Import.FY;
			fRect.BottomRight = new RPoint(fRect.Right, fRect.Bottom);
			fRect.TopLeft = new RPoint(fRect.Left, fRect.Top);
			DLLWin32Import.fScaleRect.X = DLLWin32Import.fAbsWidth / (fRect.Right - fRect.Left);
			DLLWin32Import.fScaleRect.Y = DLLWin32Import.fAbsHeight / (fRect.Bottom - fRect.Top);
			DLLWin32Import.DrawCAD(DLLWin32Import.CADFile, g1.GetHdc(), ref fRect);
		
		}

		private void fmCADImage_Load(object sender, System.EventArgs e)
		{
			cbScale.SelectedIndex = 3;
			dlgOpenDXFFile.Filter = "*.dxf; *.dwg|*.dxf;*.dwg|*.plt; *.hgl; *.hg; *.hpg"+
				"|*.plt;*.hgl;*.hg;*.hpg | *.plo; *.hp; *.hp1; *.hp2;|*.plo;*.hp;*.hp1;*.hp2"+ 
				"|*.hpgl; *.hpgl2; *.gl2;*.prn;*.spl |*.hpgl; *.hpgl2; *.gl2;*.prn;*.spl"; 
		}

		private void cbScale_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DLLWin32Import.fScale = Convert.ToInt32(cbScale.Text);
			panel1.Invalidate();
		}

		private void cbStretch_CheckedChanged(object sender, System.EventArgs e)
		{
			panel1.Invalidate();
		}

		private void fmCADImage_Resize(object sender, System.EventArgs e)
		{
			panel1.Invalidate();
		}

		private void panel1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(e.Button == MouseButtons.Right) 
			{
				DLLWin32Import.fStart = new Point(e.X, e.Y);
				DLLWin32Import.fOld =  new Point(DLLWin32Import.FX, DLLWin32Import.FY);
				panel1.Cursor = Cursors.Hand;
			}
		}

		private void panel1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(panel1.Cursor == Cursors.Hand) {
				DLLWin32Import.FX = DLLWin32Import.fOld.X + e.X - DLLWin32Import.fStart.X;
				DLLWin32Import.FY = DLLWin32Import.fOld.Y + e.Y - DLLWin32Import.fStart.Y;
				panel1.Invalidate();
			} else {
				if(DLLWin32Import.CADFile == IntPtr.Zero) {
					return;
				}
			}
  		}

		private void panel1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if((e.Button == MouseButtons.Right)&&(panel1.Cursor == Cursors.Hand)) {
				panel1.Cursor = Cursors.Default;
			}
		}
	}

	public class DLLWin32Import
	{
		public static IntPtr CADFile = new IntPtr();
		public static float fAbsHeight, fAbsWidth;
		public static int fScale = 100;
		public static int FX, FY;
		public static FPoint fScaleRect = new FPoint();
		public static Point fStart = new Point();
		public static Point fOld = new Point();

		[DllImport("CADImage.dll")]
		public static extern IntPtr CreateCAD(IntPtr hWindow, string lpFileName);		
		[DllImport("CADImage.dll")]
		public static extern int CloseCAD(IntPtr hObject);
		[DllImport("CADImage.dll")]
		public static extern int DrawCAD(IntPtr hObject, IntPtr hDC, ref Rect lprc); //??
		[DllImport("CADImage.dll")]
		public static extern int GetExtentsCAD(IntPtr handle, ref FRect fRect);	
		[DllImport("CADImage.dll")] 
		public static extern int CADLayerCount(IntPtr hObject);
		[DllImport("CADImage.dll")] 
		public static extern IntPtr CADLayer(IntPtr hObject, int nIndex, ref DXFData lpData);
		[DllImport("CADImage.dll")] 
		public static extern int GetLastErrorCAD([MarshalAs(UnmanagedType.LPStr)]string lbBuf);
		[DllImport("CADImage.dll")] 
		public static extern int DrawCADEx(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage.dll")] 
		public static extern int CADLayerVisible(IntPtr hObject, int visible);
		[DllImport("CADImage.dll")] 
		public static extern int CADVisible(IntPtr hObject, [MarshalAs(UnmanagedType.LPStr)] string lpLayerName);				
		[DllImport("CADImage.dll")] 
		public static extern IntPtr DrawCADtoBitmap(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage.dll")] 
		public static extern IntPtr DrawCADtoGif(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage.dll")] 
		public static extern IntPtr DrawCADtoJpeg(IntPtr hObject, ref CADDraw lpcd);
		[DllImport("CADImage.dll")]
		public static extern int GetBoxCAD(IntPtr hObject, float AbsWidht, float AbsHeight);
	}	

	public struct FRect 
	{
		public float Left, Top, Z1, Right, Bottom, Z2;
		public FPoint TopLeft, BottomRight;
	}

	public struct Rect 
	{
		public int Left, Top, Right, Bottom; 
		public RPoint TopLeft, BottomRight;
	}

	public struct FPoint
	{
		public float X, Y, Z;
	}

	public struct RPoint
	{
		public float X, Y;
		public RPoint(float x, float y)
		{
			X = x;
			Y = y;
		}
	}
	
	[StructLayout(LayoutKind.Sequential)]
	public struct DXFData
	{
		public ushort Tag;			
		public ushort Count;		
		public ushort TickCount;
		public byte Flags;				
		public byte Style;		
		public int Dimension;
		public FPoint DashDots;
		public int DashDotsCount;
		public int Color;		
		public int Ticks;
		public float Thickness;
		public float Rotation;
		[MarshalAs(UnmanagedType.LPStr)] 
		public string Layer;  
		[MarshalAs(UnmanagedType.LPStr)] 
		public string Text;
		public FPoint Point1;
		public FPoint Point2;
		public FPoint Point3;
		public FPoint Point4;
		public float Radius, StartAngle, EndAngle;    
		public IntPtr Block;
		public FPoint Scale;
		public float FHeight, FScale, RWidth, RHeight; 
		public byte HAlign, VAlign;
		public FPoint[] PolyPoints;
	}

	public struct CADDraw
	{
		public long Size;
		public IntPtr DC;
		public Rect R;
		public byte DrawMode;
	}
}
