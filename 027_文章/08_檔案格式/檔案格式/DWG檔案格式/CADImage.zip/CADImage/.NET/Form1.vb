Imports System.Drawing
Imports System.Drawing.Printing
Imports System.Runtime.InteropServices

Public Class Form1
    Inherits System.Windows.Forms.Form

    Public ReadOnly GENERIC_WRITE As Long = &H40000000
    Public ReadOnly FILE_SHARE_READ As Long = &H1
    Public ReadOnly CREATE_ALWAYS As Long = 1
    Public ReadOnly FILE_ATTRIBUTE_NORMAL As Long = &H80000000

    Dim KX As Single
    Dim KY As Single
    Dim PreviousPoint As POINTAPI
    Dim Offset As POINTAPI
    Dim drag As Boolean
    Dim FScale As Long = 100
    Public CADImage As IntPtr

    <DllImport("CADImage.dll", _
   SetLastError:=True, _
   CharSet:=CharSet.Ansi, ExactSpelling:=True, _
   CallingConvention:=CallingConvention.StdCall)> _
   Public Shared Function CreateCAD(ByVal hWindow As IntPtr, ByVal lpFileName As String) As IntPtr
    End Function
    <DllImport("CADImage.dll", _
        SetLastError:=True, CharSet:=CharSet.Ansi, _
        ExactSpelling:=True, _
        CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CloseCAD(ByVal hObject As IntPtr) As Integer
    End Function
    <DllImport("CADImage.dll", _
        SetLastError:=True, CharSet:=CharSet.Ansi, _
        ExactSpelling:=True, _
        CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function DrawCAD(ByVal hObject As IntPtr, ByVal hDC As IntPtr, ByRef lprc As Rect) As Integer
    End Function
    <DllImport("CADImage.dll", _
   SetLastError:=True, CharSet:=CharSet.Ansi, _
   ExactSpelling:=True, _
   CallingConvention:=CallingConvention.StdCall)> _
   Public Shared Function GetExtentsCAD(ByVal handle As IntPtr, ByRef fRect As Rect) As Integer
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CADLayerCount(ByVal hObject As IntPtr) As Integer
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CADLayer(ByVal hObject As IntPtr, ByVal nIndex As Integer, ByRef lpData As Data) As <MarshalAs(UnmanagedType.LPStr)> String
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function GetLastErrorCAD(ByVal lbBuf As String) As Integer
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function GetBoxCAD(ByVal Handle As IntPtr, ByRef AbsWidth As Long, ByRef AbsHeight As Long) As Long
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function DrawCADtoBitmap(ByVal hObject As IntPtr, ByRef lpcd As CADDRAW) As Long
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function DrawCADtoJpeg(ByVal Handle As IntPtr, ByVal CdDraw As CADDRAW) As IntPtr
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CADLayoutsCount(ByVal Handle As Long) As Integer
    End Function
    <DllImport("KERNEL32.DLL", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function GlobalSize(ByVal hMem As IntPtr) As Long
    End Function
    <DllImport("KERNEL32.DLL", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function GlobalLock(ByVal hMem As IntPtr) As IntPtr
    End Function
    <DllImport("KERNEL32.DLL", EntryPoint:="CreateFileA", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CreateFile(ByVal lpFileName As String, ByVal dwDesiredAccess As Long, ByVal dwShareMode As Long, ByVal lpSecurityAttributes As Long, ByVal dwCreationDisposition As Long, ByVal dwFlagsAndAttributes As Long, ByVal hTemplateFile As Long) As IntPtr
    End Function
    <DllImport("KERNEL32.DLL", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function WriteFile(ByVal hFile As IntPtr, ByVal lpBuffer As IntPtr, ByVal nNumberOfBytesToWrite As Long, ByVal lpNumberOfBytesWritten As Long, ByVal lpOverlapped As Long) As Long
    End Function
    <DllImport("KERNEL32.DLL", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CloseHandle(ByVal hObject As IntPtr) As Long
    End Function
    <DllImport("KERNEL32.DLL", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function GlobalUnlock(ByVal hMem As IntPtr) As Long
    End Function
    <DllImport("KERNEL32.DLL", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function GlobalFree(ByVal hMem As IntPtr) As Long
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function SaveCADtoBitmap(ByVal Handle As IntPtr, ByRef cADDraw As CADDRAW, ByVal FileName As String) As Integer
    End Function
    <DllImport("CADImage.dll", _
    SetLastError:=True, CharSet:=CharSet.Ansi, _
    ExactSpelling:=True, _
    CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function SaveCADtoJpeg(ByVal Handle As IntPtr, ByRef cADDraw As CADDRAW, ByVal FileName As String) As Integer
    End Function




    Public Sub GetClientRect(ByVal acl As Control, ByRef R As Rect)
        R.Left = acl.Left
        R.Top = acl.Top
        R.Right = acl.Size.Width
        R.Bottom = acl.Size.Height
    End Sub


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents dlgOpenDXFFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents CD As System.Windows.Forms.SaveFileDialog
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.panel1 = New System.Windows.Forms.Panel
        Me.dlgOpenDXFFile = New System.Windows.Forms.OpenFileDialog
        Me.CD = New System.Windows.Forms.SaveFileDialog
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'panel1
        '
        Me.panel1.AutoScroll = True
        Me.panel1.BackColor = System.Drawing.SystemColors.Control
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panel1.Location = New System.Drawing.Point(0, 0)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(736, 299)
        Me.panel1.TabIndex = 7
        '
        'dlgOpenDXFFile
        '
        Me.dlgOpenDXFFile.DefaultExt = "*.dxf"
        Me.dlgOpenDXFFile.Filter = "*.dxf;*.dwg |*.dxf;*.dwg"
        Me.dlgOpenDXFFile.RestoreDirectory = True
        Me.dlgOpenDXFFile.Title = "OpenDXFFile"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem3, Me.MenuItem11, Me.MenuItem4, Me.MenuItem10})
        Me.MenuItem1.Text = "File"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 0
        Me.MenuItem3.Text = "Load"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 1
        Me.MenuItem11.Text = "Save as BMP"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "Save as JPG"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 3
        Me.MenuItem10.Text = "Exit"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem5, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8, Me.MenuItem9})
        Me.MenuItem2.Text = "Scale"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 0
        Me.MenuItem5.Text = "50"
        '
        'MenuItem6
        '
        Me.MenuItem6.Checked = True
        Me.MenuItem6.Index = 1
        Me.MenuItem6.Text = "100"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 2
        Me.MenuItem7.Text = "200"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 3
        Me.MenuItem8.Text = "500"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 4
        Me.MenuItem9.Text = "1000"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(736, 299)
        Me.Controls.Add(Me.panel1)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnLoadFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        If Not (CADImage.Equals(IntPtr.Zero)) Then
            CloseCAD(CADImage)
            CADImage = IntPtr.Zero
        End If
        dlgOpenDXFFile.ShowDialog()
        CADImage = CreateCAD(panel1.Handle, dlgOpenDXFFile.FileName)
        If Not (CADImage.Equals(IntPtr.Zero)) Then
            panel1.Visible = True
            panel1.Invalidate()
        End If
        'Dim Cnt As Integer = CADLayerCount(CADImage)
        'Dim I As Integer
        'Dim Layer As String
        'Dim EData As Data = New Data
        'For I = 0 To Cnt - 1
        'Layer = CADLayer(CADImage, I, EData)
        'MessageBox.Show(Layer)
        'C = EData.Color
        'Form2.List1.AddItem(EData.Text)
        'Form2.List1.ItemData(I) = Layer
        'Form2.List1.Selected(I) = True
        'Next I
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        If Not (CADImage.Equals(IntPtr.Zero)) Then
            CloseCAD(CADImage)
            CADImage = IntPtr.Zero
        End If
    End Sub

    Private Sub panel1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles panel1.Paint
        Dim R As Rect
        Dim AbsWidth As Single
        Dim AbsHeight As Single
        Dim K As Double
        If Not (CADImage.Equals(IntPtr.Zero)) Then
            GetBoxCAD(CADImage, AbsWidth, AbsHeight)
            If AbsHeight <> -1 Then
                GetClientRect(panel1, R)
                If AbsWidth = 0 Then
                    K = 1
                Else
                    K = AbsHeight / AbsWidth
                End If
                R.Bottom = (R.Top + (R.Right - R.Left) * K)
                R.Left = (R.Left * FScale / 100) + Offset.X
                R.Right = (R.Right * FScale / 100) + Offset.X
                R.Top = (R.Top * FScale / 100) + Offset.Y
                R.Bottom = (R.Bottom * FScale / 100) + Offset.Y
                Dim g1 As Graphics = Graphics.FromHwnd(panel1.Handle)
                Dim tmp = DrawCAD(CADImage, g1.GetHdc(), R)
            End If
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dlgOpenDXFFile.Filter = "*.dxf; *.dwg|*.dxf;*.dwg|*.plt; *.hgl; *.hg; *.hpg" + _
          "|*.plt;*.hgl;*.hg;*.hpg | *.plo; *.hp; *.hp1; *.hp2;|*.plo;*.hp;*.hp1;*.hp2" + _
          "|*.hpgl; *.hpgl2; *.gl2;*.prn;*.spl |*.hpgl; *.hpgl2; *.gl2;*.prn;*.spl"
        Dim R As Rect
        KX = 1
        KY = 1
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        panel1.Invalidate()
    End Sub

    Private Sub panel1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles panel1.MouseDown
        PreviousPoint.X = e.X
        PreviousPoint.Y = e.Y
        panel1.Cursor = Cursors.Hand
        drag = True
    End Sub

    Private Sub panel1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles panel1.MouseMove
        If (CADImage.Equals(IntPtr.Zero)) Then
            Return
        End If
        If drag = True Then
            Offset.X = Offset.X - (PreviousPoint.X - e.X) / KX
            Offset.Y = Offset.Y - (PreviousPoint.Y - e.Y) / KY
            PreviousPoint.X = e.X
            PreviousPoint.Y = e.Y
            panel1.Invalidate()
        End If
    End Sub

    Private Sub panel1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles panel1.MouseUp
        drag = False
        panel1.Cursor = Cursors.Default
        panel1.Invalidate()
    End Sub

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        panel1.Visible = True
    End Sub

    Private Sub Form1_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Deactivate
        panel1.Visible = False
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click, MenuItem6.Click, MenuItem7.Click, MenuItem8.Click, MenuItem9.Click
        MenuItem5.Checked = False
        MenuItem6.Checked = False
        MenuItem7.Checked = False
        MenuItem8.Checked = False
        MenuItem9.Checked = False
        Dim tmp As MenuItem = sender
        tmp.Checked = True
        FScale = Convert.ToInt32(tmp.Text)
        panel1.Invalidate()
    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        Close()
    End Sub

    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem11.Click
        Dim CrDraw As CADDRAW = New CADDRAW
        Dim K As Single
        Dim AbsWidth As Single
        Dim AbsHeight As Single
        CD.FileName = ""
        CD.Filter = "Bmp files (bmp)|*.bmp"
        CD.ShowDialog()
        GetBoxCAD(CADImage, AbsWidth, AbsHeight)
        If AbsWidth = 0 Then
            K = 1
        Else
            K = AbsHeight / AbsWidth
        End If
        CrDraw.Size = Len(CrDraw) 'size of CADDRAW
        CrDraw.R = New Rect
        GetClientRect(panel1, CrDraw.R)
        CrDraw.R.Bottom = CrDraw.R.Right * K
        CrDraw.R.Right = CrDraw.R.Right * FScale / 100
        CrDraw.R.Bottom = CrDraw.R.Bottom * FScale / 100
        CrDraw.DrawMode = 0 ' color mode
        Dim i = SaveCADtoBitmap(CADImage, CrDraw, CD.FileName)
    End Sub

    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click

    End Sub

    Private Sub MenuItem4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        Dim CrDraw As CADDRAW = New CADDRAW
        Dim K As Single
        Dim AbsWidth As Single
        Dim AbsHeight As Single
        CD.FileName = ""
        CD.Filter = "Jpg files (jpg)|*.jpg"
        CD.ShowDialog()
        GetBoxCAD(CADImage, AbsWidth, AbsHeight)
        If AbsWidth = 0 Then
            K = 1
        Else
            K = AbsHeight / AbsWidth
        End If
        CrDraw.Size = Len(CrDraw) 'size of CADDRAW
        CrDraw.R = New Rect
        GetClientRect(panel1, CrDraw.R)
        CrDraw.R.Bottom = CrDraw.R.Right * K
        CrDraw.R.Right = CrDraw.R.Right * FScale / 100
        CrDraw.R.Bottom = CrDraw.R.Bottom * FScale / 100
        CrDraw.DrawMode = 0 ' color mode
        Dim i = SaveCADtoJpeg(CADImage, CrDraw, CD.FileName)
    End Sub
End Class

Public Structure POINTAPI
    Public X As Long
    Public Y As Long
End Structure

Public Structure Rect
    Public Left, Top, Right, Bottom As Integer
    Public Sub New(ByVal val As Rectangle)
        Left = val.Left
        Top = val.Top
        Right = val.Right
        Bottom = val.Bottom
    End Sub
End Structure

Public Structure CADDRAW
    Public Size As Single
    Public DC As Single
    Public R As Rect
    Public DrawMode As Byte
End Structure

Public Structure DXFPOINT
    Public X As Single
    Public Y As Single
    Public Z As Single

    Public Sub New(ByVal aX As Single, ByVal aY As Single)
        X = aX
        Y = aY
    End Sub
End Structure

Public Structure Data
    Public Tag As Integer
    Public Count As Integer
    Public TickCount As Integer
    Public Flags As Byte
    Public Style As Byte
    Public Dimension As Long
    Public DashDots As Long
    Public DashDotsCount As Long
    Public Color As Long
    Public Ticks As Long
    Public Thickness As Single
    Public Rotation As Single
    Public Layer As String
    Public Text As String
    Public Offset As DXFPOINT
    Public Point1 As DXFPOINT
    Public Point2 As DXFPOINT
    Public Point3 As DXFPOINT
    Public Point4 As DXFPOINT
    Public Var1 As Byte()
End Structure






