/*
Copyright (c) 2002-2004 SoftGold software company

Module Name:

    cscadimage.h

Description:

    Master include file CADImage.DLL 

*/
#ifndef _CSCADIMAGE_
#define _CSCADIMAGE_


#include <windows.h>

typedef HANDLE (WINAPI *CSDRAWTODIB)(HANDLE, LPRECT);
typedef HANDLE (WINAPI *CSCREATECAD)(HWND, LPCTSTR);
typedef int (WINAPI *CSCLOSECAD)(HANDLE);
typedef BOOL (WINAPI *CSSETBMSIZE)(int);
typedef int (WINAPI *CSGETBOXCAD)(HANDLE cad_image, float* abs_width, float *abs_height);



#endif
