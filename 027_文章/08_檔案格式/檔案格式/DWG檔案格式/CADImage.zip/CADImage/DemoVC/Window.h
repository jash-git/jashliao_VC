#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>

class CWindow 
{
protected:
	WNDCLASS WndClass;
	HWND hWnd;
	int nHeight, nWidth;
	HDC hMainWndDC;

public:
	CWindow(LPSTR, WNDPROC, HINSTANCE, HICON, HCURSOR, LPSTR, HBRUSH, UINT);
	~CWindow();

	HWND Create(LPSTR, DWORD, int, int, int, int, HMENU, LPVOID); 
	inline HWND GetWindow() {return hWnd;};
	int GetFile(HWND, char*, char*, bool);
	void RePaint();
};
