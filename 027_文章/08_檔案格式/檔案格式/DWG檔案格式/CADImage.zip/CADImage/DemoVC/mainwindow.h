#include "Window.h"
#include "cadimage.h"

#define ERR_MSG_LEN 256 //the length of cErrorCode has to be defined by user

const float ROTATION_ANGLE = 10.0f;

const int QUANTITY_OF_PARTS = 3;
const int QUANTITY_OF_BUTTONS = 9;
const int TOOLBAR_BUTTON_SIZE = 26;
const int COMBOBOX_ITEM_SIZE = 20;

const int TOOLBAR_SIZE = 32;

typedef struct _CADOPTIONS 
{
	int NullLineWidth;
	bool IsDrawingBox;
	bool IsShowLineWeight;
    bool IsNearestPointMode;
} CADOPTIONS, *LPCADOPTIONS;

class CMainWindow : public CWindow  
{
#ifndef CS_STATIC_DLL 
	HINSTANCE CADDLL;
	static CADLAYER CADLayer;
	static CADLAYERCOUNT CADLayerCount;
	static CADLAYERVISIBLE CADLayerVisible;
	static CADVISIBLE CADVisible;	
	static CLOSECAD CloseCAD;
	static CREATECAD CreateCAD;
	static CADLAYOUT CADLayout;
	static CADLAYOUTNAME CADLayoutName;
	static CADLAYOUTSCOUNT CADLayoutsCount;
	static CADLAYOUTVISIBLE CADLayoutVisible;
	static CURRENTLAYOUTCAD CurrentLayoutCAD;
	static DEFAULTLAYOUTINDEX DefaultLayoutIndex;
	static DRAWCADEX DrawCADEx;
	static DRAWCADTOJPEG DrawCADtoJpeg;
	static GETBOXCAD GetBoxCAD;
	static GETCADCOORDS GetCADCoords;
	static GETEXTENTSCAD GetExtentsCAD;
	static GETIS3DCAD GetIs3dCAD;
	static GETLASTERRORCAD GetLastErrorCAD;
	static GETNEARESTENTITY GetNearestEntity;
	static GETPOINTCAD GetPointCAD;	
	static RESETDRAWINGBOXCAD ResetDrawingBoxCAD;
	static SETDEFAULTCOLOR SetDefaultColor;
	static SETDRAWINGBOXCAD SetDrawingBoxCAD;
	static SETNULLLINEWIDTHCAD SetNullLineWidthCAD;
	static SETPROCESSMESSAGESCAD SetProcessMessagesCAD;
	static SETROTATECAD SetRotateCAD;	
	static SETSHOWLINEWEIGHTCAD SetShowLineWeightCAD;	
#endif
	CADOPTIONS optionsCAD;
	BOOL drag;
	BYTE DrwMode;
	COLORREF colorBgrnd;
	FRECT frectExtentsCAD;
	HANDLE CADImage;
	HBRUSH brushBackground;
	HCURSOR curWait, curHand, curTarget, curDefault;
	POINT offset;
	POINTS oldPoint;
	float fAbsWidth, fAbsHeight;
	FPOINT ScaleRect;
	FRECT rectDrawingBox;
	double fKoef;		
	int nScale;
	bool bIsPocessing;
	static bool IsAppChangingList;	
	CADDRAW CADDraw;
	POINT OldNearestPoint;
	bool Is3D();
	void DestroyLayersDlg();
	void DoMousePosition(POINTS PointOnScr);	
	void FillLayersList();
	static BOOL CALLBACK AboutDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK ControlProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK LayersDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK PropertiesDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
	void SplitStatusBar(int nParts= QUANTITY_OF_PARTS);			
	void RecalculateExtents();
	
public:
	bool bRotated3D, bIsRotated;
	HINSTANCE hInstance;
	HWND hwndStatusBar, hwndToolBar, hwndComboBox;		
	static HWND hwndLayersDlg;
	static HWND hwndPropertiesDlg;

	CMainWindow(LPSTR, WNDPROC, HINSTANCE, HICON, HCURSOR, LPSTR, HBRUSH, UINT);
	virtual ~CMainWindow();
	void Load(CADOPTIONS CADOpts);
	void Draw();
	void LButtonDown(POINTS);
	void LButtonUp(POINTS);
	void MouseMove(POINTS);		
	void ChangeView(BYTE);	
	void DoCreateStatusBar(HWND hwndParent, HINSTANCE hInst);
	void DoCreateToolBar(HWND hwndParent, HINSTANCE hInst);
	void DoCreateComboBox(HINSTANCE hInst);
	void DrawNearestMark(POINT NewPoint, LPPOINT OldPoint);
	bool GetIsDrawingBox();
	bool GetIsPocessing();
	bool GetIsShowLineWeight();
	bool GetIsNearestPointMode();
	int  GetNullLineWidth();
	void ResetDrawingBox();
	void ReSize(WPARAM wParam,LPARAM lParam);		
	void RotateCAD(const AXES axis, const float angle);		
	void SaveAs();	
	void SetDrawingBox();	
	void SetBgrndColor(const COLORREF color);
	void SetDefColor();
	bool SetCurrentLayout();
	bool SetNullLineWidth(int NullLineWidth);
	bool SetIsNearestPointMode(bool Checked);
	bool SetOptionsCAD(CADOPTIONS CADOpts);
	void SetTextToStatusBar(LPSTR str, int part = 0);	
	void SetScale(int);
	void ShowAboutDlg();
	void ShowLayersDlg(bool Visible=true);
	void ShowPropertiesDlg(bool Visible=true);
	bool ShowLineWeight(bool IsShow=false);
};

