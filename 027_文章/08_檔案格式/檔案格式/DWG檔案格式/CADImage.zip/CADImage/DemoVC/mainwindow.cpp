// MainWindow.cpp: implementation of the CMainWindow class.
//
//////////////////////////////////////////////////////////////////////

#include "MainWindow.h"
#include <memory.h>
#include "resource.h"
#include <stdio.h>
#include <math.h>

//
//  Functions for the mouse position definition
//
void Ort(LPFPOINT point)
{
  float len = (float)sqrt(point->x*point->x + point->y*point->y + point->z*point->z);
  point->x = point->x / len;
  point->y = point->y / len;
  point->z = point->z / len;
}

void MoveToPosition(LPFPOINT point, const FPOINT pos, const int direction)
{  
  point->x = point->x + direction * pos.x;
  point->y = point->y + direction * pos.y;
  point->z = point->z + direction * pos.z;
}

//////////////////////////////////////////////////////////////////////
// Static members
//////////////////////////////////////////////////////////////////////
#ifndef CS_STATIC_DLL
    HINSTANCE CADDLL;
	CADLAYER CMainWindow::CADLayer;
	CADLAYERCOUNT CMainWindow::CADLayerCount;
	CADLAYERVISIBLE CMainWindow::CADLayerVisible;
	CADVISIBLE CMainWindow::CADVisible;	
	CLOSECAD CMainWindow::CloseCAD;
	CREATECAD CMainWindow::CreateCAD;
	CADLAYOUT CMainWindow::CADLayout;
	CADLAYOUTNAME CMainWindow::CADLayoutName;
	CADLAYOUTSCOUNT CMainWindow::CADLayoutsCount;
	CADLAYOUTVISIBLE CMainWindow::CADLayoutVisible;
	CURRENTLAYOUTCAD CMainWindow::CurrentLayoutCAD;
	DEFAULTLAYOUTINDEX CMainWindow::DefaultLayoutIndex;
	DRAWCADEX CMainWindow::DrawCADEx;
	DRAWCADTOJPEG CMainWindow::DrawCADtoJpeg;
	GETBOXCAD CMainWindow::GetBoxCAD;
	GETCADCOORDS CMainWindow::GetCADCoords;
	GETEXTENTSCAD CMainWindow::GetExtentsCAD;
	GETIS3DCAD CMainWindow::GetIs3dCAD;
	GETLASTERRORCAD CMainWindow::GetLastErrorCAD;
	GETNEARESTENTITY CMainWindow::GetNearestEntity;
	GETPOINTCAD CMainWindow::GetPointCAD;	
	RESETDRAWINGBOXCAD CMainWindow::ResetDrawingBoxCAD;
	SETDEFAULTCOLOR CMainWindow::SetDefaultColor;
	SETDRAWINGBOXCAD CMainWindow::SetDrawingBoxCAD;
	SETNULLLINEWIDTHCAD CMainWindow::SetNullLineWidthCAD;
	SETPROCESSMESSAGESCAD CMainWindow::SetProcessMessagesCAD;
	SETROTATECAD CMainWindow::SetRotateCAD;	
	SETSHOWLINEWEIGHTCAD CMainWindow::SetShowLineWeightCAD;	
#endif

bool CMainWindow::IsAppChangingList;
HWND CMainWindow::hwndLayersDlg;
HWND CMainWindow::hwndPropertiesDlg;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CMainWindow::CMainWindow(LPSTR szClassName, WNDPROC WndProc, HINSTANCE hInst,
                 HICON hIcon, HCURSOR hCursor, LPSTR lpszMenuName,
                 HBRUSH color, UINT style):
CWindow(szClassName, WndProc, hInst, hIcon, hCursor, lpszMenuName, color, style)
{	
	hInstance = hInst;
	hwndStatusBar = hwndToolBar = hwndComboBox = hwndLayersDlg = NULL;
	curWait = LoadCursor(NULL, MAKEINTRESOURCE(IDC_WAIT));	
	int r = GetLastError();
	curHand = LoadCursor(hInstance, "HAND");
	curTarget = LoadCursor(hInstance, "TARGET");
	curDefault = hCursor;
	SetCursor(curDefault);
	ScaleRect.x = -1;
	fKoef = 1;
    colorBgrnd = RGB(255,255,255);
	oldPoint.x = 0;
	oldPoint.y = 0;
	offset.x = 0;
	offset.y = TOOLBAR_SIZE;
	nScale = 0;
	drag = false;
	bIsPocessing = false;
	DrwMode = 0;	
    brushBackground = WndClass.hbrBackground;	
	CADImage = 0;	
	optionsCAD.NullLineWidth = 0;
	optionsCAD.IsDrawingBox = false;
	optionsCAD.IsShowLineWeight = true;
	optionsCAD.IsNearestPointMode = false;
    // Initialisation hyperlink controls for "About dialog" 
	WNDCLASSEX  wndclass;	      
	wndclass.cbSize        = sizeof (wndclass);
    wndclass.style         = CS_HREDRAW | CS_VREDRAW;
    wndclass.lpfnWndProc   = ControlProc;
    wndclass.cbClsExtra    = 0;
    wndclass.cbWndExtra    = 0;
    wndclass.hInstance     = hInstance;
	wndclass.hIcon         = NULL;
    wndclass.hCursor       = LoadCursor(hInstance, "Hand");
    wndclass.hbrBackground = (HBRUSH) (COLOR_BTNFACE + 1);
    wndclass.lpszMenuName  = NULL;
    wndclass.lpszClassName = "HyperLink";
	wndclass.hIconSm       = NULL;
    RegisterClassEx (&wndclass);

#ifndef CS_STATIC_DLL 
	CADDLL = LoadLibrary("CADImage.dll");
	if (CADDLL!= NULL)
	{
		CADLayer = (CADLAYER) GetProcAddress(CADDLL, "CADLayer");
	    CADLayerCount = (CADLAYERCOUNT) GetProcAddress(CADDLL, "CADLayerCount");
	    CADLayerVisible = (CADLAYERVISIBLE) GetProcAddress(CADDLL, "CADLayerVisible");
	    CADVisible = (CADVISIBLE) GetProcAddress(CADDLL, "CADVisible");
		CreateCAD = (CREATECAD) GetProcAddress(CADDLL, "CreateCAD");
		CloseCAD  = (CLOSECAD)  GetProcAddress(CADDLL, "CloseCAD");
		CADLayout = (CADLAYOUT) GetProcAddress(CADDLL, "CADLayout");
		CADLayoutName = (CADLAYOUTNAME) GetProcAddress(CADDLL, "CADLayoutName");
		CADLayoutsCount = (CADLAYOUTSCOUNT) GetProcAddress(CADDLL, "CADLayoutsCount");
		CADLayoutVisible = (CADLAYOUTVISIBLE) GetProcAddress(CADDLL, "CADLayoutVisible");
		CurrentLayoutCAD = (CURRENTLAYOUTCAD) GetProcAddress(CADDLL, "CurrentLayoutCAD");
		DefaultLayoutIndex = (DEFAULTLAYOUTINDEX) GetProcAddress(CADDLL, "DefaultLayoutIndex");
		DrawCADEx = (DRAWCADEX) GetProcAddress(CADDLL, "DrawCADEx");
		DrawCADtoJpeg = (DRAWCADTOJPEG) GetProcAddress(CADDLL, "DrawCADtoJpeg");
		GetBoxCAD = (GETBOXCAD) GetProcAddress(CADDLL, "GetBoxCAD");
		GetCADCoords = (GETCADCOORDS) GetProcAddress(CADDLL, "GetCADCoords");
        GetExtentsCAD = (GETEXTENTSCAD) GetProcAddress(CADDLL, "GetExtentsCAD");
		GetIs3dCAD = (GETIS3DCAD) GetProcAddress(CADDLL, "GetIs3dCAD");
		GetLastErrorCAD = (GETLASTERRORCAD) GetProcAddress(CADDLL, "GetLastErrorCAD");
		GetNearestEntity = (GETNEARESTENTITY) GetProcAddress(CADDLL, "GetNearestEntity");
		GetPointCAD = (GETPOINTCAD) GetProcAddress(CADDLL, "GetPointCAD");		
		ResetDrawingBoxCAD = (RESETDRAWINGBOXCAD) GetProcAddress(CADDLL, "ResetDrawingBoxCAD");                                    
		SetDefaultColor = (SETDEFAULTCOLOR) GetProcAddress(CADDLL, "SetDefaultColor");
		SetDrawingBoxCAD = (SETDRAWINGBOXCAD) GetProcAddress(CADDLL, "SetDrawingBoxCAD");
		SetNullLineWidthCAD = (SETNULLLINEWIDTHCAD) GetProcAddress(CADDLL, "SetNullLineWidthCAD");
		SetProcessMessagesCAD = (SETPROCESSMESSAGESCAD)  GetProcAddress(CADDLL, "SetProcessMessagesCAD");
		SetRotateCAD = (SETROTATECAD) GetProcAddress(CADDLL, "SetRotateCAD");
		SetShowLineWeightCAD = (SETSHOWLINEWEIGHTCAD)  GetProcAddress(CADDLL, "SetShowLineWeightCAD");
	}
	else
	{
		CADLayer = NULL;
	    CADLayerCount = NULL;
	    CADLayerVisible = NULL;
	    CADVisible = NULL;				
		CloseCAD = NULL;
		CreateCAD = NULL;
		CADLayout = NULL;
		CADLayoutName = NULL;
		CADLayoutsCount = NULL;
		CADLayoutVisible = NULL;
		CurrentLayoutCAD = NULL;
		DefaultLayoutIndex = NULL;
		DrawCADEx = NULL;
		DrawCADtoJpeg = NULL;
		GetBoxCAD = NULL;
		GetCADCoords = NULL;
		GetIs3dCAD = NULL;
		GetLastErrorCAD = NULL;
		GetNearestEntity = NULL;
		GetPointCAD = NULL;
		GetExtentsCAD = NULL;
		ResetDrawingBoxCAD = NULL;
		SetDrawingBoxCAD = NULL;
		SetDefaultColor = NULL;
		SetNullLineWidthCAD = NULL;
        SetProcessMessagesCAD = NULL;
		SetRotateCAD = NULL;
		SetShowLineWeightCAD = NULL;
		MessageBox(0, "CADImage.dll not loaded!", "Error", 0);
	}    
#endif	
}

CMainWindow::~CMainWindow()
{
#ifndef CS_STATIC_DLL
	if (CADDLL)
		FreeLibrary(CADDLL);
#endif	
}

void CMainWindow::Load(CADOPTIONS CADOpts)
{
	if (bIsPocessing)
	{
		MessageBox(hWnd, "The program is in progress. Please wait.", "Warning", MB_ICONINFORMATION);
		return;
	}
	char cErrorCode[ERR_MSG_LEN];
	int nErrorCode;

#ifndef CS_STATIC_DLL
	if (!CADDLL) return;
#endif
	char file_name [255] = "";
	if (!this->GetFile (this->hWnd, file_name, "CAD files (dwg, dxf, plt, hpg, hpgl, cgm, svg)\0*.dwg;*.dxf;*.plt;*.hpg;*.hpgl;*.cgm; *.svg\0All files (*.*)\0*.*\0", true))
		return;	
	if (CADImage)
		CloseCAD(CADImage);
	CADImage = 0;
    bRotated3D = false;
	bIsRotated = false;	
#ifndef CS_STATIC_DLL
	if (CADDLL)
#endif
	{			
		SetCursor(curWait);
		SetTextToStatusBar("Please wait...");
		for (int i=1; i<QUANTITY_OF_PARTS; ++i)
		  SetTextToStatusBar("", i);
        bIsPocessing = true;
		CADImage = CreateCAD(hWnd, file_name);
        bIsPocessing = false;
		nErrorCode = GetLastErrorCAD(cErrorCode, ERR_MSG_LEN);
		if (nErrorCode == 0)
		{
			RecalculateExtents();
			SetCursor(curDefault);
			SetScale(100);
			SetTextToStatusBar(file_name);
			FillLayersList();
			DoCreateComboBox(hInstance);					
		}
		else
		{
			switch(nErrorCode)
			{			
			case 1006:
				MessageBox(hWnd, cErrorCode, "Error", MB_ICONERROR);
				SetTextToStatusBar("No file loaded");		
			default:
				break;
			}
		}
		SetOptionsCAD(CADOpts);
		RePaint();
	}
}

void CMainWindow::RecalculateExtents()
{
	oldPoint.x = 0;
	oldPoint.y = 0;
	offset.x = 0;
	offset.y = TOOLBAR_SIZE;
	GetExtentsCAD(CADImage, &frectExtentsCAD);
	//fAbsHeight = frectExtentsCAD.Points.Top - frectExtentsCAD.Points.Bottom;
	//fAbsWidth  = frectExtentsCAD.Points.Right - frectExtentsCAD.Points.Left;
	GetBoxCAD(CADImage, &fAbsWidth, &fAbsHeight);		
	fKoef = fAbsHeight / fAbsWidth;
	ScaleRect.x = -1;
}

void CMainWindow::Draw()
{
    if (bIsPocessing) 
		return;
	
	PAINTSTRUCT Paint;
	HDC hDC;		

	hDC = BeginPaint(hWnd, &Paint);	
	OldNearestPoint.x = -10;
	OldNearestPoint.y = -10;
	SetBgrndColor(colorBgrnd);

	if ((CADImage) 
#ifndef CS_STATIC_DLL
		&& 
		(DrawCADEx)
#endif
		)
	{		
        if (fAbsHeight > 0)// when loading the CAD file
		{		
			sgFloat scale = (sgFloat) nScale / 100.0;
			memset(&CADDraw, 0, sizeof(CADDRAW));
			GetClientRect(hWnd, &CADDraw.R);
			CADDraw.R.left = int(CADDraw.R.left  * scale) + offset.x;
			CADDraw.R.right = int(CADDraw.R.right * scale) + offset.x;
			CADDraw.R.top = int(CADDraw.R.top * scale) + offset.y;			
			CADDraw.R.bottom = int(CADDraw.R.top  + (CADDraw.R.right - CADDraw.R.left) * fKoef);						
			ScaleRect.x = fAbsWidth / (CADDraw.R.right - CADDraw.R.left);
			ScaleRect.y = fAbsHeight / (CADDraw.R.bottom - CADDraw.R.top);
			CADDraw.Size = sizeof(CADDRAW);			
			CADDraw.DrawMode = DrwMode;
			CADDraw.DC = hDC;
			
			DrawCADEx(CADImage, &CADDraw);			
		}		
	}
	EndPaint(hWnd, &Paint);	
}

void CMainWindow::LButtonDown(POINTS Point)
{
	if (CADImage) 
	{
		drag = true;
		oldPoint = Point;
		SetCursor(curHand);		
		SetCapture(hWnd);		
		RePaint();
	}
}

void CMainWindow::LButtonUp(POINTS Point)
{
	drag = false;
	SetCursor(curDefault);	
	ReleaseCapture();
}

void CMainWindow::MouseMove(POINTS Point)
{
	if (drag)
	{
		SetCursor(curHand);
		offset.x = offset.x + Point.x - oldPoint.x;
		offset.y = offset.y + Point.y - oldPoint.y; 
		oldPoint = Point;
		RePaint();
	}
	else if (CADImage) 
	{  
		SetCursor(curTarget);
		DoMousePosition(Point);		
	}
}


void CMainWindow::SetScale(int scale)
{
	HMENU hMenu;
	if ((nScale != scale) && (CADImage))
	{
		hMenu = GetMenu(hWnd);
		if (nScale)
			CheckMenuItem(hMenu, ID_SCALE + nScale, MF_BYCOMMAND | MF_UNCHECKED);
		nScale = scale;
		CheckMenuItem(hMenu, ID_SCALE + scale, MF_BYCOMMAND | MF_CHECKED);
		RePaint();
	}
}

void CMainWindow::SaveAs()
{
	CADDRAW CADDraw;	
    float AbsWidht, AbsHeight, scale;
	double Koef;		

	if ((!CADImage) 
#ifndef CS_STATIC_DLL
		|| (!CADDLL)
#endif
		) 
		return;		 
	char FileName [255] = "";
	
	if (!this->GetFile (this->hWnd, FileName, "JPEG image\0*.jpg", false))
		return;	
	memset(&CADDraw, 0, sizeof(CADDRAW));	
	CADDraw.Size = sizeof(CADDraw);
	scale = (float) nScale / 100;
	GetBoxCAD(CADImage, &AbsWidht, &AbsHeight);	
	GetClientRect(hWnd, &CADDraw.R);
    if (AbsHeight != -1)
	{    
		Koef = AbsHeight / AbsWidht;
		CADDraw.R.top = 0;
		CADDraw.R.left = 0;
		CADDraw.R.bottom = int(CADDraw.R.bottom * scale);
		CADDraw.R.right = int(CADDraw.R.right * scale);
		CADDraw.R.bottom = int(CADDraw.R.top  + CADDraw.R.right * Koef);			 
		CADDraw.DrawMode = DrwMode;
		HANDLE Hnd = DrawCADtoJpeg(CADImage, &CADDraw);		
		if (Hnd) 
		{
			DWORD Size = GlobalSize(Hnd);
			void *P = GlobalLock(Hnd);
			HANDLE FHnd = CreateFile(FileName, GENERIC_WRITE, FILE_SHARE_READ,
				NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			if (FHnd) 
			{
				DWORD Wrt;
				WriteFile(FHnd, P, Size, &Wrt, NULL);
				CloseHandle(FHnd);			
			}
			GlobalUnlock(Hnd);    
			GlobalFree(Hnd);	
			
		}
	}

}

void CMainWindow::ChangeView(BYTE View)
{
	HMENU hMenu;

	if ((DrwMode != View) && (CADImage))
	{
		hMenu = GetMenu(hWnd);		
		CheckMenuItem(hMenu, ID_VIEW + DrwMode + 1, MF_BYCOMMAND | MF_UNCHECKED);
		DrwMode = View;
		CheckMenuItem(hMenu, ID_VIEW + View + 1, MF_BYCOMMAND | MF_CHECKED);
		RePaint();
	}
}

void CMainWindow::SetDefColor()
{
	CHOOSECOLOR cc;                 
	static COLORREF acrCustClr[16]; 
	static DWORD rgbCurrent;        
	
	ZeroMemory(&cc, sizeof(CHOOSECOLOR));
	cc.lStructSize = sizeof(CHOOSECOLOR);
	cc.hwndOwner = hWnd;
	cc.hwndOwner = 0;
	cc.lpCustColors = (LPDWORD) acrCustClr;
	cc.rgbResult = rgbCurrent;
	cc.Flags = CC_FULLOPEN | CC_RGBINIT;

	if (ChooseColor(&cc)) 
	{
		  SetDefaultColor(CADImage, cc.rgbResult);
		  RePaint();
	}
}

void CMainWindow::DoCreateStatusBar(HWND hwndParent, HINSTANCE hInst) 
{     
    ::InitCommonControls(); 

    hwndStatusBar = CreateWindowEx( 
        0,                        
        STATUSCLASSNAME,          
        (LPCTSTR) NULL,           
        WS_CHILD | WS_BORDER,
        0, 0, 0, 0,               
        hwndParent,               
        NULL,                     
        hInst,                    
        NULL);                    

	SplitStatusBar();    
	SetTextToStatusBar("Demo"); 	
	ShowWindow(hwndStatusBar, SW_SHOWNORMAL);
}

void CMainWindow::SetTextToStatusBar(LPSTR str, int part)
{
	SendMessage(hwndStatusBar, SB_SETTEXT, part, (LPARAM) str); 
}

void CMainWindow::DoCreateToolBar(HWND hwndParent, HINSTANCE hInst) 
{	
    TBADDBITMAP tbAddBitMap[QUANTITY_OF_BUTTONS];	
    TBBUTTON tbButton[QUANTITY_OF_BUTTONS];
    ::InitCommonControls(); 
    hwndToolBar = ::CreateWindowEx( 
        0,      
        TOOLBARCLASSNAME,
        (LPCTSTR) NULL,  
        CCS_TOP | WS_CHILD,			 
        0, 0, 0, 0,        
        hwndParent,    
        NULL,
        hInst,         
        NULL);         
    ::SendMessage(hwndToolBar, TB_BUTTONSTRUCTSIZE, (WPARAM) sizeof(TBBUTTON) , (LPARAM)0 );
	for (int i=0; i< QUANTITY_OF_BUTTONS; i++) 
		tbAddBitMap[i].hInst = hInst;
	tbAddBitMap[0].nID = IDB_BMORBITUPX;
	tbAddBitMap[1].nID = IDB_BMORBITDOWNX;
	tbAddBitMap[2].nID = IDB_BMORBITUPY;
	tbAddBitMap[3].nID = IDB_BMORBITDOWNY;
	tbAddBitMap[4].nID = IDB_BMORBITUPZ;
	tbAddBitMap[5].nID = IDB_BMORBITDOWNZ;
	tbAddBitMap[6].nID = IDB_BMOPTIONSLAYERS;
	tbAddBitMap[7].nID = IDB_BMDRAWINGBOX;
	tbAddBitMap[8].nID = IDB_BMROTATE;
	tbButton[0].idCommand = IDM_ORBITUPX;
	tbButton[1].idCommand = IDM_ORBITDOWNX;
	tbButton[2].idCommand = IDM_ORBITUPY;
	tbButton[3].idCommand = IDM_ORBITDOWNY;
	tbButton[4].idCommand = IDM_ORBITUPZ;
	tbButton[5].idCommand = IDM_ORBITDOWNZ;
	tbButton[6].idCommand = IDM_OPTIONSLAYERS;
	tbButton[7].idCommand = IDM_OPTIONSDRAWINGBOX;
	tbButton[8].idCommand = IDM_ROTATE;
	::SendMessage(hwndToolBar, TB_SETBITMAPSIZE, (WPARAM) 0 , (LPARAM) MAKELONG(TOOLBAR_BUTTON_SIZE, TOOLBAR_BUTTON_SIZE));	
    
	for (i=0; i< QUANTITY_OF_BUTTONS; i++) 
	{
		tbButton[i].iBitmap = i;
		tbButton[i].fsState = TBSTATE_ENABLED;
	    tbButton[i].fsStyle = TBSTYLE_AUTOSIZE | TBSTYLE_BUTTON;
	    tbButton[i].dwData = 0;
		tbButton[i].iString = 0;		
		::SendMessage(hwndToolBar, TB_ADDBITMAP, (WPARAM) 0 , (LPARAM)&tbAddBitMap[i]);		
	}

    ::SendMessage(hwndToolBar, TB_SETBUTTONSIZE, (WPARAM) 0 , (LPARAM) MAKELONG(TOOLBAR_BUTTON_SIZE, TOOLBAR_BUTTON_SIZE));
	::SendMessage(hwndToolBar, TB_ADDBUTTONS , (WPARAM)i , (LPARAM)&tbButton); 		
	::SendMessage(hwndToolBar, TB_AUTOSIZE,   (WPARAM)0 , (LPARAM)0 );
	
	::ShowWindow(hwndToolBar, SW_SHOWNORMAL);    
}

void CMainWindow::DoCreateComboBox(HINSTANCE hInst) 
{	
	if (!hwndToolBar) return;
	if (CADImage) 
	{
		char LayoutName[100];
		int i, defaultLayout, Count;		
		Count = CADLayoutsCount(CADImage);
		defaultLayout = DefaultLayoutIndex(CADImage);
		if (hwndComboBox) 
			DestroyWindow(hwndComboBox);		
		hwndComboBox = ::CreateWindowEx( 
			0,      
			"COMBOBOX",
			(LPCTSTR) NULL,  
			CBS_DROPDOWNLIST | WS_CHILD,			 
			(TOOLBAR_BUTTON_SIZE+8)*QUANTITY_OF_BUTTONS, 4, 120, 40+COMBOBOX_ITEM_SIZE*Count,        
			hwndToolBar,    
			NULL,
			hInst,         
			NULL);		
	    for (i= 0; i < Count; ++i)
	    {
			CADLayoutName(CADImage, i, LayoutName, 100);			
			::SendMessage(hwndComboBox, (UINT) CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) LayoutName);			
		}
		::SendMessage(hwndComboBox, (UINT) CB_SETCURSEL, (WPARAM) defaultLayout, 0);
		RePaint();
		::ShowWindow(hwndComboBox, SW_SHOWNORMAL);
	}	
}

bool CMainWindow::SetCurrentLayout()
{
    int lindex;
    lindex = ::SendMessage(hwndComboBox, (UINT) CB_GETCURSEL, 0, 0);
	ResetDrawingBox();
    CurrentLayoutCAD(CADImage, lindex, TRUE);
	RecalculateExtents();
	SetScale(100);
	RePaint();
	return true;
}

bool CMainWindow::Is3D()
{
	int is3d;
	GetIs3dCAD(CADImage, &is3d);
	if (bRotated3D || (is3d == 1) )
		return true;
	return false;
}

void CMainWindow::DoMousePosition(POINTS PointOnScr)
{	
	if ((!CADImage) || (ScaleRect.x < 0 )) return;
	FPOINT newmousePt;
	POINT NearestPoint;
	char str[36];
	char NearestEntityName[100];
	float sX, sY;

	if (Is3D())
	{
		SetTextToStatusBar("Is 3D drawing", 1);
		return;
	}			
	NearestPoint.x = PointOnScr.x - offset.x;
	NearestPoint.y = PointOnScr.y - offset.y;
	sX = (float)((PointOnScr.x - offset.x) * ScaleRect.x / fAbsWidth);
	sY = (float)(1 - (PointOnScr.y - offset.y) * ScaleRect.y / fAbsHeight);
	GetCADCoords(CADImage, sX, sY, &newmousePt);
	sprintf(str, "(%6.6f, %6.6f)\0", newmousePt.x, newmousePt.y);
	SetTextToStatusBar(str, 1);	
	if (GetIsNearestPointMode())
	{
		GetNearestEntity(CADImage, NearestEntityName, 100, &CADDraw.R, (LPPOINT)&NearestPoint);
		DrawNearestMark(NearestPoint, &OldNearestPoint);		
		SetTextToStatusBar(NearestEntityName, 2);	
	}
}

void CMainWindow::SplitStatusBar(int nParts)
{
	RECT rcClient; 
    HLOCAL hloc; 
    LPINT lpParts; 
    int i, nWidth;
    GetClientRect(hWnd, &rcClient); 
    hloc = LocalAlloc(LHND, sizeof(int) * nParts); 
    lpParts = (LPINT)LocalLock(hloc); 
    nWidth = rcClient.right / nParts; 
    for (i = 0; i < nParts; i++) 
	{ 
        lpParts[i] = nWidth; 
        nWidth+= nWidth; 
    } 	
	
    ::SendMessage(hwndStatusBar, SB_SETPARTS, (WPARAM) nParts, (LPARAM) lpParts); 	

    LocalUnlock(hloc); 
    LocalFree(hloc);   
}

void CMainWindow::ReSize(WPARAM wParam,LPARAM lParam)
{
	SplitStatusBar();
  	::SendMessage(hwndStatusBar, WM_SIZE, wParam, lParam);
	::SendMessage(hwndToolBar, TB_AUTOSIZE, (WPARAM)0 , (LPARAM)0 );
}

void CMainWindow::RotateCAD(const AXES axis, const float angle)
{
	if (CADImage && !optionsCAD.IsDrawingBox) 
	{		
		SetRotateCAD(CADImage, angle, int(axis));
		bIsRotated = true;
		if (axis != axisZ)
		{
		  bRotated3D = true;
		  SetTextToStatusBar("", 2);	
		}
		RePaint();
	}
}

void CMainWindow::SetBgrndColor(const COLORREF color)
{
	colorBgrnd = color;
	RECT rect;
	GetClientRect(hWnd, &rect);
	LOGBRUSH brush;
	brush.lbStyle = BS_SOLID;
	brush.lbColor = colorBgrnd;
	brush.lbHatch = 0;
	brushBackground = CreateBrushIndirect(&brush);	
	FillRect(hMainWndDC, &rect, brushBackground);
	DeleteObject(brushBackground);
	RePaint();
}

void CMainWindow::ShowAboutDlg()
{
	::InitCommonControls();     
    DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUT), hWnd, AboutDialogProc);	
}

void CMainWindow::ShowLayersDlg(bool Visible)
{		
	if (hwndLayersDlg == NULL)
		hwndLayersDlg = CreateDialog(hInstance, (LPCTSTR)IDD_LAYERS, hWnd, (DLGPROC) LayersDialogProc);	
	if (Visible)
	{
		ShowWindow(hwndLayersDlg, SW_SHOW);
		SetFocus(hwndLayersDlg);
	}
	else
	{
		ShowWindow(hwndLayersDlg, SW_HIDE);
		SetFocus(hWnd);
	}	
}

void CMainWindow::ShowPropertiesDlg(bool Visible)
{		
	if (hwndPropertiesDlg == NULL)
		hwndPropertiesDlg = CreateDialog(hInstance, (LPCTSTR)IDD_PROPERTIES, hWnd, (DLGPROC) PropertiesDialogProc);	
	if (Visible)
	{
		SetWindowLong(hwndPropertiesDlg, GWL_USERDATA, (LONG) this);
		ShowWindow(hwndPropertiesDlg, SW_SHOW);
		SetFocus(hwndPropertiesDlg);
	}
	else
	{
		ShowWindow(hwndPropertiesDlg, SW_HIDE);
		SetFocus(hWnd);
	}	
}

void CMainWindow::ResetDrawingBox()
{
	if ((CADImage != NULL) && optionsCAD.IsDrawingBox && !bIsRotated)
	{
		ResetDrawingBoxCAD(CADImage);		
		RecalculateExtents();
		optionsCAD.IsDrawingBox = false;
		RePaint();		
	}		
}

void CMainWindow::SetDrawingBox()
{
	optionsCAD.IsDrawingBox = true;
	if ((CADImage != NULL) && !bIsRotated)
	{		
		rectDrawingBox.Points.Left = (frectExtentsCAD.Points.Left + frectExtentsCAD.Points.Right)/2;
		rectDrawingBox.Points.Top =  frectExtentsCAD.Points.Top;
		rectDrawingBox.Points.Z1 = 0;  
		rectDrawingBox.Points.Right = frectExtentsCAD.Points.Right; 
		rectDrawingBox.Points.Bottom = frectExtentsCAD.Points.Bottom; 
		rectDrawingBox.Points.Z2 = 0; 		
		SetDrawingBoxCAD(CADImage, &rectDrawingBox);
		RecalculateExtents();		
		RePaint();
	}	
}

void CMainWindow::DrawNearestMark(POINT NewPoint, LPPOINT OldPoint)
{
	RECT NewR, OldR;
	HPEN hPen = CreatePen(PS_SOLID, 1, 0xFF0000);
	HPEN hOldPen = (HPEN)SelectObject(hMainWndDC, hPen);

	HBRUSH hBrush;
	HBRUSH hOldBrush;
	LOGBRUSH LogBrush;
	
	int Index = SaveDC(hMainWndDC);

	LogBrush.lbStyle = BS_SOLID;
	LogBrush.lbHatch = 0;
	LogBrush.lbColor = 0xFF0000;
	hBrush = CreateBrushIndirect(&LogBrush);
	hOldBrush = (HBRUSH)SelectObject(hMainWndDC, hBrush);

	hOldPen = (HPEN)SelectObject(hMainWndDC, hPen);
	SetROP2(hMainWndDC, R2_NOTXORPEN);
	SetBkColor(hMainWndDC, (COLORREF)(LogBrush.lbColor));
	SetBkMode(hMainWndDC, OPAQUE);

	NewR.left = NewPoint.x - 4;
	NewR.top = NewPoint.y - 4;
	NewR.right = NewPoint.x + 4;
	NewR.bottom = NewPoint.y + 4;

	OldR.left = OldPoint->x - 4;
	OldR.top = OldPoint->y - 4;
	OldR.right = OldPoint->x + 4;
	OldR.bottom = OldPoint->y + 4;

	Rectangle(hMainWndDC, OldR.left, OldR.top, OldR.right, OldR.bottom);
	Rectangle(hMainWndDC, NewR.left, NewR.top, NewR.right, NewR.bottom);

	DeleteObject(hPen);	
	SelectObject(hMainWndDC, hOldPen);
	DeleteObject(hBrush);	
	SelectObject(hMainWndDC, hOldBrush);
	RestoreDC(hMainWndDC, Index);

	*OldPoint = NewPoint;
}

bool CMainWindow::ShowLineWeight(bool IsShow)
{
	optionsCAD.IsShowLineWeight = IsShow;
	if ((CADImage != NULL) && (SetShowLineWeightCAD(CADImage, (IsShow ? 1: 0)) > 0))
	{	    
		RePaint();
		return true;
	}	
	return false;
}
bool CMainWindow::SetIsNearestPointMode(bool Checked)
{
	optionsCAD.IsNearestPointMode = Checked;
	if (CADImage != NULL) 
	{	    
		RePaint();
		return true;
	}	
	return false;
}

bool CMainWindow::SetNullLineWidth(int NullLineWidth)
{
	optionsCAD.NullLineWidth = NullLineWidth;
	if ((CADImage != NULL) && (SetNullLineWidthCAD(CADImage, optionsCAD.NullLineWidth) > 0))
	{	    
		RePaint();
		return true;
	}	
	return false;
}

bool CMainWindow::SetOptionsCAD(CADOPTIONS CADOpts)
{
	if (CADImage != NULL) 
	{        
	    optionsCAD = CADOpts;
		SetShowLineWeightCAD(CADImage, (optionsCAD.IsShowLineWeight ? 1: 0));
		SetNullLineWidthCAD(CADImage, optionsCAD.NullLineWidth);
        if (optionsCAD.IsDrawingBox) 
			SetDrawingBox();
		else
			ResetDrawingBox(); 		
		return true;
	}	
	return false;
}

bool CMainWindow::GetIsShowLineWeight()
{
	return optionsCAD.IsShowLineWeight;
}

bool CMainWindow::GetIsDrawingBox()
{
	return optionsCAD.IsDrawingBox;
}

bool CMainWindow::GetIsNearestPointMode()
{
	return optionsCAD.IsNearestPointMode;
}

bool CMainWindow::GetIsPocessing()
{
	return bIsPocessing;
}

int  CMainWindow::GetNullLineWidth()
{
	return optionsCAD.NullLineWidth;
}

void CMainWindow::DestroyLayersDlg()
{
	if (hwndLayersDlg != NULL)
	{
		DestroyWindow(hwndLayersDlg);
		hwndLayersDlg = NULL;
	}
}

void CMainWindow::FillLayersList()
{
	if (CADImage == NULL) 
		return;
	DestroyLayersDlg();
	ShowLayersDlg(false);
	int i, Count, Vis;		
	LVCOLUMN lvCol;
	LVITEM lvItem;
	HANDLE hLayer;
	HWND hwndList;
	DXFDATA dxfData;	
	Count = CADLayerCount(CADImage);
	hwndList = GetDlgItem(hwndLayersDlg, IDC_LISTLAYERS);	
	ListView_DeleteAllItems(hwndList);
	ZeroMemory(&lvCol, sizeof(lvCol));
    // Initialize the columns
	lvCol.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
    lvCol.fmt = LVCFMT_LEFT; 
    lvCol.cx = 235; 	
    lvCol.pszText = "Layers names"; 	
	ListView_InsertColumn(hwndList, 0, &lvCol);
	ListView_SetItemCount(hwndList, Count);
	IsAppChangingList = true;
	ListView_SetExtendedListViewStyle(hwndList, LVS_EX_GRIDLINES | LVS_EX_CHECKBOXES);	
	for (i= 0; i< Count; i++)
	{		
		hLayer = CADLayer(CADImage, i, &dxfData);
		Vis = (dxfData.Flags & 1) == 0;
		ZeroMemory(&lvItem, sizeof(lvItem)); 
		lvItem.mask = LVIF_TEXT | LVIF_PARAM;		
		lvItem.iItem = i; 
		lvItem.iSubItem = 0; 
		lvItem.pszText = dxfData.Text;
		lvItem.lParam = (LPARAM) hLayer;		
		ListView_InsertItem(hwndList, &lvItem);		
		ListView_SetItemState(hwndList, i, INDEXTOSTATEIMAGEMASK(UINT((Vis)+1)), LVIS_STATEIMAGEMASK);
	}	
	IsAppChangingList = false;
}

/* 
  AboutDialogProc
  

*/
BOOL CALLBACK CMainWindow::AboutDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
            return TRUE;
		case WM_COMMAND:
			switch (LOWORD(wParam))                   
            {
				case IDOK:
				case IDCANCEL: 
					EndDialog(hDlg, LOWORD(wParam));
				    return TRUE;
					break;
                case IDCC_MAILTO_SG: 
					ShellExecute(hDlg, "open", "Mailto:info@cadsofttools.com", NULL, NULL, SW_SHOW);
					break; 
				case IDCC_HOMEPAGE_SG: 
					ShellExecute(hDlg, "open", "http://www.cadsofttools.com/", NULL, NULL, SW_SHOW);
					break;
			}
			break;
	}
    return FALSE;
}

/* 
  ControlProc
  

*/
LRESULT CALLBACK CMainWindow::ControlProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
     switch (message)
          {
		  case WM_PAINT:
			  {
                  HDC hdc;
				  RECT rect;	 
				  char text[300];			  
				  PAINTSTRUCT ps;
				  HFONT hOldF, hF = CreateFont(8, 0, 0, 0, 400, FALSE, 1, 0, RUSSIAN_CHARSET, OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, "MS Sans Serif");
				  GetWindowText(hWnd, text, sizeof(text));			  
				  GetClientRect(hWnd, &rect);
				  hdc = BeginPaint(hWnd, &ps);
				  hOldF = (HFONT) SelectObject(hdc, hF);
				  SetBkMode(hdc, TRANSPARENT);
				  SetTextColor(hdc, RGB(0, 0, 255));
			      DrawText(hdc, text, -1, &rect, DT_SINGLELINE | DT_LEFT | DT_VCENTER);
			      DeleteObject(hF);
			      SelectObject(hdc, hOldF);
                  EndPaint(hWnd, &ps);			  
                  break;
			  }

		  case WM_LBUTTONDOWN :
              SendMessage(GetParent(hWnd), WM_COMMAND, GetWindowLong (hWnd, GWL_ID), (LPARAM) hWnd);
			  break;
          }
     return DefWindowProc (hWnd, message, wParam, lParam);
}

/* 
  LayersDialogProc
  

*/
BOOL CALLBACK CMainWindow::LayersDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{	
	if (hDlg != hwndLayersDlg)
		return FALSE;
	HWND hwndMainWnd = GetParent(hwndLayersDlg);

	switch (message)
	{
		case WM_INITDIALOG:			
			return TRUE;

		case WM_COMMAND:			
			switch (LOWORD(wParam))
			{
				case IDOK:
				case IDCANCEL:
					CheckMenuItem(GetMenu(hwndMainWnd), IDM_OPTIONSLAYERS, MF_UNCHECKED);
					ShowWindow(hwndLayersDlg, SW_HIDE);					
					break;
			}
		case WM_MOVE:
			InvalidateRect(hwndMainWnd, NULL, TRUE);
			break;		
		case WM_NOTIFY:
			switch (wParam)
			{	
				case IDC_LISTLAYERS:
					NMHDR nmHdr = *((LPNMHDR) lParam);
					if (!IsAppChangingList && (nmHdr.code == LVN_ITEMCHANGED))
					{						
						NMLISTVIEW nmListViewItem = *((LPNMLISTVIEW)lParam);
						int Vis = (::SendMessage(GetDlgItem(hwndLayersDlg, IDC_LISTLAYERS), LVM_GETITEMSTATE, nmListViewItem.iItem, LVIS_STATEIMAGEMASK) >> 12) - 1;			
						CADLayerVisible((HANDLE)(nmListViewItem.lParam), Vis);						
						InvalidateRect(hwndMainWnd, NULL, TRUE);
					}					
				break;
			}		
	}
    return FALSE;
}

/* 
  PropertiesDialogProc
  

*/
BOOL CALLBACK CMainWindow::PropertiesDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{	
	if (hDlg != hwndPropertiesDlg)
		return FALSE;
	const MAX_WIDTH_VALUE = 100;
	HWND hwndMainWnd = GetParent(hDlg);
	HWND hwndDlgItem = GetDlgItem(hDlg, IDE_NULLLINEWIDTH);
	CMainWindow* pMainWindow = (CMainWindow*) GetWindowLong(hDlg, GWL_USERDATA);
	char text[200];	
	switch (message)
	{
		case WM_INITDIALOG:
			return TRUE;
		case WM_SHOWWINDOW:			
			ZeroMemory(text, 200);			
			SetWindowText(hwndDlgItem, itoa(pMainWindow->GetNullLineWidth(), text, 10));
			break;
		case WM_COMMAND:			
			switch (LOWORD(wParam))
			{
				case IDOK:					
					if (pMainWindow != NULL)
					{
                            ZeroMemory(text, 200);						
							GetWindowText(hwndDlgItem, text, 200);
							pMainWindow->SetNullLineWidth(atoi(text)); 
					}					
				case IDCANCEL:
					CheckMenuItem(GetMenu(hwndMainWnd), IDM_OPTIONSPROPERTIES, MF_UNCHECKED);
					ShowWindow(hDlg, SW_HIDE);
					break;
				case IDC_NEARESTPOINTMODE:
					if (pMainWindow != NULL)
					{
						if (!pMainWindow->GetIsDrawingBox())						
                            pMainWindow->SetIsNearestPointMode((SendDlgItemMessage(hwndPropertiesDlg, IDC_NEARESTPOINTMODE, BM_GETCHECK, 0, 0)) != 0);
						else	{
							SendDlgItemMessage(hwndPropertiesDlg, IDC_NEARESTPOINTMODE, BM_SETCHECK, 0, 1);
							MessageBox(hwndMainWnd, "Please reset drawing box for activation \"Nearest point mode\".", "Warning", MB_ICONWARNING);
						}
					}
					break;
			}
		case WM_MOVE:
			InvalidateRect(hwndMainWnd, NULL, TRUE);
			break;	
        case WM_NOTIFY:
            {
                LPNMHDR pnmh= (LPNMHDR) lParam;				
		   	    if (pnmh->code == UDN_DELTAPOS)
			    {
                    LPNMUPDOWN code= (LPNMUPDOWN) lParam;					
				    if (code->iDelta > 0)
					{
						ZeroMemory(text, 200);
						GetWindowText(hwndDlgItem, text, 200);
						SetWindowText(hwndDlgItem, itoa(atoi(text) - 1, text, 10));					    
					}
				    else
					{
						ZeroMemory(text, 200);
						GetWindowText(hwndDlgItem, text, 200);
						SetWindowText(hwndDlgItem, itoa(atoi(text) + 1, text, 10));
					}
					// Correcting value
					ZeroMemory(text, 200);
					GetWindowText(hwndDlgItem, text, 200);
					if (strlen(text) > 5 || atoi(text) > MAX_WIDTH_VALUE)
						SetWindowText(hwndDlgItem, "100");
					else if (strlen(text) == 0 || atoi(text) < 0)
						SetWindowText(hwndDlgItem, "0");
				}			   
			    break;		  
			}
	}
    return FALSE;
}