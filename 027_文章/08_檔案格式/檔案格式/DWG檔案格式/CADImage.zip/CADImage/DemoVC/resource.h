//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Script1.rc
//
#define IDI_ICON                        101
#define IDR_MENU1                       102
#define IDC_CURSORHAND                  106
#define IDD_LAYERS                      120
#define IDD_ABOUT                       121
#define IDD_PROPERTIES                  122
#define IDE_NULLLINEWIDTH               131
#define IDSPN_NULLLINEWIDTH             132
#define IDS_NULLLINEWIDTH               133
#define IDS_PIXELS                      134
#define IDC_NEARESTPOINTMODE			135
#define IDB_BMORBITUPX                  151
#define IDB_BMORBITUPY                  152
#define IDB_BMORBITUPZ                  153
#define IDB_BMORBITDOWNX                154
#define IDB_BMORBITDOWNY                155
#define IDB_BMORBITDOWNZ                156
#define IDB_BMOPTIONSLAYERS             157
#define IDB_BMDRAWINGBOX                158
#define IDB_BMROTATE                    159

#define IDS_DEMOCADIMAGEDLL             200
#define IDS_RIGHTS_SG                   201
#define IDS_ADDRESS_SG                  202
#define IDCC_MAILTO_SG                  203
#define IDCC_HOMEPAGE_SG                204  

#define IDC_LISTLAYERS                  1008
#define IDC_LIST1                       1009
#define IDC_COMBO1                      1010
#define IDC_SCROLLBAR1                  1011
#define ID_SCALE                        40000
#define ID_SCALE_1                      40001
#define ID_SCALE_10                     40010
#define ID_FILE_LOAD                    40014
#define ID_FILE_SAVEAS                  40015
#define ID_VIEW                         40016
#define ID_VIEW_NORMAL                  40017
#define ID_VIEW_BLACKWHITE              40018
#define ID_VIEW_GRAYSCALE               40019
#define ID_HELP_ABOUT                   40020
#define IDM_ORBITUPX                    40028
#define IDM_ORBITDOWNX                  40029
#define IDM_ORBITUPY                    40030
#define IDM_ORBITDOWNY                  40031
#define IDM_ORBITUPZ                    40032
#define IDM_ORBITDOWNZ                  40033
#define IDM_COLORS_WHITE                40034
#define IDM_COLORS_GRAY                 40035
#define IDM_COLORS_LYELLOW              40036
#define IDM_OPTIONSLAYERS               40037
#define IDM_OPTIONSPROPERTIES           40038
#define IDM_OPTIONSDRAWINGBOX           40039
#define IDM_OPTIONSSHOWLINEWEIGHT       40040 
#define IDM_ROTATE                      40041

#define ID_SETDEFAULTCOLOR      		40049
#define ID_SCALE_50                     40050
#define ID_SCALE_100                    40100
#define ID_SCALE_200                    40200
#define ID_SCALE_400                    40400
#define ID_SCALE_500                    40500
#define ID_SCALE_1000                   41000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         41001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
