// DXF_DEMO_API.cpp : Defines the entry point for the application.
//

#include "MainWindow.h"
#include "resource.h"

CMainWindow *MainWindow = 0;

LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	HWND hWnd;
	MSG Msg;
	MainWindow = new CMainWindow("MainWindow", MainWndProc, hInstance,
		LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON)), LoadCursor(0, IDC_ARROW), "MENU1", (HBRUSH)COLOR_WINDOW, 0);
	hWnd = MainWindow->Create(
		"Soft Gold CADImage DLL Demo", 
		WS_CLIPCHILDREN | WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 
		CW_USEDEFAULT, 
		500, 300, NULL, NULL);

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
    MainWindow->DoCreateStatusBar(hWnd, hInstance);
	MainWindow->DoCreateToolBar(hWnd, hInstance);
	MainWindow->DoCreateComboBox(hInstance);
	while (GetMessage(&Msg, NULL, 0, 0)) 
	{
		if (!IsDialogMessage(CMainWindow::hwndLayersDlg, &Msg))
		{
			TranslateMessage(&Msg);
			DispatchMessage(&Msg);
		}
	}
	return Msg.wParam;
}


LRESULT CALLBACK MainWndProc(HWND hWnd,UINT uiMessage,
                         WPARAM wParam,LPARAM lParam)
{ 
	bool stat;

  switch (uiMessage)
  {
    case WM_COMMAND:
		switch (LOWORD(wParam))
		{
			case ID_HELP_ABOUT:				   
				MainWindow->ShowAboutDlg();				
				break;
			case ID_FILE_LOAD: 
			{				
				char text[200];
				ZeroMemory(text, 200);
				GetWindowText(GetDlgItem(CMainWindow::hwndPropertiesDlg, IDE_NULLLINEWIDTH), text, 200);
				CADOPTIONS co;
				co.IsDrawingBox = (CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSDRAWINGBOX, MF_BYCOMMAND) == MF_CHECKED);
				co.IsShowLineWeight = (CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSSHOWLINEWEIGHT, MF_BYCOMMAND) == MF_CHECKED);
				co.IsNearestPointMode = (SendDlgItemMessage(CMainWindow::hwndPropertiesDlg, IDC_NEARESTPOINTMODE, BM_GETCHECK, 0, 0) != 0);
				co.NullLineWidth = atoi(text);
				MainWindow->Load(co);
				CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSSHOWLINEWEIGHT, ((co.IsShowLineWeight) ? MF_CHECKED : MF_UNCHECKED));
				CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSDRAWINGBOX, ((co.IsDrawingBox) ? MF_CHECKED : MF_UNCHECKED));
				break;
			}				
			case ID_FILE_SAVEAS:
				MainWindow->SaveAs();
				break;
			case ID_VIEW_NORMAL:
				MainWindow->ChangeView(0);
				break;
			case ID_VIEW_BLACKWHITE:
				MainWindow->ChangeView(1);
				break;				
			case ID_VIEW_GRAYSCALE:
				MainWindow->ChangeView(2);
				break;
			case ID_SETDEFAULTCOLOR:
				MainWindow->SetDefColor();
				break;
			case ID_SCALE_1:
            case ID_SCALE_10:
			case ID_SCALE_50:
			case ID_SCALE_500:
			case ID_SCALE_100:
			case ID_SCALE_200:
			case ID_SCALE_400:
			case ID_SCALE_1000:
				MainWindow->SetScale(LOWORD(wParam) - ID_SCALE);
				break;
			case IDM_COLORS_WHITE:				
				MainWindow->SetBgrndColor(RGB(255,255,255));
				break;
			case IDM_COLORS_GRAY:				
				MainWindow->SetBgrndColor(RGB(128,128,128));
				break;
			case IDM_COLORS_LYELLOW:				
				MainWindow->SetBgrndColor(RGB(255,239,182));
				break;
			case IDM_ORBITUPX:
				MainWindow->RotateCAD(axisX, ROTATION_ANGLE);				
				break;
			case IDM_ORBITDOWNX:
				MainWindow->RotateCAD(axisX, -ROTATION_ANGLE);
				break;
			case IDM_ORBITUPY:
				MainWindow->RotateCAD(axisY, -ROTATION_ANGLE);
				break;
			case IDM_ORBITDOWNY:
				MainWindow->RotateCAD(axisY, ROTATION_ANGLE);
				break;
			case IDM_ORBITUPZ:
				MainWindow->RotateCAD(axisZ, -ROTATION_ANGLE);
				break;
			case IDM_ORBITDOWNZ:
				MainWindow->RotateCAD(axisZ, ROTATION_ANGLE);
				break;
			case IDM_ROTATE:
				MainWindow->RotateCAD(axisZ, 180.0f);
				break;
			case IDM_OPTIONSLAYERS:
				CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSLAYERS, MF_CHECKED);
				MainWindow->ShowLayersDlg(true);
				break;
			case IDM_OPTIONSPROPERTIES:
				CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSPROPERTIES, MF_CHECKED);
				MainWindow->ShowPropertiesDlg(true);
				break;
			case IDM_OPTIONSDRAWINGBOX:
				if (MainWindow->GetIsNearestPointMode())
				{
					CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSDRAWINGBOX, MF_UNCHECKED);
                    MessageBox(hWnd, "Please reset \"Nearest point mode\" for activation drawing box.", "Warning", MB_ICONWARNING);
				}
				else
				{
                    stat = (CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSDRAWINGBOX, MF_BYCOMMAND) == MF_CHECKED);
					CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSDRAWINGBOX, ((stat) ? MF_UNCHECKED : MF_CHECKED));
					if (!stat)
	                    MainWindow->SetDrawingBox();
					else
						MainWindow->ResetDrawingBox();
				}
				break;
            case IDM_OPTIONSSHOWLINEWEIGHT:			
				stat = (CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSSHOWLINEWEIGHT, MF_BYCOMMAND) == MF_CHECKED);
				CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSSHOWLINEWEIGHT, ((stat) ? MF_UNCHECKED : MF_CHECKED));
				MainWindow->ShowLineWeight(!stat);
				break;
			case 0:
				if ((HIWORD(wParam) == CBN_SELENDOK) && (lParam == (LPARAM)MainWindow->hwndComboBox)) {
					CheckMenuItem(GetMenu(hWnd), IDM_OPTIONSDRAWINGBOX, MF_UNCHECKED);
                    MainWindow->SetCurrentLayout();
				}
				break;
		}
		break;

	case WM_PAINT:
		MainWindow->Draw();		
		break;

	case WM_MOVE:
		MainWindow->RePaint();
		break;

	case WM_SIZE:			
		MainWindow->RePaint();
		MainWindow->ReSize(wParam, lParam);			
		break;

	case WM_LBUTTONDOWN:
		MainWindow->LButtonDown(MAKEPOINTS(lParam));
		break;

	case WM_LBUTTONUP:
		MainWindow->LButtonUp(MAKEPOINTS(lParam));
		break;

	case WM_MOUSEMOVE:
		MainWindow->MouseMove(MAKEPOINTS(lParam));
		break;

    case WM_DESTROY: 
        PostQuitMessage(0);
        break;

  }
  return DefWindowProc(hWnd,uiMessage,wParam,lParam);
}