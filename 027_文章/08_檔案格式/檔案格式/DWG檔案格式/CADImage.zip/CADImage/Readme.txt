 Copy CADImage.DLL to your demo directory in order to compile and run demo application. CADImage.DLL should be on the same directory where the exe file is.

For VC++ developers:
Folder "Include" must be specified in include path of the project options.


Registration
1.Get license from http://www.cadsofttools.com/?PageName=order
page
2. Load CADSoftTools plugin Manager - CS_Manager.exe
3. Press CADImage button to show registration dialog fo CADImage.DLL Plugin. 

