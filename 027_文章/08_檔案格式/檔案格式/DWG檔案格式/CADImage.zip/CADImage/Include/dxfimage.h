/*
Copyright (c) 2002-2003 SoftGold software company

Module Name:

    dxfimage.h

Description:

    Master include file DXF Image DLL version

*/
#ifndef _DXFIAMGE_
#define _DXFIAMGE_


#include <windows.h>


typedef HANDLE	(CALLBACK *DXFCREATE)(HWND, LPCSTR);
typedef int		(CALLBACK *DXFCLOSE)(HANDLE);
typedef int		(CALLBACK *DXFDRAW)(HANDLE, HDC, LPRECT);
typedef int		(CALLBACK *DXFGETBOX)(HANDLE, float*, float*);
typedef int		(CALLBACK *DXFGETLASTERROR)(LPCSTR);

#endif