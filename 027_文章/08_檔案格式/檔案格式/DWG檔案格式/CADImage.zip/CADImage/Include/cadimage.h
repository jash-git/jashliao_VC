/*
Copyright (c) 2002-2004 SoftGold software company

Module Name:

    cadimage.h

Description:

    Master include file CAD Image DLL version

*/
#ifndef _CADIAMGE_
#define _CADIAMGE_

#include <windows.h>

#define CS_STATIC_DLL

typedef struct _CADDRAW 
{  
    DWORD Size;
    HDC DC;
    RECT R;
    BYTE DrawMode;
} CADDRAW, *LPCADDRAW;

// Soft Gold float type (float in previous version)
typedef double sgFloat;

typedef struct _FPOINT
{
	sgFloat x;
	sgFloat y;
	sgFloat z;
} FPOINT, *LPFPOINT;

typedef union _FRECT
{
	struct
	{
		sgFloat Left;
		sgFloat Top;
		sgFloat Z1;
		sgFloat Right;
		sgFloat Bottom;
		sgFloat Z2;
	} Points;
	
	struct
	{
		FPOINT TopLeft;
		FPOINT BottomRight;
	} Corners;	
} FRECT, *LPFRECT;

typedef struct _DXFPOINT
{
	float X;
	float Y;
	float Z;
} DXFPOINT, *LPDXFPOINT;

typedef struct _DXFDATA
{
	WORD Tag;
	WORD Count;
	WORD TickCount;
	BYTE Flags;
	BYTE Style;    
	int Dimension;
    LPDXFPOINT DashDots;
    int DashDotsCount;
	int Color;
	LPVOID *Ticks;
	float Thickness;
	float Rotation;
	char* Layer;
	char* Text;
	char* FontName;
    unsigned long Handle;
    int Unused;
	DXFPOINT Point1;
	DXFPOINT Point2;
	DXFPOINT Point3;
	DXFPOINT Point4;

	union
	{		
		struct
		{
			float Radius;
			float StartAngle;
			float EndAngle;
		} Arc;
		struct
		{
			HANDLE Block;
			DXFPOINT Scale;
		} Blocks;
		struct
		{
			float FHeight;
			float FScale;
			float RWidth;
			float RHeight;
			BYTE HAlign;
			BYTE VAlign;
		} Text;
		LPDXFPOINT PolyPoints;
	} DATA;
} DXFDATA, *LPDXFDATA;

typedef enum AXES { axisX=0, axisY=1, axisZ=2 };

typedef int (WINAPI *PROGRESSPROC)(BYTE*);

#ifndef CS_STATIC_DLL 
	typedef HANDLE (WINAPI *CADLAYER)(HANDLE, DWORD, LPDXFDATA);
	typedef int    (WINAPI *CADLAYERCOUNT)(HANDLE);
	typedef int    (WINAPI *CADLAYERVISIBLE)(HANDLE, int);
	typedef int    (WINAPI *CADVISIBLE)(HANDLE, LPCSTR);
	typedef HANDLE (WINAPI *CREATECAD)(HWND, LPCSTR);
	typedef int    (WINAPI *CLOSECAD)(HANDLE);
	typedef HANDLE (WINAPI *CADLAYOUT)(HANDLE, int);	  
	typedef int    (WINAPI *CADLAYOUTNAME)(HANDLE, DWORD, LPCSTR, DWORD);
	typedef int    (WINAPI *CADLAYOUTSCOUNT)(HANDLE);                            
	typedef BOOL   (WINAPI *CADLAYOUTVISIBLE)(HANDLE, int, BOOL, BOOL);
	typedef int    (WINAPI *CADUNITS)(HANDLE, int*);
	typedef HANDLE (WINAPI *CURRENTLAYOUTCAD)(HANDLE, int, BOOL);
	typedef int    (WINAPI *DEFAULTLAYOUTINDEX)(HANDLE);
	typedef int    (WINAPI *DRAWCAD)(HANDLE, HDC, LPRECT);
	typedef int    (WINAPI *DRAWCADEX)(HANDLE, LPCADDRAW);
	typedef HANDLE (WINAPI *DRAWCADTOBITMAP)(HANDLE, LPCADDRAW);
	typedef HANDLE (WINAPI *DRAWCADTODIB)(HANDLE, LPRECT);
	typedef HANDLE (WINAPI *DRAWCADTOJPEG)(HANDLE, LPCADDRAW);
	typedef HANDLE (WINAPI *DRAWCADTOGIF)(HANDLE, LPCADDRAW);
	typedef int    (WINAPI *GETBOXCAD)(HANDLE, float*, float*);
	typedef int    (WINAPI *GETCADCOORDS)(HANDLE, float, float, LPFPOINT);
	typedef int    (WINAPI *GETEXTENTSCAD)(HANDLE, LPFRECT);
	typedef int    (WINAPI *GETIS3DCAD)(HANDLE, int*);
	typedef int    (WINAPI *GETLASTERRORCAD)(LPCSTR, DWORD);
	typedef int	   (WINAPI *GETNEARESTENTITY)(HANDLE, LPCSTR, DWORD, LPRECT, LPPOINT);
	typedef int    (WINAPI *GETPOINTCAD)(HANDLE, LPFPOINT);
	typedef int    (WINAPI *RESETDRAWINGBOXCAD)(HANDLE);
	typedef BOOL   (WINAPI *SETBMSIZE)(int); 
	typedef int    (WINAPI *SETDEFAULTCOLOR)(HANDLE, int);
	typedef int    (WINAPI *SETDRAWINGBOXCAD)(HANDLE, LPFRECT);
	typedef int    (WINAPI *SETNULLLINEWIDTHCAD)(HANDLE, int);	
	typedef int    (WINAPI *SETPROCESSMESSAGESCAD)(HANDLE, int);
	typedef int    (WINAPI *SETPROGRESSPROC)(PROGRESSPROC);		
	typedef int    (WINAPI *SETROTATECAD)(HANDLE, float, int);
	typedef int    (WINAPI *SETSHOWLINEWEIGHTCAD) (HANDLE, int);
#else
	#ifdef CS_DLL_EXPORT
		#define CS_API __declspec(dllexport)
	#else
		#define CS_API __declspec(dllimport)
	#endif
	extern "C"
	{
		CS_API HANDLE WINAPI CADLayer(HANDLE, DWORD, LPDXFDATA);
		CS_API int    WINAPI CADLayerCount(HANDLE);
		CS_API int    WINAPI CADLayerVisible(HANDLE, int);
		CS_API int    WINAPI CADVisible(HANDLE, LPCSTR);
		CS_API HANDLE WINAPI CreateCAD(HWND, LPCSTR);
		CS_API int    WINAPI CloseCAD(HANDLE);	
		CS_API HANDLE WINAPI CADLayout(HANDLE, int);
		CS_API int    WINAPI CADLayoutName(HANDLE, DWORD, LPCSTR, DWORD);
		CS_API int	  WINAPI CADLayoutsCount(HANDLE);
		CS_API BOOL   WINAPI CADLayoutVisible(HANDLE, int, BOOL, BOOL);
		CS_API int    WINAPI CADUnits(HANDLE, int*);
		CS_API HANDLE WINAPI CurrentLayoutCAD(HANDLE, int, BOOL);
		CS_API int	  WINAPI DefaultLayoutIndex(HANDLE);
		CS_API int    WINAPI DrawCAD(HANDLE, HDC, LPRECT);
		CS_API int    WINAPI DrawCADEx(HANDLE, LPCADDRAW);
		CS_API HANDLE WINAPI DrawCADtoBitmap(HANDLE, LPCADDRAW);
		CS_API HANDLE WINAPI DrawCADtoDIB(HANDLE, LPRECT);
		CS_API HANDLE WINAPI DrawCADtoJpeg(HANDLE, LPCADDRAW);
		CS_API HANDLE WINAPI DrawCADtoGif(HANDLE, LPCADDRAW);
		CS_API int    WINAPI GetBoxCAD(HANDLE, float*, float*);
		CS_API int    WINAPI GetCADCoords(HANDLE, float, float, LPFPOINT);
		CS_API int    WINAPI GetExtentsCAD(HANDLE, LPFRECT);
		CS_API int    WINAPI GetIs3dCAD(HANDLE, int*);
		CS_API int    WINAPI GetLastErrorCAD(LPCSTR, DWORD);
		CS_API int    WINAPI GetNearestEntity(HANDLE, LPCSTR, DWORD, LPRECT, LPPOINT);
		CS_API int    WINAPI GetPointCAD(HANDLE, LPFPOINT);
		CS_API int    WINAPIV GetPlugInInfo(LPCSTR, LPCSTR);
		CS_API int    WINAPI ResetDrawingBoxCAD(HANDLE);
		CS_API BOOL   WINAPI SetBMSize(int);
		CS_API int    WINAPI SetDefaultColor(HANDLE, int);
		CS_API int    WINAPI SetDrawingBoxCAD(HANDLE, LPFRECT);
		CS_API int    WINAPI SetNullLineWidthCAD(HANDLE, int);
        CS_API int    WINAPI SetProcessMessagesCAD(HANDLE, int);
		CS_API void   WINAPI SetProgressProc(PROGRESSPROC);
		CS_API int    WINAPI SetRotateCAD(HANDLE, float, int);		
		CS_API void   WINAPI SetReg(LPCSTR, LPCSTR);
		CS_API int    WINAPI SetShowLineWeightCAD(HANDLE, int);
	}
#endif

#endif
