==========================
PDFlib binary distribution
==========================

This is a binary package containing PDFlib, PDFlib+PDI, and
PDFlib Personalization Server (PPS) in a single binary.
It requires a commercial license to use it. However, the
library is fully functional for evaluation purposes.

Unless a valid license key has been applied the generated PDF
output will have a www.pdflib.com demo stamp across all pages.
See the PDFlib manual (chapter 0) to learn how to apply the
license key.


C and C++ language bindings
===========================

The PDFlib header file pdflib.h plus a PDFlib library is contained in the
distribution.  The bind/c and bind/cpp directories contain sample
applications which you can use to test your installation.


Windows
-------
- On 32-bit Windows, the DLL pdflib.dll is supplied along with the
  corresponding import library pdflib.lib. In order to build
  and run the supplied C/C++ samples copy these files to the
  bind/pdflib/c or bind/pdflib/cpp directories.

  If you are working with Borland C++ Builder you must use the
  PDFlib binaries for use with Borland products since Borland tools
  are not fully compatible with DLLs created with Microsoft tools.

- On 64-bit Windows you have the following choice of compilers to
  build applications with the Win64 binaries for PDFlib:
  - cross-compile with Visual Studio 6 plus the Win64 platform SDK
  - natively compile for Win64 with the Intel compiler

  Note that the C language edition of the PDFlib manual applies to
  Win64 development in C. It is contained as PDFlib-manual.pdf in
  the Win32 binary package.


Unix
----
On Unix systems (including Mac OS X) a static library is supplied.
The bind/c and bind/cpp directories contain sample applications and
Makefiles which you can use to test your installation.


Apple Macintosh
---------------
The Mac distribution is available as a disk image (.dmg) and a compressed
tar archive (.tar.gz). Both packages have identical contents, and support
the following runtime environments:

- libpdf.a: static Mach-O/dyld library for Mac OS X (created with gcc)

- PDFlib.Carbon.Lib: static CFM/PEF Carbon library for OS 9 and X for
  use with Carbonized applications. This library requires that the host
  application be linked against CarbonLib.

- PDFlib.Classic.Lib: static CFM/PEF library for Mac OS 9 Classic
  applications without CarbonLib. This library requires that the host
  application be linked against the following Apple libraries:
  FontManager, InterfaceLib, MathLib, TextCommon, UnicodeConverter, UTCUtils.

In addition to a Makefile for use with gcc a project file for CodeWarrior is
provided to build the sample applications. The CW project also contains
a target for a sample Classic application.

In order to make the C and C++ samples work with Classic you must change the
SearchPath entries in the C to use Mac volume syntax instead of Unix-style
path names, e.g. in image.c change the line

    char *searchpath = "../data";

    to

    char *searchpath = ":data";


Other language bindings
=======================

Additional files and sample code for various languages can be found in
the bind directory. Note that not all binary libraries for all language
bindings may be present; see our Web site for additional packages.
