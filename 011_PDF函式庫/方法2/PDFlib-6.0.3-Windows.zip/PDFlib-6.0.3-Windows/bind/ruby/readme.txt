The binaries for the Ruby language binding are not included in this
distribution.

Please check our Web site for packages with additional language
bindings and combinations of language version/system version.

If you can't find the required package contact bindings@pdflib.com and
supply the exact version number of the language version you would like
to have, as well as the platform (operating system). Note that this
service is available for PDFlib licensees only.
