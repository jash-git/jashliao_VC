==========================
PDFlib binary distribution
==========================

This is a binary package containing PDFlib, PDFlib+PDI, and
PDFlib Personalization Server (PPS) in a single binary.
It requires a commercial license to use it. However, the
library is fully functional for evaluation purposes.

Unless a valid license key has been applied the generated PDF
output will have a www.pdflib.com demo stamp across all pages.
See the PDFlib manual (chapter 0) to learn how to apply the
license key.


C and C++ language bindings
===========================

The PDFlib header file pdflib.h plus a PDFlib library is contained in the
distribution.  The bind/c and bind/cpp directories contain sample
applications which you can use to test your installation.


-------
Windows
-------
- On 32-bit Windows, the DLL pdflib.dll is supplied along with the
  corresponding import library pdflib.lib. In order to build
  and run the supplied C/C++ samples copy these files to the
  bind/pdflib/c or bind/pdflib/cpp directories.

  If you are working with Borland C++ Builder you must use the
  PDFlib binaries for use with Borland products since Borland tools
  are not fully compatible with DLLs created with Microsoft tools.

- On 64-bit Windows you have the following choice of compilers to
  build applications with the Win64 binaries for PDFlib:
  - cross-compile with Visual Studio 6 plus the Win64 platform SDK
  - natively compile for Win64 with the Intel compiler

  Note that the C language edition of the PDFlib manual applies to
  Win64 development in C. It is contained as PDFlib-manual.pdf in
  the Win32 binary package.


----
Unix
----
On Unix systems (including Mac OS X) a static library is supplied.
The bind/c and bind/cpp directories contain sample applications and
Makefiles which you can use to test your installation.


---------------
Apple Macintosh
---------------
PDFlib for the Mac is available in multiple flavours for different
runtime environments. These binary flavors are packaged in disk images
according to the following description:

PDFlib-x.x.x-MacOSX-PowerPC.dmg
-------------------------------
This package contains Mach-O binaries for OS X on PowerPC for C and various
other language bindings:

- libpdf.a: static Mach-O/dyld library for Mac OS X on PowerPC
  (created with gcc)

PDFlib-x.x.x-MacOSX-Universal.dmg
---------------------------------
This package contains a Universal Mach-O binary for OS X on PowerPC and
Intel-based Macs:

- PDFlib.framework: OS X framework as Universal binary for OS X on PowerPC
  and Intel-based Macs (created with xcode).
  This framework must be installed in /Library/Frameworks.

PDFlib-x.x.x-MacOSX-Intel.dmg
-----------------------------
This package contains Mach-O binaries for OS X on Intel-based Macs for C
and various other language bindings:

- libpdf.a: static Mach-O/dyld library for Mac OS X on Intel
  (created with gcc)

PDFlib-x.x.x-MacOS-CFM.dmg
--------------------------
This package contains binaries for Code Fragment Manager, i.e. for old-style
applications:

- PDFlib.Carbon.Lib: static CFM/PEF Carbon library for OS 9 and X on PowerPC
  for use with Carbonized applications. This library requires that the host
  application be linked against CarbonLib.

- PDFlib.Classic.Lib: static CFM/PEF library for Mac OS 9 Classic
  applications without CarbonLib. This library requires that the host
  application be linked against the following Apple libraries:
  FontManager, InterfaceLib, MathLib, TextCommon, UnicodeConverter, UTCUtils.

In addition to a Makefile for use with gcc a project file for CodeWarrior is
provided to build the sample applications. The CW project also contains
a target for a sample Classic application.

In order to make the C and C++ samples work with Classic you must change the
SearchPath entries in the C to use Mac volume syntax instead of Unix-style
path names, e.g. in image.c change the line
    char *searchpath = "../data";
    to
    char *searchpath = ":data";


Other language bindings
=======================

Additional files and sample code for various languages can be found in
the bind directory. Note that not all binary libraries for all language
bindings may be present; see our Web site for additional packages.


=================================
Notes for using PDFlib on OpenVMS
=================================

A shared image is supplied for OpenVMS systems. Below are some notes
on using the PDFlib shared image.

Applying a license key via an environment variable which points to
a license file:

    $ define /log PDFLIBLICENSEFILE
    _Equ name: SYS$SYSDEVICE:[PATH.TO.LICENSE]LICENSE.TXT



Compiling C programs which use PDFlib:

    CC/INCLUDE=PDFLIBDIR hello.c

PDFLIBDIR is created by the installer:

    $ sh log pdflibdir
       "PDFLIBDIR" = "SYS$COMMON:[PDFLIB.6-x-x...]" (LNM$SYSTEM_TABLE)
 

Link against the PDFlib shared image:
 
    LINK
     HELLO.O+SYS$INPUT/OPTION
     PDFLIBSHR/SHARE
    '^Z'

Similarly for C++:

    CXX/INCLUDE=PDFLIBDIR: hello.cpp+pdflib.cpp
    CXXLINK hello+SYS$INPUT/OPTION
     PDFLIBSHR/SHARE
    '^Z'


PDFlib for C and C++ on OpenVMS has been tested with the following
development environments:

    HP C V7.1-011	(Itanium)
    HP C++ V7.1-011	(Itanium)

    HP C ?		(AXP)
    HP C++ ?		(AXP)
    JDK 1.3.1		(AXP)
