#include "stdafx.h"
#include "AcroView.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "CAcroAXDocShim.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

BEGIN_MESSAGE_MAP(CAcroViewApp, CWinApp)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
END_MESSAGE_MAP()

CAcroViewApp theApp;

BOOL CAcroViewApp::InitInstance()
{
	InitCommonControls();

	CWinApp::InitInstance();

	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();
	
	CMDIFrameWnd* pFrame = new CMainFrame;

	if (!pFrame)
		return FALSE;

	m_pMainWnd = pFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	
	HINSTANCE hInst = AfxGetResourceHandle();
	m_hMDIMenu  = ::LoadMenu(hInst, MAKEINTRESOURCE(IDR_AcroViewTYPE));
	m_hMDIAccel = ::LoadAccelerators(hInst, MAKEINTRESOURCE(IDR_AcroViewTYPE));

	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

int CAcroViewApp::ExitInstance() 
{
	if (m_hMDIMenu != NULL)
		FreeResource(m_hMDIMenu);

	if (m_hMDIAccel != NULL)
		FreeResource(m_hMDIAccel);

	return CWinApp::ExitInstance();
}

void CAcroViewApp::OnFileOpen()
{
	CFileDialog fd(TRUE, "Pdf|*.pdf");

	if (fd.DoModal() == IDOK)
	{
		CMainFrame* pFrame = STATIC_DOWNCAST(CMainFrame, m_pMainWnd);
		CChildFrame *childFrame = (CChildFrame *)pFrame->CreateNewChild(RUNTIME_CLASS(CChildFrame), 
					IDR_AcroViewTYPE, m_hMDIMenu, m_hMDIAccel);

		childFrame->m_wndView.Open(fd.GetFileName());
	}
}
