#include "stdafx.h"
#include "AcroView.h"
#include "AcroViewer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

BEGIN_MESSAGE_MAP(CAcroViewer, CWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()

BOOL CAcroViewer::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

const int CTRL_ID = 280;

int CAcroViewer::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	//Create the control, just make sure to use WS_CHILD and WS_VISIBLE.
	if (!m_ctrl.Create("AdobeWnd", WS_CHILD | WS_VISIBLE, CRect(0, 0, 0, 0), this, CTRL_ID))
	{
		AfxMessageBox("Failed to create adobe wnd");
		return -1;
	}

	return 0;
}

void CAcroViewer::Open(const char *file)
{
	//Just load the file that is opened.
	m_ctrl.LoadFile(file);
}

void CAcroViewer::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	//Resize the control with the window.
	if (IsWindow(m_hWnd))
	{
		CRect rc;
		GetClientRect(rc);
		m_ctrl.MoveWindow(rc);
	}
}
