// CAcroAXDocShim.cpp  : Definition of ActiveX Control wrapper class(es) created by Microsoft Visual C++


#include "stdafx.h"
#include "CAcroAXDocShim.h"

/////////////////////////////////////////////////////////////////////////////
// CAcroAXDocShim

IMPLEMENT_DYNCREATE(CAcroAXDocShim, CWnd)

// CAcroAXDocShim properties

// CAcroAXDocShim operations
