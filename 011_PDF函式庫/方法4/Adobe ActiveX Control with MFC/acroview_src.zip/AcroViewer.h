#pragma once

#include "CAcroAXDocShim.h"

class CAcroViewer : public CWnd
{
public:
	void Open(const char *file);

//Message functions
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);

protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	DECLARE_MESSAGE_MAP()

// Attributes
private:
	CAcroAXDocShim m_ctrl;
};

