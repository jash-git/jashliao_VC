// CPW_Test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "CPW_Test.h"
#include "CutePDFWriter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
        CCutePDFWriter PDF_Printer;
        CDC *pDC = PDF_Printer.GetDC(_T("C:\\My_PDF_Folder\\"));

        pDC->StartDoc(_T("My_PDF_File"));
        pDC->StartPage();

        pDC->Ellipse(100, 200, 300, 400);

        pDC->EndPage();
        pDC->EndDoc();

        PDF_Printer.ReleaseDC(); // optional, as PDF_Printer will go out of scope
	}

	return nRetCode;
}
