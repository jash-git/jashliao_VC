#include "StdAfx.h"
#include "CutePDFWriter.h"

#include <psapi.h>              // for GetModuleBaseName
#pragma comment(lib, "psapi")

// String constants used in this file
#define HKCU               HKEY_CURRENT_USER
#define CPW_KEY_NAME       _T("Software\\Acro Software Inc\\CPW")
#define CPW_VALUE_NAME     _T("Filename")
#define DRIVER_KEY_NAME    _T("Software\\Microsoft\\Windows NT\\CurrentVersion\\Devices")
#define DRIVER_VALUE_NAME  _T("CutePDF Writer")
#define EXE_FILE_NAME      _T("CPWSave.exe")
#define DIALOG_CLASS_NAME  _T("#32770")

#ifndef _countof
#define _countof(array) sizeof(array)/sizeof(array[0])
#endif

/////////////////////////////////////////////////////////////////////////////
//
//  CCutePDFWriter constructor  (public member function)
//    Initializes the class variables
//
//  Parameters:
//    None
//
//  Returns:
//    Nothing
//
//  Note:
//    If the CutePDF Writer (CPW) is busy and already has a "Save As"
//    dialog open, then this constructor function will wait for the
//    CPW application to finish it's current print job
//
/////////////////////////////////////////////////////////////////////////////

CCutePDFWriter::CCutePDFWriter(void)
: SavedDC(0)
, CPWProcessID(0)
{
    // Check if the CutePDF Writer is already processing a file
    HWND hWnd = GetSaveAsDialog();
    if (NULL != hWnd)
    {
        // if it is then we wait for it to finish before we proceed
        HANDLE ProcessHandle = OpenProcess(SYNCHRONIZE, FALSE, CPWProcessID);
        WaitForSingleObject(ProcessHandle, INFINITE);
        CloseHandle(ProcessHandle);
        Sleep(2000);    // Need this delay as the CPW seems to take this long to
                        // save it's settings in the registry

        CPWProcessID = 0;
    }

    TCHAR *Data = NULL;
    DWORD DataSize = 0;
    HKEY hKey = NULL;
    DWORD Type = REG_SZ;

    if (ERROR_SUCCESS == RegOpenKeyEx(HKCU, CPW_KEY_NAME, 0, KEY_READ, &hKey))
    {
        if (ERROR_SUCCESS == RegQueryValueEx(hKey, CPW_VALUE_NAME, 0, &Type, (LPBYTE)Data, &DataSize) && Type == REG_SZ)
        {
            Data = new TCHAR[DataSize / sizeof(TCHAR) + 1];
            if (ERROR_SUCCESS == RegQueryValueEx(hKey, CPW_VALUE_NAME, 0, &Type, (LPBYTE)Data, &DataSize))
            {
                Data[DataSize / sizeof(TCHAR)] = 0;
                PreviousFolder = Data;
            }
            delete[] Data;
        }
        RegCloseKey(hKey);
    }
}

/////////////////////////////////////////////////////////////////////////////
//
//  CCutePDFWriter destructor  (public member function)
//    Calls ReleaseDC() to finish the print job and then calls SetSaveFolder()
//    to reset the previously saved registry settings
//
//  Parameters:
//    None
//
//  Returns:
//    Nothing
//
/////////////////////////////////////////////////////////////////////////////

CCutePDFWriter::~CCutePDFWriter(void)
{
    ReleaseDC();

    if (!PreviousFolder.IsEmpty())
    {
        SetSaveFolder(PreviousFolder);
    }
}

// This structure is used to return data from the GetSaveAsDialogProc
struct datastruct {
    HWND hWnd;
    DWORD ProcessID;
};

/////////////////////////////////////////////////////////////////////////////
//
//  CCutePDFWriter::GetSaveAsDialog  (protected member function)
//    attempts to get the "Save As" dialog that CutePDF pops up
//
//  Parameters:
//    None
//
//  Returns:
//    The HWND handle of the "Save As" dialog
//
//  Note:
//    Also changes the CPWProcessID member variable to the
//    process ID of the CPWSave.exe application
//
/////////////////////////////////////////////////////////////////////////////

HWND CCutePDFWriter::GetSaveAsDialog(void)
{
    datastruct ds = {0};
    EnumWindows(GetSaveAsDialogProc, (LPARAM)&ds);
    CPWProcessID = ds.ProcessID;
    return ds.hWnd;
}

/////////////////////////////////////////////////////////////////////////////
//
//  CCutePDFWriter::GetSaveAsDialogProc  (protected member CALLBACK function)
//    Callback function for the EnumWindows API used in the GetSaveAsDialog function
//
//  Parameters:
//    hWnd - [in] The handle of the current window being enumerated
//    lp   - [in] a pionter to a datastruct, type cast as an LPARAM
//
//  Returns:
//     FALSE when the Save As dialog is found and the EnumWindows function can stop
//     TRUE to continue searching
//
/////////////////////////////////////////////////////////////////////////////

BOOL CALLBACK CCutePDFWriter::GetSaveAsDialogProc(HWND hWnd, LPARAM lp)
{
    BOOL result = TRUE;
    TCHAR Buffer[MAX_PATH + 1] = {0};

    GetClassName(hWnd, Buffer, _countof(Buffer));
    if (_tcsicmp(Buffer, DIALOG_CLASS_NAME) == 0)       // is this window a dialog?
    {
        DWORD ProcessID = 0;
        GetWindowThreadProcessId(hWnd, &ProcessID);     // Get the ID of the app that owns this dialog
        HANDLE hProcess = OpenProcess (PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, ProcessID);
        if (NULL != hProcess)
        {
            GetModuleBaseName(hProcess, NULL, Buffer, _countof(Buffer));  // get the name of the exe file
            if (_tcsicmp(Buffer, EXE_FILE_NAME) == 0)   // was this dialog created by the CPWSave program?
            {
                datastruct *dsp = (datastruct*)lp;
                dsp->hWnd = hWnd;
                dsp->ProcessID = ProcessID;
                result = FALSE;
            }

            CloseHandle(hProcess);
        }
    }

    return result;
}

/////////////////////////////////////////////////////////////////////////////
//
//  CCutePDFWriter::SetSaveFolder  (protected member function)
//    sets the folder where the PDF file will be saved
//    
//  Parameters:
//    Folder - [in] the path to the folder
//
//  Returns:
//    true if the path exists and was saved in the registry
//    false if the path was not created or not saved to the registry
//
//  Note:
//    Creates the specified folder if it does not already exist
//
/////////////////////////////////////////////////////////////////////////////

bool CCutePDFWriter::SetSaveFolder(LPCTSTR Folder)
{
    bool result = true;

    if (NULL != Folder && _tcslen(Folder) > 0)
    {
        result = false;
        int SHCD = SHCreateDirectoryEx(NULL, Folder, NULL);
        SetLastError(SHCD);

        if (SHCD == ERROR_SUCCESS || SHCD == ERROR_FILE_EXISTS || SHCD == ERROR_ALREADY_EXISTS)
        {
            HKEY hKey = NULL;
            result = (ERROR_SUCCESS == RegOpenKeyEx(HKCU, CPW_KEY_NAME, 0, KEY_WRITE, &hKey));
            if (result)
            {
                result = (ERROR_SUCCESS == RegSetValueEx(hKey, CPW_VALUE_NAME, 0, REG_SZ, (const LPBYTE)Folder, (_tcslen(Folder) + 1) * sizeof(TCHAR)));
                RegCloseKey(hKey);
            }
        }
    }
    return result;
}

/////////////////////////////////////////////////////////////////////////////
//
//  CCutePDFWriter::GetDC  (public member function)
//    set the current folder and return the printer DC
//
//  Parameters:
//    Folder - [in] the folder where the PDF file will be saved
//
//  Returns:
//    A pointer to the CDC object that contains the PDF printer DC
//
//  Note:
//   if GetDC() returns NULL, call GetLastError() for the reason
//
/////////////////////////////////////////////////////////////////////////////

CDC *CCutePDFWriter::GetDC(LPCTSTR Folder)
{
    CDC *RetVal = NULL;

    if (SavedDC == 0 && SetSaveFolder(Folder))
    {
        HKEY hKey = NULL;
        DWORD Type = REG_SZ;
        DWORD Size = 64 * sizeof(TCHAR);
        TCHAR Driver[64] = {0};

        if (ERROR_SUCCESS == RegOpenKeyEx(HKCU, DRIVER_KEY_NAME, 0, KEY_READ, &hKey))
        {
            if (ERROR_SUCCESS == RegQueryValueEx(hKey, DRIVER_VALUE_NAME, 0, &Type, (LPBYTE)Driver, &Size))
            {
                TCHAR *ptr = _tcschr(Driver, _T(','));
                if (NULL != ptr)
                {
                    *ptr = NULL;
                }

                if (DC.CreateDC(Driver, DRIVER_VALUE_NAME, NULL, NULL))
                {
                    SavedDC = DC.SaveDC();
                    RetVal = &DC;
                }
            }
            RegCloseKey(hKey);
        }
    }

    return RetVal;
}

/////////////////////////////////////////////////////////////////////////////
//
//  CCutePDFWriter::ReleaseDC  (public member function)
//    reset and delete the DC, and click the save button on the "save as" dialog
//
//  Parameters:
//    None
//
//  Returns:
//    Nothing
//
/////////////////////////////////////////////////////////////////////////////

void CCutePDFWriter::ReleaseDC(void)
{
    if (SavedDC != 0)
    {
        DC.RestoreDC(SavedDC);
        DC.DeleteDC();

        Sleep(1000); // give the "Save As" dialog a chance to show

        if (HWND hWnd = GetSaveAsDialog())  // sets CPWProcessID
        {
            // simulate a click on the Save button
            if (HWND Button = ::GetDlgItem(hWnd, IDOK))
            {
                HANDLE ProcessHandle = OpenProcess(SYNCHRONIZE, FALSE, CPWProcessID);
                ::PostMessage(hWnd, WM_COMMAND, MAKEWPARAM(IDOK, BN_CLICKED), (LPARAM)Button);
                WaitForSingleObject(ProcessHandle, INFINITE);
                CloseHandle(ProcessHandle);
                Sleep(2000);    // Need this delay as the CPW seems to take this long to
                                // save it's settings in the registry
            }
        }
    }
    SavedDC = 0;
    CPWProcessID = 0;
}
