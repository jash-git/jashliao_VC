#pragma once

class CCutePDFWriter
{
private:
    CDC DC;                         // the printer DC
    int SavedDC;                    // the saved dc state
    DWORD CPWProcessID;             // Process ID of the CPWSave.exe module
    CString PreviousFolder;         // the previous folder location

protected:
    HWND GetSaveAsDialog(void);     // attempts to get the "Save As" dialog that CutePDF pops up
    static BOOL CALLBACK GetSaveAsDialogProc(HWND, LPARAM);  // EnumWindows callback function
    bool SetSaveFolder(LPCTSTR);    // sets the folder where the PDF file will be saved

public:
    CCutePDFWriter(void);           // save the previous folder location
    ~CCutePDFWriter(void);          // reset the previous folder location

    CDC *GetDC(LPCTSTR);            // set the current folder and return the printer DC
    void ReleaseDC(void);           // reset and delete the DC, and click the save button on the "save as" dialog
};
