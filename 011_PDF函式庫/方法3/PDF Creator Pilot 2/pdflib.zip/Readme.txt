PDF Creator Pilot
Copyright (C) 2002-2006 Two Pilots

1. THE PURPOSE OF THE PROGRAM
The library for creating PDF files from Visual Basic, ASP, Delphi, 
Visual C++, VBScript. PDF Creator Pilot includes detailed 
documentation together with the step-by-step tutorials.

2. SYSTEM REQUIREMENTS
  - x86-based personal computer (486 minimum);
  - Microsoft Windows Windows 95/98/NT/2000/ME/XP;
  - no less than 16 MB application RAM;
  - 2 MB hard disk space.

3. INSTALLATION
To install the program, run Setup.exe and then follow requests of 
the installation program.

4. THE STATUS OF THE PROGRAM
PDF Creator Pilot is distributed as demo.

5. THE DISTRIBUTION STATUS OF THE PROGRAM
The demo version of PDF Creator Pilot is freely distributable.

6. HOW TO CONTACT US
Two Pilots
http://www.colorpilot.com/
