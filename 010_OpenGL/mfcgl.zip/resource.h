//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MFCGL.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MFCGLTYPE                   129
#define IDR_TOOLBAR_COMMAND             130
#define IDC_CUR_ZOOM                    132
#define IDC_CUR_MOVE                    133
#define IDC_CUR_ROTATE                  134
#define IDC_CUR_SELECT                  135
#define C_PAN                           32771
#define SELECTMODE                      32772
#define C_ROTATE                        32773
#define ID_DRAWMODE_SOLID               32774
#define ID_DRAWMODE_WIRE                32775
#define ID_DRAWMODE_POINTS              32776
#define ID_DRAWMODE_SILHOUETTE          32777
#define ID_ORTHO                        32778
#define ID_PERSPECTIVE                  32779
#define ID_X_VIEW                       32780
#define ID_Y_VIEW                       32781
#define ID_Z_VIEW                       32782
#define ID_FREE_VIEW                    32783
#define ID_DRAWMODE_ORIENTATION_INSIDE  32784
#define ID_DRAWMODE_ORIENTATION_OUTSIDE 32785
#define ID_DRAWMODE_SHADING_NONE        32786
#define ID_DRAWMODE_SHADING_FLAT        32787
#define ID_SHOW_COORDINATE_AXIS         32788
#define ID_DRAWMODE_SHADING_SMOOTH      32789

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
