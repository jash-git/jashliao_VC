// MFCGLView.h : interface of the CMFCGLView class
//
/////////////////////////////////////////////////////////////////////////////


/*##################################################################

  Author:	Masoud Samimi
  Website:	www.geocities.com/samimi73
  Email:	marcello43@hotmail.com

  Program:	MFC OpenGL
  History:	Last modified for web on 22.07.2000 (dd.mm.yy)
  
  Purpose: Please visit my website, it is expalined there.
  

Important Notice:

	No guarantee/warantee is given on this app and I will not be responsible 
	for any damage to you, your property or any other person from using it.
	USE IT ON YOUR OWN RISK.

	Thankyou and have FUNNE =-)

	Masoud Samimi.

##################################################################*/


#if !defined(AFX_MFCGLVIEW_H__525FE02F_FEBF_11D3_BEC0_DA6A43B1B745__INCLUDED_)
#define AFX_MFCGLVIEW_H__525FE02F_FEBF_11D3_BEC0_DA6A43B1B745__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Camera.h"

//define the Actions
#define CAMERA_PAN      0
#define SCENE_PAN      1
#define CAMERA_ROTATE    2
#define SCENE_ROTATE    3

#define SHAPE_MOVE		10
#define SHAPE_ROTATE	 11
#define SHAPE_SCALE		12

#define SELECT          9

//define the ViewMode
#define X_VIEW      1
#define Y_VIEW      2
#define Z_VIEW      3
#define FREE_VIEW   4

// define drawing modes
#define WIRE 1
#define SOLID 2
#define POINTS 3
#define SILHOUETTE 4

// define Lighting normals facing Inside or Outside
#define INSIDE	1
#define OUTSIDE	 2

// define Shading effects None, Flat or Smooth
#define NONE	 1
#define FLAT	  2
#define SMOOTH	 3

// define Shapes type
#define SPHERE 1
#define CONE 2
#define CUBE  3
#define CYLINDER 4
#define TORUS 5
#define TEAPOT 6
#define DISK	7

class CMFCGLView : public CView
{
protected: // create from serialization only
	CMFCGLView();
	DECLARE_DYNCREATE(CMFCGLView)

	GLUquadricObj* m_pShape;

	HGLRC m_hGLContext;
	BOOL CreateViewGLContext(HDC hDC);
	int m_GLPixelIndex;
	BOOL SetWindowPixelFormat(HDC hDC);
	
	void DisplayWorldCoord(CPoint);

// Attributes
public:
	CMFCGLDoc* GetDocument();

	CCamera    m_Camera;            //use to pan the scene 
    CScene     m_Scene;             //use to rotate the coordinate axis
	int        m_RotateAxis;        //determine the current rotate axis


	void CheckOrtho();              //Is it Ortho or Perspective Mode
	bool m_bBuildList;              //Has the DisplayList built,can speed up the display
	int m_Action;                   //determine what  going to do ,when the mouse move
	BOOL m_bShowAxis;			   //should we show the coordinate
	void SetViewMode();             //set X,Y,Z or Perspectiv view mode
	int m_ViewMode;                 //current view mode
	void InitOpenGL();              //initialize the necessary OpenGL environment
	float m_WHRatio;                //the ratio of the width and heigh of the window
	BOOL m_bOrtho;                  //current ortho mode
	CPoint m_OldPoint;              //save the previous mouse click point
	
	BOOL m_bSelection;

	UINT m_nDrawMode,
		 m_nDrawOrient,
		 m_nShading;

	FLOAT m_fLineWidth;

// Operations
public:

	void ProcessSelection(int xPos, int yPos);
	void ProcessPlanet(GLuint *pSelectBuff);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCGLView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_MSG
	//}}AFX_VIRTUAL

// Implementation
public:
	void RenderScene();
	virtual ~CMFCGLView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMFCGLView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnCameraPan();
	afx_msg void OnUpdateCameraPan(CCmdUI* pCmdUI);
	afx_msg void OnSELECTMODE();
	afx_msg void OnUpdateSELECTMODE(CCmdUI* pCmdUI);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSceneRotate();
	afx_msg void OnUpdateSceneRotate(CCmdUI* pCmdUI);
	afx_msg void OnPaint();
	afx_msg void OnOrtho();
	afx_msg void OnUpdateOrtho(CCmdUI* pCmdUI);
	afx_msg void OnPerspective();
	afx_msg void OnUpdatePerspective(CCmdUI* pCmdUI);
	afx_msg void OnXView();
	afx_msg void OnYView();
	afx_msg void OnZView();
	afx_msg void OnFreeView();
	afx_msg void OnUpdateXView(CCmdUI* pCmdUI);
	afx_msg void OnUpdateYView(CCmdUI* pCmdUI);
	afx_msg void OnUpdateZView(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFreeView(CCmdUI* pCmdUI);
	afx_msg void OnShowCoordinateAxis();
	afx_msg void OnUpdateShowCoordinateAxis(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeSolid();
	afx_msg void OnUpdateDrawmodeSolid(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeWire();
	afx_msg void OnUpdateDrawmodeWire(CCmdUI* pCmdUI);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnDrawmodePoints();
	afx_msg void OnUpdateDrawmodePoints(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeSilhouette();
	afx_msg void OnUpdateDrawmodeSilhouette(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeOrientationInside();
	afx_msg void OnUpdateDrawmodeOrientationInside(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeOrientationOutside();
	afx_msg void OnUpdateDrawmodeOrientationOutside(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeShadingFlat();
	afx_msg void OnUpdateDrawmodeShadingFlat(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeShadingNone();
	afx_msg void OnUpdateDrawmodeShadingNone(CCmdUI* pCmdUI);
	afx_msg void OnDrawmodeShadingSmooth();
	afx_msg void OnUpdateDrawmodeShadingSmooth(CCmdUI* pCmdUI);
	//}}AFX_MSG
	

	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MFCGLView.cpp
inline CMFCGLDoc* CMFCGLView::GetDocument()
   { return (CMFCGLDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCGLVIEW_H__525FE02F_FEBF_11D3_BEC0_DA6A43B1B745__INCLUDED_)
