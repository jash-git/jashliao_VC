// MFCGLDoc.cpp : implementation of the CMFCGLDoc class
//

/*##################################################################

  Author:	Masoud Samimi
  Website:	www.geocities.com/samimi73
  Email:	marcello43@hotmail.com

  Program:	MFC OpenGL
  History:	Last modified for web on 22.07.2000 (dd.mm.yy)
  
  Purpose: Please visit my website, it is expalined there.
  

Important Notice:

	No guarantee/warantee is given on this app and I will not be responsible 
	for any damage to you, your property or any other person from using it.
	USE IT ON YOUR OWN RISK.

	Thankyou and have FUNNE =-)

	Masoud Samimi.

##################################################################*/

#include "stdafx.h"
#include "MFCGL.h"

#include "MFCGLDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCGLDoc

IMPLEMENT_DYNCREATE(CMFCGLDoc, CDocument)

BEGIN_MESSAGE_MAP(CMFCGLDoc, CDocument)
	//{{AFX_MSG_MAP(CMFCGLDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCGLDoc construction/destruction

CMFCGLDoc::CMFCGLDoc()
{
	// TODO: add one-time construction code here

}

CMFCGLDoc::~CMFCGLDoc()
{
}

BOOL CMFCGLDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMFCGLDoc serialization

void CMFCGLDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMFCGLDoc diagnostics

#ifdef _DEBUG
void CMFCGLDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMFCGLDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMFCGLDoc commands
