

#ifndef CCAMERA_H
#define CCAMERA_H

#define AXIS_X   0
#define AXIS_Y   1
#define AXIS_Z   2

void MyMatrixMult(float*,float*,float*);

class CTransferMatrix
{
public:

	float Matrix[16];          
	CTransferMatrix(); 
	void MyIdentity();
	void Load(float*);         

};

class CScene
{
public:

	CTransferMatrix m_TransferMatrix;        
    CScene();
    
	void RotateRoundAxis(float r,int axis);  
	void Apply();                           
    
};


class CCamera
{public:
	CTransferMatrix m_TransferMatrix;      
        CCamera();
	void Offset(float,float,float);       
	void RotateRoundAxis(float r,int axis);  
	void Apply();                          
   
};

#endif
