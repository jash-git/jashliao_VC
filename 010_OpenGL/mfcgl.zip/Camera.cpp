#include "stdafx.h"
#include "Camera.h"

void MyMatrixMult(float* V1,float* V2,float* V3)
{
	
	glPushMatrix();
	glLoadMatrixf(V1);
	glMultMatrixf(V2);
	glGetFloatv(GL_MODELVIEW_MATRIX,V3);
	glPopMatrix();

}
CTransferMatrix::CTransferMatrix()
{
	MyIdentity();
}

void CTransferMatrix::MyIdentity()
{   
	int i;
	for(i=0;i<16;i++)        
	    Matrix[i]=0.0;
	for(i=0;i<16;i+=5)       
	    Matrix[i]=1.0;
}

void CTransferMatrix::Load(float* M)
{
	for(int i=0;i<16;i++)    
	    Matrix[i]=M[i];
}


CScene::CScene()
{
}
void CScene::RotateRoundAxis(float r,int axis)
{	glPushMatrix();
	glLoadMatrixf(m_TransferMatrix.Matrix);
	if(axis==AXIS_X)
	   glRotatef(r,1,0,0);
	if(axis==AXIS_Y)
           glRotatef(r,0,1,0); 	
	if(axis==AXIS_Z)
	   glRotatef(r,0,0,1); 
        float m_newMatrix[16];
	glGetFloatv(GL_MODELVIEW_MATRIX,m_newMatrix);
	m_TransferMatrix.Load(m_newMatrix);
	glPopMatrix();
}

void CScene::Apply()
{
	glMultMatrixf(m_TransferMatrix.Matrix);
}



void CCamera::RotateRoundAxis(float r,int axis)
{


	glPushMatrix();

	glLoadMatrixf(m_TransferMatrix.Matrix);

	if(axis==AXIS_X)
	   glRotatef(r,1,0,0);

	if(axis==AXIS_Y)
       glRotatef(r,0,1,0); 	
	
	if(axis==AXIS_Z)
	   glRotatef(r,0,0,1); 
  
    float m_newMatrix[16];

	glGetFloatv(GL_MODELVIEW_MATRIX,m_newMatrix);

	m_TransferMatrix.Load(m_newMatrix);

	glPopMatrix();
}


CCamera::CCamera()
{
}

void CCamera::Offset(float x,float y,float z)
{
   
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(x,y,z);
	float m_tempMatrix[16];
	float m_newMatrix[16];
	glGetFloatv(GL_MODELVIEW_MATRIX,m_newMatrix);
    
	MyMatrixMult(m_newMatrix,m_TransferMatrix.Matrix,m_newMatrix);
	m_TransferMatrix.Load(m_newMatrix);
	glPopMatrix();
}


void CCamera::Apply()
{
	glMultMatrixf(m_TransferMatrix.Matrix);
}


