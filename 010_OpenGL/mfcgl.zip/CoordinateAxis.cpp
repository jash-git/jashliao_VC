#include "stdafx.h"
#include "math.h"
#include "CoordinateAxis.h"


CCoordinateAxis::CCoordinateAxis(float x,float y,float z)
{       
	lx=x;ly=y;lz=z;
}

void CCoordinateAxis::Display()
{
	int  m_light;
	glGetIntegerv(GL_LIGHTING,&m_light);
	glDisable(GL_LIGHTING);
	glColor3f(1,0,0);
	JLine(0,0,0,lx,0,0);
	glColor3f(0,1,0);
	JLine(0,0,0,0,ly,0);
	glColor3f(0,0,1);
	JLine(0,0,0,0,0,lz);
	if(m_light==GL_TRUE)
    glEnable(GL_LIGHTING);
}


void CCoordinateAxis::JLine(float x1,float y1,float z1,float x2,float y2,float z2)
{
    glBegin(GL_LINES);
    glVertex3f(x1,y1,z1);
    glVertex3f(x2,y2,z2);
    glEnd();
}
void CCoordinateAxis::JLine(CVector V1,CVector V2)
{
	JLine(V1.V.x,V1.V.y,V1.V.z,V2.V.x,V2.V.y,V2.V.z);
}


CVector GetNormal(CVector& C,CVector& V1,CVector& V2,CVector& V3,CVector& V4)
{
    CVector V=(V1-C).x(V2-C)+(V2-C).x(V3-C)+(V3-C).x(V4-C)+(V4-C).x(V1-C);
    V.Normalize();
    return V;
}

CVector::CVector(Coordinate& m_Coor)
{
   V=m_Coor;
}

CVector::CVector(float x,float y,float z)
{  
   V.x=x;
   V.y=y;
   V.z=z;
}
void CVector::Normalize()
{
   float r=GetMagnitude();
   V.x/=r;V.y/=r;V.z/=r;
}
float CVector::GetMagnitude()
{
   return (float)sqrt((double)(V.x*V.x+V.y*V.y+V.z*V.z));
}

CVector CVector::operator +(CVector& m)
{  
   return CVector(V.x+m.V.x,V.y+m.V.y,V.z+m.V.z);
}

CVector CVector::operator -(CVector& m)
{
   return CVector(V.x-m.V.x,V.y-m.V.y,V.z-m.V.z);
}

float   CVector::operator *(CVector& m)
{
   return V.x*m.V.x+V.y*m.V.y+V.z*m.V.z;
}

CVector  CVector::x(CVector& m)
{
   return CVector(V.y*m.V.z-V.z*m.V.y, V.z*m.V.x-V.x*m.V.z,V.x*m.V.y-V.y*m.V.x);
}
void CVector::operator +=(CVector& m)
{
   V.x+=m.V.x;
   V.y+=m.V.y;
   V.z+=m.V.z;
}
void CVector::operator-=(CVector& m)
{
   V.x-=m.V.x;
   V.y-=m.V.y;
   V.z-=m.V.z;
}

CVector CVector::operator *(float a)
{
   return CVector(V.x*a,V.y*a,V.z*a);
}