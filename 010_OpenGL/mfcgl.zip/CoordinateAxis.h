
#ifndef CCOORDINATEAXIS_H
#define CCOORDINATEAXIS_H

#define  XY   0
#define  YZ   1
#define  XZ   2
#define PI  3.1415926

struct Coordinate
{
   float x,y,z;

};

class CVector
{
public:

   CVector(Coordinate&);
   CVector(float=0,float=0,float=0);

   Coordinate V;                     
   void Normalize();                 
   float GetMagnitude();             
   CVector operator +(CVector&);
   CVector operator -(CVector&);
   float   operator *(CVector&);     
   CVector  x(CVector&);             
   void operator +=(CVector&);
   void operator -=(CVector&);
   CVector operator *(float a);      

};

CVector GetNormal(CVector&,CVector&,CVector&,CVector&,CVector&);


class CCoordinateAxis
{
public:
	float lx,ly,lz;   
	CCoordinateAxis(float=1,float=1,float=1);
	void Display();  
	
	void JLine(float,float,float,float,float,float);
	void JLine(CVector V1,CVector V2);
};

#endif

