void message( char * str );

void message2( char * str, char *s2 );