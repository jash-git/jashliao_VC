#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library

int loadTargaTexture(char *filename,  GLuint *ptex);