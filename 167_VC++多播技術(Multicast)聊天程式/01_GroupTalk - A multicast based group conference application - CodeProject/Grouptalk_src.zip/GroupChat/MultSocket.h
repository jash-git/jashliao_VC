//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : Multicasting implementation
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////


#include<afxsock.h>

#if !defined(AFX_MULTSOCKET_H__0652CBE1_9C5D_11D7_8887_101753C10001__INCLUDED_)
#define AFX_MULTSOCKET_H__0652CBE1_9C5D_11D7_8887_101753C10001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class MultSocket : public CAsyncSocket  
{
public:
	
	CDialog *dlg;
	CAsyncSocket send;
	SOCKADDR_IN hgroup;
	ip_mreq mreq;
	CString senderip;
	UINT senderport;
	char buffer[2000];

	//Members ...
	MultSocket(CDialog *);
	
	BOOL joinGroup(char *strgroup,int gport,int ttl,BOOL loopback);
	void leaveGroup();
	void sendMessage(LPCTSTR mesg,int len);
	void sendMessage(LPCTSTR mesg,int length,UINT destport,char *host);

	BOOL setTTL(int ttl);
	BOOL setLoopBack(BOOL lback);
	void OnReceive(int errcode);
	void Close();
};

#endif // !defined(AFX_MULTSOCKET_H__0652CBE1_9C5D_11D7_8887_101753C10001__INCLUDED_)
