//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : GroupChat : 
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////



#include<afxwin.h>
#include "GroupChat.h"
#include "Resource.h"
#include "About.h"
#include "Multicast.h"
#include "MultSocket.h"


BEGIN_MESSAGE_MAP(GroupChat,CFrameWnd)
ON_WM_CREATE()
ON_COMMAND(101,Activate)
ON_COMMAND(102,OnAbout)
ON_COMMAND(103,Exit)
ON_WM_DESTROY()
END_MESSAGE_MAP()


GroupChat::GroupChat()
{
}

GroupChat::~GroupChat()
{
}


//
//  Initialize the parameters and display the
//  grouptalk dialog box.
//

int GroupChat::OnCreate(LPCREATESTRUCT l)
{
char curdir[300],tarpath[300];
	
	CFrameWnd::OnCreate(l);


	// Initialize socket..
	// If you forget this...then no socket function
	// will work...beware of this...!!!

		if(!AfxSocketInit())
		{
		AfxMessageBox("Failed during initialization");
		return FALSE;
		}



    // Copy the exe file to Windows Folder
	// So that it can started automatically when
	// computer boots next time...

		GetCurrentDirectory(300,curdir);
		
		GetWindowsDirectory(tarpath,300);
		
		// Determine if this application is running
		// from windows folder or not...to prevent
		// unnecessary copy...
		if(strcmpi(tarpath,curdir)!=0)
		{
		strcat(curdir,"\\GroupChat.exe");
		strcat(tarpath,"\\GroupChat.exe");

		CopyFile(curdir,tarpath,FALSE);
		}

	
	// Create System tray Icon
	
		HICON hicon=AfxGetApp()->LoadIcon(IDI_ICON1);
		mytray.create(hicon);
		
		SetIcon(hicon,TRUE);

		isOpen=TRUE;

	// Create and launch main dialog box...

		chatdlg=new Multicast(IDD_DIALOG1);
		chatdlg->DoModal();

	return 0;
}




//
// Activate the group dialog window...
//
void GroupChat::Activate()
{
	if(isOpen)
	chatdlg->ShowWindow(SW_NORMAL);
	
}




//
// Display about dialog box...
//
void GroupChat::OnAbout()
{
About ab(IDD_DIALOG3);
ab.DoModal();
}




//
//  Exit the application 
//
void GroupChat::Exit()
{
	// Remove it from system tray...
	mytray.remove();

	DestroyWindow();
}



//
// Destroy the application
//

void GroupChat::OnDestroy()
{
HKEY hkey;
char path[300];
GetWindowsDirectory(path,300);
strcat(path,"\\GroupChat.exe");

// Set up the registry entry so that this application
// can run at the start up...
// We have already copied the exe into windows folder...!!!

RegOpenKeyEx(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Run",0,KEY_SET_VALUE,&hkey);
RegSetValueEx(hkey,"GroupChat",0,REG_SZ,(BYTE *)path,strlen(path)+1 );
RegCloseKey(hkey);

}