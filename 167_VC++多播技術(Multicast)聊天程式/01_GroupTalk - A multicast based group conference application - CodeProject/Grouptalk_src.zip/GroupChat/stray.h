
//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : System tray implementation
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////

class stray:public CWnd
{
NOTIFYICONDATA ndata;
CMenu menu;


public:

	virtual LRESULT  WindowProc(UINT mess,WPARAM wp,LPARAM lp);
	
	stray()
	{
	}
	
	BOOL create(HICON h);
	LRESULT OnMessage(WPARAM w,LPARAM l);
	
	void remove();
	void setdefault();
	void activate();

DECLARE_MESSAGE_MAP()
};