//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : Main application
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////


#if !defined(AFX_DISPMULT_H__18BBBF74_9BF1_11D7_8887_601753C10001__INCLUDED_)
#define AFX_DISPMULT_H__18BBBF74_9BF1_11D7_8887_601753C10001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DispMult : public CWinApp  
{
public:
   BOOL InitInstance();
};

#endif // !defined(AFX_DISPMULT_H__18BBBF74_9BF1_11D7_8887_601753C10001__INCLUDED_)
