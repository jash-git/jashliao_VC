//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : About dialog 
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////



#if !defined(AFX_ABOUT_H__82808C20_0E0B_11D6_A4FF_000795508B71__INCLUDED_)
#define AFX_ABOUT_H__82808C20_0E0B_11D6_A4FF_000795508B71__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class About : public CDialog  
{
public:
	About(int n);
	virtual ~About();
	HBRUSH OnCtlColor(CDC *pdc,CWnd *pwnd,UINT ctrl);
	void OnPaint();
DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_ABOUT_H__82808C20_0E0B_11D6_A4FF_000795508B71__INCLUDED_)
