//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : System tray class
//   Description : Displays application as a tray icon...
//
//////////////////////////////////////////////////////////////////////////////


#include<afxwin.h>
#include"stray.h"


BEGIN_MESSAGE_MAP(stray,CWnd)
ON_MESSAGE(WM_USER+15,OnMessage)
END_MESSAGE_MAP()

//
//   Create the system tray icon for this application
//

BOOL stray::create(HICON icon)
{
	
	CWnd::CreateEx(0,AfxRegisterWndClass(0),"",WS_POPUP,0,0,10,10,NULL,0);

	// Crete pop up menu for the tray icon
	menu.CreatePopupMenu();
	menu.AppendMenu(MF_STRING,101,"Open GroupChat");
	menu.AppendMenu(MF_STRING,102,"About GroupChat");
	menu.AppendMenu(MF_STRING,103,"Exit");

	
	// Create tray icon

	ndata.cbSize=sizeof(NOTIFYICONDATA);
	ndata.hWnd=m_hWnd;
	ndata.uID=1;
	ndata.hIcon=icon;
	ndata.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;
	ndata.uCallbackMessage=WM_USER+15;
	strcpy(ndata.szTip,"Group Chat");

	Shell_NotifyIcon(NIM_ADD,&ndata);

return 0;
}

//
// Handle the mouse event at the tray icon
//


LRESULT stray::OnMessage(WPARAM w,LPARAM l)
{
CWnd *pwnd=AfxGetMainWnd();

	// Right button pressed ...
	// Activate the pop up menu

	if(LOWORD(l)==WM_RBUTTONUP)
	{
	CPoint p;
	GetCursorPos(&p);
	pwnd->SetForegroundWindow();
	//setdefault();
	menu.TrackPopupMenu(TPM_RIGHTBUTTON,p.x,p.y,pwnd);
	pwnd->PostMessage(WM_NULL,0,0);
	}
	else
	{

		// Double click...
		// Active the dialog box of the application

		if(LOWORD(l)==WM_LBUTTONDBLCLK)
		{
		pwnd->SetForegroundWindow();
		pwnd->SendMessage(WM_COMMAND,101,0);
		}

	}

	return 0L;

}




//
// Remote the icon from the tray
//

void stray::remove()
{
Shell_NotifyIcon(NIM_DELETE,&ndata);
}


//
// Set default menu item for the icon
//
void stray::setdefault()
{
	::SetMenuDefaultItem(menu.m_hMenu,101,NULL);
}



LRESULT stray::WindowProc(UINT mess, WPARAM wp, LPARAM lp)
{
	return CWnd::WindowProc(mess,wp,lp);
}


//
// Active the dialog box
//
void stray::activate()
{
this->SetForegroundWindow();
MessageBox("Application activated");
}