//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : Frame window class...
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GROUPCHAT_H__D9205501_E15A_11D7_8887_000B2B0F84B6__INCLUDED_)
#define AFX_GROUPCHAT_H__D9205501_E15A_11D7_8887_000B2B0F84B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include<afxwin.h>
#include "stray.h"
#include "About.h"
#include "Multicast.h"
#include "MultSocket.h"



class GroupChat : public CFrameWnd  
{
public:
	stray mytray;
	Multicast *chatdlg;
	BOOL isOpen;


	
	GroupChat();
	virtual ~GroupChat();
	int OnCreate(LPCREATESTRUCT);
	void Activate();
	void OnAbout();
	void Exit();
	void OnDestroy();
DECLARE_MESSAGE_MAP()

};

#endif // !defined(AFX_GROUPCHAT_H__D9205501_E15A_11D7_8887_000B2B0F84B6__INCLUDED_)
