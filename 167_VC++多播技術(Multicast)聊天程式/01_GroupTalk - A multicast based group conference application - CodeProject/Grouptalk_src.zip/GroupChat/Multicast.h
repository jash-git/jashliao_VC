//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : GroupTalk dialog class
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////



#if !defined(AFX_MULTICAST_H__18BBBF75_9BF1_11D7_8887_601753C10001__INCLUDED_)
#define AFX_MULTICAST_H__18BBBF75_9BF1_11D7_8887_601753C10001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include<afxwin.h>
#include"MultSocket.h"
#include"Myedit.h"
#include "About.h"

class Multicast : public CDialog 
{
public:
	CListBox *userlist,*recvlist;
	CButton *radGroup,*radUser;
	CComboBox *cmbUser;
	CScrollBar *sc_vert;
	MultSocket *msock;
	char send[525];
	char username[200];
	char curuser[50];
	char mesg[525];
	BOOL isJoin,isGroup,isEnable;
	CMenu *menu;
	CFont efont,sfont;
	CEdit *sendbox;
	CButton *sendbutton,*clearbutton;
	MyEdit *m_edit;
	CString m_text;
	CBitmap sbmp,cbmp;
	char m_path[200];
	int usercount;
	int m_count;


	Multicast(int n);
	BOOL OnInitDialog();
	void OnPaint();
	HBRUSH OnCtlColor(CDC *pdc,CWnd *pwnd,UINT ctrl);
	void OnSize(UINT type,int cx,int cy);

	void DoDataExchange(CDataExchange* pDX);
	void Join();
	void OnClear();
	
	void Leave();
	void OnAbout();
	void OnRadio(int id);
	void OnSend();
	void OnCancel();
	void OnDestroy();

	void DispMesg(char *);
	void OnSelectUser();
	void OnEraseBkgnd(CDC *pdc);
	void OnEndSession(BOOL bend);

DECLARE_MESSAGE_MAP()

};

#endif // !defined(AFX_MULTICAST_H__18BBBF75_9BF1_11D7_8887_601753C10001__INCLUDED_)
