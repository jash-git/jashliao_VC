//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       102
#define IDR_ACCELERATOR1                103
#define IDD_DIALOG2                     104
#define IDD_DIALOG3                     105
#define IDI_ICON1                       106
#define IDR_MAINFRAME                   107
#define IDB_BITMAP1                     108
#define IDB_BITMAP2                     109
#define IDB_BITMAP3                     110
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_BUTTON1                     1002
#define IDC_EDIT3                       1003
#define IDC_BUTTON2                     1004
#define IDC_EDIT4                       1005
#define IDC_BUTTON3                     1006
#define IDC_LIST1                       1007
#define IDC_LIST3                       1009
#define IDC_IPADDRESS1                  1010
#define IDC_RADIO1                      1011
#define IDC_RADIO2                      1013
#define IDC_COMBO1                      1015
#define ID_JOINGROUP                    40001
#define ID_LEAVEGROUP                   40002
#define ID_ABOUT                        40004
#define ID_CLEAR                        40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
