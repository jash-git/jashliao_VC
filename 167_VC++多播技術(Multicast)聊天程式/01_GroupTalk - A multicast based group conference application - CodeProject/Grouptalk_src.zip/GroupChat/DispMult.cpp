//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name :  Main application class
//   Description : starts the application
//
//////////////////////////////////////////////////////////////////////////////

#include<afxwin.h>


#include "DispMult.h"
#include "GroupChat.h"
#include "resource.h"


BOOL DispMult::InitInstance()
{
	
	
	GroupChat *group=new GroupChat();
	m_pMainWnd=group;

	BOOL ret=group->LoadFrame(IDR_MAINFRAME,
						WS_OVERLAPPEDWINDOW, 
						NULL,
						NULL);


	return TRUE;
}

DispMult disp;
