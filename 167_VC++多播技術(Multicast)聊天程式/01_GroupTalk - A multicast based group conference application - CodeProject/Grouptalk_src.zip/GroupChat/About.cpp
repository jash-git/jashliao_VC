//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : About dialog 
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////

#include <afxwin.h>
#include "About.h"




BEGIN_MESSAGE_MAP(About,CDialog)
ON_WM_PAINT()
ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


About::About(int n):CDialog(n)
{

}

About::~About()
{

}





void About::OnPaint()
{
CRect r;
CPen p[64];
int i,factor;

	CPaintDC pdc(this);
	
	GetClientRect(&r);
	factor=r.bottom/63;

	for(i=0;i<64;i++)
	p[i].CreatePen(PS_SOLID,1,RGB(200,170+i,252));
	
	for(i=0;i<=r.bottom/2;i++)
	{
	pdc.SelectObject(&p[i/factor]);
	
	pdc.MoveTo(0,i);
	pdc.LineTo(r.right,i);
	pdc.MoveTo(0,r.bottom-i);
	pdc.LineTo(r.right,r.bottom-i);
	}

}



/*                                                           */
/* This function will paint the bkgnd of individual          */
/* components of dialog box                                  */
/*                                                           */ 


HBRUSH About::OnCtlColor(CDC *pdc,CWnd *pwnd,UINT ctrl)
{
int id=pwnd->GetDlgCtrlID();
HBRUSH hbr;
pdc->SetTextColor(RGB(0,0,255));

pdc->SetBkMode(TRANSPARENT);
hbr=(HBRUSH)GetStockObject(HOLLOW_BRUSH);


return hbr;
}

