//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : Customized edit control...
//   Description : ....
//
//////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYEDIT_H__8AE4CEAB_E116_11D7_8887_000B2B0F84B6__INCLUDED_)
#define AFX_MYEDIT_H__8AE4CEAB_E116_11D7_8887_000B2B0F84B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include<afxwin.h>


class MyEdit : public CEdit  
{
public:
	CDialog *dlg;	

	MyEdit(CDialog *dlg);
	virtual ~MyEdit();
	
	UINT OnGetDlgCode();
     void OnKeyUp(UINT code,UINT repcnt,UINT flags);
	  
DECLARE_MESSAGE_MAP()
};


	

#endif // !defined(AFX_MYEDIT_H__8AE4CEAB_E116_11D7_8887_000B2B0F84B6__INCLUDED_)
