
//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : GroupTalk dialog
//   Description : It uses simple message format for conference 
//					Message Format :
//					1)Membership :
//									Type     : 5 bytes ( JOIN , LEVE etc terminated with :)
//									Username : Rest of the bytes
//					2)General 
//									Type     :  5 bytes ( MESG:)
//									Username : 15 bytes (username terminated with 0)
//									Length   :  5 bytes
//									data     :  Rest of bytes....
//
//
//////////////////////////////////////////////////////////////////////////////


#include <afxwin.h>

// Required only for sndPlaySound function
#include <mmsystem.h>

#include "resource.h"
#include "Multicast.h"
#include "MultSocket.h"
#include "About.h"


// Required only for sndPlaySound function
#pragma comment(lib,"winmm")


BEGIN_MESSAGE_MAP(Multicast,CDialog)
ON_COMMAND(IDC_BUTTON1,OnSend)
ON_COMMAND(IDCANCEL,OnCancel)
ON_COMMAND(ID_ABOUT,OnAbout)
ON_COMMAND(IDC_BUTTON2,OnClear)
ON_COMMAND_RANGE(IDC_RADIO1,IDC_RADIO2,OnRadio)
ON_CBN_SELENDOK(IDC_COMBO1,OnSelectUser)   
ON_WM_SIZE()
ON_WM_ENDSESSION()
ON_WM_DESTROY()
ON_WM_ERASEBKGND()
ON_WM_PAINT()
ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


Multicast::Multicast(int n):CDialog(n)
{
	m_edit=new MyEdit(this);
}


void Multicast::DoDataExchange(CDataExchange* pDX)
{
           CDialog::DoDataExchange(pDX);
           DDX_Control(pDX, IDC_EDIT1, *m_edit);
}



BOOL Multicast::OnInitDialog()
{
	userlist=(CListBox *) GetDlgItem(IDC_LIST1);
	recvlist=(CListBox *) GetDlgItem(IDC_LIST3);
	radGroup=(CButton*) GetDlgItem(IDC_RADIO1);
	radUser=(CButton*) GetDlgItem(IDC_RADIO2);
	sendbox=(CEdit *) GetDlgItem(IDC_EDIT1);
	sendbutton=(CButton*)GetDlgItem(IDC_BUTTON1);
	clearbutton=(CButton*)GetDlgItem(IDC_BUTTON2);
	cmbUser=(CComboBox*)GetDlgItem(IDC_COMBO1);
	cmbUser->SetWindowPos(&wndTop,0,0,160,200,SWP_NOMOVE);

	OnRadio(IDC_RADIO1);


	
	efont.CreateFont(12,8,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,0,0,"Arial");
	sfont.CreateFont(10,6,0,0,0,0,0,0,DEFAULT_CHARSET,0,0,0,0,"System");

	sendbox->SetFont(&sfont);
	recvlist->SetFont(&efont);
	
	sbmp.LoadBitmap(IDB_BITMAP2);
	cbmp.LoadBitmap(IDB_BITMAP3);

	sendbutton->SetBitmap((HBITMAP)sbmp.m_hObject); 
	clearbutton->SetBitmap((HBITMAP)cbmp.m_hObject); 
	
	GetWindowsDirectory(m_path,200);
	strcat(m_path,"\\media\\ding.wav");

	sndPlaySound(m_path,SND_ASYNC);

	m_count=0;
	usercount=0;
	isEnable=TRUE;

	m_text.Empty();

	menu=GetMenu();
	

	
    sendbox->EnableWindow(FALSE);
	msock=new MultSocket(this);

	
		
	gethostname(username,200);
	strcpy(mesg,"MESG:");
	strcat(mesg,username);

	Join();
	
	return CDialog::OnInitDialog();
}


void Multicast::OnEraseBkgnd(CDC *pdc)
{


}


/*                                                           */
/* OnPaint() will fill the client area with                  */
/* the selected gradient color.                              */
/*                                                           */ 

void Multicast::OnPaint()
{
CRect r;
CPen p[64];
int i,factor;

CPaintDC pdc(this);
	
	GetClientRect(&r);
	factor=r.bottom/63;

	for(i=0;i<64;i++)
	p[i].CreatePen(PS_SOLID,1,RGB(200,170+i,252));
	

	for(i=0;i<=r.bottom/2;i++)
	{
	pdc.SelectObject(&p[i/factor]);
	
	pdc.MoveTo(0,i);
	pdc.LineTo(r.right,i);
	pdc.MoveTo(0,r.bottom-i);
	pdc.LineTo(r.right,r.bottom-i);
	}

}


/*                                                           */
/* This function will paint the bkgnd of individual          */
/* components of dialog box                                  */
/*                                                           */ 

HBRUSH Multicast::OnCtlColor(CDC *pdc,CWnd *pwnd,UINT ctrl)
{
int id=pwnd->GetDlgCtrlID();
HBRUSH hbr;
pdc->SetTextColor(RGB(0,0,255));


	switch(id)
	{
	case IDC_EDIT1:case IDC_LIST1:case IDC_LIST3:case IDC_COMBO1:
	hbr=CreateSolidBrush(RGB(255,255,255));
	return hbr;

	case IDC_RADIO1:case IDC_RADIO2:
	pdc->SetBkMode(TRANSPARENT);
	hbr=(HBRUSH)GetStockObject(HOLLOW_BRUSH);
	return hbr;

	default:
	hbr=CreateSolidBrush(RGB(255,255,255));
	return hbr;
	
	}

return NULL;
}


//
//  Clear all the messages displayed...
//
void Multicast::OnClear()
{
recvlist->ResetContent();
m_count=0;
}



//
// If the dialog is minimized then hide it...
//

void Multicast::OnSize(UINT type,int cx,int cy)
{

	if(type==SIZE_MINIMIZED)
	{
		ShowWindow(SW_HIDE);
	}

	CDialog::OnSize(type,cx,cy);

}


//
//  Join the multicast group....
//

void Multicast::Join()
{

		if( msock->joinGroup((char*)(LPCTSTR)"225.6.7.8",4000,8,TRUE) == FALSE)
		{
			
			isJoin=FALSE;
			AfxMessageBox("Unable to the Join Group");
			return ;
		}

		isJoin=TRUE;

		// Send the message to the group
		// that i have joined...

		char str[200];	
		sprintf(str,"JOIN:%s",username);
	    msock->sendMessage(str,strlen(str));
		
}

  
//
//  Leave the multicast group....
//
void Multicast::Leave()
{
char text[200];

if(isJoin==FALSE) return;

	// Intimate all other member that i am leaving
	sprintf(text,"LEVE:%s",username);
	msock->sendMessage(text,strlen(text));

	// leave group
	msock->leaveGroup();

	// clear the contents...
	sendbutton->EnableWindow(FALSE);
	userlist->ResetContent();
	recvlist->ResetContent();

	isJoin=FALSE;
}



//
//  This is invoked before exiting the application
//  If the user shutdowns the pc without exiting the
//  application then this method is called....
//  Here we can leave group ...properly
//
void Multicast::OnEndSession(BOOL bEnd)
{
char text[200];

if(bEnd==FALSE)
return;

if(isJoin==FALSE) return;
	// Inform others....
	sprintf(text,"LEVE:%s",username);
	msock->sendMessage(text,strlen(text));

	// Now safely leave the group
	msock->leaveGroup();

}


//
//   Display about dialog box
//
void Multicast::OnAbout()
{
About ab(IDD_DIALOG3);
ab.DoModal();
}


//
//  Send the mesg to the group/individual
//

void Multicast::OnSend()
{
int len;
char str[200];

	// No users are there..return
	if(usercount==0)
	{
		SetDlgItemText(IDC_EDIT1,"");
		return;
	}
	
	// No message typed...return...
	if(m_text.IsEmpty())
	{
	GetDlgItemText(IDC_EDIT1,m_text);
	
	if(m_text.IsEmpty())
	return;
	}
	
	// Go to top to view the message format...

	len=m_text.GetLength();
	sprintf(&mesg[20],"%d",len);
	strcpy(&mesg[25],m_text);
	
	SetDlgItemText(IDC_EDIT1,"");
	
	
	sprintf(str,"%s >> %s ",username,&mesg[25]);
	recvlist->AddString(str);
	
	m_count++;
	
	if(m_count>9)
	recvlist->SetCurSel(recvlist->GetCount()-1);
	

	// Send to the group...
	if(isGroup)
	msock->sendMessage(mesg,len+25);
	else  // Send to the individual...
	{
		msock->sendMessage(mesg,len+25,4000,curuser);
	}

     m_text.Empty();
}


//
//  Hide the dialog box...don't exit
//
void Multicast::OnCancel()
{
ShowWindow(SW_HIDE);
}



//
//  Destroy the dialog box...
//
void Multicast::OnDestroy()
{
	Leave();
	msock->Close();
	
	CDialog::OnDestroy();


}


//
//  Different member is selected from the combo box
//
//
void Multicast::OnSelectUser()
{

if(cmbUser->GetCount()==0)
return;

cmbUser->GetLBText(cmbUser->GetCurSel(),curuser);
}


//
//  Either group / individual radio button is clicked...
//
void Multicast::OnRadio(int id)
{
	switch(id)
	{
		case IDC_RADIO1:    //Group
		radGroup->SetCheck(1);
		radUser->SetCheck(0);
		cmbUser->EnableWindow(FALSE);
		strcpy(curuser,"group");
		isGroup=TRUE;
		break;
		
		case IDC_RADIO2:    //Individual User
		radGroup->SetCheck(0);
		radUser->SetCheck(1);
		cmbUser->EnableWindow(TRUE);
		
		if(cmbUser->GetCount()>=1)
		cmbUser->GetLBText(cmbUser->GetCurSel(),curuser);

		isGroup=FALSE;
		break;
	}

}


//
//  Handle message arrived from the another group member
//
//	For message format just look at the top of this page
//

void Multicast::DispMesg(char *mesg)
{
int i,pos,index,prev_index=-1;
char header[5];
char text[525];
char disp_mesg[200];

	// Is mesg was sent by myself...
	// then ignore it...

	if(strcmpi(username,&mesg[5])==0)
	{
		return;
	}

	// Determine type of packet..
	for(i=0;i<4;i++)
	header[i]=mesg[i];

	header[4]=0;

// Now header contains type of packet...
// Based upon this take different actions...


//
//  Remote user has joined the group
//
if( strcmpi(header,"JOIN")==0)
{
	pos=userlist->FindString(-1,&mesg[5]);

	sendbox->EnableWindow(TRUE);

	// Send information about our existence to this new member
	sprintf(text,"MINE:%s",username);
	msock->sendMessage(text,strlen(text));

	

	if(pos==LB_ERR)
	{
		usercount++;
		userlist->AddString(&mesg[5]);
	
		if(cmbUser->GetCount()>=1)
		prev_index=cmbUser->GetCurSel();
		else
		prev_index=-1;
		
		cmbUser->AddString(&mesg[5]);
	
			if(prev_index!=-1)
			cmbUser->SetCurSel(prev_index);
			else
			cmbUser->SetCurSel(0);
	
		ShowWindow(SW_SHOWNORMAL);
		sprintf(disp_mesg," User %s logged in....",&mesg[5]);
		MessageBox(disp_mesg);

	}

	
	

return;
}

//
// This mesg is used to distinguish betn initial JOIN
// and response to JOIN(MINE)...
//
if( strcmpi(header,"MINE")==0)
{
	pos=userlist->FindString(-1,&mesg[5]);

	if(pos==LB_ERR)
	{
		usercount++;
		sendbox->EnableWindow(TRUE);
	
		if(cmbUser->GetCount()>=1)
		prev_index=cmbUser->GetCurSel();
		else
		prev_index=-1;

		cmbUser->AddString(&mesg[5]);
		
		if(prev_index!=-1)
		cmbUser->SetCurSel(prev_index);
		else
		cmbUser->SetCurSel(0);

		userlist->AddString(&mesg[5]);
	}


return;
}

//
//  Remote member has left the group...
//  

if(strcmpi(header,"LEVE")==0)
{
	pos=userlist->FindString(-1,&mesg[5]);
	
	if(pos!=LB_ERR)
	{
		usercount--;
		if(usercount<1)
		sendbox->EnableWindow(FALSE);

		userlist->DeleteString(pos);

		ShowWindow(SW_SHOWNORMAL);
		sprintf(disp_mesg," User %s logged off....",&mesg[5]);
		MessageBox(disp_mesg);
	
	}
	
	index=cmbUser->FindStringExact(-1,&mesg[5]);

	if(index!=CB_ERR)
	cmbUser->DeleteString(index);

	if(usercount<1)
	cmbUser->ResetContent();  //clear the combo box

return;
}


	// This is general message packet..
	// Display this message in the display panel...

	m_count=m_count+1;

	// Active dialog box..since new message arrived
	
	ShowWindow(SW_SHOWNORMAL);
	SetForegroundWindow();

	// Beep...
	sndPlaySound(m_path,SND_ASYNC);

	sprintf(text,"%s >> %s ",&mesg[5],&mesg[25]);
	recvlist->AddString(text);
	
	if(m_count>9)
	recvlist->SetCurSel(recvlist->GetCount()-1);
}





