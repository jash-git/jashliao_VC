//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name :  MultSocket class
//   Description : Multicasting based on group conference
//
//////////////////////////////////////////////////////////////////////////////



#include <afxwin.h>
#include <afxsock.h>
#include "Multicast.h"
#include "MultSocket.h"


MultSocket::MultSocket(CDialog *dialog)
{
	dlg=dialog;

}



BOOL MultSocket::joinGroup(char *strgroup,int gport,int ttl,BOOL lback)
{

	/* Create socket for receiving packets from multicast group */

	if(!Create(gport,SOCK_DGRAM, FD_READ))
	return FALSE;


	BOOL bMultipleApps = TRUE;		/* allow reuse of local port if needed */
	SetSockOpt(SO_REUSEADDR, (void*)&bMultipleApps, sizeof(BOOL), SOL_SOCKET);

	
	
	/* Join the multicast group */
	
	memset(&mreq,0,sizeof(ip_mreq));
	mreq.imr_multiaddr.s_addr = inet_addr(strgroup);	/* group addr */ 
	mreq.imr_interface.s_addr = htons(INADDR_ANY);		/* use default */ 
	
	if(setsockopt(m_hSocket, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char far *)&mreq,sizeof(mreq))!=0 )
	{
		AfxMessageBox("Join:: Adding member failed");
		return FALSE;
	}
	
	/**
	*   You can send the data to any multicast group
	*   without becoming the member of that group.
	*   But in order to receive data from the group you
	*   must be the member of that group.
	*/

	
	// For sending message to multicast group
	// create datagram socket...
		
	// setup the group address and port ...
	// user for sending later...
	memset(&hgroup, 0, sizeof(hgroup));
	hgroup.sin_family = AF_INET;
	hgroup.sin_addr.s_addr = inet_addr(strgroup);
	hgroup.sin_port = htons((USHORT)gport);

	// Create datagram socket...
	if(!send.Create(0, SOCK_DGRAM, 0))		
	{
		AfxMessageBox("Join :: Creation of sending socket failed");
		return FALSE;
	}
	
	// Limit the scope of group...
	if(!setTTL(ttl))								// Set Time to Live as specified by user
	{
		AfxMessageBox("Joing :: Error Setting TTL");
		return FALSE;

	}
	
	
	setLoopBack(lback);							// Enable/Disable Loopback
	
	return TRUE;
}



//
//  Limit the scope of group
//
BOOL MultSocket::setTTL(int ttl)
{
	/* Set Time to Live to parameter TTL */
	if(send.SetSockOpt(IP_MULTICAST_TTL, &ttl, sizeof(int), IPPROTO_IP) == 0)
		return FALSE;		/* Error Setting TTL */
	else
		return TRUE;		/* else TTL set successfully */

}


//
//  Enable/disable loop back...
//
BOOL MultSocket::setLoopBack(BOOL lback)
{
return TRUE;
}



//
// Leave the group
//	
	
void MultSocket::leaveGroup()
{
	
	if(setsockopt(m_hSocket, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char FAR *)&mreq,sizeof(mreq))!=0 )
	{
		
		AfxMessageBox("Leave :: Failed to drop membership");
		return;
	}

	// Close all sockets...
	CAsyncSocket::Close();
	send.Close();

}


//
//  Incoming message handler...
//

void MultSocket::OnReceive(int errcode)
{
	
	int error = ReceiveFrom (buffer, 2000, senderip, senderport);
	
	if(error==SOCKET_ERROR)
	{
	AfxMessageBox("Error while receiving message");
	}
	else
	{
		buffer[error]=NULL;

		((Multicast *)dlg)->DispMesg(buffer);
	
	}
	CAsyncSocket::OnReceive(errcode);
}

//
//  Close this socket...
//
void MultSocket::Close()
{
	CAsyncSocket::Close();
	send.Close();
}


// 
//  Send the message to group...
//
void MultSocket::sendMessage(LPCTSTR mesg,int length)
{

SendTo(mesg,length,(SOCKADDR*)&hgroup,sizeof(SOCKADDR),0);

}




// 
//  Send the message to individual user...
//
void MultSocket::sendMessage(LPCTSTR mesg,int length,UINT destport,char *host)
{

SendTo(mesg,length,destport,host);
}