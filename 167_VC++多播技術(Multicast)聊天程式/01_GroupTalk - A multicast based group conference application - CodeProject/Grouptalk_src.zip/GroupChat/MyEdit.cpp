//////////////////////////////////////////////////////////////////////////////
//
//   GroupTalk 
//   Multicasting based conference application
//
//   Author : Nagareshwar Y Talekar
//
//   Name : MyEdit class
//   Description :  Implementation of customized edit control
//                  Whenever user types the message and preses the
//					ENTER key ..the message has to be sent.In order to
//					trap this ENTER key event , customized edit control
//					is used.				
//////////////////////////////////////////////////////////////////////////////


#include "MyEdit.h"
#include "Multicast.h"



	  BEGIN_MESSAGE_MAP(MyEdit, CEdit)
      ON_WM_GETDLGCODE()
      ON_WM_KEYUP()
      END_MESSAGE_MAP()
	  
      
	  
	  	MyEdit::MyEdit(CDialog *dialog)
		{
		dlg=dialog;
		}

		MyEdit::~MyEdit()
		{

		}
	  
		
		UINT MyEdit::OnGetDlgCode()
		{

           return DLGC_WANTARROWS|DLGC_WANTALLKEYS|DLGC_WANTCHARS;
     
		}

		//
		//  Trap the enter key hit at the edit control
		//

		  void MyEdit::OnKeyUp(UINT code,UINT repcnt,UINT flags)
		  {
	  			
				 // If user pressed enter key...
				 // then send the message....
				 if(code==VK_RETURN)
				  {

					   GetWindowText( ( (Multicast*) dlg)->m_text);
					   
					   int p= ( (Multicast*) dlg)->m_text.GetLength();
					   
					   // If string length is less than 2 
					   // or no users are present then return....
					   
					   if(p==2 || ( (Multicast*) dlg)->usercount==0)
					   {
						   SetWindowText("");
						   return;
					   }
					   
					   // Retrieve the message from the edit control
					   // except the last 2 letter pertaining to ENTER key "\r\n"
					   ((Multicast*) dlg)->m_text.SetAt(p-2,0);
					   
					   // Send the message...
					   ( (Multicast*) dlg)->OnSend();
				  
				 
				 }
				  else	// Default handling...
				  CEdit::OnKeyUp(code,repcnt,flags);
			
		  }

   
