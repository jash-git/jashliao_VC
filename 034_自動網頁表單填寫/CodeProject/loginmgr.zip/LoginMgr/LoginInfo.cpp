// LoginInfo.cpp : Implementation of CLoginInfo

#include "stdafx.h"
#include "LoginInfo.h"


// CLoginInfo
