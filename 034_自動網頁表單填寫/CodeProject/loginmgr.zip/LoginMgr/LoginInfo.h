// LoginInfo.h : Declaration of the CLoginInfo

#pragma once

#include "resource.h"       // main symbols
#include <atlhost.h>
#include "ExDispID.h"
#include "atlutil.h"
#include <comdef.h>

// CLoginInfo

class CLoginInfo : 
	public CAxDialogImpl<CLoginInfo>
{
public:
	
	CLoginInfo(bstr_t& bsURL, bstr_t& bsUid, bstr_t& bsPwd)
	{
		m_bsURL = bsURL;
		m_bsUid = bsUid;
		m_bsPwd = bsPwd;
	}

	~CLoginInfo()
	{
	}

	enum { IDD = IDD_LOGININFO };

BEGIN_MSG_MAP(CLoginInfo)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOK)
	CHAIN_MSG_MAP(CAxDialogImpl<CLoginInfo>)
END_MSG_MAP()
private:
	bstr_t m_bsURL;
	bstr_t m_bsUid;
	bstr_t m_bsPwd;
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CAxDialogImpl<CLoginInfo>::OnInitDialog(uMsg, wParam, lParam, bHandled);
		this->SetDlgItemText(IDC_WEBURL,m_bsURL);
		this->SetDlgItemText(IDC_UID,m_bsUid);
		this->SetDlgItemText(IDC_PWD,m_bsPwd);

		return 1;  // Let the system set the focus
	}

	LRESULT OnClickedOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
	
};


