

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Mon Jan 29 16:26:06 2007
 */
/* Compiler settings for .\LoginMgr.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __LoginMgr_h__
#define __LoginMgr_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IIeLoginHelper_FWD_DEFINED__
#define __IIeLoginHelper_FWD_DEFINED__
typedef interface IIeLoginHelper IIeLoginHelper;
#endif 	/* __IIeLoginHelper_FWD_DEFINED__ */


#ifndef __IeLoginHelper_FWD_DEFINED__
#define __IeLoginHelper_FWD_DEFINED__

#ifdef __cplusplus
typedef class IeLoginHelper IeLoginHelper;
#else
typedef struct IeLoginHelper IeLoginHelper;
#endif /* __cplusplus */

#endif 	/* __IeLoginHelper_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __IIeLoginHelper_INTERFACE_DEFINED__
#define __IIeLoginHelper_INTERFACE_DEFINED__

/* interface IIeLoginHelper */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IIeLoginHelper;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("685B63F0-BA47-487E-9A2D-3461CCB0FB27")
    IIeLoginHelper : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IIeLoginHelperVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IIeLoginHelper * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IIeLoginHelper * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IIeLoginHelper * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IIeLoginHelper * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IIeLoginHelper * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IIeLoginHelper * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IIeLoginHelper * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } IIeLoginHelperVtbl;

    interface IIeLoginHelper
    {
        CONST_VTBL struct IIeLoginHelperVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IIeLoginHelper_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IIeLoginHelper_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IIeLoginHelper_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IIeLoginHelper_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IIeLoginHelper_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IIeLoginHelper_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IIeLoginHelper_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IIeLoginHelper_INTERFACE_DEFINED__ */



#ifndef __LoginMgrLib_LIBRARY_DEFINED__
#define __LoginMgrLib_LIBRARY_DEFINED__

/* library LoginMgrLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_LoginMgrLib;

EXTERN_C const CLSID CLSID_IeLoginHelper;

#ifdef __cplusplus

class DECLSPEC_UUID("BF468356-BB7E-42D7-9F15-4F3B9BCFCED2")
IeLoginHelper;
#endif
#endif /* __LoginMgrLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


