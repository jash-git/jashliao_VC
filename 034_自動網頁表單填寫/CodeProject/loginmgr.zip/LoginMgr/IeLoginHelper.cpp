// IeLoginHelper.cpp : Implementation of CIeLoginHelper

#include "stdafx.h"
#include "ExDispID.h"
#include "atlutil.h"
#include <comdef.h>
#include "Wininet.h"
#include "Mshtml.h"
#include "IeLoginHelper.h"
#include "MsHtmdid.h"
#include "LoginInfo.h"
// CIeLoginHelper

//===========================================================================
//      Project: autologin
//     Filename: IeLoginHelper.cpp
//
//  Description: Header for CIeLoginHelper procedures and classes
//
//    Copyright: (C) 2005-6, All rights reserved.
//
//      History:
// 25-May-2005 Ram Created
// 24-Aug-2006 Added dialog 
// 29-Aug-2006 	
// 1.void EnumFrames, RecurseWindows,m_bFoungLoginPage
// 2. converted all interface pointers in spart pointers:CComPtr<>
// Important Notice:
// @The author does not take any responsibility of any misuse of this source,
// @for any unstability condition to the target system after installing/unsitalling this BHO, 
// @damage to the system of data on it, if at all happens to target system. 
//===========================================================================

#if 0 // make 1 to see debugging messages
#define _MSGBOX
#endif

// CIeLoginHelper

//
// sink events through this class
//
HRESULT CIeLoginHelper::SinkBrowserConnection(ConnectType eConnectType)
{
	try
	{
		if (eConnectType == ConnType_Unadvise && m_dwBrowserCookie == 0)
			return S_OK;

		ATLASSERT(m_pWebBrowser2);
		if (!m_pWebBrowser2)
			return S_OK;

		HRESULT hr = E_FAIL;
		if (eConnectType == ConnType_Advise)
		{
			ATLASSERT(m_dwBrowserCookie == 0);
			hr = AtlAdvise (m_pWebBrowser2, (IDispatch*)this, __uuidof(DWebBrowserEvents2), &m_dwBrowserCookie);

		}
		else
		{
			hr = AtlUnadvise(m_pWebBrowser2, __uuidof(DWebBrowserEvents2), m_dwBrowserCookie);
			m_dwBrowserCookie = 0;
		}
		ATLASSERT(SUCCEEDED(hr));
		return hr;
	} 
	catch(...)
	{}
}
void  CIeLoginHelper::EnableEvents(CComPtr<IHTMLElementCollection> &spElemColl)
{
	
	try
	{
		if(spElemColl == NULL)
			return;
		_variant_t varIdx(0L, VT_I4);
		long lCount = 0;
		HRESULT hr  = S_OK;
		hr = spElemColl->get_length (&lCount);
		if (SUCCEEDED(hr))
		{
			for(long lIndex = 0; lIndex < lCount; lIndex++ )
			{
				varIdx = lIndex;
				CComPtr<IDispatch> spElemDisp;
				hr = spElemColl->item(varIdx, varIdx, &spElemDisp);

				if (SUCCEEDED(hr))
				{
					// a login page always is in a <FORM> object
					CComPtr<IHTMLFormElement> spElem;
					hr = spElemDisp->QueryInterface(IID_IHTMLFormElement, (void**)&spElem);

					if (SUCCEEDED(hr))
					{
#ifdef _MSGBOX
						::MessageBox(0,_T("hr = spElemDisp->QueryInterface(IID_IHTMLElement, 
							(void**)&spElem);"),_T("Success"),0); 
#endif
							ConnectEvents(ConnType_Advise, spElem);
					
					}

				}
			}
		}
	}
	catch(...)
	{}
}

void CIeLoginHelper::ConnectEvents(ConnectType eConnectType, CComPtr<IHTMLFormElement>& spElem)
{
	HRESULT hr;	
	try
	{
		if(spElem == NULL)
			return;
		// Check that this is a connectable object.
		if (eConnectType == ConnType_Advise)
		{
			CComPtr<IConnectionPointContainer> pConPtContainer;
			hr = spElem->QueryInterface(IID_IConnectionPointContainer, (void**)&pConPtContainer);

			if (SUCCEEDED(hr))
			{
				// Find the connection point.
				// in most of the cases you need to handle events of DIID_HTMLFormElementEvents2
				CComPtr<IConnectionPoint> spConPt;
				hr = pConPtContainer->FindConnectionPoint(DIID_HTMLFormElementEvents2, &spConPt);

				if (SUCCEEDED(hr))
				{
					// Advise the connection point.
					// pUnk is the IUnknown interface pointer for your event sink
					hr = spConPt->Advise((IDispatch*)this, &m_dwBrowserCookie);									

				}
				else
				{
#ifdef _MSGBOX
					::MessageBox(0,_T("pCPC->FindConnectionPoint(DIID_HTMLElementEvents2, &pCP);"),
						_T("failed"),0); 
#endif
				}

			}
			else
			{
#ifdef _MSGBOX
				::MessageBox(0,_T("QueryInterface(IID_IConnectionPointContainer, (void**)&pCPC);"),
					_T("failed"),0); 
#endif
			}
		}
		else
		{
			hr = AtlUnadvise(m_pWebBrowser2, __uuidof(DWebBrowserEvents2), m_dwBrowserCookie);
			m_dwBrowserCookie = 0;
		}
	} 
	catch(...)
	{}
} 


//
// IOleObjectWithSite Methods
//
STDMETHODIMP CIeLoginHelper::SetSite(IUnknown *pUnkSite)
{
	if (!pUnkSite)
	{
		ATLTRACE(_T("SetSite(): pUnkSite is NULL\n"));
	}
	else
	{
		// Query pUnkSite for the IWebBrowser2 interface.
		m_pWebBrowser2 = pUnkSite;
		if (m_pWebBrowser2)
		{
			// Connect to the browser in order to handle events.
			HRESULT hr = SinkBrowserConnection(ConnType_Advise);
			if (FAILED(hr))
				ATLTRACE(_T("Failure sinking events from IWebBrowser2\n"));
		}
		else
		{
			ATLTRACE(_T("QI for IWebBrowser2 failed\n"));
		}
	}

	return S_OK;
}

STDMETHODIMP CIeLoginHelper::Invoke(DISPID dispidMember, REFIID riid, LCID lcid, WORD wFlags,
									DISPPARAMS* pDispParams, VARIANT* pvarResult,
									EXCEPINFO*  pExcepInfo,  UINT* puArgErr)
{
	try
	{
		if (!pDispParams)
			return E_INVALIDARG;

		switch (dispidMember)
		{
		case DISPID_BEFORENAVIGATE:
			m_bPasswordCaptured = FALSE;
			break;

		case DISPID_NAVIGATECOMPLETE2:
			ATLTRACE(_T("(%ld) DISPID_NAVIGATECOMPLETE2\n"), ::GetCurrentThreadId());
			{

				if (!m_pWBDisp)
				{
					// This is the IDispatch* of the top-level browser
					m_pWBDisp = pDispParams->rgvarg[1].pdispVal;				
					m_bPasswordCaptured = FALSE;
					m_bFoungLoginPage = FALSE;

				}
			}
			break;	

		case DISPID_DOCUMENTCOMPLETE:
			/* when HTML page is completely downloaded and shown, try to connect to events*/
			if (m_pWBDisp && 
				m_pWBDisp == pDispParams->rgvarg[1].pdispVal)
			{
				// If the LPDISPATCH are same, that means
				// it is the final DocumentComplete. Reset m_pWBDisp.

				m_pWBDisp = NULL;
				CComPtr<IDispatch> spDisp;
				HRESULT hr = m_pWebBrowser2->get_Document(&spDisp);
				if (SUCCEEDED(hr) && spDisp)
				{
					// If this is not an HTML document 
					//(e.g., it's a Word doc or a PDF), don't sink.
					CComQIPtr<IHTMLDocument2, &IID_IHTMLDocument2> spHTML(spDisp);
					if (spHTML)
					{
						CComPtr<IHTMLFramesCollection2> spFrameset;
						hr = spHTML->get_frames(&spFrameset);
						if (SUCCEEDED(hr) && spFrameset)
						{
							/*there can be frames in HTML page
							enumerate each of frameset or iframe and find out 
							if any of them contain a login page*/
							EnumFrames(spHTML);		
						}
						
					}

					CComQIPtr<IOleObject, &IID_IOleObject> spOleObject(spDisp);
					if (spOleObject)
					{
						CComPtr<IOleClientSite> spClientSite;
						hr = spOleObject->GetClientSite(&spClientSite);
						if (SUCCEEDED(hr) && spClientSite)
						{
							m_pDefaultOleCommandTarget = spClientSite;	
						}
					}

				}
			} 

			break;

		case DISPID_QUIT:
			SinkBrowserConnection(ConnType_Unadvise);
			break;
		case DISPID_HTMLFORMELEMENTEVENTS2_ONSUBMIT:
			{
				/* this event occurs if a form is submitted with 
				INPUT TYPE=submit, INPUT TYPE=image, or BUTTON TYPE=submit object*/
				if(m_bPasswordCaptured)
					break;
				CComPtr<IDispatch> spDisp;
				HRESULT hr = m_pWebBrowser2->get_Document(&spDisp);
				if (SUCCEEDED(hr) && spDisp)
				{
					// If this is not an HTML document (e.g., it's a Word doc or a PDF), don't sink.
					CComQIPtr<IHTMLDocument2, &IID_IHTMLDocument2> spHTML(spDisp);
					if (spHTML)
					{
						/*	Get pointers to default interfaces
						create connection event
						*/
						CComQIPtr<IHTMLElementCollection, &IID_IHTMLElementCollection> spElcol;
						hr = spHTML->get_all(&spElcol);
						if (SUCCEEDED(hr) && spElcol)
						{
							_bstr_t bsUserId = L"", bsPassword = L"";
							GetUserId_Pwd(spElcol,bsUserId,bsPassword);
							_bstr_t bsUrl;		
							hr = m_pWebBrowser2->get_LocationURL(&bsUrl.GetBSTR());
							CLoginInfo oLoginInfo(bsUrl,bsUserId,bsPassword);
							oLoginInfo.DoModal();
							m_bPasswordCaptured = TRUE;

#ifdef _MSGBOX
							bstr_t Msg = L"User: ";
							Msg += bsUserId;Msg += L" Pwd: ";Msg += bsPassword;
							Msg += " URL: ";Msg += bsUrl;
							if(bsPassword.GetBSTR() && bsPassword.GetBSTR() )
								::MessageBox(0,Msg,L"Loginhelper",0); 
							m_bPasswordCaptured = TRUE;
#endif
						}
					}
				}

			}
			break;
		case DISPID_HTMLELEMENTEVENTS2_ONKEYPRESS:
			{
				/* some pages use form.submit, so handle keybord messages*/
				if(m_bPasswordCaptured)
					break;
				HRESULT hr;
				CComPtr<IDispatch> spEventObj;
				spEventObj = pDispParams->rgvarg[0].pdispVal;
				CComPtr<IHTMLEventObj> pHtmlEvent; 
				hr = spEventObj->QueryInterface(IID_IHTMLEventObj,(LPVOID*)&pHtmlEvent);
				BOOL bLoginEvent = FALSE;
				if (SUCCEEDED(hr) && pHtmlEvent)
				{
					CComPtr<IHTMLElement>spElement;
					hr = pHtmlEvent->get_srcElement(&spElement);
					if (SUCCEEDED(hr) && spElement)
					{
						_bstr_t bsTag;
						hr = spElement->get_tagName(&bsTag.GetBSTR());
						_bstr_t bsType = L"";
						CComPtr<IHTMLInputElement> spInputElm;
						hr = spElement->QueryInterface(IID_IHTMLInputElement,
							(void**)&spInputElm);
						if (SUCCEEDED(hr) && spInputElm )
						{
							hr = spInputElm->get_type(&bsType.GetBSTR());
							if (SUCCEEDED(hr) && bsTag.GetBSTR() && bsType.GetBSTR())
							{
								LONG lKeyCode = 0;
								pHtmlEvent->get_keyCode(&lKeyCode);
								if((bsType.operator ==(L"text") || bsType.operator ==(L"password")) 
									&& bsTag.operator ==(L"INPUT") &&  lKeyCode == 13)
									bLoginEvent = TRUE;
							}

						}					
					}				
				}
				if(!bLoginEvent)
					break;
			}
		case DISPID_HTMLELEMENTEVENTS2_ONCLICK:

			{
				/* some pages use form.submit, so handle mouse click*/
				if(m_bPasswordCaptured)
					break;
				HRESULT hr;
				CComPtr<IDispatch> spEventObj;
				spEventObj = pDispParams->rgvarg[0].pdispVal;
				CComPtr<IHTMLEventObj> pHtmlEvent; 
				hr = spEventObj->QueryInterface(IID_IHTMLEventObj,(LPVOID*)&pHtmlEvent);
				BOOL bLoginEvent = FALSE;
				if (SUCCEEDED(hr) && pHtmlEvent)
				{
					CComPtr<IHTMLElement> spElement; 
					hr = pHtmlEvent->get_srcElement(&spElement);
					if (SUCCEEDED(hr) && spElement)
					{
						_bstr_t bsTag;
						hr = spElement->get_tagName(&bsTag.GetBSTR());	
						CComPtr<IHTMLInputElement> spInputElm;

						if (SUCCEEDED(hr) && bsTag.GetBSTR())
						{
							if(bsTag.operator ==(L"INPUT") ||bsTag.operator ==(L"BUTTON") 
								|| bsTag.operator ==(L"IMG") 
								|| bsTag.operator ==(L"A"))
								bLoginEvent = TRUE;

							hr = spElement->QueryInterface(IID_IHTMLInputElement, (void**)&spInputElm);
							if (SUCCEEDED(hr) && spInputElm )
							{
								_bstr_t bsType = L"";
								hr = spInputElm->get_type(&bsType.GetBSTR());
								if(bsType.operator ==(L"submit"))
									bLoginEvent = FALSE;
								LONG lKeyCode = 0;
								pHtmlEvent->get_keyCode(&lKeyCode);
								if((bsType.operator ==(L"text") || bsType.operator ==(L"password")) 
									&& lKeyCode != 13)
									bLoginEvent = FALSE;						
							}

						}

					}				
				}
				if(!bLoginEvent)
					break;
				CComPtr<IDispatch> spDisp;
				hr = m_pWebBrowser2->get_Document(&spDisp);
				if (SUCCEEDED(hr) && spDisp)
				{
					// If this is not an HTML document (e.g., it's a Word doc or a PDF), don't sink.
					CComQIPtr<IHTMLDocument2, &IID_IHTMLDocument2> spHTML(spDisp);
					if (spHTML)
					{
						/*	 Get pointers to default interfaces
						create connection event
						*/
						CComQIPtr<IHTMLElementCollection, &IID_IHTMLElementCollection> spElcol;
						hr = spHTML->get_all(&spElcol);
						if (SUCCEEDED(hr) && spElcol)
						{
							_bstr_t bsUserId = L"", bsPassword = L"";
							GetUserId_Pwd(spElcol,bsUserId,bsPassword);
							_bstr_t bsUrl;		
							hr = m_pWebBrowser2->get_LocationURL(&bsUrl.GetBSTR());
							//open login info dialog
							CLoginInfo oLoginInfo(bsUrl,bsUserId,bsPassword);
							oLoginInfo.DoModal();
							m_bPasswordCaptured = TRUE;
#ifdef _MSGBOX
							bstr_t Msg = L"User: ";
							Msg += bsUserId;Msg += L" Pwd: ";Msg += bsPassword;
							Msg += " URL: ";Msg += bsUrl;
							if(bsPassword.GetBSTR() && bsPassword.GetBSTR() )
								::MessageBox(0,Msg,L"Loginhelper",0); 
							m_bPasswordCaptured = TRUE;

#endif
						}
					}
				}

			}
			break;
		default:
			break;
		}

		return S_OK;
	}
	catch(...)
	{
		return S_OK;
	}
}
/*if user id and password fields are consecutively placed.*/
void  CIeLoginHelper::GetUserId_Pwd(CComPtr<IHTMLElementCollection>&spElemColl, _bstr_t& bsUserId, _bstr_t& bsPassword)
{

	try
	{
		if(spElemColl == NULL)
			return;
		_variant_t varIdx(0L, VT_I4);
		long lCount = 0;
		HRESULT hr  = S_OK;
		hr = spElemColl->get_length (&lCount);
		if (SUCCEEDED(hr))
		{
			for(long lIndex = 0; lIndex < lCount; lIndex++ )
			{
				varIdx = lIndex;
				CComPtr<IDispatch>spElemDisp;
				hr = spElemColl->item(varIdx, varIdx, &spElemDisp);

				if (SUCCEEDED(hr))
				{
					CComPtr<IHTMLInputElement>spElem;
					hr = spElemDisp->QueryInterface(IID_IHTMLInputElement, (void**)&spElem);
					if (SUCCEEDED(hr))
					{
						_bstr_t bsType;
						spElem->get_type(&bsType.GetBSTR());
						if(bsType.operator ==(L"text"))
						{
							spElem->get_value(&bsUserId.GetBSTR());							
						}
						else if(bsType.operator==(L"password"))
						{
							spElem->get_value(&bsPassword.GetBSTR());							
						}				
					}

				}
				if(bsUserId.GetBSTR() && bsPassword.GetBSTR() 
					&& ( bsUserId.operator!=(L"") && bsPassword.operator!=(L"") ) )
				{
					return;
				}			

			}
		}
	}
	catch(...)
	{

	}
}
/*if a page has a password field then this is the you'll be interested in getting userid and password.*/
BOOL  CIeLoginHelper::IsLoginPage(CComPtr<IHTMLElementCollection>&spElemColl)
{
	
	try
	{
		if(spElemColl == NULL)
			return m_bFoungLoginPage;
		_variant_t varIdx(0L, VT_I4);
		long lCount = 0;
		HRESULT hr  = S_OK;
		hr = spElemColl->get_length (&lCount);
		if (SUCCEEDED(hr))
		{
			for(long lIndex = 0; lIndex < lCount; lIndex++ )
			{
				varIdx = lIndex;
				CComPtr<IDispatch>spElemDisp;
				hr = spElemColl->item(varIdx, varIdx, &spElemDisp);
				if (SUCCEEDED(hr))
				{
					CComPtr< IHTMLInputElement > spElem;
					hr = spElemDisp->QueryInterface(IID_IHTMLInputElement, (void**)&spElem);
					if (SUCCEEDED(hr))
					{
						_bstr_t bsType;
						hr = spElem->get_type(&bsType.GetBSTR());
						if(SUCCEEDED(hr) && bsType.operator==(L"password"))
						{
							m_bFoungLoginPage = true;
						}

					}

				}
				if(m_bFoungLoginPage)
					return m_bFoungLoginPage;
			}
		}
		return m_bFoungLoginPage;
	}
	catch(...)
	{
		return m_bFoungLoginPage;
	}
}
void CIeLoginHelper::EnumFrames(CComPtr<IHTMLDocument2>& spDocument) 
{	
	try
	{
		/*
			For how to browse through frame see-
			http://support.microsoft.com/kb/q196340/
		*/
		CComPtr<IHTMLDocument2> spDocument2;
		try
		{

			CComPtr<IOleContainer> pContainer;
			// Get the container
			HRESULT hr = spDocument->QueryInterface(IID_IOleContainer,
				(void**)&pContainer);

			if (FAILED(hr))
				return ;
			CComPtr<IEnumUnknown>pEnumerator;
			// Get an enumerator for the frames
			hr = pContainer->EnumObjects(OLECONTF_EMBEDDINGS, &pEnumerator);

			if (FAILED(hr))
				return ;
			IUnknown* pUnk;
			ULONG uFetched;

			// Enumerate and refresh all the frames
			BOOL bFrameFound = FALSE;
			for (UINT nIndex = 0; S_OK == pEnumerator->Next(1, &pUnk, &uFetched);
				nIndex++)
			{
				CComPtr<IWebBrowser2> pBrowser;
				hr = pUnk->QueryInterface(IID_IWebBrowser2, (void**)&pBrowser);
				pUnk->Release();
				if (SUCCEEDED(hr))
				{
					CComPtr<IDispatch> spDisp;
					pBrowser->get_Document(&spDisp);
					CComQIPtr<IHTMLDocument2, &IID_IHTMLDocument2> spDocument2(spDisp);					
					RecurseWindows(spDocument2);
					bFrameFound = TRUE;

				}
			}
			if(!bFrameFound || !m_bFoungLoginPage)
			{
				
				CComPtr<IHTMLElementCollection> spFrmCol;
				CComPtr<IHTMLElementCollection> spElmntCol;
				/*	multipe <FORM> object can be in a page, connect to each one them
				You never know which one contains uid and pwd fields
				*/
				hr = spDocument->get_forms(&spFrmCol);
				// get element collection from page to check if a page is a lgoin page
				hr = spDocument->get_all(&spElmntCol);
				if(IsLoginPage(spElmntCol))						
					EnableEvents(spFrmCol);								
						
			}

		}
		catch(_com_error Error)
		{
			ATLTRACE(Error.ErrorMessage());
		}
		catch(...)
		{
			ATLTRACE(_T("Unspecified exception thrown in GetPageContents\n"));
		}
		//RecurseWindows(spDocument);
	}
	catch(_com_error Error)
	{
		ATLTRACE(Error.ErrorMessage());
	}
	catch(...)
	{
		ATLTRACE(_T("Unspecified exception thrown in OnTestEnumlinks\n"));
	}

}
/*this portion of source is adopted from MS sample OBJVW*/
void CIeLoginHelper::RecurseWindows(CComPtr<IHTMLDocument2>& spDocument)
{

	// enumerating frames in a document.
	HRESULT hr;
	if(spDocument == NULL)
		// Not an HTML document
		return;
	try
	{

		// Find out if this page has a "BODY".  If it does, it will not have a 
		// <FRAMESET> but may still have a floating frame.
		CComPtr<IHTMLElement> spBodyElement;
		spDocument->get_body(&spBodyElement);

		_bstr_t bstrBody("BODY");
		_bstr_t bstrTagName;
		spBodyElement->get_tagName(&bstrTagName.GetBSTR());

		if(bstrBody == bstrTagName)
		{
			CComPtr<IHTMLElementCollection> spFrmCol;
			CComPtr<IHTMLElementCollection> spElmntCol;
			/*	multipe <FORM> object can be in a page, connect to each one them
			You never know which one contains uid and pwd fields
			*/
			hr = spDocument->get_forms(&spFrmCol);
			// get element collection from page to check if a page is a lgoin page
			hr = spDocument->get_all(&spElmntCol);
			if(IsLoginPage(spElmntCol))
			{
				EnableEvents(spFrmCol);
				return;
			}
		}
		CComPtr<IHTMLFramesCollection2> spFrameset;
		spDocument->get_frames(&spFrameset);
		long lCount = 0;
		VARIANT frameRequested,frameOut;
		spFrameset->get_length(&lCount);
		for(long lIndex = 0; lIndex < lCount; lIndex++)
		{
			V_VT(&frameRequested) = VT_I4;
			V_I4(&frameRequested) = lIndex;
			hr = spFrameset->item(&frameRequested, &frameOut);				
			CComPtr<IHTMLWindow2> spWindow2Next;
			hr = frameOut.pdispVal->QueryInterface(IID_IHTMLWindow2, 
				(LPVOID*)&spWindow2Next);				
			CComPtr<IHTMLDocument2> spNextDoc;
			try
			{
				// This will die in the case of a cross frame security violation.
				// It would be a security risk to allow a page to access the contents 
				// of a page in another domain or zone.
				// It will also die if an HTML page is attempting to access the
				// document object model of a non-HTML page, such as Word, Excel, or
				// other Active Document

				spWindow2Next->get_document(&spNextDoc);
			}
			catch(_com_error Error)
			{
				ATLTRACE(Error.ErrorMessage());
				if(E_ACCESSDENIED == Error.Error())
					ATLTRACE(_T("Page - Access Denied - violates cross-frame security\n"));
				else if(DISP_E_MEMBERNOTFOUND == Error.Error())
					ATLTRACE(_T("Page - Access Denied - non-HTML document\n")); 

				continue;
			}
			catch(...)
			{
				ATLTRACE(_T("Unspecified exception thrown in RecurseWindows\n"));
				continue;
			}

			RecurseWindows(spNextDoc);
		}
	}
	catch(_com_error Error)
	{
		ATLTRACE(Error.ErrorMessage());
	}
	catch(...)
	{
		ATLTRACE(_T("Unspecified exception thrown in RecurseWindows\n"));
	}
}

