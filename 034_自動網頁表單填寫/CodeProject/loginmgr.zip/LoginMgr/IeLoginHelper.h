// IeLoginHelper.h : Declaration of the CIeLoginHelper

#pragma once
#include "resource.h"       // main symbols
#include <mshtmhst.h>
#include "ExDispID.h"
#include <exdisp.h>
#include "LoginMgr.h"
// CIeLoginHelper

class ATL_NO_VTABLE CIeLoginHelper : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CIeLoginHelper, &CLSID_IeLoginHelper>,
	public IObjectWithSiteImpl<CIeLoginHelper>,
	public IDispatchImpl<IIeLoginHelper, &IID_IIeLoginHelper, &LIBID_LoginMgrLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IOleCommandTarget
{
public:
	CIeLoginHelper(): m_dwBrowserCookie(0), m_pWBDisp(NULL), m_bPasswordCaptured(0)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_IELOGINHELPER)


BEGIN_COM_MAP(CIeLoginHelper)
	COM_INTERFACE_ENTRY(IIeLoginHelper)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IOleCommandTarget)	
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

	  // IODriveAdvPropHelper
public:

	//
	// IDispatch Methods
	//
	STDMETHOD(Invoke)(DISPID dispidMember,REFIID riid, LCID lcid, WORD wFlags,
		DISPPARAMS * pdispparams, VARIANT * pvarResult,
		EXCEPINFO * pexcepinfo, UINT * puArgErr);

	//
	// IOleObjectWithSite Methods
	//
	STDMETHOD(SetSite)(IUnknown *pUnkSite);
	
	//
	// IOleCommandTarget
	//
	STDMETHOD(QueryStatus)(
		/*[in]*/ const GUID *pguidCmdGroup, 
		/*[in]*/ ULONG cCmds,
		/*[in,out][size_is(cCmds)]*/ OLECMD *prgCmds,
		/*[in,out]*/ OLECMDTEXT *pCmdText)
	{
		return m_pDefaultOleCommandTarget->QueryStatus(pguidCmdGroup, cCmds, prgCmds, pCmdText);
	}

	STDMETHOD(Exec)(
		/*[in]*/ const GUID *pguidCmdGroup,
		/*[in]*/ DWORD nCmdID,
		/*[in]*/ DWORD nCmdExecOpt,
		/*[in]*/ VARIANTARG *pvaIn,
		/*[in,out]*/ VARIANTARG *pvaOut)
	{
		if (nCmdID == OLECMDID_SHOWSCRIPTERROR)
		{
			// Don't show the error dialog, but
			// continue running scripts on the page.
			(*pvaOut).vt = VT_BOOL;
			(*pvaOut).boolVal = VARIANT_TRUE;
			return S_OK;
		}
		return m_pDefaultOleCommandTarget->Exec(pguidCmdGroup, nCmdID, nCmdExecOpt, pvaIn, pvaOut);
	}


private:
	// Connection Tokens - used for Advise and Unadvise
	DWORD m_dwBrowserCookie;   

	// Smart pointer to browser
	CComQIPtr<IWebBrowser2, &IID_IWebBrowser2> m_pWebBrowser2;

	// Top-level web browser IDispatch*
	LPDISPATCH m_pWBDisp; 

	// Default interface pointers	
	CComQIPtr<IOleCommandTarget, &IID_IOleCommandTarget> m_pDefaultOleCommandTarget;
	BOOL m_bPasswordCaptured;
	BOOL m_bFoungLoginPage;

private:
	HRESULT SinkBrowserConnection(ConnectType eConnectType);
	void EnableEvents(CComPtr<IHTMLElementCollection> &spElemColl);
	void ConnectEvents(ConnectType eConnectType, CComPtr<IHTMLFormElement>& spElem);
	void GetUserId_Pwd(CComPtr<IHTMLElementCollection>& spElemColl, _bstr_t& bsUserId, _bstr_t& bsPassword);
	BOOL IsLoginPage(CComPtr<IHTMLElementCollection>&spElemColl);
	void EnumFrames(CComPtr<IHTMLDocument2>& spDocument);
	void RecurseWindows(CComPtr<IHTMLDocument2>& spDocument);

};

OBJECT_ENTRY_AUTO(__uuidof(IeLoginHelper), CIeLoginHelper)
