// ReCtrlExTTDlg.h : ͷ�ļ�
//

#pragma once

#include "SizingDialog.h"

#ifndef baseCReCtrlExTTDlg
#define baseCReCtrlExTTDlg CSizingDialog
#endif


// CReCtrlExTTDlg �Ի���
class CReCtrlExTTDlg : public baseCReCtrlExTTDlg
{
// ����
public:
	CReCtrlExTTDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_RECTRLEXTT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedCheck4();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

protected:
	void AddCtrls();
	void InitializeList();

private:
	BOOL m_bRate;
	CSizingDialog* m_pDialog2;

public:
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton1();
};
