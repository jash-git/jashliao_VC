//////////////////////////////////////////////////////////////////////////
// 
// CSizingDialog V2.1
// 
// Copyright 2005 Xia Xiongjun( ���۾� ), All Rights Reserved.
//
// E-mail: xj-14@163.com
//
// This source file can be copyed, modified, redistributed  by any means
// PROVIDING that this notice and the author's name and all copyright 
// notices remain intact, and PROVIDING it is NOT sold for profit without 
// the author's expressed written consent. The author accepts no 
// liability for any damage/loss of business that this product may cause.
//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// SizingDialog.cpp :  implementation file

#include "stdafx.h"
#include "SizingDialog.h"
#include ".\SizingDialog.h"

#define ID_TIMER				1


//////////////////////////////////////////////////////////////////////////
// CSizingDialog dialog

IMPLEMENT_SIZING_SUPPORT(CSizingDialog)

CSizingDialog::CSizingDialog(
	LPCTSTR lpszSection /*= NULL*/, LPCTSTR lpszEntry /*= NULL*/)
	: m_lpszSection(lpszSection)
	, m_lpszEntry(lpszEntry)
	, m_bEnableRWP(TRUE)
	, m_bErase(TRUE)
{
	CDialog::CDialog();
}

CSizingDialog::CSizingDialog(
	UINT nIDTemplate, CWnd* pParentWnd /*= NULL*/, 
	LPCTSTR lpszSection /*= _T("Placement")*/, 
	LPCTSTR lpszEntry /*= _T("MainDialog")*/)
	: CDialog(nIDTemplate, pParentWnd)
	, m_lpszSection(lpszSection)
	, m_lpszEntry(lpszEntry)
	, m_bEnableRWP(TRUE)
	, m_bErase(TRUE)
{
}

BEGIN_MESSAGE_MAP(CSizingDialog, CDialog)
	ON_WM_CREATE()
	ON_WM_SHOWWINDOW()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_NCHITTEST()
END_MESSAGE_MAP()

// CSizingDialog message handlers

int CSizingDialog::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	::SetWindowLong(m_hWnd, GWL_STYLE, 
		::GetWindowLong(m_hWnd, GWL_STYLE) | WS_THICKFRAME);

	Initialize(m_hWnd);

	return 0;
}

void CSizingDialog::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);

	if (m_bEnableRWP == FALSE)
		return;

	// The following code will be run only once
	m_bEnableRWP = FALSE;

	// Restore window placement
	if (m_lpszSection == NULL || m_lpszEntry == NULL)
		return;

	WINDOWPLACEMENT* pwp;
	UINT nBytes;
	if (::AfxGetApp()->GetProfileBinary(m_lpszSection, m_lpszEntry, 
		(LPBYTE *)&pwp, &nBytes))
	{
		if (pwp->showCmd == SW_SHOWMINIMIZED)
			pwp->showCmd = pwp->flags + 1;
		if (pwp->showCmd == SW_SHOWMAXIMIZED)
			m_bErase = FALSE;
		SetWindowPlacement(pwp);

		MYDELETEARRAY(pwp);
	}
}

void CSizingDialog::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	m_objSizingSP.ResizeControls();
	if (IsWindowVisible())
		::SetTimer(m_hWnd, ID_TIMER, 10, NULL);
}

void CSizingDialog::OnTimer(UINT nIDEvent)
{
	::KillTimer(m_hWnd, ID_TIMER);
	m_objSizingSP.UpdateGBoxFPic();

	CDialog::OnTimer(nIDEvent);
}

void CSizingDialog::OnPaint() 
{
	CDialog::OnPaint();
}

BOOL CSizingDialog::OnEraseBkgnd(CDC* pDC)
{
	//return CDialog::OnEraseBkgnd(pDC);

	if (m_bErase != TRUE)
	{
		m_bErase = TRUE;
		return FALSE;
	}

	m_objSizingSP.EraseBkgnd(pDC->m_hDC);
	return TRUE;
}

void CSizingDialog::OnDestroy()
{
	CDialog::OnDestroy();

	// Save window placement
	if (m_lpszSection == NULL || m_lpszEntry == NULL)
		return;

	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);
	::AfxGetApp()->WriteProfileBinary(m_lpszSection, m_lpszEntry, 
		(LPBYTE)&wp, sizeof(wp));
}

UINT CSizingDialog::OnNcHitTest(CPoint point)
{
	// move the window when clicked
	UINT nHitTest = CDialog::OnNcHitTest(point);
	if(nHitTest == HTCLIENT)
		nHitTest = HTCAPTION;
	return nHitTest;
}

