// ReCtrlVC6Demo.h : main header file for the RECTRLVC6DEMO application
//

#if !defined(AFX_RECTRLVC6DEMO_H__66C45A66_B1AC_4064_8ECD_D3D21EBC5E92__INCLUDED_)
#define AFX_RECTRLVC6DEMO_H__66C45A66_B1AC_4064_8ECD_D3D21EBC5E92__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CReCtrlVC6DemoApp:
// See ReCtrlVC6Demo.cpp for the implementation of this class
//

class CReCtrlVC6DemoApp : public CWinApp
{
public:
	CReCtrlVC6DemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReCtrlVC6DemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CReCtrlVC6DemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RECTRLVC6DEMO_H__66C45A66_B1AC_4064_8ECD_D3D21EBC5E92__INCLUDED_)
