pid-control  
Edit by Alvin Yeats  <alvinyeats@gmail.com>  
This project is licensed under a FreeBSD License  

This is my first open source project.  
In this project,you will learn more pid-control methods.  

- 供您参考：[PID基本概念](basic_concept.md)
- 该项目主要是针对刘金琨老师的《先进pid控制及其MATLAB仿真》所做的源码翻译工作
- 因本人能力有限，目前只进行C语言版本的翻译工作。
- 陆续将推出c++版本和python版本,敬请期待！

另：对该项目感兴趣的朋友可通过邮箱联系我，一起进行源码翻译工作，合作愉快！