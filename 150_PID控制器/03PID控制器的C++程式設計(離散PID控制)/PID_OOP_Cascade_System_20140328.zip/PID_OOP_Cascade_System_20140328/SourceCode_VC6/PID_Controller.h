// PID_Controller.h: interface for the PID_Controller class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PID_CONTROLLER_H__F6771D9A_4FD3_425D_90A6_F0138CBE8406__INCLUDED_)
#define AFX_PID_CONTROLLER_H__F6771D9A_4FD3_425D_90A6_F0138CBE8406__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class PID_Controller  
{
public:
	void Initialization();
	void Calculate();
	double *pointer_sp;	//input
	double *pointer_pv;	//input
	double cv;	//output
	double kp,kd,ki;
	double err,err2,err_sum;

	PID_Controller();
	virtual ~PID_Controller();

};

#endif // !defined(AFX_PID_CONTROLLER_H__F6771D9A_4FD3_425D_90A6_F0138CBE8406__INCLUDED_)
