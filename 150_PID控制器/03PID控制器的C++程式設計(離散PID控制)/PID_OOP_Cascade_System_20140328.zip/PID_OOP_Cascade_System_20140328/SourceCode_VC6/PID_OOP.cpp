// -------------------------------------------
// PID_OOP.cpp : PID control program MAIN.
// Designed by Students and Teacher
// in the class of Intelligent Instrument Design
// Date: 2014-03-28
// MagtomoLab: http://emt.bjtu.edu.cn
// BJTU: http://www.bjtu.edu.cn
// -------------------------------------------
#include "stdafx.h"
#include "PID_Controller.h"
#include "RC_Object.h"
int main(int argc, char* argv[])
{
    FILE *fp;
    double sp=2.5;
    PID_Controller con1,con2;
    RC_Object obj1,obj2;
    // Initialize
    con1.Initialization();
    obj1.Initialization();
    con2.Initialization();
    obj2.Initialization();
    // Customized Setting
    con1.kp=2.0;
    con1.ki=1;
    con2.ki=1.2;
    // Connection
    con2.pointer_sp=&sp;
    con1.pointer_sp=&con2.cv;
    obj1.pointer_cv=&con1.cv;
    obj2.pointer_cv=&obj1.pv;
    con2.pointer_pv=&obj2.pv;
    con1.pointer_pv=&obj1.pv;
    // Run
    fp=fopen("Record.csv","wt");
    fprintf(fp, "pv\n");
    for (int k=0;k<100;k++)
    {   //Print result
        fprintf(fp, "%f\n", obj2.pv);
        con2.Calculate();
        con1.Calculate();
        obj1.Calculate();
        obj2.Calculate();
    }
    fclose(fp);
    printf("Finished!\n");
    return 0;
}