// RC_Object.h: interface for the RC_Object class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RC_OBJECT_H__F67247B6_2961_4D2F_95AC_A96F0593C41A__INCLUDED_)
#define AFX_RC_OBJECT_H__F67247B6_2961_4D2F_95AC_A96F0593C41A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class RC_Object  
{
public:
	void Initialization();
	double pv_history;
	double alpha;
	void Calculate();
	double *pointer_cv;
	double pv;

	RC_Object();
	virtual ~RC_Object();

};

#endif // !defined(AFX_RC_OBJECT_H__F67247B6_2961_4D2F_95AC_A96F0593C41A__INCLUDED_)
