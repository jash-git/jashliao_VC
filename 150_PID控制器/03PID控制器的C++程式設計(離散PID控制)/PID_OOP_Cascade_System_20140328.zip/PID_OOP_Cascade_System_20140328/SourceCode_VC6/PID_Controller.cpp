// PID_Controller.cpp: implementation of the PID_Controller class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PID_Controller.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

PID_Controller::PID_Controller()
{

}

PID_Controller::~PID_Controller()
{

}

void PID_Controller::Calculate()
{	// PID Calculation
	err=(*pointer_sp)-*pointer_pv;
	err_sum+=err;
	cv=kp*err + ki*(err_sum)  + kd* (err2-err);
	err2=err;
}

void PID_Controller::Initialization()
{	
	kp=1;
	ki=0;
	kd=0;
	err=0;
	err2=0;
	err_sum=0;
}
