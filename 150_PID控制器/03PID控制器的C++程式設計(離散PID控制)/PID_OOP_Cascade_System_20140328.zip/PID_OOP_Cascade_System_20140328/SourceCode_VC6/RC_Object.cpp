// RC_Object.cpp: implementation of the RC_Object class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RC_Object.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

RC_Object::RC_Object()
{

}

RC_Object::~RC_Object()
{

}

void RC_Object::Calculate()
{
	pv=*pointer_cv*alpha  + pv_history*(1-alpha);
	pv_history=pv;
}

void RC_Object::Initialization()
{
	alpha=0.2;
	pv=0;
	pv_history=0;

}
