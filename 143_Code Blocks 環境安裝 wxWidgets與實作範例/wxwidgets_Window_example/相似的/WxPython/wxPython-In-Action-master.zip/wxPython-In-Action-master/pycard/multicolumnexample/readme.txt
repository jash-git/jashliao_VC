This is a test of the MultiColumnList component by William Volkman.
His version of the MultiColumnList component was added to 
PythonCard in release 0.7.2 (September 2003).

I made some slight mods to his resource file before checking it in, 
the original post is at:

  http://aspn.activestate.com/ASPN/Mail/Message/1546982
