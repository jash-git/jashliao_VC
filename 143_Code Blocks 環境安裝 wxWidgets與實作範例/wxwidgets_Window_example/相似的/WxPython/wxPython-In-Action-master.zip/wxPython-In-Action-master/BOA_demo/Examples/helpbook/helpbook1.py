# The simplest way to view a helpbook
from wxPython.tools import helpviewer
helpviewer.main(['', 'helpbook1.hhp'])
