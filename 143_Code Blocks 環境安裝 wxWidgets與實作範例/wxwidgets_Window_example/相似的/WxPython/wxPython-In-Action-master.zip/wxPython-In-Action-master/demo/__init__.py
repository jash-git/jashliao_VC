#!/usr/bin/env python

"""demo of wxPython functions"""