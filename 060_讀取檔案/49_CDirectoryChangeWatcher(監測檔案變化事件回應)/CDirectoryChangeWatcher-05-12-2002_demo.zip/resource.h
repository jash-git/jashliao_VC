//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DirWatcher.rc
//
#define IDD_DIRWATCHER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_DLG_TEST_PATTERNS           129
#define IDD_SET_FILTER_FLAGS_DLG        130
#define IDC_EDIT_DIR_TO_MONITOR         1000
#define IDC_BTN_MONITOR                 1001
#define IDC_LIST_CHANGES                1002
#define IDC_EDIT_DIR_TO_MONITOR2        1003
#define IDC_LIST_CHANGES2               1004
#define IDC_BTN_MONITOR2                1005
#define IDC_CHECK_FILE_NAME1            1006
#define IDC_CHECK_SUBDIR1               1007
#define IDC_CHECK_SUBDIR2               1008
#define IDC_CHECK_DIR_NAME1             1009
#define IDC_CHECK_SIZE1                 1010
#define IDC_CHECK_ATTRIBUTES1           1011
#define IDC_CHECK_LAST_WRITE1           1012
#define IDC_CHECK_LAST_ACCESS1          1013
#define IDC_CHECK_CREATION1             1014
#define IDC_CHECK_SECURITY1             1015
#define IDC_CHECK_FILE_NAME2            1016
#define IDC_CHECK_DIR_NAME2             1017
#define IDC_CHECK_SIZE2                 1018
#define IDC_CHECK_ATTRIBUTES2           1019
#define IDC_CHECK_LAST_WRITE2           1020
#define IDC_CHECK_LAST_ACCESS2          1021
#define IDC_CHECK_CREATION2             1022
#define IDC_CHECK_SECURITY2             1023
#define IDC_BTN_CLEAR1                  1024
#define IDC_BTN_CLEAR2                  1025
#define IDC_BTN_BROWSE1                 1027
#define IDC_BTN_BROWSE2                 1028
#define IDC_EDIT_INCLUDE_FILTER1        1029
#define IDC_EDIT_EXCLUDE_FILTER1        1030
#define IDC_EDIT_INCLUDE_FILTER2        1031
#define IDC_EDIT_EXCLUDE_FILTER2        1032
#define IDC_RADIO_DONT_USE_FILTERS      1033
#define IDC_RADIO_CHECK_FILENAME_ONLY   1034
#define IDC_RADIO_CHECK_FULL_PATH       1035
#define IDC_RADIO_CHECK_PARTIAL_PATH    1036
#define IDC_RADIO_DONT_TEST_HANDLER     1037
#define IDC_RADIO_TEST_HANDLER_AFTER    1038
#define IDC_RADIO_TEST_HANDLER_BEFORE   1039
#define IDC_EDIT_TEST_PATH              1040
#define IDC_EDIT_TEST_PATTERN           1041
#define IDC_BTN_TEST                    1042
#define IDC_STATIC_TEST_RESULTS         1043
#define IDC_BTN_TEST_PATTERNS           1044
#define IDC_CHECK_WATCHSTARTED          1045
#define IDC_CHECK_WATCHSTOPPED          1046
#define IDC_BTN_SET_FILTER_FLAGS        1047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
