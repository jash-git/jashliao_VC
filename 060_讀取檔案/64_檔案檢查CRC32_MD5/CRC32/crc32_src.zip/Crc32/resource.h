//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Crc32.rc
//
#define IDD_CRC32_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_FILENAME               1000
#define IDC_BROWSE                      1001
#define IDC_COMBO_CRC32_METHOD          1002
#define IDC_CRC32                       1003
#define IDC_EDIT_CRC32                  1004
#define IDC_EDIT_TIME                   1005
#define IDC_CLEAR                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
