// MD5Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "MD5.h"
#include "MD5Dlg.h"
#include <iostream>
#include <windows.h>
#include <wincrypt.h>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include "shlobj.h"
#include <direct.h>
#include <strsafe.h>


//CMD5ProgressDlg pDlg;
INT_PTR npDlgRet = -1;


HCRYPTPROV hCryptProv;
CMD5Dlg *m_dlg;

using namespace std;

typedef struct {
    unsigned char digest[16];
    unsigned long hHash;
} MD5Context;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
public:
	afx_msg void OnBnClickedButton1();
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CAboutDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON1, &CAboutDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CMD5Dlg dialog




CMD5Dlg::CMD5Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMD5Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	hThread = NULL;
	m_nFlag = 0;
}

void CMD5Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDITFILENAME, m_CFileNameBox);
	DDX_Control(pDX, IDC_EDITMD5VALUE, m_CMD5ValueBox);
	DDX_Control(pDX, IDC_EDITFILENAME2, m_CMD5File);
	DDX_Control(pDX, IDC_EDITMD5VALUE2, m_CGivenFileBox);
	DDX_Control(pDX, IDC_EDITMD5VALUE3, m_CcalMD5box);
	DDX_Control(pDX, IDC_EDITMD5VALUE4, m_CGivenMD5box);
	DDX_Control(pDX, IDC_EDITFILENAME3, m_CFolderBox);
	DDX_Control(pDX, IDC_SUBFOLDERCHECK, m_CSubFolderCheck);
	//DDX_Control(pDX, IDC_EDITFILENAME6, m_CLogBox);
	DDX_Control(pDX, IDC_CREATEMD5BUTTON, m_CcreateMulMD5);
	DDX_Control(pDX, IDC_VERIFYMULTIPLEMD5BUTTON, m_CmulVerifyButton);
	DDX_Control(pDX, IDC_BROWSERBUTTON, m_CFolderBrowseButton);
	//DDX_Control(pDX, IDC_LOGBROWSERBUTTON, m_CLogBrowseButton);
	DDX_Control(pDX, IDC_LOGOPENCHECK, m_CLogOpenCheck);
	DDX_Control(pDX, IDC_BUTTON3, m_CCalSingMD5Browse);
	DDX_Control(pDX, IDC_BUTTON2, m_CShowMD5Button);
	DDX_Control(pDX, IDC_CREATESINGMD5, m_CCreateSingMD5);
	//DDX_Control(pDX, IDCANCEL, m_CCreateRadio);
	DDX_Control(pDX, IDC_BUTTON5, m_CVeriSingMD5Browse);
	DDX_Control(pDX, IDC_VERIFYMD5BUTTON, m_CVeriSingMD5Button);
	DDX_Control(pDX, IDC_READMEBUTTON, m_CReadMe);
	DDX_Control(pDX, IDCANCEL, m_CExitButton);
	DDX_Control(pDX, IDC_MD5PROGRESSBAR, m_CMD5ProgessBar);
	DDX_Control(pDX, IDC_PARSEMD5BUTTON, m_CParseMD5Button);
	DDX_Control(pDX, IDC_EDITSTATUS, m_CEditStatus);
}

BEGIN_MESSAGE_MAP(CMD5Dlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
//	ON_BN_CLICKED(IDC_BUTTON1, &CMD5Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CMD5Dlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CMD5Dlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON5, &CMD5Dlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_VERIFYMD5BUTTON, &CMD5Dlg::OnBnClickedVerifymd5button)
	ON_BN_CLICKED(IDC_CREATEMD5BUTTON, &CMD5Dlg::OnBnClickedCreatemd5button)
	ON_BN_CLICKED(IDC_BROWSERBUTTON, &CMD5Dlg::OnBnClickedBrowserbutton)
	ON_BN_CLICKED(IDC_CREATESINGMD5, &CMD5Dlg::OnBnClickedCreatesingmd5)
	//ON_BN_CLICKED(IDC_LOGBROWSERBUTTON, &CMD5Dlg::OnBnClickedLogbrowserbutton)
	ON_BN_CLICKED(IDC_CREATEMD5RADIO, &CMD5Dlg::OnBnClickedCreatemd5radio)
	ON_BN_CLICKED(IDC_VERIFYMD5RADIO, &CMD5Dlg::OnBnClickedVerifymd5radio)
	ON_BN_CLICKED(IDC_VERIFYMULTIPLEMD5BUTTON, &CMD5Dlg::OnBnClickedVerifymultiplemd5button)
//	ON_BN_CLICKED(IDC_ADVANCEDBUTTON, &CMD5Dlg::OnBnClickedAdvancedbutton)
	ON_BN_CLICKED(IDC_READMEBUTTON, &CMD5Dlg::OnBnClickedReadmebutton)
//	ON_WM_TIMER()
	ON_BN_CLICKED(IDCANCEL, &CMD5Dlg::OnBnClickedCancel)
	ON_EN_CHANGE(IDC_EDITFILENAME2, &CMD5Dlg::OnEnChangeEditfilename2)
	ON_EN_CHANGE(IDC_EDITFILENAME, &CMD5Dlg::OnEnChangeEditfilename)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDOK, &CMD5Dlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_PARSEMD5RADIO, &CMD5Dlg::OnBnClickedParsemd5radio)
	ON_BN_CLICKED(IDC_PARSEMD5BUTTON, &CMD5Dlg::OnBnClickedParsemd5button)
END_MESSAGE_MAP()


// CMD5Dlg message handlers

BOOL CMD5Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_CLogOpenCheck.SetCheck(BST_CHECKED);
	m_dlg = this;
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMD5Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMD5Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMD5Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void DebugLog(char * szLogString)
{
	FILE *stream = NULL ;
	char *FileName = new char[1024];
	size_t *pReturnValue = new size_t[256];
	/* Open file in text mode: */
	getenv_s(pReturnValue, FileName, 1024, "temp");
	strcat(FileName, "\\MD5.txt");

	SYSTEMTIME  time;
	::GetSystemTime(&time);
	char str[100];
	sprintf(str,"%d/%d/%d %d:%d:%d",time.wMonth,time.wDay,time.wYear,time.wHour,time.wMinute,time.wSecond);

	if( (stream = fopen(FileName, "a")) != NULL )
	{
		fprintf(stream ,"[%s] %s\n",str,szLogString);
		fflush(stream);
	}
	if(stream)
		fclose( stream );
	delete FileName;
	delete pReturnValue;
	//delete szLogString;
	return ;
}
using std::endl;
void WriteLog(LPCTSTR LogPath, LPCTSTR GivenFile, LPCTSTR Value)
{
	ofstream outdata;
	outdata.open(LogPath, ios_base::app);
	CString FileData =  GivenFile + CString(Value);

	const size_t StringSize = FileData.GetLength() + 1;
	size_t CharactersConverted = 0;
	char *szLogString = new char[StringSize];
	wcstombs_s(&CharactersConverted, szLogString, FileData.GetLength()+1, FileData, _TRUNCATE);

	outdata << szLogString << endl;
	outdata.close();
	delete szLogString;
}

BOOL CryptStartup()
{
    if(CryptAcquireContext(&hCryptProv, NULL, MS_ENHANCED_PROV, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT) == 0){
        if(GetLastError() == NTE_EXISTS){
            if(CryptAcquireContext(&hCryptProv, NULL, MS_ENHANCED_PROV, PROV_RSA_FULL, 0) == 0)
                return FALSE;
        }else return FALSE;
    }
    return TRUE;
}

void CryptCleanup()
{
    if(hCryptProv) CryptReleaseContext(hCryptProv, 0);
    hCryptProv = 0;
}

void MD5Init(MD5Context *ctx)
{
    CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &ctx->hHash);
}


void MD5Update(MD5Context *ctx, unsigned char const *buf, unsigned int len)
{
    CryptHashData(ctx->hHash, buf, len, 0);
}

void MD5Final(MD5Context *ctx)
{
    DWORD dwCount = 16;
    CryptGetHashParam(ctx->hHash, HP_HASHVAL, ctx->digest, &dwCount, 0);
    if(ctx->hHash) CryptDestroyHash(ctx->hHash);
    ctx->hHash = 0;
}
int CalculateMD5(CString FileName, CString &MD5)
{
	const size_t StringSize = FileName.GetLength() + 1;
	size_t CharactersConverted = 0;

	char *file = new char[StringSize];
	//char file[1024];
	wcstombs_s(&CharactersConverted, file, FileName.GetLength()+1, FileName, _TRUNCATE);


	int i, j;
    FILE *fInput;
    MD5Context md5Hash;
    unsigned char bBuffer[4096];
    unsigned char b;
    char c;
	
	
    
    if(!CryptStartup())
	{
        MessageBoxW(0, L"Could not start crypto library", L"MD5", MB_ICONERROR);
        return 0;
    }
    
    fInput = fopen(file, "rb");
    if(!fInput)
	{
       MessageBoxW(0, L"Failed to open - Invaild File", L"MD5", MB_ICONERROR);
        CryptCleanup();
        return 0;
    }
    
    memset(&md5Hash, 0, sizeof(MD5Context));
    MD5Init(&md5Hash);
    while(!feof(fInput)){
        unsigned int nCount = fread(bBuffer, sizeof(unsigned char), 4096, fInput);
        MD5Update(&md5Hash, bBuffer, nCount);
    }
    MD5Final(&md5Hash);
    
    fclose(fInput);
    //printf("\nChecksum of '%s' is: ", argv[1]);
	char *Value = new char[1024];int k = 0;
    for(i = 0; i < 16; i++)
	{
        b = md5Hash.digest[i];
        for(j = 4; j >= 0; j -= 4)
		{
            c = ((char)(b >> j) & 0x0F);
            if(c < 10) c += '0';
            else c = ('a' + (c - 10));
            //printf("%c", c);
			Value[k] = c;
			k++;
        }
    }
	Value[k] = '\0';
    CryptCleanup();
	
	//CString cString;
	MD5 = CString(Value);
	//MessageBox(cString);
	
	
	delete file;
	delete Value;
	return 1;

}
void CMD5Dlg::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	//DeActivateControls();
	
	m_CFileNameBox.GetWindowTextW(FileNameToThread);
	FileNameToThread.Trim();
	if(FileNameToThread.CompareNoCase(L"") == 0)
		return;

	DWORD dwThreadId;
	m_nFlag = 1;
	hThread = CreateThread( 
            NULL,              // default security attributes
            0,                 // use default stack size  
            MD5ThreadProc,        // thread function 
			NULL,             // argument to thread function 
            0,                 // use default creation flags 
            &dwThreadId);   // returns the thread identifier 

	//ShowWindow(0);
	
	
	/*pDlg.EndDialog(npDlgRet);
	ShowWindow(SW_SHOW);
	CloseHandle(hThread);*/
		
}

void CMD5Dlg::OnBnClickedButton3()
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, L"exe and iso (*.exe)(*.iso)|*.exe;*.iso|All Files (*.*)|*.*||", this);
	if(dlg.DoModal()== IDOK)
	{
		CString FilePath = dlg.GetPathName();
		m_CFileNameBox.SetWindowTextW(FilePath);
		m_CMD5ValueBox.SetWindowTextW(L"");
	}
}

void CMD5Dlg::OnBnClickedButton5()
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, L"MD5 Files (*.md5)|*.md5||", this);
	if(dlg.DoModal()== IDOK)
	{
		m_CcalMD5box.SetWindowTextW(L"");
		m_CGivenFileBox.SetWindowTextW(L"");
		m_CGivenMD5box.SetWindowTextW(L"");
		m_CEditStatus.SetWindowTextW(L"");

		CString FilePath = dlg.GetPathName();
		m_CMD5File.SetWindowTextW(FilePath);
		

		const size_t StringSize = FilePath.GetLength() + 1;
		size_t CharactersConverted = 0;

		char *file = new char[StringSize];
		//char file[1024];
		wcstombs_s(&CharactersConverted, file, FilePath.GetLength()+1, FilePath, _TRUNCATE);

		ifstream read(file, ios::binary);
		read.seekg(0,ios::end);
		int l = read.tellg();
		read.seekg(0,ios::beg);
		char *buf = new char[l + 1];
		read.read(buf,l);
		buf[l] = '\0';
		//strcat(buf, "\0");
		CString FileName;
		FileName = CString(buf);
		delete file;
		delete buf;

		int index = FileName.Find(' ', 0);
		if(index != -1)
		{
			CString GivenMD5 = FileName.Left(index);
			m_CGivenMD5box.SetWindowTextW(GivenMD5);

			index = FileName.Find('*', 0);
			if(index == -1)
			{
				index = FileName.Find(' ');
			}
			CString GivenFile = FileName.Right(FileName.GetLength() - (index + 1));
			GivenFile.Trim();
			
			if(GivenFile.Find('\\', 0) == -1 && GivenFile.Find('/', 0) == -1)
			{
				index = FilePath.ReverseFind('\\');
				GivenFile = FilePath.Left(index + 1) + GivenFile;
			}
			GivenFile.Trim();
			m_CGivenFileBox.Clear();
			m_CGivenFileBox.SetWindowTextW(GivenFile);
		}
		else
			MessageBoxW(L"Invalid MD5 File", 0, MB_ICONERROR);
				
	}
}

void CMD5Dlg::OnBnClickedVerifymd5button()
{
	// TODO: Add your control notification handler code here
	CString GivenFile;
	m_CGivenFileBox.GetWindowTextW(GivenFile);
	GivenFile.Trim();

	FileNameToThread = GivenFile;
	DWORD dwThreadId;
	m_nFlag = 5;
	hThread = CreateThread( 
			NULL,              // default security attributes
			0,                 // use default stack size  
			MD5ThreadProc,        // thread function 
			NULL,             // argument to thread function 
			0,                 // use default creation flags 
			&dwThreadId);   // returns the thread identifier 

}
int CreateMD5Files(CString path, CString title, CString Ext, CString LogPath = L"NULL")
{
	CString MD5, FileName;
	CFile fp;

	
	if(CalculateMD5(path, MD5) != 0)
	{
		
		if(Ext.CompareNoCase(L".iso") == 0)
		{
			FileName = path + L".md5";
			MD5 = MD5 + L" *" + title + L".iso";
		}
		else if(Ext.CompareNoCase(L".exe") == 0)
		{
			FileName = path;
			FileName.Replace(L".exe", L".md5");
			MD5 = MD5 + L" *" + title + L".exe";
		}
		MD5.Trim();
		
		const size_t StringSize = MD5.GetLength() + 1;
		size_t CharactersConverted = 0;

		char *file = new char[StringSize];
		//char file[1024];
		wcstombs_s(&CharactersConverted, file, MD5.GetLength()+1, MD5, _TRUNCATE);

		fp.Open(FileName, CFile::modeCreate | CFile::modeWrite);
		fp.Write(file, MD5.GetLength());
		fp.Close();

		delete file;
		if(LogPath.CompareNoCase(L"NULL") != 0)
			WriteLog(LogPath, FileName, CString(" - Successfully created"));
		return 1;
		//MessageBox(MD5);
	}
	if(LogPath.CompareNoCase(L"NULL") != 0)
		WriteLog(LogPath, path, CString(" - MD5 file failed to create"));
	return 0;
}
int CreateSubfoldersMD5(CString myDirectory, CString LogPath)
{
	CString FileList[2000];
	CString FolderPath, Ext;
	
	
	//CString myDirectory = L"C:\\Program Files";
	CFileFind finder, exeFinder;

	int count = -1;
	
	Ext = L".iso";
	for(int i = 0; i < 2; i++) //For finding the files in the root folder
	{
		BOOL exeFinding = exeFinder.FindFile (myDirectory + L"\\*" + Ext);
		while (exeFinding)
		{
			exeFinding = exeFinder.FindNextFile();
			CString path = exeFinder.GetFilePath();
			CString title = exeFinder.GetFileTitle();
			//MessageBox(0, path, title, 0);
			CreateMD5Files(path, title, Ext, LogPath);
		}
		Ext = L".exe";
	}
			
	do
	{
		BOOL finding = finder.FindFile (myDirectory + CString ("\\*.*"));
		while (finding)
		{
			finding = finder.FindNextFile();
			CString path = finder.GetFilePath();
			CString title = finder.GetFileTitle();
			int ret = _chdir(CT2A(path));
			if (ret == 0)
			{
				if(path != (myDirectory + L"\\.") && path != (myDirectory + L"\\.."))
				{
					//MessageBoxW(0, myDirectory, L"Folder is", 0);
					Ext = L".iso";
					for(int i = 0; i < 2; i++)
					{
						BOOL exeFinding = exeFinder.FindFile (path + L"\\*" + Ext);
						while (exeFinding)
						{
							exeFinding = exeFinder.FindNextFile();
							CString path = exeFinder.GetFilePath();
							CString title = exeFinder.GetFileTitle();
							
							CreateMD5Files(path, title, Ext, LogPath);
							//MessageBox(0, path, title, 0);
						}
						Ext = L".exe";
					}
					++count;
					FileList[count] = path;
				}
			}
			
		}
		if(count >= 0)
		{
			myDirectory = FileList[count];
		}
		--count;

	}while(count >= -1);
	exeFinder.Close();
	finder.Close ();
	return 1;
}


void CMD5Dlg::OnBnClickedCreatemd5button()
{
	// TODO: Add your control notification handler code here
	try
	{
		CString FolderPath;

		m_CFolderBox.GetWindowTextW(FolderPath);
		FolderPath.Trim();
		if(FolderPath.CompareNoCase(L"") == 0)
			return;

		FileNameToThread = FolderPath;
		DWORD dwThreadId;
		m_nFlag = 3;
		hThread = CreateThread( 
				NULL,              // default security attributes
				0,                 // use default stack size  
				MD5ThreadProc,        // thread function 
				NULL,             // argument to thread function 
				0,                 // use default creation flags 
				&dwThreadId);   // returns the thread identifier 

		//ShowWindow(0);

		

		
	}
	catch(...)
	{
		/*pDlg.EndDialog(npDlgRet);
		ShowWindow(SW_SHOW);
		CloseHandle(hThread);*/
		MessageBoxW(L"You may not have write permission in this location", 0, MB_ICONERROR);
	}
}

int BrowseFolder(CString &folderpath)
{

	BROWSEINFO bi; int Flag = 0;
	memset(&bi, 0, sizeof(bi));

    bi.ulFlags   = BIF_NEWDIALOGSTYLE|BIF_NONEWFOLDERBUTTON;
    bi.hwndOwner = NULL;
    bi.lpszTitle = L"Select a folder";
    //bi.pszDisplayName = L"Shaheer";

    ::OleInitialize(NULL);

	LPITEMIDLIST pIDL = ::SHBrowseForFolder(&bi);

    if(pIDL != NULL)
    {
		// Create a buffer to store the path, then 
       // get the path.
       LPWSTR buffer = new WCHAR[1024];
       if(::SHGetPathFromIDList(pIDL, buffer) != 0)
       {
          // Set the string value.
		   folderpath = CString(buffer);
		   Flag = 1;	
		}
	    delete buffer;	
        // free the item id list
        CoTaskMemFree(pIDL);
    }

    ::OleUninitialize();
	return Flag;
}
void CMD5Dlg::OnBnClickedBrowserbutton()
{
	// TODO: Add your control notification handler code here
	CString folderpath;
	if(BrowseFolder(folderpath) != 0)
	{
		m_CFolderBox.SetWindowTextW(folderpath);
	}

}

void CMD5Dlg::OnBnClickedCreatesingmd5()
{
	// TODO: Add your control notification handler code here
	try
	{
		
		m_CFileNameBox.GetWindowTextW(FileNameToThread);
		FileNameToThread.Trim();
		if(FileNameToThread.CompareNoCase(L"") == 0)
			return;

		DWORD dwThreadId;
		m_nFlag = 2;
		hThread = CreateThread( 
	            NULL,              // default security attributes
	            0,                 // use default stack size  
	            MD5ThreadProc,        // thread function 
	            NULL,             // argument to thread function 
	            0,                 // use default creation flags 
	            &dwThreadId);   // returns the thread identifier 

	
		//if(hThread != NULL)
		//{
		//	CloseHandle(hThread);
		//	hThread = NULL;
		//}
	}
	catch(...)
	{
		/*pDlg.EndDialog(npDlgRet);
		ShowWindow(SW_SHOW);
		CloseHandle(hThread);*/
		MessageBoxW(L"You may not have write permission in this location", 0, MB_ICONERROR);
	}
		

	
}

void CMD5Dlg::OnBnClickedCreatemd5radio()
{
	// TODO: Add your control notification handler code here
	m_CcreateMulMD5.ShowWindow(SW_SHOW);
	m_CmulVerifyButton.ShowWindow(0);
	m_CParseMD5Button.ShowWindow(0);
}

void CMD5Dlg::OnBnClickedVerifymd5radio()
{
	// TODO: Add your control notification handler code here
	m_CcreateMulMD5.ShowWindow(0);
	m_CParseMD5Button.ShowWindow(0);
	m_CmulVerifyButton.ShowWindow(SW_SHOW);
}
void CMD5Dlg::OnBnClickedParsemd5radio()
{
	// TODO: Add your control notification handler code here
	m_CmulVerifyButton.ShowWindow(0);
	m_CcreateMulMD5.ShowWindow(0);
	m_CParseMD5Button.ShowWindow(SW_SHOW);
}
void ParseMD5Files(CString FilePath, CString LogPath)
{
	const size_t StringSize = FilePath.GetLength() + 1;
	size_t CharactersConverted = 0;

	char *file = new char[StringSize];
	//char file[1024];
	wcstombs_s(&CharactersConverted, file, FilePath.GetLength()+1, FilePath, _TRUNCATE);

	ifstream read(file, ios::binary);
	read.seekg(0,ios::end);
	int l = read.tellg();
	read.seekg(0,ios::beg);
	char *buf = new char[l + 1];
	read.read(buf,l);
	buf[l] = '\0';
	//strcat(buf, "\0");
	CString FileName;
	FileName = CString(buf);
	delete file;
	delete buf;

	int index = FileName.Find(' ', 0);
	if(index != -1)
	{
		CString GivenMD5 = FileName.Left(index);
		//m_CGivenMD5box.SetWindowTextW(GivenMD5);

		index = FileName.Find('*', 0);
		if(index == -1)
		{
			index = FileName.Find(' ');
		}
		CString GivenFile = FileName.Right(FileName.GetLength() - (index + 1)), ExeName;
		GivenFile.Trim();ExeName = GivenFile;
		
		if(GivenFile.Find('\\', 0) == -1 && GivenFile.Find('/', 0))
		{
			index = FilePath.ReverseFind('\\');
			GivenFile = FilePath.Left(index + 1) + GivenFile;
		}
		GivenFile.Trim();
		CString MD5, LogFile;
		
		WriteLog(LogPath, GivenFile + L"," + ExeName + L",", GivenMD5);
		/*if(CalculateMD5(GivenFile, MD5) != 0)
		{
			//m_CcalMD5box.SetWindowTextW(MD5);
			if(MD5 == GivenMD5)
				//MessageBox(0, MD5, L"Equal", 0);
				WriteLog(LogPath, GivenFile, " - is OK");
			else
				//MessageBox(0, MD5, L"Not Equal", 0);
				WriteLog(LogPath, GivenFile, " - is Wrong");
		}*/
	}
	else
		//MessageBox(0, FilePath, L"Invalid", 0);
		WriteLog(LogPath, FilePath, CString(" - is Invalid MD5 file"));
}

int ParseSubfoldersMD5(CString myDirectory, CString LogPath)
{
	CString FileList[2000];
	CString FolderPath, Ext;
	
	
	//CString myDirectory = L"C:\\Program Files";
	CFileFind finder, exeFinder;

	int count = -1;
	
	
	
	BOOL exeFinding = exeFinder.FindFile (myDirectory + L"\\*.md5");
	while (exeFinding)
	{
		exeFinding = exeFinder.FindNextFile();
		CString path = exeFinder.GetFilePath();
		//MessageBox(0, path, title, 0);
		ParseMD5Files(path, LogPath);
	}			
	do
	{
		BOOL finding = finder.FindFile (myDirectory + CString ("\\*.*"));
		while (finding)
		{
			finding = finder.FindNextFile();
			CString path = finder.GetFilePath();
			CString title = finder.GetFileTitle();
			int ret = _chdir(CT2A(path));
			if (ret == 0)
			{
				if(path != (myDirectory + L"\\.") && path != (myDirectory + L"\\.."))
				{
					//MessageBoxW(0, myDirectory, L"Folder is", 0);
					
					BOOL exeFinding = exeFinder.FindFile (path + L"\\*.md5");
					while (exeFinding)
					{
						exeFinding = exeFinder.FindNextFile();
						CString path = exeFinder.GetFilePath();
												
						ParseMD5Files(path, LogPath);
						//MessageBox(0, path, title, 0);
					}
					++count;
					FileList[count] = path;
				}
			}
			
		}
		if(count >= 0)
		{
			myDirectory = FileList[count];
		}
		--count;

	}while(count >= -1);
	exeFinder.Close();
	finder.Close ();
	return 1;
}

void VerifyMD5Files(CString FilePath, CString LogPath)
{
	const size_t StringSize = FilePath.GetLength() + 1;
	size_t CharactersConverted = 0;

	char *file = new char[StringSize];
	//char file[1024];
	wcstombs_s(&CharactersConverted, file, FilePath.GetLength()+1, FilePath, _TRUNCATE);

	ifstream read(file, ios::binary);
	read.seekg(0,ios::end);
	int l = read.tellg();
	read.seekg(0,ios::beg);
	char *buf = new char[l + 1];
	read.read(buf,l);
	buf[l] = '\0';
	//strcat(buf, "\0");
	CString FileName;
	FileName = CString(buf);
	delete file;
	delete buf;

	int index = FileName.Find(' ', 0);
	if(index != -1)
	{
		CString GivenMD5 = FileName.Left(index);
		//m_CGivenMD5box.SetWindowTextW(GivenMD5);

		index = FileName.Find('*', 0);
		if(index == -1)
		{
			index = FileName.Find(' ');
		}
		CString GivenFile = FileName.Right(FileName.GetLength() - (index + 1));
		GivenFile.Trim();
		
		if(GivenFile.Find('\\', 0) == -1 && GivenFile.Find('/', 0))
		{
			index = FilePath.ReverseFind('\\');
			GivenFile = FilePath.Left(index + 1) + GivenFile;
		}
		GivenFile.Trim();
		CString MD5, LogFile;
		
		if(CalculateMD5(GivenFile, MD5) != 0)
		{
			//m_CcalMD5box.SetWindowTextW(MD5);
			if(MD5 == GivenMD5)
				//MessageBox(0, MD5, L"Equal", 0);
				WriteLog(LogPath, GivenFile, CString(" - is OK"));
			else
				//MessageBox(0, MD5, L"Not Equal", 0);
				WriteLog(LogPath, GivenFile, CString(" - is Wrong"));
		}
	}
	else
		//MessageBox(0, FilePath, L"Invalid", 0);
		WriteLog(LogPath, FilePath, CString(" - is Invalid MD5 file"));
}
int VerifySubfoldersMD5(CString myDirectory, CString LogPath)
{
	CString FileList[2000];
	CString FolderPath, Ext;
	
	
	//CString myDirectory = L"C:\\Program Files";
	CFileFind finder, exeFinder;

	int count = -1;
	
	
	
	BOOL exeFinding = exeFinder.FindFile (myDirectory + L"\\*.md5");
	while (exeFinding)
	{
		exeFinding = exeFinder.FindNextFile();
		CString path = exeFinder.GetFilePath();
		//MessageBox(0, path, title, 0);
		VerifyMD5Files(path, LogPath);
	}			
	do
	{
		BOOL finding = finder.FindFile (myDirectory + CString ("\\*.*"));
		while (finding)
		{
			finding = finder.FindNextFile();
			CString path = finder.GetFilePath();
			CString title = finder.GetFileTitle();
			int ret = _chdir(CT2A(path));
			if (ret == 0)
			{
				if(path != (myDirectory + L"\\.") && path != (myDirectory + L"\\.."))
				{
					//MessageBoxW(0, myDirectory, L"Folder is", 0);
					
					BOOL exeFinding = exeFinder.FindFile (path + L"\\*.md5");
					while (exeFinding)
					{
						exeFinding = exeFinder.FindNextFile();
						CString path = exeFinder.GetFilePath();
												
						VerifyMD5Files(path, LogPath);
						//MessageBox(0, path, title, 0);
					}
					++count;
					FileList[count] = path;
				}
			}
			
		}
		if(count >= 0)
		{
			myDirectory = FileList[count];
		}
		--count;

	}while(count >= -1);
	exeFinder.Close();
	finder.Close ();
	return 1;
}

void CMD5Dlg::OnBnClickedVerifymultiplemd5button()
{
	// TODO: Add your control notification handler code here

	CString FolderPath;

	m_CFolderBox.GetWindowTextW(FolderPath);
	FolderPath.Trim();
	if(FolderPath.CompareNoCase(L"") == 0)
		return;

	FileNameToThread = FolderPath;
	DWORD dwThreadId;
	m_nFlag = 4;
	hThread = CreateThread( 
			NULL,              // default security attributes
			0,                 // use default stack size  
			MD5ThreadProc,        // thread function 
			NULL,             // argument to thread function 
			0,                 // use default creation flags 
			&dwThreadId);   // returns the thread identifier 
}

void CMD5Dlg::OnBnClickedReadmebutton()
{
	// TODO: Add your control notification handler code here
	MessageBoxW(L"There are 3 sections in this tool:-\n\n1. Calculate/Create MD5 file for a single file: \n\tUsing this section, you can just calculate the MD5 value of any type of file or can create the MD5 file if the given file is an exe or iso.\n   You can either browse or directly enter the file path in the given edit box .\n\n2. Create/Verify/Parse MD5 Files for multiple files: \n\tThis section will accept a folder path and will verify all the MD5 files inside that folder and subfolders(Subfolder is optional) or will create\n   the MD5 files for all exes/isos inside that folder and subfolders(again subfolder is optional) or parse the MD5 files in the given folder and will list in the Exe/ISO names and corresponding MD5 values in a CSV file.\n   Here first of all, you have to select an action: Create MD5 or Verfy MD5 or Parse MD5; then only the buttons for Verify or Create MD5s will get activated.\n   Then Chek the checkbox \"Include Subfolders\", if you want to Check/Verify MD5s in subfolers also.\n   There is one more checkbox \"Open log file after the process\"which is checked by default. This is for opening log file automatically\n   after the Creation/Verification of MD5 files.\n\n3. Verify MD5 for a single file: \n\tThis section is for verifying MD5 value of a single file(exe or iso).  You can either browse or directly enter the file path in the given edit box .\n\nNote: This tool supports both local and network files.", L"MD5 - ReadMe", 0);
}

void CMD5Dlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	OnCancel();
}

void CMD5Dlg::OnEnChangeEditfilename2()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
	m_CGivenMD5box.SetWindowTextW(L"");
	m_CcalMD5box.SetWindowTextW(L"");
	m_CGivenFileBox.SetWindowTextW(L"");
	m_CEditStatus.SetWindowTextW(L"");
	
}

void CMD5Dlg::OnEnChangeEditfilename()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
	m_CMD5ValueBox.SetWindowTextW(L"");
}
void CMD5Dlg::DeActivateControls()
{
	m_CFileNameBox.EnableWindow(0);
	m_CCalSingMD5Browse.EnableWindow(0);
	m_CShowMD5Button.EnableWindow(0);
	m_CCreateSingMD5.EnableWindow(0);
	m_CMD5File.EnableWindow(0);
	m_CLogOpenCheck.EnableWindow(0);
	m_CFolderBox.EnableWindow(0);
	m_CFolderBrowseButton.EnableWindow(0);
	m_CcreateMulMD5.EnableWindow(0);
	m_CmulVerifyButton.EnableWindow(0);
	m_CVeriSingMD5Browse.EnableWindow(0);
	m_CVeriSingMD5Button.EnableWindow(0);
	m_CSubFolderCheck.EnableWindow(0);
	m_CExitButton.EnableWindow(0);
}
void CMD5Dlg::ActivateControls()
{
	m_CFileNameBox.EnableWindow(1);
	m_CCalSingMD5Browse.EnableWindow(1);
	m_CShowMD5Button.EnableWindow(1);
	m_CCreateSingMD5.EnableWindow(1);
	m_CMD5File.EnableWindow(1);
	m_CLogOpenCheck.EnableWindow(1);
	m_CFolderBox.EnableWindow(1);
	m_CFolderBrowseButton.EnableWindow(1);
	m_CcreateMulMD5.EnableWindow(1);
	m_CmulVerifyButton.EnableWindow(1);
	m_CVeriSingMD5Browse.EnableWindow(1);
	m_CVeriSingMD5Button.EnableWindow(1);
	m_CSubFolderCheck.EnableWindow(1);
	m_CExitButton.EnableWindow(1);
}
DWORD WINAPI CMD5Dlg::MD5ThreadProc( LPVOID lpParam ) 
{
	CString MD5 = L"", FileName = L"";
	m_dlg->DeActivateControls();

	m_dlg->m_CMD5ProgessBar.ShowWindow(1);
	m_dlg->m_CMD5ProgessBar.SetRange(0, 100);
	m_dlg->m_CMD5ProgessBar.SetStep(1);
	
	UINT_PTR timer = m_dlg->SetTimer(IDC_MD5PROGRESSBAR, 25, m_dlg->TimerProc); 

	if(m_dlg->m_nFlag == 1)//Show MD5
	{
		FileName = m_dlg->FileNameToThread;
		m_dlg->SetWindowText(L"MD5 Checksum - MD5 value is being calculated for " + FileName);

		if(CalculateMD5(FileName, MD5) != 0)
		{
			m_dlg->m_CMD5ValueBox.SetWindowTextW(MD5);
			m_dlg->FileNameToThread=L"";
		}
	}
	if(m_dlg->m_nFlag == 2)//Create a single md5 file
	{
		CString title, Ext;
		FileName = m_dlg->FileNameToThread;
		m_dlg->SetWindowText(L"MD5 Checksum - MD5 file is being created for " + FileName);

		if(CalculateMD5(FileName, MD5) != 0)
		{
			m_dlg->m_CMD5ValueBox.SetWindowTextW(MD5);
			int index = FileName.ReverseFind('\\'); 
			title = FileName.Right(FileName.GetLength() - index - 1);
			index = title.Find('.');
			Ext = title.Right(title.GetLength() - index);
			title = title.Left(index);

			if(CreateMD5Files(FileName, title, Ext) != 0)//the fourth parameter is giving here is Just a Place holder
			{
				/*pDlg.EndDialog(npDlgRet);
				ShowWindow(SW_SHOW);
				CloseHandle(hThread);*/
				AfxMessageBox(L"MD5 File for \'" + FileName + L"\' has been created in the same location", 0, MB_ICONINFORMATION);
			}
			else
			{
				AfxMessageBox(L"MD5 File for \'" + FileName + L"\' falied to create", 0, MB_ICONERROR);
			}

		}
	}
	if(m_dlg->m_nFlag == 3)//Create MD5 files in a folder
	{
		CString FolderPath = m_dlg->FileNameToThread, Ext, MD5, FileName, LogPath;
		CFile fp;
		CFileFind Finder;
		m_dlg->SetWindowText(L"MD5 Checksum - MD5 files are being created in folder " + FolderPath);

		LogPath.GetEnvironmentVariableW(L"TEMP");
		LogPath = LogPath + L"\\MD5_Log.txt";
		DeleteFile(LogPath);

		int CheckState = m_dlg->m_CSubFolderCheck.GetCheck();
		if(CheckState == BST_CHECKED)
		{
			CreateSubfoldersMD5(FolderPath, LogPath);
			//MessageBox(L"Checked");
		}
		else
		{
			//MessageBox(L"Root Only");
			Ext = L".iso";
			for(int i = 0; i < 2; i++)
			{
				BOOL finding = Finder.FindFile (FolderPath + L"\\*" + Ext);
				while (finding)
				{
					finding = Finder.FindNextFile();
					CString path = Finder.GetFilePath();
					CString title = Finder.GetFileTitle();
					CreateMD5Files(path, title, Ext, LogPath);
				}
				Ext = L".exe";
			}
			Finder.Close();
		}
		if(m_dlg->m_CLogOpenCheck.GetCheck() == BST_CHECKED)
			ShellExecute(0, L"open", LPCTSTR(LogPath), L"", L"", SW_SHOW);
		else
			AfxMessageBox(L"Find the log in: " + LogPath, 0, MB_ICONINFORMATION);
	}
	if(m_dlg->m_nFlag == 4)//Verifying MD5 files in a folder
	{
		CString FolderPath = m_dlg->FileNameToThread, Ext, MD5, FileName, LogPath;
		CFile fp;
		CFileFind Finder;
		m_dlg->SetWindowText(L"MD5 Checksum - MD5 files are being verified in folder " + FolderPath);

		LogPath.GetEnvironmentVariableW(L"TEMP");
		LogPath = LogPath + L"\\MD5_Log.txt";
		DeleteFile(LogPath);
		int CheckState = m_dlg->m_CSubFolderCheck.GetCheck();
		if(CheckState == BST_CHECKED)
		{
			
			VerifySubfoldersMD5(FolderPath, LogPath);
		}
		else
		{
			//MessageBox(L"Root Only");
			
			BOOL finding = Finder.FindFile (FolderPath + L"\\*.md5");
			while (finding)
			{
				finding = Finder.FindNextFile();
				CString path = Finder.GetFilePath();
				VerifyMD5Files(path, LogPath);
				//MessageBox(path);
				
			}
			
			
			Finder.Close();
		}

		if(m_dlg->m_CLogOpenCheck.GetCheck() == BST_CHECKED)
			ShellExecute(0, L"open", LPCTSTR(LogPath), L"", L"", SW_SHOW);
		else
			AfxMessageBox(L"Find the log in: " + LogPath, 0, MB_ICONINFORMATION);
	}
	if(m_dlg->m_nFlag == 5)
	{
		CString GivenFile = m_dlg->FileNameToThread, MD5, FilePath;
		if(GivenFile == L"")
		{
			m_dlg->m_CMD5File.GetWindowTextW(FilePath);
			FilePath.Trim();
			const size_t StringSize = FilePath.GetLength() + 1;
			size_t CharactersConverted = 0;

			char *file = new char[StringSize];
			//char file[1024];
			wcstombs_s(&CharactersConverted, file, FilePath.GetLength()+1, FilePath, _TRUNCATE);

			ifstream read(file, ios::binary);
			read.seekg(0,ios::end);
			int l = read.tellg();
			read.seekg(0,ios::beg);
			char *buf = new char[l + 1];
			read.read(buf,l);
			buf[l] = '\0';
			//strcat(buf, "\0");
			CString FileName;
			FileName = CString(buf);
			delete file;
			delete buf;

			int index = FileName.Find(' ', 0);
			if(index != -1)
			{
				CString GivenMD5 = FileName.Left(index);
				m_dlg->m_CGivenMD5box.SetWindowTextW(GivenMD5);

				index = FileName.Find('*', 0);
				if(index == -1)
				{
					index = FileName.Find(' ');
				}
				GivenFile = FileName.Right(FileName.GetLength() - (index + 1));
				GivenFile.Trim();
				
				if(GivenFile.Find('\\', 0) == -1 && GivenFile.Find('/', 0) == -1)
				{
					index = FilePath.ReverseFind('\\');
					GivenFile = FilePath.Left(index + 1) + GivenFile;
				}
				GivenFile.Trim();
				m_dlg->m_CGivenFileBox.Clear();
				m_dlg->m_CGivenFileBox.SetWindowTextW(GivenFile);
			}
			else
			{
				AfxMessageBox(L"Invalid MD5 File", 0, MB_ICONERROR);
				m_dlg->SetWindowText(L"MD5 Checksum");
				m_dlg->FileNameToThread = L"";
				m_dlg->m_nFlag = 0;
				m_dlg->KillTimer(timer);
				m_dlg->m_CMD5ProgessBar.ShowWindow(0);
				m_dlg->ActivateControls();
				return 0;
			}
				
		}
		m_dlg->m_CcalMD5box.SetWindowTextW(L"Calculating MD5....");
		m_dlg->SetWindowText(L"MD5 Checksum - MD5 value is being verified for " + GivenFile);

		if(CalculateMD5(GivenFile, MD5) != 0)
		{
			m_dlg->m_CcalMD5box.SetWindowTextW(MD5);

			CString temp;
			m_dlg->m_CGivenMD5box.GetWindowTextW(temp);
			if(MD5 == temp)
			{
				m_dlg->m_CEditStatus.SetWindowTextW(L"Same");
				m_dlg->MessageBox(L"MD5 check sums are same", 0, MB_ICONINFORMATION);
			}
			else
			{
				m_dlg->m_CEditStatus.SetWindowTextW(L"Not Same");
				m_dlg->MessageBox(L"MD5 check sums are not same", 0, MB_ICONERROR);
			}
		}
	}
	if(m_dlg->m_nFlag == 6)//Parsing MD5 files in a folder
	{
		CString FolderPath = m_dlg->FileNameToThread, Ext, MD5, FileName, LogPath;
		CFile fp;
		CFileFind Finder;
		m_dlg->SetWindowText(L"MD5 Checksum - MD5 files are being parsed in folder " + FolderPath);

		LogPath.GetEnvironmentVariableW(L"TEMP");
		LogPath = LogPath + L"\\MD5List.csv";
		DeleteFile(LogPath);
		WriteLog(LogPath, L"Full Path,EXE Name,", L"MD5 Value");
		int CheckState = m_dlg->m_CSubFolderCheck.GetCheck();
		if(CheckState == BST_CHECKED)
		{
			
			ParseSubfoldersMD5(FolderPath, LogPath);
		}
		else
		{
			//MessageBox(L"Root Only");
			
			BOOL finding = Finder.FindFile (FolderPath + L"\\*.md5");
			while (finding)
			{
				finding = Finder.FindNextFile();
				CString path = Finder.GetFilePath();
				ParseMD5Files(path, LogPath);
				//MessageBox(path);
				
			}
			
			
			Finder.Close();
		}

		if(m_dlg->m_CLogOpenCheck.GetCheck() == BST_CHECKED)
			ShellExecute(0, L"open", LPCTSTR(LogPath), L"", L"", SW_SHOW);
		else
			AfxMessageBox(L"Find the log in: " + LogPath, 0, MB_ICONINFORMATION);
	}
	m_dlg->SetWindowText(L"MD5 Checksum");
	m_dlg->FileNameToThread = L"";
	m_dlg->m_nFlag = 0;
	m_dlg->KillTimer(timer);
	m_dlg->m_CMD5ProgessBar.ShowWindow(0);
	m_dlg->ActivateControls();
	return 0;
}
void CMD5Dlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	if (m_CMD5ProgessBar.GetPos()!= 100)
	 {
		m_CMD5ProgessBar.StepIt();
	 }
	 else
	 {//If you want Send a Message, Send a your own message here. 
		m_CMD5ProgessBar.SetPos(0);
	 }
	CDialog::OnTimer(nIDEvent);
}
VOID CALLBACK CMD5Dlg::TimerProc(HWND hwnd,UINT uMsg, UINT idEvent, DWORD dwTime) 
{

	if (m_dlg->m_CMD5ProgessBar.GetPos()!= 100)
	 {
		m_dlg->m_CMD5ProgessBar.StepIt();
	 }
	 else
	 {//If you want Send a Message, Send a your own message here. 
		m_dlg->m_CMD5ProgessBar.SetPos(0);
	 }
}
void CMD5Dlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CAboutDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	OnOK();
}

void CAboutDlg::OnBnClickedButton1()
{
	ShellExecute(0, L"open", L"http://shaheerva.googlepages.com/home", L"", L"", SW_SHOW);
	OnOK();
}


void CMD5Dlg::OnBnClickedParsemd5button()
{
	// TODO: Add your control notification handler code here
	CString FolderPath;

	m_CFolderBox.GetWindowTextW(FolderPath);
	FolderPath.Trim();
	if(FolderPath.CompareNoCase(L"") == 0)
		return;

	FileNameToThread = FolderPath;
	DWORD dwThreadId;
	m_nFlag = 6;
	hThread = CreateThread( 
			NULL,              // default security attributes
			0,                 // use default stack size  
			MD5ThreadProc,        // thread function 
			NULL,             // argument to thread function 
			0,                 // use default creation flags 
			&dwThreadId);   // returns the thread identifier 
}
