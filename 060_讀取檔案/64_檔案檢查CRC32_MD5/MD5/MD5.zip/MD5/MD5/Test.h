#include "stdafx.h"
void Start();