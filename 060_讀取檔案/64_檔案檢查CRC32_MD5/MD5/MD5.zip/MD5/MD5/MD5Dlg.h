// MD5Dlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CMD5Dlg dialog
class CMD5Dlg : public CDialog
{
// Construction
public:
	CMD5Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MD5_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_CFileNameBox;
public:
	CEdit m_CMD5ValueBox;
public:
//	afx_msg void OnBnClickedButton1();
public:
	afx_msg void OnBnClickedButton2();
public:
	afx_msg void OnBnClickedButton3();
public:
	afx_msg void OnBnClickedButton5();
public:
	CEdit m_CMD5File;
public:
	CEdit m_CGivenFileBox;
public:
	CEdit m_CcalMD5box;
public:
	CEdit m_CGivenMD5box;
public:
	afx_msg void OnBnClickedVerifymd5button();
public:
	afx_msg void OnBnClickedCreatemd5button();
public:
	afx_msg void OnBnClickedBrowserbutton();
public:
	CEdit m_CFolderBox;
public:
	CButton m_CSubFolderCheck;
public:
	afx_msg void OnBnClickedCreatesingmd5();
public:
	CEdit m_CLogBox;
public:
	CButton m_CcreateMulMD5;
public:
	//afx_msg void OnBnClickedLogbrowserbutton();
public:
	afx_msg void OnBnClickedCreatemd5radio();
public:
	CButton m_CmulVerifyButton;
public:
	CButton m_CFolderBrowseButton;
public:
	CButton m_CLogBrowseButton;
public:
	afx_msg void OnBnClickedVerifymd5radio();
public:
	afx_msg void OnBnClickedVerifymultiplemd5button();
public:
//	afx_msg void OnBnClickedAdvancedbutton();
public:
	afx_msg void OnBnClickedReadmebutton();
public:
	CButton m_CLogOpenCheck;
public:
//	afx_msg void OnTimer(UINT_PTR nIDEvent);
public:
	afx_msg void OnBnClickedCancel();
public:
	afx_msg void OnEnChangeEditfilename2();
public:
	afx_msg void OnEnChangeEditfilename();
public:
	CButton m_CCalSingMD5Browse;
public:
	CButton m_CShowMD5Button;
public:
	CButton m_CCreateSingMD5;
//public:
	//CButton m_CCreateRadio;
public:
	CButton m_CVeriSingMD5Browse;
public:
	CButton m_CVeriSingMD5Button;
public:
	CButton m_CReadMe;
	void ActivateControls();
	void DeActivateControls();
	HANDLE hThread;
	static DWORD WINAPI MD5ThreadProc( LPVOID lpParam );
	CString FileNameToThread;
	int m_nFlag;

public:
	CButton m_CExitButton;
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
public:
	CProgressCtrl m_CMD5ProgessBar;
	static VOID CALLBACK TimerProc(HWND hwnd,UINT uMsg, UINT idEvent, DWORD dwTime); 

public:
	afx_msg void OnBnClickedOk();
public:
	CButton m_CParseMD5Button;
public:
	afx_msg void OnBnClickedParsemd5radio();
public:
	afx_msg void OnBnClickedParsemd5button();
public:
	CEdit m_CEditStatus;
};
