#ifndef _HITPARAMS_H_
#define _HITPARAMS_H_

typedef struct {

	int x;
	int y;
	BOOL hit;

} hitParams;

#endif // _HITPARAMS_H_
