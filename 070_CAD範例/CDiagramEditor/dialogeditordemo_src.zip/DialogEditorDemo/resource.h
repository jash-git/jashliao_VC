//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DialogEditorDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DIALOGTYPE                  129
#define IDD_DIALOG_SETTINGS             130
#define IDD_DIALOG_BUTTON_PROPERTIES    131
#define IDD_DIALOG_EDIT_PROPERTIES      132
#define IDB_BITMAP1                     134
#define IDC_EDIT_WIDTH                  1000
#define IDC_EDIT_NAME                   1000
#define IDC_EDIT_HEIGHT                 1001
#define IDC_EDIT_GRID_WIDTH             1002
#define IDC_EDIT_GRID_HEIGHT            1003
#define IDC_EDIT_LEFT                   1004
#define IDC_EDIT_TOP                    1005
#define IDC_EDIT_RIGHT                  1006
#define IDC_EDIT_BOTTOM                 1007
#define IDC_EDIT_TITLE                  1008
#define IDC_BUTTON_APPLY                1009
#define IDC_PROPERTIES                  32772
#define IDC_SETTINGS                    32774
#define ID_ADD_BUTTON                   32775
#define ID_ADD_EDIT                     32776
#define ID_ADD_STATIC                   32777
#define IDC_90PERC                      32778
#define IDC_80PERS                      32779
#define IDC_70PERC                      32780
#define IDC_60PERC                      32781
#define IDC_50PERC                      32782
#define IDC_25PERC                      32783
#define IDC_100PERC                     32784
#define IDC_110PERC                     32785
#define IDC_120PERC                     32786
#define IDC_130PERC                     32787
#define IDC_140PERC                     32788
#define IDC_150PERC                     32789
#define IDC_200PERC                     32790
#define IDC_80PERC                      32791
#define IDC_SELECT_ALL                  32792
#define ID_ADD_CHECKBOX                 32794
#define ID_ADD_RADIOBUTTON              32795
#define ID_ADD_LISTBOX                  32796
#define ID_ADD_GROUPBOX                 32798
#define ID_ZOOM_IN                      32799
#define ID_ZOOM_OUT                     32800
#define ID_ADD_COMBOBOX                 32801
#define ID_SNAP_TO_GRID                 32802
#define ID_SHOW_GRID                    32804
#define ID_SNAP_TO_MARGIN               32805
#define ID_MARGINS                      32806
#define ID_RESTRAIN                     32807
#define ID_LEFT_ALIGN                   32808
#define ID_RIGHT_ALIGN                  32809
#define ID_TOP_ALIGN                    32810
#define ID_BOTTOM_ALIGN                 32811
#define ID_MAKE_SAME_SIZE               32812
#define ID_UP                           32813
#define ID_DOWN                         32814
#define ID_FRONT                        32815
#define ID_BOTTOM                       32816
#define ID_EXPORT                       32817
#define ID_ADD_NONE                     32819
#define ID_BUTTON_MULTIDRAW             32821

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32823
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
