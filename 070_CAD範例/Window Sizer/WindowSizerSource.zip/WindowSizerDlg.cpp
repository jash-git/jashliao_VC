
#include "stdafx.h"
#include "WindowSizer.h"
#include "WindowSizerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)	
END_MESSAGE_MAP()


// CWindowSizerDlg dialog



CWindowSizerDlg::CWindowSizerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWindowSizerDlg::IDD, pParent)
	, m_windowtitle(_T(""))
	, bShown(false)
	, m_cursize(_T(""))
	, bCustomChk(FALSE)
	, m_cusx(0)
	, m_cusy(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWindowSizerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDITTITLE, m_windowtitle);
	DDX_Control(pDX, IDC_LIST1, c_listbox);
	DDX_Text(pDX, IDC_EDIT1, m_cursize);
	DDX_Check(pDX, IDC_CHECK1, bCustomChk);
	DDX_Control(pDX, IDC_EDIT2CUS_X, c_cusx);
	DDX_Control(pDX, IDC_EDIT3_CUS_Y, c_cusy);
	DDX_Text(pDX, IDC_EDIT2CUS_X, m_cusx);
	DDV_MinMaxUInt(pDX, m_cusx, 50, 2000);
	DDX_Text(pDX, IDC_EDIT3_CUS_Y, m_cusy);
	DDV_MinMaxUInt(pDX, m_cusy, 50, 2000);
}

BEGIN_MESSAGE_MAP(CWindowSizerDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_MESSAGE(WM_HOTKEY,OnHotKey)
	ON_MESSAGE(WM_USER+1,OnTrayMessage)	
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_COMMAND(ID_SIZER_EXIT, OnSizerExit)
	ON_BN_CLICKED(IDC_CHECK1, OnBnClickedCheck1)
	ON_COMMAND(ID_SIZER_ABOUT, OnSizerAbout)
END_MESSAGE_MAP()


// CWindowSizerDlg message handlers

BOOL CWindowSizerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	RegisterHotKey(m_hWnd,100,MOD_ALT | MOD_CONTROL,VK_F12);

	// Populate list box
	int cx = GetSystemMetrics(SM_CXSCREEN);
	int cy = GetSystemMetrics(SM_CYSCREEN);

	int j = 0;
	int k = 0;
	CString str;
	for (int i = 320; i <= 1600; i += 160)
	{		
		j = (int)(0.75 * i);
		str.Format("%04d x %04d",i,j);
		if( (i < cx) && (j < cy) )
			c_listbox.AddString(str);
		str.Format("%04d x %04d",j,j);
		if( (j < cx) && (j < cy) )
			c_listbox.AddString(str);
		k = (int)(0.8 * j);
		str.Format("%04d x %04d",k,j);
		if( (k < cx) && (j < cy) )
			c_listbox.AddString(str);
	}

	m_cusx = m_cusy = 300;
	UpdateData(FALSE);

	c_cusx.EnableWindow(false);
	c_cusy.EnableWindow(false);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWindowSizerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWindowSizerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWindowSizerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CWindowSizerDlg::PostNcDestroy()
{
	UnregisterHotKey(m_hWnd,100);
	CDialog::PostNcDestroy();
	delete this;
}

void CWindowSizerDlg::OnBnClickedCancel()
{
	ShowWindow(SW_HIDE);
	::EnableWindow(m_hCurWindow,true);
	::SetForegroundWindow(m_hCurWindow);
	bShown = false;
}

void CWindowSizerDlg::OnBnClickedOk()
{
	ShowWindow(SW_HIDE);
	::EnableWindow(m_hCurWindow,true);
	::SetForegroundWindow(m_hCurWindow);
	bShown = false;
}

LRESULT CWindowSizerDlg::OnHotKey(WPARAM wParam, LPARAM lParam)
{
	CWnd* pwnd = GetForegroundWindow();
	if(pwnd && !bShown)
	{
		if (IsWindow(pwnd->m_hWnd))
		{	
			RECT rect;
			pwnd->GetWindowRect(&rect);
			m_cursize.Format("%04d x %04d",rect.right-rect.left,rect.bottom-rect.top);
			pwnd->GetWindowText(m_windowtitle);
			UpdateData(FALSE);
			ShowWindow(SW_SHOW);
			c_listbox.SetCurSel(0);
			SetForegroundWindow();
			m_hCurWindow = pwnd->m_hWnd;
			::EnableWindow(m_hCurWindow,false);
			bShown = true;
		}
	}
	return 0;
}
void CWindowSizerDlg::CloseProg()
{
	::EnableWindow(m_hCurWindow,true);
	::SetForegroundWindow(m_hCurWindow);
	DestroyWindow();
}

void CWindowSizerDlg::OnBnClickedButton2()
{
	int cx = GetSystemMetrics(SM_CXSCREEN);
	int cy = GetSystemMetrics(SM_CYSCREEN);
	CRect rect;
	::GetWindowRect(m_hCurWindow,&rect);
	int newwidth;
	int newheight;
	if(bCustomChk)
	{
		UpdateData(TRUE);
		newwidth = m_cusx;
		newheight = m_cusy;
		m_cursize.Format("%04d x %04d",newwidth,newheight);
	}
	else
	{
		CString str;
		c_listbox.GetText(c_listbox.GetCurSel(),str);
		m_cursize = str;
		newwidth = atoi(str);
		str = str.Right(str.GetLength() - str.Find("x") - 1);
		newheight = atoi(str);	
	}	
	::MoveWindow(m_hCurWindow,rect.left,rect.top,newwidth,newheight,TRUE);		
	SetWindowLong(m_hCurWindow,GWL_STYLE,GetWindowLong(m_hCurWindow,GWL_STYLE) & ~WS_MAXIMIZE);
	
	if ( ((rect.left + newwidth) > cx) ||
		((rect.top + newheight) > cy) )
	{
		CWnd nWnd;
		nWnd.Attach(m_hCurWindow);
		nWnd.CenterWindow();
		nWnd.Detach();
	}
	UpdateData(FALSE);
}

LRESULT CWindowSizerDlg::OnTrayMessage(WPARAM wParam, LPARAM lParam)
{
	if(lParam == WM_RBUTTONDOWN)
	{
		POINT pos;
		GetCursorPos(&pos);
		CMenu menu;
		menu.LoadMenu(IDR_MENU1);
		SetForegroundWindow();
		menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON,
			pos.x,pos.x,this);
		PostMessage(WM_NULL);
	}
	return 0;
}
void CWindowSizerDlg::OnSizerExit()
{
	if(bShown)
		CloseProg();
	else
		DestroyWindow();
}

void CWindowSizerDlg::OnBnClickedCheck1()
{
	UpdateData(TRUE);
	if(bCustomChk)
	{
		c_cusx.EnableWindow(true);
		c_cusy.EnableWindow(true);
		c_listbox.EnableWindow(false);
		c_cusx.SetFocus();
	}
	else
	{
		c_cusx.EnableWindow(false);
		c_cusy.EnableWindow(false);
		c_listbox.EnableWindow(true);
		c_listbox.SetCurSel(0);
		c_listbox.SetFocus();
	}
}

void CWindowSizerDlg::OnSizerAbout()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();	
}
