#include "stdafx.h"
#include "WindowSizer.h"
#include "WindowSizerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CWindowSizerApp

BEGIN_MESSAGE_MAP(CWindowSizerApp, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


// CWindowSizerApp construction

CWindowSizerApp::CWindowSizerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CWindowSizerApp object

CWindowSizerApp theApp;
CLimitSingleInstance g_singinst("{0A86C486-1AF4-40ca-8A1B-BBC550F76812}");

// CWindowSizerApp initialization

BOOL CWindowSizerApp::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	AfxEnableControlContainer();

	
	if (g_singinst.IsAnotherInstanceRunning())
		return FALSE;	


	CWindowSizerDlg* dlg = new CWindowSizerDlg(); ;
	m_pMainWnd = dlg;
	dlg->Create(CWindowSizerDlg::IDD);
	dlg->ShowWindow(SW_HIDE);
	SetForegroundWindow(GetDesktopWindow());

	char buff[128];
	sprintf(buff,"WindowSizer is active. Press Ctrl-Alt-F12");
	nid.cbSize=sizeof NOTIFYICONDATA;
	nid.hWnd=dlg->m_hWnd;
	nid.uID=100;
	nid.uCallbackMessage = WM_USER+1;
	nid.uFlags=NIF_ICON | NIF_TIP | NIF_MESSAGE ;
	strcpy(nid.szTip,buff);
	
	nid.hIcon = this->LoadIcon(IDR_MAINFRAME);
					
	Shell_NotifyIcon(NIM_ADD,&nid);
	
	return TRUE;
}

int CWindowSizerApp::ExitInstance()
{	
	Shell_NotifyIcon(NIM_DELETE,&nid);
	return CWinApp::ExitInstance();
}
