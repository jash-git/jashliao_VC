// WindowSizerDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CWindowSizerDlg dialog
class CWindowSizerDlg : public CDialog
{
// Construction
public:
	CWindowSizerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_WINDOWSIZER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	LRESULT OnHotKey(WPARAM wParam, LPARAM lParam);
	LRESULT OnTrayMessage(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
	virtual void PostNcDestroy();
public:
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
	void CloseProg();
	CString m_windowtitle;
	CListBox c_listbox;
	afx_msg void OnBnClickedButton2();
protected:
	HWND m_hCurWindow;
	bool bShown;
public:
	CString m_cursize;
	afx_msg void OnSizerExit();
	BOOL bCustomChk;
	afx_msg void OnBnClickedCheck1();
	CEdit c_cusx;
	CEdit c_cusy;
	UINT m_cusx;
	UINT m_cusy;
	afx_msg void OnSizerAbout();
};
