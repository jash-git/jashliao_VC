// WindowSizer.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// CWindowSizerApp:
// See WindowSizer.cpp for the implementation of this class
//

class CWindowSizerApp : public CWinApp
{
public:
	CWindowSizerApp();
	NOTIFYICONDATA nid;

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
	virtual int ExitInstance();
};

class CLimitSingleInstance
{
protected:
	DWORD  m_dwLastError;
	HANDLE m_hMutex;

public:
	CLimitSingleInstance(TCHAR *strMutexName)
	{    
		m_hMutex = CreateMutex(NULL, FALSE, strMutexName); 
		m_dwLastError = GetLastError();
	}

	~CLimitSingleInstance() 
	{
		if (m_hMutex)
		{
			CloseHandle(m_hMutex); 
			m_hMutex = NULL; 
		}
	}

	BOOL IsAnotherInstanceRunning() 
	{
		return (ERROR_ALREADY_EXISTS == m_dwLastError);
	}
};

extern CWindowSizerApp theApp;