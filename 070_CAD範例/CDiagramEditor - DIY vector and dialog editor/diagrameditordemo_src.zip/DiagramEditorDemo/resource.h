//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DiagramEditorDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DIAGRAMEDITORDEMO_DIALOG    102
#define IDS_CHANGED_SAVE                102
#define IDS_SAVED                       103
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_PAPER_SIZE           129
#define IDD_DIALOG_GRID_SIZE            130
#define IDC_STATIC_PLACEHOLDER          1000
#define IDC_BUTTON_BOX                  1001
#define IDC_BUTTON_LINE                 1002
#define IDC_BUTTON_NEW                  1003
#define IDC_BUTTON_COPY                 1004
#define IDC_BUTTON_PASTE                1005
#define IDC_BUTTON_UNDO                 1006
#define IDC_BUTTON_CUT                  1007
#define IDC_CHECK_SNAP                  1008
#define IDC_CHECK_SHOW_GRID             1009
#define IDC_BUTTON_SIZE                 1010
#define IDC_EDIT_WIDTH                  1010
#define IDC_BUTTON_SAVE                 1011
#define IDC_EDIT_HEIGHT                 1011
#define IDC_BUTTON_LOAD                 1012
#define IDC_BUTTON_GRID_SIZE            1013
#define IDC_BUTTON1                     1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
