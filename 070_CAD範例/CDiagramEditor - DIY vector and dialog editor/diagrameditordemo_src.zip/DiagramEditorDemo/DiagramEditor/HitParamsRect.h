#ifndef _HITPARAMSRECT_H_
#define _HITPARAMSRECT_H_

typedef struct {

	CRect rect;
	BOOL hit;

} hitParamsRect;

#endif // _HITPARAMSRECT_H_
