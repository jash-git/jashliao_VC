#if !defined(AFX_IEBAR_H__6335E429_3DA0_4D26_955F_3E36623B1825__INCLUDED_)
#define AFX_IEBAR_H__6335E429_3DA0_4D26_955F_3E36623B1825__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IEBar.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CIEBar dialog

class CIEBar : public CDialogBar
{
// attributes
public:
	CFont         m_Font;              // the font for IE bar
	CRect         m_VirClientRc;       // virtual client rectangle
	CString       m_TitleTxt;          // title text
	int           m_cyTitle;           // title height
	int           m_cxIEBar;           // IE bar width
	CTreeCtrl*    pTreeCtrl;           // pointer tree control
    CToolTipCtrl  m_TipCtrl;           // for tip
	bool          m_bResize;           // indicate resize IE bar
	CPoint        m_PrePnt;            // store previous point

	CRect         m_HideBtnRc;         // rectangle of hide button
	bool          m_bTrack;            // track mouse
	bool          m_bRaised;           // draw raised hide button
	bool          m_bPressed;          // draw pressed hide button

public:
// operations
	BOOL InitIEBar();                  // initialize
	void DrawFrm(CDC& dc);             // draw big frame for IE bar
	void DrawTitleTxt(CDC& dc);        // draw title text
	void DrawHideBtn(CDC& dc);         // draw hide button
	CTreeCtrl* GetTreeCtrl();          // get tree control 
	void ChangeCursor();               // change cursor
	void ResizeIEBar();                // adjust IE bar size
	void DrawDragLine(CPoint point);   // draw draging line
	void DrawHideBtnFace(CPoint point);// draw hide-button for raised and pressed
	CPoint GetFitPnt();                // get fit point

// Construction
public:
	CIEBar(CWnd* pParent = NULL);      // standard constructor
// Dialog Data
	//{{AFX_DATA(CIEBar)
	enum { IDD = IDD_IEBAR };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIEBar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    virtual CSize CalcDynamicLayout( int nLength, DWORD dwMode );
    virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIEBar)
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IEBAR_H__6335E429_3DA0_4D26_955F_3E36623B1825__INCLUDED_)
