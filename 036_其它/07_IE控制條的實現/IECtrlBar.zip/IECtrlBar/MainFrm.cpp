// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "IECtrlBar.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(IDD_SHOW_HIDE_IE_BAR, OnShowHideIEBar)
	ON_UPDATE_COMMAND_UI(IDD_SHOW_HIDE_IE_BAR, OnUpdateShowHideIEBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	if(!m_IEBar.Create(this, IDD_IEBAR, CBRS_LEFT, 100) || !m_IEBar.InitIEBar())
		return -1;
	CTreeCtrl* pTreeCtrl = m_IEBar.GetTreeCtrl();
	ASSERT(pTreeCtrl);
	// modify tree styles
	pTreeCtrl->ModifyStyle(NULL, 
		TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS);
	HTREEITEM t_hRoot = pTreeCtrl->InsertItem("root");
	for(int i=0; i<40; i++)
	{
		CString t_ItemStr;
		t_ItemStr.Format("node %d", i+1);
		pTreeCtrl->InsertItem(t_ItemStr, t_hRoot);
	}

	m_IEBar.EnableDocking(CBRS_ORIENT_HORZ);
	DockControlBar(&m_IEBar);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnShowHideIEBar() 
{	
	ShowControlBar(&m_IEBar, 
		           (m_IEBar.GetStyle() & WS_VISIBLE) == 0, 
		           FALSE);	
}

void CMainFrame::OnUpdateShowHideIEBar(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((m_IEBar.GetStyle() & WS_VISIBLE) != 0);	
}
