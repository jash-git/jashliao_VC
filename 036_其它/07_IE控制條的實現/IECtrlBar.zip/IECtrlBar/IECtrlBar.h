// IECtrlBar.h : main header file for the IECTRLBAR application
//

#if !defined(AFX_IECTRLBAR_H__5D179167_7E04_4C79_9A37_15F3E5D3C601__INCLUDED_)
#define AFX_IECTRLBAR_H__5D179167_7E04_4C79_9A37_15F3E5D3C601__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CIECtrlBarApp:
// See IECtrlBar.cpp for the implementation of this class
//

class CIECtrlBarApp : public CWinApp
{
public:
	CIECtrlBarApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIECtrlBarApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CIECtrlBarApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IECTRLBAR_H__5D179167_7E04_4C79_9A37_15F3E5D3C601__INCLUDED_)
