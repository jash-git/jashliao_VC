// IECtrlBarView.cpp : implementation of the CIECtrlBarView class
//

#include "stdafx.h"
#include "IECtrlBar.h"

#include "IECtrlBarDoc.h"
#include "IECtrlBarView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIECtrlBarView

IMPLEMENT_DYNCREATE(CIECtrlBarView, CView)

BEGIN_MESSAGE_MAP(CIECtrlBarView, CView)
	//{{AFX_MSG_MAP(CIECtrlBarView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIECtrlBarView construction/destruction

CIECtrlBarView::CIECtrlBarView()
{
	// TODO: add construction code here

}

CIECtrlBarView::~CIECtrlBarView()
{
}

BOOL CIECtrlBarView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CIECtrlBarView drawing

void CIECtrlBarView::OnDraw(CDC* pDC)
{
	CIECtrlBarDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CIECtrlBarView printing

BOOL CIECtrlBarView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CIECtrlBarView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CIECtrlBarView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CIECtrlBarView diagnostics

#ifdef _DEBUG
void CIECtrlBarView::AssertValid() const
{
	CView::AssertValid();
}

void CIECtrlBarView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CIECtrlBarDoc* CIECtrlBarView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CIECtrlBarDoc)));
	return (CIECtrlBarDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIECtrlBarView message handlers
