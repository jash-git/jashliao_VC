// CPUTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CPUTest.h"
#include "CPUTestDlg.h"

#include "CPU.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCPUTestDlg dialog

CCPUTestDlg::CCPUTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCPUTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCPUTestDlg)
	m_pc = -1;
	m_tp = -1;
	m_mhz = 0;
	m_msec = 0;
	m_num = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCPUTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCPUTestDlg)
	DDX_CBIndex(pDX, IDC_COMBO_PROCESS, m_pc);
	DDX_CBIndex(pDX, IDC_COMBO_THREAD, m_tp);
	DDX_Text(pDX, IDC_EDIT_MHZ, m_mhz);
	DDX_Text(pDX, IDC_EDIT_MS, m_msec);
	DDV_MinMaxUInt(pDX, m_msec, 1, 10000);
	DDX_Text(pDX, IDC_EDIT_NUMBER, m_num);
	DDV_MinMaxUInt(pDX, m_num, 1, 20);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCPUTestDlg, CDialog)
	//{{AFX_MSG_MAP(CCPUTestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_REFRESH, OnButtonRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCPUTestDlg message handlers

BOOL CCPUTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_num = 1;
	m_msec = 50;
	m_tp = 6;
	m_pc = 3;
	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCPUTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCPUTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCPUTestDlg::OnButtonRefresh() 
{
	if (!UpdateData())
		return;

	m_mhz = CCPU::GetMHz(m_num, m_msec, GetTP(), GetPC());
	UpdateData(FALSE);
}

int CCPUTestDlg::GetTP()
{
	int	tps[] = {
		THREAD_PRIORITY_IDLE,
		THREAD_PRIORITY_LOWEST,
		THREAD_PRIORITY_BELOW_NORMAL,
		THREAD_PRIORITY_NORMAL,
		THREAD_PRIORITY_ABOVE_NORMAL,
		THREAD_PRIORITY_HIGHEST,
		THREAD_PRIORITY_TIME_CRITICAL
	};

	return(tps[m_tp]);
}

DWORD CCPUTestDlg::GetPC()
{
	DWORD	pcs[] = {
		IDLE_PRIORITY_CLASS,
		NORMAL_PRIORITY_CLASS,
		HIGH_PRIORITY_CLASS,
		REALTIME_PRIORITY_CLASS
	};

	return(pcs[m_pc]);
}
