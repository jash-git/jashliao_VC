// CPUTestDlg.h : header file
//

#if !defined(AFX_CPUTESTDLG_H__9A224A07_3489_11D5_B22D_444553540001__INCLUDED_)
#define AFX_CPUTESTDLG_H__9A224A07_3489_11D5_B22D_444553540001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCPUTestDlg dialog

class CCPUTestDlg : public CDialog
{
// Construction
public:
	CCPUTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCPUTestDlg)
	enum { IDD = IDD_CPUTEST_DIALOG };
	int		m_pc;
	int		m_tp;
	int		m_mhz;
	UINT	m_msec;
	UINT	m_num;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCPUTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	DWORD GetPC();
	int GetTP();
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCPUTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonRefresh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CPUTESTDLG_H__9A224A07_3489_11D5_B22D_444553540001__INCLUDED_)
