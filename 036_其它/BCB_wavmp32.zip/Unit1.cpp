//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <fstream>
#include <iostream>
#include "Unit1.h"

#define _BLADEDLL           //Don't forget it
#include "lame_enc.h"
#include "format.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"


TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BrowseClick(TObject *Sender)
{
  OpenDialog1->InitialDir=ExtractFileDir(Application->ExeName);
  if(OpenDialog1->Execute())
  {
    FileEdit->Text=OpenDialog1->FileName;
    int Pos=OpenDialog1->FileName.AnsiPos(".");
    OutputFileName=OpenDialog1->FileName.SubString(0,Pos-1)+".mp3";
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::EncodeClick(TObject *Sender)
{
  if(FileEdit->Text=="")return;
  std::ifstream fin(FileEdit->Text.c_str(),std::ios::binary);
  if(!fin)return;

  //read the 12 character in front of the file
  fin.read((char*)&startID,sizeof(startID));

  //get the format chunk
  FormatChunk fc;
  fin.read((char*)&fc,sizeof(FormatChunk));
  // the first chunk MUST be the format chunk
  if(strncmp(fc.chunkID,"fmt ",4)!=0)
  {
    Application->MessageBox("This is not a valid Wave file",
                            "Wav2Mp3 ERROR",MB_OK);
    return;
  }
  if(fc.wFormatTag!=1)
  {
    Application->MessageBox("Cannot handle compressed Wave file",
                            "Wav2Mp3 ERROR",MB_OK);
    return;
  }

  // initialization of Mp3 encoder
  BE_CONFIG bc;
  bc.dwConfig=BE_CONFIG_MP3;
  //32000, 44100 and 48000 are the only sample rate authorized
  //due to encoding limitations
  if(fc.dwSamplesPerSec==32000 || fc.dwSamplesPerSec==44100 ||
      fc.dwSamplesPerSec==48000)
        bc.format.mp3.dwSampleRate=fc.dwSamplesPerSec;
  else
  {
    Application->MessageBox("Unsuported sample rate",
                            "Wav2Mp3 ERROR",MB_OK);
    return;
  }
  if(fc.wChannels==1)bc.format.mp3.byMode=BE_MP3_MODE_MONO;
  else bc.format.mp3.byMode=BE_MP3_MODE_STEREO;
  //the resulting file length depends on this parameter
  //higher the bitrate, better the result
  bc.format.mp3.wBitrate=192;
  bc.format.mp3.bCopyright=false;
  bc.format.mp3.bCRC=false;
  bc.format.mp3.bOriginal=false;
  bc.format.mp3.bPrivate=false;
  //skip extra formatchunk parameter, if any
  if(sizeof(FormatChunk)<8+fc.chunkSize)
  {
    char c;
    for(int i=0;i<8+fc.chunkSize-sizeof(FormatChunk);i++)fin.get(c);
  }

  //get next chunk
  Chunk chunk;
  fin.read((char*)&chunk,sizeof(Chunk));
  //check if it's the data chunk
  while(strncmp(chunk.chunkID,"data",4)!=0)
  {
    char c;
    for(int i=0;i<chunk.chunkSize;i++)fin.get(c);
    fin.read((char*)&chunk,sizeof(Chunk));
  }

  //process with the encoding
  DWORD dwNumberOfSamples;
  DWORD dwOutputBufferLength;
  HBE_STREAM hStream;
  if(beInitStream(&bc,&dwNumberOfSamples,&dwOutputBufferLength,&hStream)
    !=BE_ERR_SUCCESSFUL)
  {
    Application->MessageBox("Cannot perform compression",
                            "Wav2Mp3 ERROR",MB_OK);
    return;
  }
  std::ofstream fout(OutputFileName.c_str(),std::ios::binary);
  char *Mp3Buffer=new char[dwOutputBufferLength];
  SHORT *InputBuffer=new SHORT[dwNumberOfSamples];      //SHORT=short=16 bits

  int SamplesPerformed=0;
  DWORD dwNumberOfSamplesEncoded;
  while(SamplesPerformed<chunk.chunkSize)
  {
    fin.read((char*)InputBuffer,dwNumberOfSamples*2);
    SamplesPerformed+=dwNumberOfSamples*2;
    if(beEncodeChunk(hStream,dwNumberOfSamples,InputBuffer,
        (BYTE*)Mp3Buffer,&dwNumberOfSamplesEncoded)!=BE_ERR_SUCCESSFUL)
    {
      Application->MessageBox("Cannot perform compression",
                              "Wav2Mp3 ERROR",MB_OK);
      return;
    }
    fout.write(Mp3Buffer,dwNumberOfSamplesEncoded);
  }
  beDeinitStream(hStream,(BYTE*)Mp3Buffer,&dwNumberOfSamplesEncoded);
  beCloseStream(hStream);

  delete Mp3Buffer;
  delete InputBuffer;
  return;
}
//---------------------------------------------------------------------------

