//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
  TOpenDialog *OpenDialog1;
  TEdit *FileEdit;
  TLabel *Label1;
  TButton *Browse;
  TButton *Encode;
  void __fastcall BrowseClick(TObject *Sender);
  void __fastcall EncodeClick(TObject *Sender);
private:	// User declarations
  AnsiString OutputFileName;
public:		// User declarations
  __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
 