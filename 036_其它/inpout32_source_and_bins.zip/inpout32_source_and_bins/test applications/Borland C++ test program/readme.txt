
	This test application is written by 

	Douglas Beattie Jr.
    	Electronics R&D Engineering Consultant
    	Ogden, Utah, U.S.A.

	http://www.hytherion.com/beattidp/
