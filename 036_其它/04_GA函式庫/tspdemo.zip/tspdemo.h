// tspdemo.h : main header file for the TSPDEMO application
//

#if !defined(AFX_TSPDEMO_H__27ACB975_9765_11D2_836E_00C04F8F199B__INCLUDED_)
#define AFX_TSPDEMO_H__27ACB975_9765_11D2_836E_00C04F8F199B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTspdemoApp:
// See tspdemo.cpp for the implementation of this class
//

class CTspdemoApp : public CWinApp
{
public:
	CTspdemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTspdemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTspdemoApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TSPDEMO_H__27ACB975_9765_11D2_836E_00C04F8F199B__INCLUDED_)
