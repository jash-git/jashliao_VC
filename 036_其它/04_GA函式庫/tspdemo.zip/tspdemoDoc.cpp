// tspdemoDoc.cpp : implementation of the CTspdemoDoc class
//

#include "stdafx.h"
#include "tspdemo.h"

#include "tspdemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTspdemoDoc

IMPLEMENT_DYNCREATE(CTspdemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CTspdemoDoc, CDocument)
	//{{AFX_MSG_MAP(CTspdemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTspdemoDoc construction/destruction

CTspdemoDoc::CTspdemoDoc()
{
	// TODO: add one-time construction code here

}

CTspdemoDoc::~CTspdemoDoc()
{
}

BOOL CTspdemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTspdemoDoc serialization

void CTspdemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTspdemoDoc diagnostics

#ifdef _DEBUG
void CTspdemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTspdemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTspdemoDoc commands
