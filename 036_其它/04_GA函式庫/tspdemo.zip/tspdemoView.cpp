// tspdemoView.cpp : implementation of the CTspdemoView class
//

#include "stdafx.h"

#include <math.h>
#include "tspdemo.h"

#include "tspdemoDoc.h"
#include "tspdemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTspdemoView

IMPLEMENT_DYNCREATE(CTspdemoView, CView)

BEGIN_MESSAGE_MAP(CTspdemoView, CView)
	//{{AFX_MSG_MAP(CTspdemoView)
	ON_COMMAND(GA_CNTRL_EVOLVE, OnEvolve)
	ON_COMMAND(GA_CNTRL_REWIND, OnReset)
	ON_COMMAND(GA_CNTRL_STEP, OnStep)
	ON_COMMAND(GA_CNTRL_STOP, OnStop)
	ON_COMMAND(GA_MALG_CROWDING, OnSelectGACrowding)
	ON_COMMAND(GA_MALG_SIMPLE, OnSelectGASimple)
	ON_COMMAND(GA_MALG_SS, OnSelectGASteadyState)
	ON_COMMAND(GA_CNTRL_SOME, OnEvolveSome)
	ON_UPDATE_COMMAND_UI(GA_MALG_CROWDING, OnUpdateGACrowding)
	ON_UPDATE_COMMAND_UI(GA_MALG_DEME, OnUpdateGADeme)
	ON_UPDATE_COMMAND_UI(GA_MALG_INCREMENTAL, OnUpdateGAIncremental)
	ON_UPDATE_COMMAND_UI(GA_MALG_SIMPLE, OnUpdateGASimple)
	ON_UPDATE_COMMAND_UI(GA_MALG_SS, OnUpdateGASteadyState)
	ON_COMMAND(GA_MALG_DEME, OnSelectGADeme)
	ON_COMMAND(GA_MALG_INCREMENTAL, OnSelectGAIncremental)
	ON_COMMAND(GA_PARAMETERS, OnParameters)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTspdemoView construction/destruction

CTspdemoView::CTspdemoView(){
	_whichFunction = MIN_DIST;
	_whichGA = SIMPLE;

	_theGenome = 0;
	_theGA = 0;
	_params = 0;
	
	_pmut = 0.01;
	_pcross = 0.9;
	_ngen = 150;
	_popsize = 40;

	_enabled = 1;
	_running = 0;

	configure();
}

CTspdemoView::~CTspdemoView(){
	delete _theGA;
	delete _theGenome;
	delete _params;
}

BOOL CTspdemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTspdemoView drawing

void CTspdemoView::OnDraw(CDC* pDC){
	CTspdemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	draw(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CTspdemoView diagnostics

#ifdef _DEBUG
void CTspdemoView::AssertValid() const
{
	CView::AssertValid();
}

void CTspdemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTspdemoDoc* CTspdemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTspdemoDoc)));
	return (CTspdemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTspdemoView message handlers

void CTspdemoView::OnEvolve() {
	if(!_running) {
		_enabled = -1;
		AfxBeginThread(Evolve, this, THREAD_PRIORITY_NORMAL);
	}
}

void CTspdemoView::OnReset() {
	_enabled = 0;
	while(_running) { ; } // wait for thread to stop
	_theGA->initialize();
	InvalidateRect(NULL);
}

void CTspdemoView::OnStep() {
	if(!_running) {
		_enabled = _theGA->generation()+1;
		AfxBeginThread(Evolve, this, THREAD_PRIORITY_NORMAL);
	}
}

void CTspdemoView::OnStop() {
	_enabled = 0;
}

void CTspdemoView::OnEvolveSome() {
	if(!_running) {
		_enabled = _theGA->generation()+10;
		AfxBeginThread(Evolve, this, THREAD_PRIORITY_NORMAL);
	}
}




UINT CTspdemoView::Evolve(LPVOID param) {
	CTspdemoView* ptr = reinterpret_cast<CTspdemoView*>(param);

	if(ptr->_running) return 0;
	int n = ptr->_enabled;
	while(ptr->_enabled != 0) {
		ptr->_running = 1;
		if((n < 0 && ptr->_theGA->done() == gaFalse) || ptr->_theGA->generation() < n){
			ptr->_theGA->step();
			ptr->InvalidateRect(NULL);
		}
		else {
			ptr->_enabled = 0;
		}
	}
	ptr->_running = 0;
	ptr->InvalidateRect(NULL);
	return 0;
}








void CTspdemoView::OnSelectGASimple() {
	_whichGA = SIMPLE;
	configure();	
	InvalidateRect(NULL);
}

void CTspdemoView::OnSelectGASteadyState() {
	_whichGA = STEADY_STATE;
	configure();	
	InvalidateRect(NULL);
}

void CTspdemoView::OnSelectGAIncremental() {
	_whichGA = INCREMENTAL;
	configure();	
	InvalidateRect(NULL);
}

void CTspdemoView::OnSelectGACrowding() {
	_whichGA = CROWDING;
	configure();	
	InvalidateRect(NULL);
}

void CTspdemoView::OnSelectGADeme() {
	_whichGA = DEME;
	configure();	
	InvalidateRect(NULL);
}

void CTspdemoView::OnUpdateGASimple(CCmdUI* pCmdUI) {
	if(_whichGA == SIMPLE) pCmdUI->SetCheck(1);
	else pCmdUI->SetCheck(0);
}

void CTspdemoView::OnUpdateGASteadyState(CCmdUI* pCmdUI) {
	if(_whichGA == STEADY_STATE) pCmdUI->SetCheck(1);
	else pCmdUI->SetCheck(0);
}

void CTspdemoView::OnUpdateGAIncremental(CCmdUI* pCmdUI) {
	if(_whichGA == INCREMENTAL) pCmdUI->SetCheck(1);
	else pCmdUI->SetCheck(0);
}

void CTspdemoView::OnUpdateGACrowding(CCmdUI* pCmdUI) {
	if(_whichGA == CROWDING) pCmdUI->SetCheck(1);
	else pCmdUI->SetCheck(0);
}

void CTspdemoView::OnUpdateGADeme(CCmdUI* pCmdUI) {
	if(_whichGA == DEME) pCmdUI->SetCheck(1);
	else pCmdUI->SetCheck(0);
}





void CTspdemoView::OnParameters() {
	if(! _params) {
		_params = new CGAParametersDialog(this);
		_params->m_pcross = pCrossover();
		_params->m_pmut = pMutation();
		_params->m_ngen = nGenerations();
		_params->m_popsize = populationSize();
		if(_params->Create() != TRUE) {
			delete _params;
			_params = 0;
		}
	}
	else {
		_params->ShowWindow(SW_RESTORE);
		_params->EnableWindow();
		_params->UpdateWindow();
//		_params->SetActiveWindow();
	}

	if(_params) {
		_params->GetDlgItem(IDC_APPLY)->EnableWindow(FALSE);
		_params->GetDlgItem(IDC_REVERT)->EnableWindow(FALSE);
	}
}




float CTspdemoView::pCrossover(float n) {
	if(0.0<=n && n<=1.0) {
		_pcross = _theGA->pCrossover(n);
	}
	return _pcross;
}
float CTspdemoView::pMutation(float n) {
	if(0.0<=n && n<=1.0) {
		_pmut = _theGA->pMutation(n);
	}
	return _pmut;
}
int CTspdemoView::populationSize(int n) {
	return _popsize = _theGA->populationSize(n);
}
int CTspdemoView::nGenerations(int n) {
	return _ngen = _theGA->nGenerations(n);
}







int CTspdemoView::ntowns = 0;
double CTspdemoView::DISTANCE[MAX_TOWNS][MAX_TOWNS];
double CTspdemoView::x[MAX_TOWNS];
double CTspdemoView::y[MAX_TOWNS];
double CTspdemoView::theight;
double CTspdemoView::twidth;

// read in the information we need to do the tsp problem
int
CTspdemoView::readConfigFile() {
  ifstream in(TSP_FILE);
  if(in.eof()) {
 //   cerr << "could not read data file " << TSP_FILE << "\n";
    return 1;
  }
  ntowns=0;
  do {
	double dump;
    in >> dump;
    if(!in.eof()) {
      in >> x[ntowns];
      in >> y[ntowns];
      ntowns++;
    }
  } while(!in.eof() && ntowns < MAX_TOWNS);
  in.close();
  if(ntowns >= MAX_TOWNS) {
//    cerr << "data file contains more towns than allowed for in the fixed\n";
//    cerr << "arrays.  Recompile the program with larger arrays or try a\n";
//    cerr << "smaller problem.\n";
    return 1;
  }


  double dx,dy;
  int i, j;
  for(i=0;i<ntowns;i++) {
    for(j=i; j<ntowns;j++) {
      dx=x[i]-x[j]; dy=y[i]-y[j];
      DISTANCE[j][i]=DISTANCE[i][j]=sqrt(dx*dx+dy*dy);
    }
  }
  float minx=MAXFLOAT, maxx=MINFLOAT, miny=MAXFLOAT, maxy=MINFLOAT;
  for(i=0; i<ntowns; i++) {
    minx = (minx < x[i]) ? minx : x[i];
    maxx = (maxx > x[i]) ? maxx : x[i];
  }
  for(i=0; i<ntowns; i++) {
    miny = (miny < y[i]) ? miny : y[i];
    maxy = (maxy > y[i]) ? maxy : y[i];
  }
  twidth = maxx - minx;
  theight = maxy - miny;

  return 0;
}

// Configure the genome and/or genetic algorithm based upon the
// settings that have been specified via the user interface.
// First we create a genome, then we configure it, then we create
// a genetic algorithm using the genome (the GA clones the genome
// to create its population, so the genome must be configured
// before we create the genetic algorithm).  Finally, we set the
// parameters on the genetic algorithm.
void 
CTspdemoView::configure() {
	if(readConfigFile()) return;

	delete _theGenome;

	_theGenome = new GAListGenome<int>;
	_theGenome->initializer(Initializer);
	_theGenome->comparator(Comparator);
	_theGenome->mutator(Mutator);
	_theGenome->crossover(Crossover);
	_theGenome->evaluator(MinimizeDistance);

	delete _theGA;

	GASigmaTruncationScaling sigma;

	switch(_whichGA) {
	case STEADY_STATE: 
		_theGA = new GASteadyStateGA(*_theGenome);
		_theGA->scaling(sigma);
		break;
	case INCREMENTAL:
		_theGA = new GAIncrementalGA(*_theGenome);
		_theGA->scaling(sigma);
		break;
	case DEME:
		_theGA = new GADemeGA(*_theGenome);
		break;
	case CROWDING:
		_theGA = new GADCrowdingGA(*_theGenome);
		break;
	case SIMPLE:
	default:
		_theGA = new GASimpleGA(*_theGenome);
		_theGA->scaling(sigma);
		break;
	}

	_theGA->minimize();
	_theGA->pMutation(_pmut);
	_theGA->pCrossover(_pcross);
	_theGA->nGenerations(_ngen);
	_theGA->populationSize(_popsize);
	_theGA->initialize();
}




// This is the main drawing routine that renders the main window.
// To change how each genome is drawn, you should modify the 
// draw population method.
void 
CTspdemoView::draw(CDC* pDC) {
	TEXTMETRIC  tm;
	pDC->GetTextMetrics( &tm );
	int charht = tm.tmHeight + tm.tmExternalLeading;

	RECT rect;
	GetClientRect(&rect);

	int width = rect.right;
	int height = rect.bottom;

	if(!_theGenome) {
		pDC->SetTextColor(RGB(0,0,255));
		CString txt;
		txt.Format("no data file loaded");
		pDC->TextOut(width/2, height/3, txt);
		txt.Format("expecting file '%s'", TSP_FILE);
		pDC->TextOut(width/2, 2*height/3, txt);
		return;
	}
	else if(_running != 0) {
		pDC->SetTextColor(RGB(0,0,255));
		CString txt;
		txt.Format("evolving... %d", _theGA->generation());
		pDC->TextOut(20, 30, txt);
		return;
	}

 	int txtx = width/2;
	int txty = height - charht -5;

    pDC->SetTextColor(RGB(0,0,255));

	CString txt;
	txt.Format("%d", _theGA->generation());
	pDC->TextOut(txtx, txty, txt);

	static int NCOL=5;
	static int rpval[] = {100,  0,  0,  0,100};
	static int gpval[] = {  0,100,  0,100,100};
	static int bpval[] = {  0,  0,100,100,  0};
	static int rval[]  = {255,  0,  0,  0,255};
	static int gval[]  = {  0,255,  0,255,255};
	static int bval[]  = {  0,  0,255,255,  0};

	if(_whichGA == DEME) {
		GADemeGA& ga = (GADemeGA&)(*_theGA);
		for(int i=0; i<ga.nPopulations(); i++) {
			CPen poppen( PS_SOLID, 2, RGB(rpval[i%NCOL], gpval[i%NCOL], bpval[i%NCOL]) );
			CPen bestpen( PS_SOLID, 2, RGB(rval[i%NCOL], gval[i%NCOL], bval[i%NCOL]) );
			drawPopulation(pDC, ga.population(i), width, height, 10, 10, 
				&poppen, &bestpen);
		}
	}
	else {
		CPen greypen( PS_SOLID, 2, RGB(150,150,150) );
		CPen redpen( PS_SOLID, 2, RGB(255,0,0) );
		drawPopulation(pDC, _theGA->population(), width, height, 10, 10, 
			&greypen, &redpen);
	}
}







// These are the drawing routines that actually render the individual genomes
// to the main window.  If you change the genome type or prefer to see the
// genomes draw a different way, this is the place to do it.

// in ms windows, upper left is 0,0 and lower right is +,+

void 
CTspdemoView::drawPopulation(CDC* pDC, const GAPopulation& pop, 
							int width, int height, int scale, int buf,
							CPen* miscpen, CPen* bestpen) {  
	int nrows = (int)sqrt(1.3333333333 * pop.size()) + 1;
	int ncols = pop.size() / nrows + 1;
	int idx = 0;
	for(int i=0; i<nrows && idx < pop.size(); i++){
		for(int j=0; j<ncols && idx < pop.size(); j++){
		drawIndividual(pDC, pop.best(idx++),
			buf + i*(scale*twidth+buf),
			buf + j*(scale*theight+buf), scale);
		}
	} 
}

void 
CTspdemoView::drawIndividual(CDC* pDC, GAGenome& g, int xx, int yy, int scale) {
	GAListGenome<int>& genome = (GAListGenome<int>&)g;
	if(genome.size() > 0) {
		for(int i=0; i<genome.size()+1; i++){
			int sidx = *genome.current();
			int eidx = *genome.next();
			pDC->MoveTo(xx+scale*x[sidx], yy+scale*y[sidx]);
			pDC->LineTo(xx+scale*x[eidx], yy+scale*y[eidx]);
		}
	}
}








// If your genome needs a custom comparator, crossover, mutator,
// or initializer, define it here.  You can assign it to the
// genome later.  For the TSP we have custom methods for initializing,
// mutating, crossing, and comparison.

void
CTspdemoView::Initializer(GAGenome& g) {
  GAListGenome<int> &child=(GAListGenome<int> &)g;
  while(child.head()) child.destroy(); // destroy any pre-existing list

  int i,town;
  static int visit[MAX_TOWNS];

  memset(visit, 0, MAX_TOWNS*sizeof(int));
  town=GARandomInt(0,ntowns-1);
  visit[town]=1;
  child.insert(town,GAListBASE::HEAD); // the head node
 
  for( i=1; i<ntowns; i++) {
    do {
      town=GARandomInt(0,ntowns-1);
    } while (visit[town]);
    visit[town]=1;
    child.insert(town);
  }             // each subsequent node 
}

int
CTspdemoView::Mutator(GAGenome& g, float pmut) {
  GAListGenome<int> &child=(GAListGenome<int> &)g;
  register int n, i;
  if ((GARandomFloat() >= pmut) || (pmut <= 0)) return 0;

  n = child.size();
  
  if (GARandomFloat()<0.5) {
    child.swap(GARandomInt(0,n-1),GARandomInt(0,n-1)); // swap only one time
  }
  else {
    int nNodes = GARandomInt(1,((int)(n/2-1)));       // displace nNodes 
    child.warp(GARandomInt(0,n-1));                   // with or without
    GAList<int> TmpList;                              // inversion
    for(i=0;i<nNodes;i++) {
      int *iptr = child.remove();
      TmpList.insert(*iptr,GAListBASE::AFTER);
      delete iptr;
      child.next();
    }
    int invert;
    child.warp(GARandomInt(0,n-nNodes));
    invert = (GARandomFloat()<0.5) ? 0 : 1;
    if (invert) TmpList.head(); else TmpList.tail();

    for(i=0;i<nNodes;i++) {
      int *iptr = TmpList.remove();
      child.insert(*iptr,GAListBASE::AFTER);
      delete iptr;
      if (invert) TmpList.prev(); else TmpList.next();
    }
  }
  child.head();         // set iterator to root node

  return (1);
}

int
CTspdemoView::Crossover(const GAGenome& g1, const GAGenome& g2, GAGenome* c1, GAGenome* c2) {
  int nc=0;
  if(c1) { ERXOneChild(g1,g2,c1); nc+=1; }
  if(c2) { ERXOneChild(g1,g2,c2); nc+=1; }
  return nc;
}

void
CTspdemoView::ERXOneChild(const GAGenome& g1, const GAGenome& g2, GAGenome* c1) {
  GAListGenome<int> &mate1=(GAListGenome<int> &)g1;
  GAListGenome<int> &mate2=(GAListGenome<int> &)g2;
  GAListGenome<int> &sis=(GAListGenome<int> &)*c1;
  
  int i,j,k,t1,t2,town;

  static char CM[MAX_TOWNS][MAX_TOWNS],visit[MAX_TOWNS];
  memset(CM, 0, MAX_TOWNS*MAX_TOWNS*sizeof(char));
  memset(visit, 0, MAX_TOWNS*sizeof(char));

  while (sis.head()) sis.destroy();

  // create connection matrix
  mate1.head();
  for(j=0; j<ntowns; j++) {
    t1 = *mate1.current(); t2 = *mate1.next();
    CM[t1][t2]=1; CM[t2][t1]=1;
  }
  mate2.head();
  for(j=0; j<ntowns; j++) {
    t1 = *mate2.current(); t2 = *mate2.next();
    CM[t1][t2]=1; CM[t2][t1]=1;
  }
  
  // select 1st town randomly
  town=GARandomInt(0,ntowns-1);
  visit[town]=1; memset(CM[town], 0, MAX_TOWNS*sizeof(char));
  sis.insert(town); // the head node 
  
  GAList<int> PossFollowList;
  GAList<int> FollowersList[5];
  while (PossFollowList.head()) PossFollowList.destroy();
  for(k=0; k<5; k++) {
    while (FollowersList[k].head()) FollowersList[k].destroy(); 
  }
  
  // select the following town with the minimal no of next folling towns
  int nPoss,nFollow;
  for(i=1; i<ntowns; i++) {           
    nPoss = 0;
    for(j=0; j<ntowns; j++) {          // no of poss. following towns
      if (CM[j][town]) {
        nPoss += 1;
        PossFollowList.insert(j);}
    }
    // nPoss = 0;
    if (nPoss == 0) {
      do {town=GARandomInt(0,ntowns-1);} while (visit[town]); // no follower
      visit[town]=1; memset(CM[town], 0, MAX_TOWNS*sizeof(char));
      sis.insert(town); 
    }
    else {
      PossFollowList.head();
      for(j=0; j<nPoss; j++) {
        nFollow = 0; 
        town = (*PossFollowList.current());
        for(k=0; k<ntowns; k++) {
          if (CM[k][town]) nFollow++; 
        }
        FollowersList[nFollow].insert(town);
        PossFollowList.next();
      }
      k=0;
      while (FollowersList[k].size() == 0) k++;
      FollowersList[k].warp(GARandomInt(0,FollowersList[k].size()));
      town = (*FollowersList[k].current());
      visit[town]=1; memset(CM[town], 0, MAX_TOWNS*sizeof(char));
      sis.insert(town); 
    }
    while (PossFollowList.head()) PossFollowList.destroy();
    for(k=0; k<5; k++) {
      while (FollowersList[k].head()) FollowersList[k].destroy(); 
    }
  }
  sis.head();         // set iterator to head of list
}



float
CTspdemoView::Comparator(const GAGenome& g1, const GAGenome& g2) 
{
  GAListGenome<int> &a = (GAListGenome<int> &)g1;
  GAListGenome<int> &b = (GAListGenome<int> &)g2;

  int i,j,t1,t2;
  float dist=ntowns;

  static char CM1[MAX_TOWNS][MAX_TOWNS],CM2[MAX_TOWNS][MAX_TOWNS];
  memset(CM1, 0, MAX_TOWNS*MAX_TOWNS*sizeof(char));
  memset(CM2, 0, MAX_TOWNS*MAX_TOWNS*sizeof(char));

  // create connection matrix CM1
  a.head();
  for(i=0; i<ntowns; i++) {
    t1 = *a.current(); t2 = *a.next();
    CM1[t1][t2]=1; CM1[t2][t1]=1;
  }
  // create connection matrix CM2
  b.head();
  for(i=0; i<ntowns; i++) {
    t1 = *b.current(); t2 = *b.next();
    CM2[t1][t2]=1; CM2[t2][t1]=1;
  }
  //calc distance = how many edges are different
  for (i=0; i<ntowns; i++) {
    for (j=i; j<ntowns; j++) {
      if (CM1[i][j]&CM2[i][j]) dist--;
    }
  }
  return (dist);
}


// Here is/are the objective function(s) that will be used in
// this application.
float
CTspdemoView::MinimizeDistance(GAGenome& g) {
  GAListGenome<int> & genome = (GAListGenome<int> &)g;
  float dist = 0;
  if(genome.head()) {
    for(int i=0; i<ntowns; i++)
      dist += DISTANCE[*genome.current()][*genome.next()];
  }
  return dist;
}


