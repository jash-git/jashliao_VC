// tspdemoView.h : interface of the CTspdemoView class
//
/////////////////////////////////////////////////////////////////////////////

#include <ga/ga.h>
#include "GAParametersDialog.h"

#if !defined(AFX_TSPDEMOVIEW_H__27ACB97D_9765_11D2_836E_00C04F8F199B__INCLUDED_)
#define AFX_TSPDEMOVIEW_H__27ACB97D_9765_11D2_836E_00C04F8F199B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000




#define MAX_TOWNS 50
#define TSP_FILE "tsp_data.txt"
#define MAXFLOAT 1e10
#define MINFLOAT -1e10



class CTspdemoView : public CView
{
protected: // create from serialization only
	CTspdemoView();
	DECLARE_DYNCREATE(CTspdemoView)

// Attributes
public:
	CTspdemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTspdemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTspdemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTspdemoView)
	afx_msg void OnEvolve();
	afx_msg void OnReset();
	afx_msg void OnStep();
	afx_msg void OnStop();
	afx_msg void OnSelectGACrowding();
	afx_msg void OnSelectGASimple();
	afx_msg void OnSelectGASteadyState();
	afx_msg void OnEvolveSome();
	afx_msg void OnUpdateGACrowding(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGADeme(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGAIncremental(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGASimple(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGASteadyState(CCmdUI* pCmdUI);
	afx_msg void OnSelectGADeme();
	afx_msg void OnSelectGAIncremental();
	afx_msg void OnParameters();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	typedef enum { SIMPLE, STEADY_STATE, INCREMENTAL, DEME, CROWDING } Algorithm;
	typedef enum { MIN_DIST } Function;

	static float MinimizeDistance(GAGenome&);
	static void Initializer(GAGenome&);
	static int Mutator(GAGenome&, float);
	static int Crossover(const GAGenome&, const GAGenome&, GAGenome*, GAGenome*);
	static void ERXOneChild(const GAGenome&, const GAGenome&, GAGenome*);
	static float Comparator(const GAGenome&, const GAGenome&);

	GAGeneticAlgorithm& ga() const { return *_theGA; }
	float pCrossover() const { return _pcross; }
	float pCrossover(float n);
	float pMutation() const { return _pmut; }
	float pMutation(float n);
	int nGenerations() const { return _ngen; }
	int nGenerations(int n);
	int populationSize() const { return _popsize; }
	int populationSize(int n);

protected:
	Algorithm _whichGA;
	Function _whichFunction;
	volatile int _enabled;
	volatile int _running;

	GAGenome* _theGenome;
	GAGeneticAlgorithm* _theGA;
	CGAParametersDialog* _params;

	float _pmut;
	float _pcross;
	int _ngen;
	int _popsize;

	static double DISTANCE[MAX_TOWNS][MAX_TOWNS];
	static double x[MAX_TOWNS],y[MAX_TOWNS];
	static int ntowns;
	static double twidth, theight;
	int readConfigFile();

	void configure();
	void draw(CDC*);
	void drawPopulation(CDC*, const GAPopulation&, int, int, int, int, CPen*,CPen*);
	void drawIndividual(CDC*, GAGenome&, int, int, int);

	static UINT Evolve(LPVOID); 
};

#ifndef _DEBUG  // debug version in tspdemoView.cpp
inline CTspdemoDoc* CTspdemoView::GetDocument()
   { return (CTspdemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TSPDEMOVIEW_H__27ACB97D_9765_11D2_836E_00C04F8F199B__INCLUDED_)
