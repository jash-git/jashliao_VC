/* ----------------------------------------------------------------------------
  version.h
  mbwall 10oct98

   This is the header file to keep track of the versions and revisions of the
GA library.  You can use the ident command to extract the version of galib
that you are using.
---------------------------------------------------------------------------- */
#ifndef _version_h_
#define _version_h_

static char *rcsid = "$Date: 1998/10/10 22:25:33 $ $Revision: 2.4.3 $";

#endif
