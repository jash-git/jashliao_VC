// ServerDlg.h : header file
//

#if !defined(AFX_SERVERDLG_H__E8CA8A80_BBF1_4E7F_9AE4_8119DF6EE94E__INCLUDED_)
#define AFX_SERVERDLG_H__E8CA8A80_BBF1_4E7F_9AE4_8119DF6EE94E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CServerDlg dialog

class CServerDlg : public CDialog
{

	IGraphBuilder  *m_pGraph ;
	IBaseFilter *m_pVidDeviceFilter;
	IBaseFilter *m_pAudDeviceFilter;
	IMediaControl *m_pMediaControl;
	IMediaEvent *m_pEvent ; //Media Event interface for capture the media events
	IBaseFilter *m_pWMASFWritter ; //IBase Filter for WMASFWritter 
	IFileSinkFilter* m_pFileSinkFilter;
	IWMWriterAdvanced2 *m_pWriter2 ; //Windows media writer advanced from WMF
	IWMWriterNetworkSink *m_pNetSink;
	IServiceProvider *m_pProvider ;
	
// Construction
public:
	GetAudeoDevices(CString strDevName,IBaseFilter **pFilter);
	HRESULT ConnectFilters(IGraphBuilder *pGraph,IBaseFilter *pFirst, IBaseFilter *pSecond,CString strAsfFilterPin);
	IPin* GetPinByName(IBaseFilter *pFilter, LPCOLESTR pinname);
	BOOL StartStreaming();
	HRESULT GetPin(IBaseFilter *pFilter, PIN_DIRECTION PinDir, IPin **ppPin);
	HRESULT ConnectFilters(IGraphBuilder *pGraph, IBaseFilter *pFirst, IBaseFilter *pSecond);
	GetVideoDevices(CString strDevName,IBaseFilter **pFilter);
	CServerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CServerDlg)
	enum { IDD = IDD_SERVER_DIALOG };
	CStatic	m_StaticUrl;
	CEdit	m_EditPort;
	CButton	m_btnStop;
	CButton	m_btnPause;
	CButton	m_btnStart;
	CComboBox	m_CboAudioDevices;
	CComboBox	m_CboVideoDevices;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CServerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonPause();
	afx_msg void OnButtonStop();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERDLG_H__E8CA8A80_BBF1_4E7F_9AE4_8119DF6EE94E__INCLUDED_)
