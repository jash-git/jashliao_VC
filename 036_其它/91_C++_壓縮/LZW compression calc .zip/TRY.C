  #include "graph.h"   
  #include "math.h"
  #include "stdio.h" 
  double pi=3.14159;
  double n=36.0;
    static double xx[]={150.0,200.0,210.0,60.0,150.0};
    static double zz[]={0.0,0.0,0.0,0.0,0.0};
    static double xy[]={-55.0,-20.0,50.0,40.0,-55.0};
    static double f[4][4];
    int i;
    double th;
    double x,y,z;
    double x0,y0,z0; 
    void affine(void);
    void affine3(double *x,double *y,double *z);
    void rotate_y(double theta_y);
    void axis(void);
    void main(void)
     { 
       int graphdriver=DETECT,graphmode;
       initgraph(&graphdriver,&graphmode,"");
       cleardevice();
       setactivepage(0);
       setvisualpage(0);
       setbkcolor(1);
       axis();
       th=pi/n;
       rotate_y(th);
       affine();
       getch();
       closegraph();
              
     } 
     
   void axis(void)
    {
      line(320,240,600,240);
      line(320,240,320,100);
      
    }  
   void rotate_y(double theta_y)
    {
       double co=cos(theta_y),si=sin(theta_y);
       f[0][0]=co;f[0][1]=si;
       f[0][3]=0.0;
       f[1][0]=0.0;f[1][1]=1.0;
       f[1][2]=0.0;f[1][3]=0.0;
       f[2][0]=-si;f[2][1]=0.0;
       f[2][2]=co;f[2][3]=0.0;
       f[3][0]=0.0;f[3][1]=0.0;
       f[3][2]=0.0;f[3][3]=1.0;
       
    }  
   void affine3(double *x,*y,*z)
    {
      double _x,_y,_z;
      _x=*x;_y=*y;_z=*z;
      *x=_x*f[0][0]+_y*f[1][0]+_z*f[2][0]+f[3][0];
      *y=_x*f[0][1]+_y*f[1][1]+_z*f[2][1]+f[3][1];
      *z=_x*f[0][2]+_y*f[1][2]+_z*f[2][2]+f[3][2];
      
    } 
   void affine(void)
    {
      for(th=0.0;th<2*pi;th+=pi/n){
        for(i=0;i<4;i++){
          x=xx[i];y=yy[i];z=zz[i];
          affine3(&x,&y,&z);
          if(i==0)
             putpixel(320+(int)x,240-(int)y,1);
          else{
             setcolor(5);
             line(320+(int)x0,240-(int)y0,320+(int)x,240-(int)y);
          }
          xx[i]=x0=x;yy[i]=y0=y;zz[i]=z0=z;   
        }
      }
    } 