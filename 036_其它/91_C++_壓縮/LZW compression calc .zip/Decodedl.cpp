// decodedl.cpp : implementation file
//

#include "stdafx.h"
#include "tlzw.h"
#include "decodedl.h"     
#include "lzwtable.h"
#include "lzwcode.h"
#include "lzwfile.h"
#include "batchdlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDecodeDlg dialog


CDecodeDlg::CDecodeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDecodeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDecodeDlg)
	m_szDirName = "";
	m_szHGLZName = "";
	//}}AFX_DATA_INIT
}

void CDecodeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDecodeDlg)
	DDX_Control(pDX, IDC_ALL_FILES, m_listFiles);
	DDX_Text(pDX, IDC_DIR_NAME, m_szDirName);
	DDX_Text(pDX, IDC_HGLZ_NAME, m_szHGLZName);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDecodeDlg, CDialog)
	//{{AFX_MSG_MAP(CDecodeDlg)
	ON_BN_CLICKED(IDC_SEL_HGLZ, OnSelHglz)
	ON_BN_CLICKED(IDC_DECOMPRESS, OnDecompress)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDecodeDlg message handlers

void CDecodeDlg::OnSelHglz()
{
	CString szF("HGLZ Files (*.HLZ) | *.HLZ ||");
	CFileDialog dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szF);
	if(dlg.DoModal()==IDOK)
	{
		CString szOut=dlg.GetPathName();
		m_szHGLZName=szOut;
		UpdateData(FALSE);
	}
	else
		return;
	CStringArray array;
	m_listFiles.ResetContent();
	if(LZWParseFileHead(m_szHGLZName,array))
	{
		for(int i=0;i<array.GetUpperBound()+1;i++)
		{
			CString szName=array.GetAt(i);
			m_listFiles.AddString(szName);
		}
	}
	array.RemoveAll();
	
}

void CDecodeDlg::OnDecompress()
{
	UpdateData();
	if(m_szHGLZName.GetLength()==0)
	{
		AfxMessageBox("file name invalid");
		return;
	}
	int iSelCount=m_listFiles.GetSelCount();
	if(LB_ERR==iSelCount || 0==iSelCount)
		return;
	int *piSel=new int[iSelCount];
	if(LB_ERR==m_listFiles.GetSelItems(iSelCount,piSel))
		return;
	CBatchDlg dlg(m_szHGLZName,m_szDirName,piSel,iSelCount);
	dlg.DoModal();
	delete piSel;
/*	for(int i=0;i<iSelCount;i++)//<iSelCount
	{
		LZWDecodeFileOnPosition(m_szHGLZName,m_szDirName,(DWORD)piSel[i],NULL);
	}
	AfxMessageBox("end decompress");
*/	
}
