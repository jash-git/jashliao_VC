// singledl.cpp : implementation file
//

#include "stdafx.h"
#include "tlzw.h"
#include "singledl.h"
#include "lzwtable.h"
#include "lzwcode.h"
#include "lzwfile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSingleDlg dialog


CSingleDlg::CSingleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSingleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSingleDlg)
	m_szIn = "";
	m_szOut = "";
	//}}AFX_DATA_INIT
}

void CSingleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSingleDlg)
	DDX_Text(pDX, IDC_IN, m_szIn);
	DDX_Text(pDX, IDC_OUT, m_szOut);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSingleDlg, CDialog)
	//{{AFX_MSG_MAP(CSingleDlg)
	ON_BN_CLICKED(IDC_BEGIN, OnBegin)
	ON_BN_CLICKED(IDC_DECODE, OnDecode)
	ON_BN_CLICKED(IDC_PARSE, OnParse)
	ON_BN_CLICKED(IDC_SEL_FILE, OnSelFile)
	ON_BN_CLICKED(IDC_APPEND, OnAppend)
	ON_BN_CLICKED(IDC_SEL_HLZ, OnSelHlz)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CSingleDlg message handlers

void CSingleDlg::OnBegin()
{
	UpdateData();
	if(m_szIn.GetLength()==0 || m_szOut.GetLength()==0)
	{
		AfxMessageBox("file name invalid");
		return;
	}
	LZWEncodeFile(m_szIn,m_szOut);
	AfxMessageBox("end compress");
}

void CSingleDlg::OnParse()
{
	UpdateData();
	if(m_szOut.GetLength()==0)
	{
		AfxMessageBox("file name invalid");
		return;
	}
	LZWParseFileHead(m_szOut);
	
}

void CSingleDlg::OnDecode()
{
	//return;
	UpdateData();
	if(m_szIn.GetLength()==0 || m_szOut.GetLength()==0)
	{
		AfxMessageBox("file name invalid");
		return;
	}
	LZWDecodeFileToFile(m_szOut,m_szIn);
	AfxMessageBox("end decompress");
}

void CSingleDlg::OnSelFile()
{
	CString szF("All Files (*.*) | *.* ||");
	CFileDialog dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szF);
	if(dlg.DoModal()==IDOK)
	{
		CString szFileIn=dlg.GetPathName();
		CString szFileOut=szFileIn;
		CString szFileExt=dlg.GetFileExt();
		if(szFileExt.GetLength())
		{
			char szFN[300];
			sprintf(szFN,"%s",szFileOut);
			szFN[szFileOut.GetLength()-szFileExt.GetLength()-1]='\0';
			szFileOut=szFN;
			szFileOut+=".HLZ";
		}
		else
			szFileOut+=".HLZ";
		m_szIn=szFileIn;
		m_szOut=szFileOut;
		UpdateData(FALSE);
	}
}


void CSingleDlg::OnAppend()
{
	UpdateData();
	if(m_szIn.GetLength()==0 || m_szOut.GetLength()==0)
	{
		AfxMessageBox("file name invalida");
		return;
	}
	LZWAddEncodeFile(m_szIn,m_szOut);
	AfxMessageBox("end append");
}

void CSingleDlg::OnSelHlz()
{
	UpdateData(TRUE);
	CString szF("HGLZ Files (*.HLZ) | *.HLZ ||");
	CFileDialog dlg(TRUE,"*.HLZ",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szF);
	if(dlg.DoModal()==IDOK)
	{
		CString szOut=dlg.GetPathName();
		m_szOut=szOut;
		UpdateData(FALSE);
	}
}
