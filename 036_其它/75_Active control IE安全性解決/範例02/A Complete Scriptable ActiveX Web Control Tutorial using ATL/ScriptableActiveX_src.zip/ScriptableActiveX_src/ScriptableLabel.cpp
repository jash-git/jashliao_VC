// ScriptableLabel.cpp : Implementation of CScriptableLabel

#include "stdafx.h"
#include "ScriptableActiveX.h"
#include "ScriptableLabel.h"

/////////////////////////////////////////////////////////////////////////////
// CScriptableLabel

STDMETHODIMP CScriptableLabel::SetClientSite(LPOLECLIENTSITE pSite)
{
    HRESULT hr = CComControlBase::IOleObject_SetClientSite(pSite);
    if(!m_pFont && pSite)
    {
        hr = GetAmbientFontDisp(&m_pFont);
    }
    GetAmbientBackColor(m_clrBackColor);
    GetAmbientForeColor(m_clrForeColor);
    return hr;
}
