// ScriptableLabel.h : Declaration of the CScriptableLabel

#ifndef __SCRIPTABLELABEL_H_
#define __SCRIPTABLELABEL_H_

#include "resource.h"       // main symbols
#include <atlctl.h>


/////////////////////////////////////////////////////////////////////////////
// CScriptableLabel
class ATL_NO_VTABLE CScriptableLabel : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CScriptableLabel, IScriptableLabel, &IID_IScriptableLabel, &LIBID_SCRIPTABLEACTIVEXLib>,
	public CComControl<CScriptableLabel>,
	public IPersistStreamInitImpl<CScriptableLabel>,
	public IPersistPropertyBagImpl<CScriptableLabel>,
	public IObjectSafetyImpl<CScriptableLabel, 
                        INTERFACESAFE_FOR_UNTRUSTED_CALLER | 
                        INTERFACESAFE_FOR_UNTRUSTED_DATA>,
	public IOleControlImpl<CScriptableLabel>,
	public IOleObjectImpl<CScriptableLabel>,
	public IOleInPlaceActiveObjectImpl<CScriptableLabel>,
	public IViewObjectExImpl<CScriptableLabel>,
	public IOleInPlaceObjectWindowlessImpl<CScriptableLabel>,
	public IConnectionPointContainerImpl<CScriptableLabel>,
	public IPersistStorageImpl<CScriptableLabel>,
	public ISpecifyPropertyPagesImpl<CScriptableLabel>,
	public IQuickActivateImpl<CScriptableLabel>,
	public IDataObjectImpl<CScriptableLabel>,
	public IProvideClassInfo2Impl<&CLSID_ScriptableLabel, &DIID__IScriptableLabelEvents, &LIBID_SCRIPTABLEACTIVEXLib>,
	public IPropertyNotifySinkCP<CScriptableLabel>,
	public CComCoClass<CScriptableLabel, &CLSID_ScriptableLabel>
{
public:
	CContainedWindow m_ctlStatic;
	

	CScriptableLabel() :	
		m_ctlStatic(_T("Static"), this, 1)
	{
		m_bWindowOnly = TRUE;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCRIPTABLELABEL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CScriptableLabel)
	COM_INTERFACE_ENTRY(IScriptableLabel)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
	COM_INTERFACE_ENTRY(IObjectSafety)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CScriptableLabel)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("BackColor", DISPID_BACKCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("Caption", DISPID_CAPTION, CLSID_NULL)
	PROP_ENTRY("Font", DISPID_FONT, CLSID_StockFontPage)
	PROP_ENTRY("ForeColor", DISPID_FORECOLOR, CLSID_StockColorPage)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CScriptableLabel)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CScriptableLabel)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	CHAIN_MSG_MAP(CComControl<CScriptableLabel>)
ALT_MSG_MAP(1)
	// Replace this with message map entries for superclassed Static
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);


	LRESULT OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		LRESULT lRes = CComControl<CScriptableLabel>::OnSetFocus(uMsg, wParam, lParam, bHandled);
		if (m_bInPlaceActive)
		{
			DoVerbUIActivate(&m_rcPos,  NULL);
			if(!IsChild(::GetFocus()))
				m_ctlStatic.SetFocus();
		}
		return lRes;
	}

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		RECT rc;
		GetWindowRect(&rc);
		rc.right -= rc.left;
		rc.bottom -= rc.top;
		rc.top = rc.left = 0;
		//m_ctlStatic.Create(m_hWnd, rc);
		m_ctlStatic.Create( m_hWnd,
                    rc, 
                    _T("Static"),
                    WS_CHILD|WM_PAINT);
		return 0;
	}
	STDMETHOD(SetObjectRects)(LPCRECT prcPos,LPCRECT prcClip)
	{
		IOleInPlaceObjectWindowlessImpl<CScriptableLabel>::SetObjectRects(prcPos, prcClip);
		int cx, cy;
		cx = prcPos->right - prcPos->left;
		cy = prcPos->bottom - prcPos->top;
		::SetWindowPos(m_ctlStatic.m_hWnd, NULL, 0,
			0, cx, cy, SWP_NOZORDER | SWP_NOACTIVATE);
		return S_OK;
	}

	STDMETHOD(SetClientSite)(LPOLECLIENTSITE pSite);

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IScriptableLabel
public:
	OLE_COLOR m_clrBackColor;
	CComBSTR m_bstrCaption;
	CComPtr<IFontDisp> m_pFont;
	OLE_COLOR m_clrForeColor;

	void DrawString( HDC hdc, RECT* rc, BSTR caption )
	{
		USES_CONVERSION;		
		TCHAR* pCaption = OLE2T(caption);

		DrawText( hdc,
				 pCaption,
				 lstrlen( pCaption ),
				 rc,
				 DT_WORDBREAK );
	}

	HRESULT OnDraw(ATL_DRAWINFO& di)
	{
		RECT& rc  = *(RECT*)di.prcBounds;
		HDC   hdc = di.hdcDraw;

		COLORREF clrFore, clrBack;
		OleTranslateColor(m_clrForeColor, NULL, &clrFore);
		OleTranslateColor(m_clrBackColor, NULL, &clrBack);
		SetTextColor(hdc, m_clrForeColor);
		HBRUSH hbrBtn = CreateSolidBrush(m_clrBackColor);

		FillRect(hdc, &rc, hbrBtn);		
		DrawString(hdc, &rc, m_bstrCaption);	

		DeleteObject(hbrBtn);
		return 0;
	}
};

#endif //__SCRIPTABLELABEL_H_
