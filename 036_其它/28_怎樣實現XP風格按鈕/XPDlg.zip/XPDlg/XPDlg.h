// XPDlg.h : main header file for the XPDLG application
//

#if !defined(AFX_XPDLG_H__EABE9213_BAD8_4F84_B04D_17190734BF09__INCLUDED_)
#define AFX_XPDLG_H__EABE9213_BAD8_4F84_B04D_17190734BF09__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXPDlgApp:
// See XPDlg.cpp for the implementation of this class
//

class CXPDlgApp : public CWinApp
{
public:
	CXPDlgApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXPDlgApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CXPDlgApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XPDLG_H__EABE9213_BAD8_4F84_B04D_17190734BF09__INCLUDED_)
