// ShutdownComputer.h : main header file for the SHUTDOWNCOMPUTER application
//

#if !defined(AFX_SHUTDOWNCOMPUTER_H__F6059A14_E153_4443_8529_AF90DDE08776__INCLUDED_)
#define AFX_SHUTDOWNCOMPUTER_H__F6059A14_E153_4443_8529_AF90DDE08776__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CShutdownComputerApp:
// See ShutdownComputer.cpp for the implementation of this class
//

//##ModelId=3DB7B498021B
class CShutdownComputerApp : public CWinApp
{
public:
	//##ModelId=3DB7B498022F
	CShutdownComputerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShutdownComputerApp)
	public:
	//##ModelId=3DB7B4980230
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CShutdownComputerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHUTDOWNCOMPUTER_H__F6059A14_E153_4443_8529_AF90DDE08776__INCLUDED_)
