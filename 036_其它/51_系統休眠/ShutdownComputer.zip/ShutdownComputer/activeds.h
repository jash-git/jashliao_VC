// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// IADsComputerOperations wrapper class

//##ModelId=3DB7B498024D
class IADsComputerOperations : public COleDispatchDriver
{
public:
	//##ModelId=3DB7B4980258
	IADsComputerOperations() {}		// Calls COleDispatchDriver default constructor
	//##ModelId=3DB7B4980259
	IADsComputerOperations(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	//##ModelId=3DB7B4980262
	IADsComputerOperations(const IADsComputerOperations& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	//##ModelId=3DB7B498026B
	CString GetName();
	//##ModelId=3DB7B498026C
	CString GetClass();
	//##ModelId=3DB7B4980275
	CString GetGuid();
	//##ModelId=3DB7B4980276
	CString GetADsPath();
	//##ModelId=3DB7B498027F
	CString GetParent();
	//##ModelId=3DB7B4980280
	CString GetSchema();
	//##ModelId=3DB7B4980289
	void GetInfo();
	//##ModelId=3DB7B498028A
	void SetInfo();
	//##ModelId=3DB7B4980293
	VARIANT Get(LPCTSTR bstrName);
	//##ModelId=3DB7B498029D
	void Put(LPCTSTR bstrName, const VARIANT& vProp);
	//##ModelId=3DB7B49802A7
	VARIANT GetEx(LPCTSTR bstrName);
	//##ModelId=3DB7B49802B1
	void PutEx(long lnControlCode, LPCTSTR bstrName, const VARIANT& vProp);
	//##ModelId=3DB7B49802BC
	void GetInfoEx(const VARIANT& vProperties, long lnReserved);
	//##ModelId=3DB7B49802C7
	LPDISPATCH Status();
	//##ModelId=3DB7B49802D0
	void Shutdown(BOOL bReboot);
};
