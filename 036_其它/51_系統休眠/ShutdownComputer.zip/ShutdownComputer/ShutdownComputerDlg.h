// ShutdownComputerDlg.h : header file
//

#if !defined(AFX_SHUTDOWNCOMPUTERDLG_H__C6B5CC76_3105_4887_965E_0BDC75AC8609__INCLUDED_)
#define AFX_SHUTDOWNCOMPUTERDLG_H__C6B5CC76_3105_4887_965E_0BDC75AC8609__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CShutdownComputerDlg dialog

//##ModelId=3DB7B498014A
class CShutdownComputerDlg : public CDialog
{
// Construction
public:
	//##ModelId=3DB7B4980153
	CShutdownComputerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CShutdownComputerDlg)
	enum { IDD = IDD_SHUTDOWNCOMPUTER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShutdownComputerDlg)
	protected:
	//##ModelId=3DB7B498015D
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//##ModelId=3DB7B4980168
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CShutdownComputerDlg)
	//##ModelId=3DB7B49801C1
	virtual BOOL OnInitDialog();
	//##ModelId=3DB7B49801CB
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//##ModelId=3DB7B49801DF
	afx_msg void OnPaint();
	//##ModelId=3DB7B49801E9
	afx_msg HCURSOR OnQueryDragIcon();
	//##ModelId=3DB7B49801EB
	afx_msg void OnButton1();
	//##ModelId=3DB7B49801F4
	afx_msg void OnTimer(UINT nIDEvent);
	//##ModelId=3DB7B4980207
	afx_msg void OnButton2();
	//##ModelId=3DB7B4980209
	afx_msg void OnButton3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHUTDOWNCOMPUTERDLG_H__C6B5CC76_3105_4887_965E_0BDC75AC8609__INCLUDED_)
