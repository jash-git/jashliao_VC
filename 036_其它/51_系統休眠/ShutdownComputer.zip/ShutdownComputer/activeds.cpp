// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "activeds.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// IADsComputerOperations properties

/////////////////////////////////////////////////////////////////////////////
// IADsComputerOperations operations

//##ModelId=3DB7B498026B
CString IADsComputerOperations::GetName()
{
	CString result;
	InvokeHelper(0x2, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

//##ModelId=3DB7B498026C
CString IADsComputerOperations::GetClass()
{
	CString result;
	InvokeHelper(0x3, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

//##ModelId=3DB7B4980275
CString IADsComputerOperations::GetGuid()
{
	CString result;
	InvokeHelper(0x4, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

//##ModelId=3DB7B4980276
CString IADsComputerOperations::GetADsPath()
{
	CString result;
	InvokeHelper(0x5, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

//##ModelId=3DB7B498027F
CString IADsComputerOperations::GetParent()
{
	CString result;
	InvokeHelper(0x6, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

//##ModelId=3DB7B4980280
CString IADsComputerOperations::GetSchema()
{
	CString result;
	InvokeHelper(0x7, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

//##ModelId=3DB7B4980289
void IADsComputerOperations::GetInfo()
{
	InvokeHelper(0x8, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

//##ModelId=3DB7B498028A
void IADsComputerOperations::SetInfo()
{
	InvokeHelper(0x9, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

//##ModelId=3DB7B4980293
VARIANT IADsComputerOperations::Get(LPCTSTR bstrName)
{
	VARIANT result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0xa, DISPATCH_METHOD, VT_VARIANT, (void*)&result, parms,
		bstrName);
	return result;
}

//##ModelId=3DB7B498029D
void IADsComputerOperations::Put(LPCTSTR bstrName, const VARIANT& vProp)
{
	static BYTE parms[] =
		VTS_BSTR VTS_VARIANT;
	InvokeHelper(0xb, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 bstrName, &vProp);
}

//##ModelId=3DB7B49802A7
VARIANT IADsComputerOperations::GetEx(LPCTSTR bstrName)
{
	VARIANT result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0xc, DISPATCH_METHOD, VT_VARIANT, (void*)&result, parms,
		bstrName);
	return result;
}

//##ModelId=3DB7B49802B1
void IADsComputerOperations::PutEx(long lnControlCode, LPCTSTR bstrName, const VARIANT& vProp)
{
	static BYTE parms[] =
		VTS_I4 VTS_BSTR VTS_VARIANT;
	InvokeHelper(0xd, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 lnControlCode, bstrName, &vProp);
}

//##ModelId=3DB7B49802BC
void IADsComputerOperations::GetInfoEx(const VARIANT& vProperties, long lnReserved)
{
	static BYTE parms[] =
		VTS_VARIANT VTS_I4;
	InvokeHelper(0xe, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 &vProperties, lnReserved);
}

//##ModelId=3DB7B49802C7
LPDISPATCH IADsComputerOperations::Status()
{
	LPDISPATCH result;
	InvokeHelper(0x21, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

//##ModelId=3DB7B49802D0
void IADsComputerOperations::Shutdown(BOOL bReboot)
{
	static BYTE parms[] =
		VTS_BOOL;
	InvokeHelper(0x22, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 bReboot);
}
