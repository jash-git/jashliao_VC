// ShutdownComputerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ShutdownComputer.h"
#include "ShutdownComputerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif





INT SetPower();
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

//##ModelId=3DB7B49802DA
class CAboutDlg : public CDialog
{
public:
	//##ModelId=3DB7B49802EE
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	public:
	//##ModelId=3DB7B49802F8
	virtual BOOL DestroyWindow();
	protected:
	//##ModelId=3DB7B4980302
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//##ModelId=3DB7B49802EE
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

//##ModelId=3DB7B4980302
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShutdownComputerDlg dialog

//##ModelId=3DB7B4980153
CShutdownComputerDlg::CShutdownComputerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShutdownComputerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShutdownComputerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

//##ModelId=3DB7B498015D
void CShutdownComputerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShutdownComputerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShutdownComputerDlg, CDialog)
	//{{AFX_MSG_MAP(CShutdownComputerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()	
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShutdownComputerDlg message handlers

//##ModelId=3DB7B49801C1
BOOL CShutdownComputerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	BringWindowToTop();
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	SetWindowPos(&wndTopMost,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);
	// TODO: Add extra initialization here
	SetTimer(1,1000,NULL);	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

//##ModelId=3DB7B49801CB
void CShutdownComputerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

//##ModelId=3DB7B49801DF
void CShutdownComputerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
//##ModelId=3DB7B49801E9
HCURSOR CShutdownComputerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}





void  PERR(LPTSTR szAPI, DWORD dwLastError);
#define RTN_ERROR 13
INT SetPower()
{
	
	// TODO: Add your control notificationhandler code here
   TOKEN_PRIVILEGES tp;
    HANDLE hToken;
	LUID luid;

   LPTSTR MachineName=NULL; // pointer to machine name

	if(!OpenProcessToken(GetCurrentProcess(),
                        TOKEN_ADJUST_PRIVILEGES,
                        &hToken ))
    {
        PERR("OpenProcessToken", GetLastError() );
        return RTN_ERROR;
    }

    if(!LookupPrivilegeValue(MachineName, SE_SHUTDOWN_NAME, &luid))

    {
        PERR("LookupPrivilegeValue", GetLastError() );
        return RTN_ERROR;
    }

    tp.PrivilegeCount           = 1;
    tp.Privileges[0].Luid       = luid;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES),
                                NULL, NULL );

        SetSystemPowerState(FALSE,TRUE);			    
		return 0;

}
//##ModelId=3DB7B49801EB
void CShutdownComputerDlg::OnButton1() 
{
	SetPower();	
	OnOK();
}

void PERR(
    LPTSTR szAPI,       // pointer to failed API name
    DWORD dwLastError   // last error value associated with API
    )
{
    LPTSTR MessageBuffer;
    DWORD dwBufferLength;

    // 
    // TODO get this fprintf out of here!
    // 
    fprintf(stderr,"%s error! (rc=%lu)\n", szAPI, dwLastError);

    if(dwBufferLength=FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
                                    FORMAT_MESSAGE_FROM_SYSTEM,
                                    NULL,
                                    dwLastError,
                                    LANG_NEUTRAL,
                                    (LPTSTR) &MessageBuffer,
                                    0,
                                    NULL))
    {


        DWORD dwBytesWritten;

        // 
        // Output message string on stderr
        // 
        WriteFile(GetStdHandle(STD_ERROR_HANDLE),
                  MessageBuffer,
                  dwBufferLength,
                  &dwBytesWritten,
                  NULL);

        // 
        // free the buffer allocated by the system
        // 
        LocalFree(MessageBuffer);
    }
} 

//##ModelId=3DB7B49801F4
void CShutdownComputerDlg::OnTimer(UINT nIDEvent) 
{	
	// TODO: Add your message handler code here and/or call default
	static UINT counter=0;	
	Beep(500+50*counter,200);
	counter++;
	if(counter>10)
	{
		  Beep(1000,2000);		  		  
		  KillTimer(1);
	 	  SetPower();				  
		  OnOK();
	}
	TCHAR captionmsg[256];
	sprintf(captionmsg,"��������״̬ - %02d",10-counter);	
    SetWindowText(captionmsg);
	CDialog::OnTimer(nIDEvent);
}



//##ModelId=3DB7B49802F8
BOOL CAboutDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	KillTimer(1);
	return CDialog::DestroyWindow();
}

//##ModelId=3DB7B4980207
void CShutdownComputerDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
		SetPower();
		OnOK();
}

//##ModelId=3DB7B4980209
void CShutdownComputerDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here	
	KillTimer(1);
	OnOK();	
}
