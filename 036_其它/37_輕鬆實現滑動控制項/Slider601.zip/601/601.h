// 601.h : main header file for the 601 application
//

#if !defined(AFX_601_H__3B1651E1_6D99_47E0_85AD_ACE45D7BACBB__INCLUDED_)
#define AFX_601_H__3B1651E1_6D99_47E0_85AD_ACE45D7BACBB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMy601App:
// See 601.cpp for the implementation of this class
//

class CMy601App : public CWinApp
{
public:
	CMy601App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy601App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMy601App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_601_H__3B1651E1_6D99_47E0_85AD_ACE45D7BACBB__INCLUDED_)
