class AFX_EXT_CLASS CMousehook:public CObject
{
public:
	CMousehook();
	~CMousehook();
	
	BOOL starthook();
	BOOL stophook();
	VOID SetCheck1(UINT i);
	VOID SetCheck2(UINT i);
	VOID SetCheck3(UINT i);
	static BOOL CALLBACK EnumWindowsProc(HWND hwnd,LPARAM lParam);

	VOID UseForExit();
};




