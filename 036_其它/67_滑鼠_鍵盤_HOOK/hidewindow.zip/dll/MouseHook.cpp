// MouseHook.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>
#include "MouseHook.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#pragma data_seg("mydata") 
HINSTANCE glhInstance=NULL;
HHOOK glhHook=NULL;
HWND  GlobalWndHandle[100]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
							NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
							NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
							NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                            NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
UINT  Global_i=0;
BOOL  Condition1=0;
BOOL  Condition2=0;
BOOL  HideOrVisitableFlag=0;
BOOL  Check1=0; 
BOOL  Check2=0;
BOOL  Check3=0;

#pragma data_seg() 

#define DLLEXPORT _declspec(dllexport)
extern "C" DLLEXPORT LRESULT WINAPI MouseProc(int nCode,WPARAM wParam,LPARAM lParam);

static AFX_EXTENSION_MODULE MouseHookDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("MOUSEHOOK.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(MouseHookDLL, hInstance))
			return 0;

		new CDynLinkLibrary(MouseHookDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("MOUSEHOOK.DLL Terminating!\n");
		// Terminate the library before destructors are called
		AfxTermExtensionModule(MouseHookDLL);
	}
	glhInstance=hInstance;
	return 1;   
}
CMousehook::CMousehook() 
{ 

} 
CMousehook::~CMousehook() 
{ 
	stophook(); 
}

BOOL CMousehook::starthook()
{
	BOOL bResult=false;
	glhHook=::SetWindowsHookEx(WH_MOUSE,MouseProc,glhInstance,0);
	if(glhHook!=NULL)
		bResult=true;

	return bResult;
}

BOOL CMousehook::stophook() 
{ 
    BOOL bResult=FALSE; 
    if(glhHook) 
	{ 
		{
		bResult=UnhookWindowsHookEx(glhHook); 
        if(bResult) 
		{
		   glhHook=NULL;
		}
		} 
         
	}return bResult; 
}

extern "C" _declspec(dllexport) LRESULT WINAPI MouseProc(int nCode,WPARAM wParam,LPARAM lParam)
{
	if(nCode>=0) 
	{
		if(wParam==WM_LBUTTONDOWN)
			Condition1=1;
		if(wParam==WM_LBUTTONUP)
			Condition1=0;
		if(wParam==WM_RBUTTONDOWN)
			Condition2=1;
		if(wParam==WM_RBUTTONUP)
			Condition2=0;

		if(Condition1 & Condition2)
		{
			Condition1=Condition2=0;
			HideOrVisitableFlag=!HideOrVisitableFlag;
			if(HideOrVisitableFlag)
			{
				::EnumWindows(CMousehook::EnumWindowsProc,NULL);
			}

			if(!HideOrVisitableFlag)	
				while(Global_i>0)
				{   
					Global_i--;	
					::ShowWindow(GlobalWndHandle[Global_i],SW_SHOW);
				}
		}
		return CallNextHookEx(glhHook,nCode,wParam,lParam);
	
	}
    return CallNextHookEx(glhHook,nCode,wParam,lParam);
}

BOOL CMousehook::EnumWindowsProc(HWND hwnd,LPARAM lParam)
{   
	char buff[256];
	if(Check1==0)
	{	
		::GetWindowText(hwnd,buff,255);
		if(!lstrcmp(buff,"Program Manager"))
			return 1;
	}

	if(Check2==0)
	{
		::GetClassName(hwnd,buff,255);
	    if(!lstrcmp(buff,"Shell_TrayWnd"))
			return 1;
	}

	if(GetWindowLong(hwnd,GWL_STYLE) & WS_VISIBLE)
	{
		if(Check3)
		{
			::GetWindowText(hwnd,buff,255);
		    if(!lstrcmp(buff,"ħ��һ��"))
			return 1;
			::ShowWindow(hwnd,SW_HIDE);
			::SendMessage(hwnd,WM_CLOSE,0,0);
			//::SendMessage(hwnd,WM_DESTROY,0,0);
			//::SendMessage(hwnd,WM_NCDESTROY,0,0);
			return 1;
		}
	    GlobalWndHandle[Global_i]=hwnd;
		Global_i++;
		ShowWindow(hwnd,SW_HIDE);
	}

	return 1;
}


VOID CMousehook::SetCheck1(UINT i)
{
	Check1=i;
}

VOID CMousehook::SetCheck2(UINT i)
{
	Check2=i;
}

VOID CMousehook::SetCheck3(UINT i)
{
	Check3=i;
}

VOID CMousehook::UseForExit()
{	
		while(Global_i>0)
		{   
			Global_i--;	
			::ShowWindow(GlobalWndHandle[Global_i],SW_SHOW);
		}
	
}

/*
HHOOK SetWindowsHookEx( int idHook, HOOK_PROC lpfn, HINSTANCE hMod,DWORD dwThreadID);

����˵���� 
idHook �����ӵ�����

lpfn �����Ӵ���������ַ

hMod ���������Ӻ�����ģ����

dwThreadID �����ӵļ���߳�

����˵������������ϵͳ�й���һ����idHookָ�����͵Ĺ��ӣ���ز�������Ӧ���ض���Ϣ��



BOOL UnhookWindowsHookEx( HHOOK hhk );
����˵����������������hhkָ���Ĺ��ӡ�


LRESULT CallNextHookEx( HHOOK hhk, int nCode, WPARAM wParam,LPARAM lParam );
����˵������������Ϣ���´��ݣ���һ�����Ӵ������ػ���һ��Ϣ��
*/