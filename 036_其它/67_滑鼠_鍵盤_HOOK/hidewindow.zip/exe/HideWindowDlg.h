// HideWindowDlg.h : header file
//

#if !defined(AFX_HIDEWINDOWDLG_H__8381247E_D044_47D3_9D83_06F1DAB5A73C__INCLUDED_)
#define AFX_HIDEWINDOWDLG_H__8381247E_D044_47D3_9D83_06F1DAB5A73C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "MouseHook.h"
/////////////////////////////////////////////////////////////////////////////
// CHideWindowDlg dialog

class CHideWindowDlg : public CDialog
{
// Construction
public:
	CHideWindowDlg(CWnd* pParent = NULL);// standard constructor
	~CHideWindowDlg();

	void ModifyIcon();
	void DeleteIcon();
	void AddIcon();
	NOTIFYICONDATA m_notify;
	BOOL m_bOpen;

protected:
	UINT i,j,k;//Use for Checks;
	CMousehook hook;

// Dialog Data
	//{{AFX_DATA(CHideWindowDlg)
	enum { IDD = IDD_HIDEWINDOW_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHideWindowDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHideWindowDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCheck1();
	afx_msg void OnCheck2();
	virtual void OnCancel();
	afx_msg void OnCheck3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HIDEWINDOWDLG_H__8381247E_D044_47D3_9D83_06F1DAB5A73C__INCLUDED_)
