// DynCreateCtrlDlg.h : header file
//

#if !defined(AFX_DYNCREATECTRLDLG_H__75C7D0E0_F531_4810_9A6C_20948BFBA249__INCLUDED_)
#define AFX_DYNCREATECTRLDLG_H__75C7D0E0_F531_4810_9A6C_20948BFBA249__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDynCreateCtrlDlg dialog

class CDynCreateCtrlDlg : public CDialog
{
// Construction
public:
	CDynCreateCtrlDlg(CWnd* pParent = NULL);	// standard constructor
	CEdit	 	m_MyEdit;
// Dialog Data
	//{{AFX_DATA(CDynCreateCtrlDlg)
	enum { IDD = IDD_DYNCREATECTRL_DIALOG };
	CString	m_StaticCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDynCreateCtrlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDynCreateCtrlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnChangeEdit();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DYNCREATECTRLDLG_H__75C7D0E0_F531_4810_9A6C_20948BFBA249__INCLUDED_)
