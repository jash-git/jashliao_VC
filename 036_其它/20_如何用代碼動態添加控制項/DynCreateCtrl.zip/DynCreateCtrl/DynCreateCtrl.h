// DynCreateCtrl.h : main header file for the DYNCREATECTRL application
//

#if !defined(AFX_DYNCREATECTRL_H__D4AFF538_47E2_4FA3_958E_D014D4EEA67C__INCLUDED_)
#define AFX_DYNCREATECTRL_H__D4AFF538_47E2_4FA3_958E_D014D4EEA67C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDynCreateCtrlApp:
// See DynCreateCtrl.cpp for the implementation of this class
//

class CDynCreateCtrlApp : public CWinApp
{
public:
	CDynCreateCtrlApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDynCreateCtrlApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDynCreateCtrlApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DYNCREATECTRL_H__D4AFF538_47E2_4FA3_958E_D014D4EEA67C__INCLUDED_)
