/* /% C %/ */
/***********************************************************************
 * cint (C/C++ interpreter)
 ************************************************************************
 * Header file lib/pthread/thread.h
 ************************************************************************
 * Description:
 *  Create POSIX Thread function interface
 ************************************************************************/

/* Please read README file in this directory */

#ifndef G__THREADDLL_H
#define G__THREADDLL_H

#include <pthread.h>




#endif
