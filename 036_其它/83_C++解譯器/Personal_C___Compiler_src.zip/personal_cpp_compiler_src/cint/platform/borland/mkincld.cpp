
#pragma hdrstop
#include <condefs.h>

USEUNIT("mkincld2.c");
//---------------------------------------------------------------------------
extern "C" int G__main();
//---------------------------------------------------------------------------
#pragma argsused
int main(int argc, char **argv)
{
        return(G__main());
}
