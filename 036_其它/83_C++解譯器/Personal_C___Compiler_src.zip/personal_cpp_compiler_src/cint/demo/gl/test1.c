#include <GL/glut.h>
#include "display1.dll"

void init (void)
{
   glClearColor (0.0, 0.0, 0.0, 0.0);

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
   glutInitWindowSize (250, 250);
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("hello");
   init ();
   glutDisplayFunc(display); /* call back functions must be precompiled */
   glutKeyboardFunc(key);    /* call back functions must be precompiled */
   printf("\n!!!Move cursor to the graphic window annd press ESC to quit!!!\n");
   glutMainLoop();
   return 0; 
}
