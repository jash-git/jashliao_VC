demo/errpipe/README.txt

  This directory contains a simple example for using Cint's error message
 redirection. You need to compile Cint with -DG__ERRORCALLBACK flag in 
 OTHMACRO. (Refer to platform/README.txt)

FILES:

   README.txt    : This file
   errpipe.h     : Program to be precompiled
   errpipe.cxx   : Program to be interpreted
   setup         : Demo script


RUNNING:

    $ sh setup
