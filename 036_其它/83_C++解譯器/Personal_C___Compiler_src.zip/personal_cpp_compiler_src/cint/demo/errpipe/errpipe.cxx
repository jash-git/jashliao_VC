
#include "errpipe.dll"

int main() {
  InitializeDump();
  a;
  printf("%s\n",x);
}
