File: $CINTSYSDIR/demo/graphs/README

 Demonstration of scientific calculation and XY graph plotting. You need 
'xgraph' utility and X window to run these scripts. These examples show
you good examples of how C++ scripts look like.

	$ cint eular.c
	$ cint fir.c
	$ cint fir2.c
	$ cint stripline.c
	    .
	    .

