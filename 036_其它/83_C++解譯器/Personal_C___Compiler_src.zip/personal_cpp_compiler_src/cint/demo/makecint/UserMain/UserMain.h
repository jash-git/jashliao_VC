
// precompiled library
void f1(int i) ;
void f2(double d) ;

