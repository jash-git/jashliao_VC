#ifndef STUB_H
#define STUB_H

#include "Complex.h"

#ifdef __CINT__

void Display(Complex a);

#else

void Display();

#endif


#endif
