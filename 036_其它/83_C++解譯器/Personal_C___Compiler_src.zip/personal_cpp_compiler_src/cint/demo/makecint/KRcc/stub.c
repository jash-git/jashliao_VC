#include "stub.h"

void Display(Complex a) {
	printf("re=%g im=%g\n",a.re,a.im);
}
