demo/makecint/p2f/README

 This directory contains example of pointer to function handling in CINT.
This example also presents '#pragma compile' and '#pragma bytecode' features
to accelerate execution.  Highly experimental. 

 Refer to p2f.C for how to use pointer to function between compiled and 
interpreted code.

Try following script.

    UNIX
	sh setup

    WinNT Visual C++
	setup.bat

    WinNT Symantec C++
	scsetup.bat
