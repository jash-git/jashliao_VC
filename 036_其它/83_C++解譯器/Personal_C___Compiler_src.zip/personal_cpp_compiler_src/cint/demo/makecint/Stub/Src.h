// Src.h , Compiled function header

#ifndef SRC_H
#define SRC_H

double f2(double din,int iin) ; 

int pain();

#endif
