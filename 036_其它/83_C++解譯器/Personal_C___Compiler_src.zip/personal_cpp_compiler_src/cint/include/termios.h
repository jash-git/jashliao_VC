/* dummy termios.h */
