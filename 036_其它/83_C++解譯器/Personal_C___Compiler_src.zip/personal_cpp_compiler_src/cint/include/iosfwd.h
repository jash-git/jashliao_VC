#ifndef G__IOSFWD_H
#define G__IOSFWD_H
#include <iostream.h>
#endif
