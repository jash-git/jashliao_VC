/* dummy timespec.h */
