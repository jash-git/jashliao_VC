//    Copyright (C) 2005  Charles Lazo

//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



#pragma once

#include "resource.h"

#define WSA_ASYNC WM_USER + 1                    // our asynch notification message
#define BASE1900 9435484800                      // number of seconds from January 1, 1601 to January 1, 1900 (UTC)
//#define BASE1970 11644473600                     // number of seconds from January 1, 1601 to January 1, 1970 (UTC)
#define MAXSTRSIZE 80                            // maximum length of strings displayed in the client area

ULONG BigIndian2UL(unsigned char *);
void DisplayTime(ULONG, HWND);
BOOL GetString(int, int, char *);
void PromptServer(SOCKET&, HWND, char *);
void ReadServer(SOCKET, HWND, BOOL);
void SetString(char *, HWND);
void SynchronizeClock(ULONG, HWND);
char *ULONG2String(ULONG);
void WSAError(int, char *, HWND);
