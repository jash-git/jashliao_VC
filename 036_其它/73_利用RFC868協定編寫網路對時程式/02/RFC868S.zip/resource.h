//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RFC868.rc
//
#define IDC_MYICON                      2
#define IDD_RFC868_DIALOG               102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_RFC868                      107
#define IDI_SMALL                       108
#define IDC_RFC868                      109
#define IDR_MAINFRAME                   128
#define ID_HELP_RFC868PROGRAMHELP       129
#define IDR_ACCELERATOR1                130
#define ID_FILE_EXTRACTSOURCECODE       131
#define ID_SETCLOCK_CHOOSETIMESERVER    132
#define ID_SETCLOCK_SYNCRONIZECLOCK     133
#define IDD_TIMESERVER                  134
#define IDD_DIALOG1                     135
#define ID_SETCLOCK_CHOOSESERVER        136
#define ID_SETCLOCK_DISPLAYTIME         137
#define ID_HELP_GNULICENSEAGREEMENT     138
#define ID_HELP_RFC868TIMEPROTOCOL      139
#define ID_HELP_INTERNETTIMESERVICE     140
#define ID_HELP_EMAILAUTHOR             141
#define ID_HELP_DOWNLOADSOURCECODE      142
#define IDC_LIST1                       1002
#define IDC_SERVER                      1002
#define IDC_LIST2                       1003
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
