//    Copyright (C) 2005  Charles Lazo

//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



#include "stdafx.h"
#include "RFC868.h"

#define MSGSIZE 333                    // MAX message length
#define LINESIZE 99                    // MAX line length

char msgBuf[MSGSIZE];
char lineBuf[LINESIZE];

ULONG BigIndian2UL(unsigned char *Buf)
{
  return ((ULONG)Buf[0] << 24) + ((ULONG)Buf[1] << 16) + ((ULONG)Buf[2] << 8) + (ULONG)Buf[3];
}

char buf[LINESIZE];

char *ULONG2String(ULONG ulValue)
{
  ULONG units, thousands, millions, billions;

  units = ulValue % 1000;
  ulValue -= units;
  ulValue /= 1000;
  thousands = ulValue % 1000;
  ulValue -= thousands;
  ulValue /= 1000;
  millions = ulValue % 1000;
  ulValue -= millions;
  ulValue /= 1000;
  billions = ulValue;
  sprintf(buf, "%lu,%lu,%lu,%lu", billions, millions, thousands, units);
  return buf;
}

SYSTEMTIME st;
FILETIME FileTime;
char *DayOfWeek[7] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

void DisplaySystemTime(SYSTEMTIME st, HWND hWnd)
{
  sprintf(lineBuf, "%s %u-%u-%u  %u:%u:%u",
  DayOfWeek[st.wDayOfWeek],
  st.wYear,
  st.wMonth,
  st.wDay,
  st.wHour,
  st.wMinute,
  st.wSecond);
  SetString(lineBuf, hWnd);
}

void SynchronizeClock(ULONG seconds, HWND hWnd)
{
  _int64 thistime = seconds + BASE1900;

  lineBuf[0] = 0;
  SetString(lineBuf, hWnd);
  strcpy(lineBuf, "System Time was:");
  SetString(lineBuf, hWnd);
  GetSystemTime(&st);
  DisplaySystemTime(st, hWnd);
  strcpy(lineBuf, "COORDINATED UNIVERSAL TIME");
  SetString(lineBuf, hWnd);
  thistime *= 10000000;
  FileTime.dwHighDateTime = (DWORD)(thistime >> 32);
  FileTime.dwLowDateTime = (DWORD)thistime;
  FileTimeToSystemTime(&FileTime, &st);
  SetSystemTime(&st);
  lineBuf[0] = 0;
  SetString(lineBuf, hWnd);
  strcpy(lineBuf, "Syncronized with the Server the System Time is now:");
  SetString(lineBuf, hWnd);
  DisplaySystemTime(st, hWnd);
  strcpy(lineBuf, "COORDINATED UNIVERSAL TIME");
  SetString(lineBuf, hWnd);
}

void DisplayTime(ULONG seconds, HWND hWnd)
{
  _int64 thistime = seconds + BASE1900;

  thistime *= 10000000;
  FileTime.dwHighDateTime = (DWORD)(thistime >> 32);
  FileTime.dwLowDateTime = (DWORD)thistime;
  FileTimeToSystemTime(&FileTime, &st);

  lineBuf[0] = 0;
  SetString(lineBuf, hWnd);

  sprintf(lineBuf, "Server reports %s seconds since Jan 1, 1900", ULONG2String(seconds));
  SetString(lineBuf, hWnd);

  lineBuf[0] = 0;
  SetString(lineBuf, hWnd);

  DisplaySystemTime(st, hWnd);

  strcpy(lineBuf, "COORDINATED UNIVERSAL TIME");
  SetString(lineBuf, hWnd);

  lineBuf[0] = 0;
  SetString(lineBuf, hWnd);

  FileTimeToLocalFileTime(&FileTime, &FileTime);
  FileTimeToSystemTime(&FileTime, &st);
  DisplaySystemTime(st, hWnd);

  strcpy(lineBuf, "LOCAL TIME");
  SetString(lineBuf, hWnd);

  lineBuf[0] = 0;
  SetString(lineBuf, hWnd);
}

void ComplainNoMemory(HWND hWnd)
{
  MessageBox(hWnd, "Cannot Allocate Memory", "RFC868 Client", MB_OK | MB_ICONSTOP);
	PostQuitMessage(0);                  // Terminate with extreme prejudice.
}

// The SetString() and GetString() functions work together to provide a scrolling display of events
// reported in the client area.  The memory allocated can accommodate MAXCOUNT strings.  When this
// table is full new strings overwrite old ones and the CurrentPos location pointer indicates the
// next position in the table to store a string.

#define MAXCOUNT 40

BOOL bFirstTime = TRUE;
HANDLE hMem;
PSTR pMem;
int CurrentPos = 0;
int StrCount;

void SetString(char *string, HWND hWnd)
{
  RECT r;

  if (bFirstTime)                                // the first time here we allocate memory
  {
    hMem = HeapCreate(0, MAXSTRSIZE * MAXCOUNT, 0);
    if (!hMem)
    {
      ComplainNoMemory(hWnd);
      return;
    }
    pMem = (PSTR)HeapAlloc(hMem, 0, MAXSTRSIZE * MAXCOUNT);
    if (!pMem)
    {
      ComplainNoMemory(hWnd);
      return;
    }
    bFirstTime = FALSE;
  }

  string[MAXSTRSIZE-1] = 0;                      // truncate to maximum size
  strcpy(pMem + CurrentPos * MAXSTRSIZE, string);// place string in array
  CurrentPos = ++CurrentPos % MAXCOUNT;          // wrap to the beginning if necessary
  if (StrCount < MAXCOUNT) StrCount++;           // increment if not maxed out
  GetClientRect(hWnd, &r);
  InvalidateRect(hWnd, &r, TRUE);
}

BOOL GetString(int i, int maxdesired, char *string)
{
  int index;

  if (!pMem) return FALSE;                       // none stored
  if (i == maxdesired) return FALSE;             // we want no more
  if (i == StrCount) return FALSE;               // no more to be had
  index = CurrentPos - StrCount + i;             // point to 'i'th string
  if (StrCount > maxdesired)                     // if there are more strings than can be displayed...
    index += StrCount - maxdesired;              // then bump the index to move to the end
  if (index < 0) index += MAXCOUNT;
  index %= MAXCOUNT;                             // wrap if necessary (maybe never?)
  strcpy(string, pMem + index * MAXSTRSIZE);     // copy it to passed buffer
  return TRUE;
}






















