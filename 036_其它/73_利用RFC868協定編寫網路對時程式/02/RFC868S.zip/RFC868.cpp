//    Copyright (C) 2005  Charles Lazo

//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



// RFC868.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "RFC868.h"

#define MAX_LOADSTRING 100
#define WS_VERSION_REQD	0x0101         // WinSock Version 1.1 required

// Global Variables:
HINSTANCE hInst;								       // current instance
TCHAR szTitle[MAX_LOADSTRING];         // The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];   // the main window class name
WSADATA stWSAData;                     // WinSock DLL Info
SOCKET hSocket = INVALID_SOCKET;       // WinSock socket handle

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ChooseTimeServer(HWND, UINT, WPARAM, LPARAM);
void WSAError(int, char *, HWND);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;
  int nRet;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_RFC868, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_RFC868);

  nRet = WSAStartup(WS_VERSION_REQD, &stWSAData);
  if (nRet) WSAError(nRet, "WSAStartup()", NULL);
  else                                 // continue only if WinSock init success
  {
	  // Main message loop:
	  while (GetMessage(&msg, NULL, 0, 0)) 
	  {
		  if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		  {
			  TranslateMessage(&msg);
			  DispatchMessage(&msg);
		  }
	  }
  }

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_RFC868);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCTSTR)IDC_RFC868;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
  HWND hWnd;

  hInst = hInstance; // Store instance handle in our global variable

  int wide = GetSystemMetrics(SM_CXFULLSCREEN);
  int high = GetSystemMetrics(SM_CYFULLSCREEN)+GetSystemMetrics(SM_CYCAPTION);

  hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
    (wide - 500)/2, (high - 400)/2, 500, 500, NULL, NULL, hInstance, NULL);

  if (!hWnd)
  {
    return FALSE;
  }

  ShowWindow(hWnd, nCmdShow);
  UpdateWindow(hWnd);

  return TRUE;
}

int nServerListItem = -1;              // index of chosen server
char SelText[MAX_LOADSTRING];          // selected text:  name of time server
#define SERVERLISTSIZE 14

// WARNING:  Be careful to keep the two arrays below in sync when adding or removing items.
//           Each server IP corresponds one-for-one with the corresponding description.

// This list was obtained from the NIST Internet Time Servers webpage:  http://www.boulder.nist.gov/timefreq/service/time-servers.html.

char *IP_List[SERVERLISTSIZE] = {
  "129.6.15.28",
  "129.6.15.29",
  "132.163.4.101",
  "132.163.4.102",
  "132.163.4.103",
  "128.138.140.44",
  "192.43.244.18",
  "131.107.1.10",
  "69.25.96.13",
  "216.200.93.8",
  "208.184.49.9",
  "207.126.98.204",
  "207.200.81.113",
  "64.236.96.53"
};

char *ServerList[SERVERLISTSIZE] = {
  "time-a.nist.gov --- NIST  Gaithersburg, Maryland",
  "time-b.nist.gov --- NIST  Gaithersburg, Maryland",
  "time-a.timefreq.bldrdoc.gov --- NIST  Boulder, Colorado",
  "time-b.timefreq.bldrdoc.gov --- NIST  Boulder, Colorado",
  "time-c.timefreq.bldrdoc.gov --- NIST  Boulder, Colorado",
  "utcnist.colorado.edu --- University of Colorado, Boulder",
  "time.nist.gov --- NCAR  Boulder, Colorado",
  "time-nw.nist.gov --- Microsoft, Redmond, Washington",
  "nist1.symmetricom.com --- Symmetricom, San Jose, California",
  "nist1-dc.glassey.com --- Abovenet, Virginia",
  "nist1-ny.glassey.com --- Abovenet, New York City",
  "nist1-sj.glassey.com --- Abovenet, San Jose, California",
  "nist1.aol-ca.truetime.com --- TrueTime, AOL facility, Sunnyvale, California",
  "nist1.aol-va.truetime.com --- TrueTime, AOL facility, Virginia"
};

void QueryServer(HWND hWnd)
{
  int nRet;                            // return code

  if (nServerListItem >= 0)
  {
    if (hSocket != INVALID_SOCKET)
    {
      nRet = closesocket(hSocket);
      if (nRet == SOCKET_ERROR) WSAError(WSAGetLastError(), "closesocket()", hWnd);
      hSocket = INVALID_SOCKET;
    }
    PromptServer(hSocket, hWnd, IP_List[nServerListItem]);
  }
  else MessageBox(hWnd, "Please choose a Time Server first.", "RFC868 Client", MB_OK);
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//

BOOL bSyncClock = FALSE;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  int wmId, wmEvent, nRet;
  PAINTSTRUCT ps;
  HDC hdc;
  WORD WSAEvent, WSAErr;

  switch (message) 
  {
  case WSA_ASYNC:
    WSAEvent = WSAGETSELECTEVENT (lParam); // LOWORD
    WSAErr   = WSAGETSELECTERROR (lParam); // HIWORD
    if (WSAErr) WSAError(WSAErr, "FD_READ", hWnd);
    else if (WSAEvent == FD_READ) ReadServer(hSocket, hWnd, bSyncClock);
		break;
  case WM_COMMAND:
	  wmId    = LOWORD(wParam); 
	  wmEvent = HIWORD(wParam); 
	  // Parse the menu selections:
	  switch (wmId)
	  {
	  case IDM_ABOUT:
		  DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
		  break;
    case ID_HELP_RFC868PROGRAMHELP:
      nRet = (int)ShellExecute(hWnd, "open", "http://4nax.com/RFC868 Documentation.html", NULL, NULL, SW_SHOW);
      if (nRet < 33) MessageBox(hWnd, "Sorry, couldn't open RFC868 program documentation.", "RFC868 Client", MB_OK | MB_ICONQUESTION);
			break;
    case ID_HELP_GNULICENSEAGREEMENT:
      nRet = (int)ShellExecute(hWnd, "open", "http://www.gnu.org/copyleft/gpl.html", NULL, NULL, SW_SHOW);
      if (nRet < 33) MessageBox(hWnd, "Sorry, couldn't open the GNU web page.", "RFC868 Client", MB_OK | MB_ICONQUESTION);
			break;
    case ID_HELP_RFC868TIMEPROTOCOL:
      nRet = (int)ShellExecute(hWnd, "open", "http://www.faqs.org/rfcs/rfc868.html", NULL, NULL, SW_SHOW);
      if (nRet < 33) MessageBox(hWnd, "Sorry, couldn't open the RFC868 web document.", "RFC868 Client", MB_OK | MB_ICONQUESTION);
			break;
    case ID_HELP_INTERNETTIMESERVICE:
      nRet = (int)ShellExecute(hWnd, "open", "http://www.boulder.nist.gov/timefreq/service/its.htm", NULL, NULL, SW_SHOW);
      if (nRet < 33) MessageBox(hWnd, "Sorry, couldn't open the Internet Time Service web document.", "RFC868 Client", MB_OK | MB_ICONQUESTION);
			break;
    case ID_HELP_EMAILAUTHOR:
      nRet = (int)ShellExecute(hWnd, "open", "mailto:charles@4nax.com", NULL, NULL, SW_SHOW);
      if (nRet < 33) MessageBox(hWnd, "Sorry, couldn't open email application.", "RFC868 Client", MB_OK | MB_ICONQUESTION);
			break;
    case ID_HELP_DOWNLOADSOURCECODE:
      nRet = (int)ShellExecute(hWnd, "open", "http://4nax.com/RFC868 Help.html", NULL, NULL, SW_SHOW);
      if (nRet < 33) MessageBox(hWnd, "Sorry, couldn't open RFC868 program documentation.", "RFC868 Client", MB_OK | MB_ICONQUESTION);
			break;
    case ID_SETCLOCK_CHOOSESERVER:
		  DialogBox(hInst, (LPCTSTR)IDD_TIMESERVER, hWnd, (DLGPROC)ChooseTimeServer);
      if (nServerListItem >= 0) SetString(SelText, hWnd);
			break;
    case ID_SETCLOCK_DISPLAYTIME:
      QueryServer(hWnd);
      bSyncClock = FALSE;
			break;
    case ID_SETCLOCK_SYNCRONIZECLOCK:
      QueryServer(hWnd);
      bSyncClock = TRUE;
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
    SIZE Size;
    RECT r;
    int high, count, i;
    char s[MAXSTRSIZE];

    GetClientRect(hWnd, &r);
    high = r.bottom - r.top;
    GetTextExtentPoint32(hdc, "SAMPLE TEXT", 11, &Size);
    count = high / Size.cy;
    for (i = 0; GetString(i, count, s); i++) TextOut(hdc, 0, i * Size.cy, s, (int)strlen(s));
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
		{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;
	}
	return FALSE;
}


// Message handler for Time Server selection.
LRESULT CALLBACK ChooseTimeServer(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
  int wmId = LOWORD(wParam), wmEvent = HIWORD(wParam);
  HWND hwndList;

	switch (message)
	{
	case WM_INITDIALOG:
    hwndList = GetDlgItem(hDlg, IDC_SERVER);
    for (int i = 0; i < SERVERLISTSIZE; i++) SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)ServerList[i]);
		return TRUE;

	case WM_COMMAND:
    switch (wmId)
    {
      case IDC_SERVER:
        if (wmEvent == LBN_SELCHANGE)
        {
          hwndList = GetDlgItem(hDlg, IDC_SERVER);
          nServerListItem = (int)SendMessage(hwndList, LB_GETCURSEL, 0, 0);
        }
			  break;
      case IDCANCEL:
			  return TRUE;
      case IDOK:
        if (nServerListItem >= 0)
        {
          hwndList = GetDlgItem(hDlg, IDC_SERVER);
          SendMessage(hwndList, LB_GETTEXT, nServerListItem, (LPARAM)SelText);
        }
			  EndDialog(hDlg, LOWORD(wParam));
    }
	}
	return FALSE;
}


void WSAError(int errno, char *errmsg, HWND hwnd)
{
  char msg[99];

  sprintf(msg, "%s, error #%i", errmsg, errno);
  MessageBox(hwnd, msg, "RFC868 Error", MB_OK);
}



