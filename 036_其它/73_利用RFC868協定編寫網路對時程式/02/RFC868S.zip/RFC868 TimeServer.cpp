//    Copyright (C) 2005  Charles Lazo

//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



#include "stdafx.h"
#include "RFC868.h"

#define BUFSIZE 16                     // must be at least 4

SOCKADDR_IN sa;                        // socket address structure
unsigned char inBuf[BUFSIZE];
                                       // SOCKET modified, so pass a reference
void PromptServer(SOCKET& hSocket, HWND hWnd, char *ServerIP)
{
  char Packet[] = " ";                 // send "anything" to get the server's attention
  int nRet;                            // socket function return values

  hSocket = socket(AF_INET, SOCK_DGRAM, 0);      // Get a UDP socket.
  if (hSocket == INVALID_SOCKET)
  {
    WSAError(WSAGetLastError(), "socket()", hWnd);
    return;
  }

  // Request async notification of incoming data.
  nRet = WSAAsyncSelect(hSocket, hWnd, WSA_ASYNC, FD_READ);
  if (nRet == SOCKET_ERROR)
  {
    WSAError(WSAGetLastError(), "WSAAsyncSelect()", hWnd);
    return;
  }
  sa.sin_family = PF_INET;
  sa.sin_port   = htons(IPPORT_TIMESERVER);
  sa.sin_addr.s_addr = INADDR_ANY;
  nRet = bind(hSocket, (sockaddr *)&sa, sizeof(SOCKADDR_IN));
  if (nRet == SOCKET_ERROR)
  {
    WSAError(WSAGetLastError(), "bind()", hWnd);
    return;
  }
  sa.sin_addr.s_addr = inet_addr(ServerIP);      // WARNING:  This should only fail if IP_List[] and ServerList[] are not in sync!
  sa.sin_family = PF_INET;
  sa.sin_port   = htons (IPPORT_TIMESERVER);
  nRet = sendto(hSocket, Packet, 1, 0, (sockaddr *)&sa, sizeof(SOCKADDR_IN));
  if (nRet == SOCKET_ERROR)
  {
    WSAError(WSAGetLastError(), "sendto()", hWnd);
    return;
  }
}

void ReadServer(SOCKET hSocket, HWND hWnd, BOOL bSyncClock)
{
  int nAddrSize = sizeof(SOCKADDR_IN), nRet;

  // Receive the available data
  nRet = recvfrom (hSocket, (char *)inBuf, BUFSIZE, 0, (sockaddr *)&sa, &nAddrSize);

  // Tell user if receive failed.
  if (nRet == SOCKET_ERROR)
  {
    WSAError(WSAGetLastError(), "recvfrom()", hWnd);
    return;
  }

  if (bSyncClock) SynchronizeClock(BigIndian2UL(inBuf), hWnd);
  else DisplayTime(BigIndian2UL(inBuf), hWnd);
}









































