// calldllDlg.h : header file
//

#if !defined(AFX_CALLDLLDLG_H__111F06F2_136D_4261_817B_320E83B9E1A1__INCLUDED_)
#define AFX_CALLDLLDLG_H__111F06F2_136D_4261_817B_320E83B9E1A1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\..\mfcexpenddll\SXBUTTON.h"
#pragma comment(lib,"mfcexpenddll.lib") 
/////////////////////////////////////////////////////////////////////////////
// CCalldllDlg dialog

class CCalldllDlg : public CDialog
{
// Construction
public:
	CCalldllDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCalldllDlg)
	enum { IDD = IDD_CALLDLL_DIALOG };
	CSXButton	m_button2;
	CSXButton	m_button1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalldllDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCalldllDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALLDLLDLG_H__111F06F2_136D_4261_817B_320E83B9E1A1__INCLUDED_)
