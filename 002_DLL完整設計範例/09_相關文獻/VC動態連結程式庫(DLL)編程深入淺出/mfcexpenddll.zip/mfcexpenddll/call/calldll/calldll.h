// calldll.h : main header file for the CALLDLL application
//

#if !defined(AFX_CALLDLL_H__8694F4EA_3EE4_4B2C_B799_6CCFDB314676__INCLUDED_)
#define AFX_CALLDLL_H__8694F4EA_3EE4_4B2C_B799_6CCFDB314676__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCalldllApp:
// See calldll.cpp for the implementation of this class
//

class CCalldllApp : public CWinApp
{
public:
	CCalldllApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalldllApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCalldllApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALLDLL_H__8694F4EA_3EE4_4B2C_B799_6CCFDB314676__INCLUDED_)
