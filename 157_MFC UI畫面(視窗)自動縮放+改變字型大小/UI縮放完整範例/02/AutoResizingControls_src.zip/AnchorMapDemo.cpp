// AnchorMapDemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "AnchorMapDemo.h"
#include "AnchorMapDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAnchorMapDemoApp

BEGIN_MESSAGE_MAP(CAnchorMapDemoApp, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


// CAnchorMapDemoApp construction

CAnchorMapDemoApp::CAnchorMapDemoApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CAnchorMapDemoApp object
CAnchorMapDemoApp theApp;

// CAnchorMapDemoApp initialization

// ======================================================================================================
// ======================================================================================================
BOOL CAnchorMapDemoApp::InitInstance() {
char                szPathName[1024];
char                szDir[512];
char                szDrv[512];
char                szName[512];
char                szExt[512];
CCommandLineInfo    cmdInfo;


    // get our "HomePath"
    GetModuleFileName((HMODULE)m_hInstance, (LPSTR)&szPathName, sizeof(szPathName));
    _splitpath(szPathName, szDrv, szDir, szName, szExt);
    m_csHomePath.Format("%s%s", szDrv, szDir);
    m_csHomePath.TrimRight((TCHAR)'\\');


	CWinApp::InitInstance();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	CAnchorMapDemoDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
// ======================================================================================================
// ======================================================================================================
int CAnchorMapDemoApp::ExitInstance() {

    return CWinApp::ExitInstance();
}









