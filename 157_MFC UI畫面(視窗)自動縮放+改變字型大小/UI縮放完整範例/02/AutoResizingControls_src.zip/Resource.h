//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AnchorMapDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ANCHORMAPDEMO_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDEB_NOTES                      1000
#define IDPG_LEVEL                      1001
#define IDEB_FIRST_NAME                 1002
#define IDEB_LAST_NAME                  1003
#define IDEB_EMAIL                      1004
#define IDEB_PHONE1                     1005
#define IDEB_PHONE2                     1006
#define IDCB_SKILL1                     1007
#define IDCB_SKILL2                     1008
#define IDCB_SKILL3                     1009
#define IDCB_SKILL4                     1010
#define IDCB_SKILL5                     1011
#define IDCB_SKILL6                     1012
#define IDLB_GROUPS                     1013
#define IDPB_HELP                       1014
#define IDC_BUTTON3                     1016
#define IDST_HEADER                     1017
#define IDC_LINE1                       1018
#define IDST_FIRST_NAME                 1019
#define IDST_LAST_NAME                  1020
#define IDST_EMAIL                      1021
#define IDST_PHONE                      1022
#define IDST_SKILLBOX                   1023
#define IDGB_SKILLBOX                   1023
#define IDST_GROUPS                     1024
#define IDST_NOTES                      1025
#define IDC_LINE2                       1026
#define IDC_SCROLLBAR1                  1027
#define ID_TET                          32771
#define ID_TET_SADFASDF                 32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
