// AnchorMapDemo.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

// CAnchorMapDemoApp:
// See AnchorMapDemo.cpp for the implementation of this class
//

//<--<BP>-->
class CAnchorMapDemoApp : public CWinApp {
//<--<BP>-->
public:
	CAnchorMapDemoApp();
	
//<--<BP>-->
    
public:
    // execution directory (without \)
	CString m_csHomePath;   
	
	
// �berschreibungen
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementierung

	DECLARE_MESSAGE_MAP()
	
//<--<BP>-->
//<--<BP>-->	
};

//<--<BP>-->

extern CAnchorMapDemoApp theApp;

//<--<BP>-->








