using System;
using System.Collections.Generic;
using System.Text;

namespace SOFM
{
    public enum Functions
    {
        Discrete,
        Gaus,
        MexicanHat,
        FrenchHat
    }
}
