// 功能：代码 2-4 Mat 转换为 IplImage 类型和 CvMat 类型
// 作者：朱伟 zhu1988wei@163.com
// 来源：《OpenCV图像处理编程实例》
// 博客：http://blog.csdn.net/zhuwei1988
// 更新：2016-8-1
// 说明：版权所有，引用或摘录请联系作者，并按照上面格式注明出处，谢谢。

cv::Mat img;  
CvMat cvMatImg = img; 
IplImage IplImg = img;
