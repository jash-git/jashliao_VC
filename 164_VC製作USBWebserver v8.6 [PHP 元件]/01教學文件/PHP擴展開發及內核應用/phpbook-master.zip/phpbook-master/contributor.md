# 《PHP扩展开发与内核应用》贡献者名单

根据首次参与时间，升序排列：

 * Walu, [weibo.com/walu](<http://weibo.com/walu>)，项目发起人。
 * Laruence, [weibo.com/laruence](<weibo.com/laruence>)，[Blog](<http://www.laruence.com>)，PHP开发组成员, Yaf, Taint, APC等Pecl扩展作者、维护者。鸟哥，不知道的话你就out了...
 * Demon，[weibo.com/409238807](<http://weibo.com/409238807>)，[Blog](<http://www.demon.at>)
 * 花生，[weibo.com/723441938](<http://weibo.com/723441938>)，[Blog](<http://wenjun.in>)
 * Guoguo，[github.com/goosman-lei](<https://github.com/goosman-lei/>)，14-20章内容提供者。
