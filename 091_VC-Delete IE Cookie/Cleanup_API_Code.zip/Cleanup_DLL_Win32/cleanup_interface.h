__declspec( dllexport ) BOOL Delete_IECache(BOOL bDeleteCache = TRUE, 
											    BOOL bDeleteCacheIndex = FALSE);
__declspec( dllexport ) BOOL Delete_IECookies(BOOL bDeleteCookies = TRUE, 
							                  BOOL bDeleteCookiesIndex = FALSE);
__declspec( dllexport ) HRESULT Delete_IEHistory(BOOL bDeleteHistory = TRUE, 
											  BOOL bDeleteHistoryIndex = FALSE); 
__declspec( dllexport ) void Delete_IEAddressBarHistory();
__declspec( dllexport ) void Delete_DesktopRunHistory();
__declspec( dllexport ) void Delete_DesktopRecentDocsHistory();
__declspec( dllexport ) void Delete_DesktopRecycleBinContents();









