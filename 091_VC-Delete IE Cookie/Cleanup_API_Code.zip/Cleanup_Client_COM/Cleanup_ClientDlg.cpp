#include "stdafx.h"
#include "Cleanup_Client.h"
#include "Cleanup_ClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CCleanup_ClientDlg dialog



CCleanup_ClientDlg::CCleanup_ClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCleanup_ClientDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCleanup_ClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CCleanup_ClientDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_CLEANUP_IE_CACHE, OnButtonIECacheClicked)
	ON_BN_CLICKED(IDC_BUTTON_CLEANUP_IE_COOKIES, OnButtonIECookiesClicked)
	ON_BN_CLICKED(IDC_BUTTON_CLEANUP_IE_HISTORY, OnButtonIEHistoryClicked)
	ON_BN_CLICKED(IDC_BUTTON_CLEANUP_IE_ADDRESS_BAR, OnButtonIEAddressBarClicked)
	ON_BN_CLICKED(IDC_BUTTON_CLEANUP_RUN_HISTORY, OnButtonRunHistoryClicked)
	ON_BN_CLICKED(IDC_BUTTON_CLEANUP_RECENT_DOCS, OnButtonRecentDocsHistoryClicked)
	ON_BN_CLICKED(IDC_BUTTON_CLEANUP_RECYCLE_BIN, OnButtonRecycleBinClicked)
END_MESSAGE_MAP()


// CCleanup_ClientDlg message handlers

BOOL CCleanup_ClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	CoInitialize(NULL);
	//ICleanupAPI* 
    m_pCleanup = NULL;
	CoCreateInstance(__uuidof(CleanupAPI),
		             NULL,
					 CLSCTX_INPROC_SERVER,
                     __uuidof(ICleanupAPI),
					 reinterpret_cast<void**>(&m_pCleanup));

	//pCleanup->
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCleanup_ClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCleanup_ClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCleanup_ClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CCleanup_ClientDlg::OnButtonIECacheClicked()
{
	m_pCleanup->Delete_IECache(TRUE, FALSE);
}

void CCleanup_ClientDlg::OnButtonIECookiesClicked()
{
	m_pCleanup->Delete_IECookies(TRUE, FALSE);
}

void CCleanup_ClientDlg::OnButtonIEHistoryClicked()
{
	CString strMsg;
	
	strMsg =  "IE History is usually locked by Windows Explorer and IE. "; 
	strMsg += "To test this function, please kill 'explorer' and 'iexplore' ";
	strMsg += "processes with Task Manager.\r\n\r\nNote: you can easily ";
	strMsg += "restore shell by typing 'explorer' in File/New task ...  ";
	strMsg += "of Task Manager.";

	AfxMessageBox(strMsg);

	m_pCleanup->Delete_IEHistory(TRUE, FALSE);
}

void CCleanup_ClientDlg::OnButtonIEAddressBarClicked()
{
	m_pCleanup->Delete_IEAddressBarHistory();
}

void CCleanup_ClientDlg::OnButtonRunHistoryClicked()
{
	CString strMsg;

	m_pCleanup->Delete_DesktopRunHistory();
	
	strMsg =  "Run History has been cleaned up. You can see the "; 
	strMsg += "results after logoff/logon or after reboot.";

	AfxMessageBox(strMsg);
}

void CCleanup_ClientDlg::OnButtonRecentDocsHistoryClicked()
{
	m_pCleanup->Delete_DesktopRecentDocsHistory();
}

void CCleanup_ClientDlg::OnButtonRecycleBinClicked()
{
	m_pCleanup->Delete_DesktopRecycleBinContents();
}
