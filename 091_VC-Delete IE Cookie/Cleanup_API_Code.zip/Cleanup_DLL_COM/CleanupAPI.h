// CleanupAPI.h : Declaration of the CCleanupAPI

#pragma once
#include "resource.h"       // main symbols

#include "Cleanup_COM.h"


// CCleanupAPI

class ATL_NO_VTABLE CCleanupAPI : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCleanupAPI, &CLSID_CleanupAPI>,
	public IDispatchImpl<ICleanupAPI, &IID_ICleanupAPI, &LIBID_Cleanup_COMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CCleanupAPI()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CLEANUPAPI)

DECLARE_NOT_AGGREGATABLE(CCleanupAPI)

BEGIN_COM_MAP(CCleanupAPI)
	COM_INTERFACE_ENTRY(ICleanupAPI)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(Delete_IECache)(BOOL bDeleteCache, BOOL bDeleteCacheIndex);
	STDMETHOD(Delete_IECookies)(BOOL bDeleteCookies, BOOL bDeleteCookiesIndex);
	STDMETHOD(Delete_IEHistory)(BOOL bDeleteHistory, BOOL bDeleteHistoryIndex);
	STDMETHOD(Delete_IEAddressBarHistory)(void);
	STDMETHOD(Delete_DesktopRecentDocsHistory)(void);
	STDMETHOD(Delete_DesktopRunHistory)(void);
	STDMETHOD(Delete_DesktopRecycleBinContents)(void);
};

OBJECT_ENTRY_AUTO(__uuidof(CleanupAPI), CCleanupAPI)
