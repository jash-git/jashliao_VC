

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Tue Aug 22 13:51:04 2006
 */
/* Compiler settings for .\Cleanup_COM.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Cleanup_COM_h__
#define __Cleanup_COM_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ICleanupAPI_FWD_DEFINED__
#define __ICleanupAPI_FWD_DEFINED__
typedef interface ICleanupAPI ICleanupAPI;
#endif 	/* __ICleanupAPI_FWD_DEFINED__ */


#ifndef __CleanupAPI_FWD_DEFINED__
#define __CleanupAPI_FWD_DEFINED__

#ifdef __cplusplus
typedef class CleanupAPI CleanupAPI;
#else
typedef struct CleanupAPI CleanupAPI;
#endif /* __cplusplus */

#endif 	/* __CleanupAPI_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __ICleanupAPI_INTERFACE_DEFINED__
#define __ICleanupAPI_INTERFACE_DEFINED__

/* interface ICleanupAPI */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ICleanupAPI;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0BB05174-458D-4526-B7B3-1F8B2C120B17")
    ICleanupAPI : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delete_IECache( 
            /* [in] */ BOOL bDeleteCache,
            /* [in] */ BOOL bDeleteCacheIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delete_IECookies( 
            /* [in] */ BOOL bDeleteCookies,
            /* [in] */ BOOL bDeleteCookiesIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delete_IEHistory( 
            /* [in] */ BOOL bDeleteHistory,
            /* [in] */ BOOL bDeleteHistoryIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delete_IEAddressBarHistory( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delete_DesktopRecentDocsHistory( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delete_DesktopRunHistory( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delete_DesktopRecycleBinContents( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICleanupAPIVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICleanupAPI * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICleanupAPI * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICleanupAPI * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICleanupAPI * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICleanupAPI * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICleanupAPI * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICleanupAPI * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Delete_IECache )( 
            ICleanupAPI * This,
            /* [in] */ BOOL bDeleteCache,
            /* [in] */ BOOL bDeleteCacheIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Delete_IECookies )( 
            ICleanupAPI * This,
            /* [in] */ BOOL bDeleteCookies,
            /* [in] */ BOOL bDeleteCookiesIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Delete_IEHistory )( 
            ICleanupAPI * This,
            /* [in] */ BOOL bDeleteHistory,
            /* [in] */ BOOL bDeleteHistoryIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Delete_IEAddressBarHistory )( 
            ICleanupAPI * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Delete_DesktopRecentDocsHistory )( 
            ICleanupAPI * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Delete_DesktopRunHistory )( 
            ICleanupAPI * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Delete_DesktopRecycleBinContents )( 
            ICleanupAPI * This);
        
        END_INTERFACE
    } ICleanupAPIVtbl;

    interface ICleanupAPI
    {
        CONST_VTBL struct ICleanupAPIVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICleanupAPI_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICleanupAPI_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICleanupAPI_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICleanupAPI_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICleanupAPI_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICleanupAPI_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICleanupAPI_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICleanupAPI_Delete_IECache(This,bDeleteCache,bDeleteCacheIndex)	\
    (This)->lpVtbl -> Delete_IECache(This,bDeleteCache,bDeleteCacheIndex)

#define ICleanupAPI_Delete_IECookies(This,bDeleteCookies,bDeleteCookiesIndex)	\
    (This)->lpVtbl -> Delete_IECookies(This,bDeleteCookies,bDeleteCookiesIndex)

#define ICleanupAPI_Delete_IEHistory(This,bDeleteHistory,bDeleteHistoryIndex)	\
    (This)->lpVtbl -> Delete_IEHistory(This,bDeleteHistory,bDeleteHistoryIndex)

#define ICleanupAPI_Delete_IEAddressBarHistory(This)	\
    (This)->lpVtbl -> Delete_IEAddressBarHistory(This)

#define ICleanupAPI_Delete_DesktopRecentDocsHistory(This)	\
    (This)->lpVtbl -> Delete_DesktopRecentDocsHistory(This)

#define ICleanupAPI_Delete_DesktopRunHistory(This)	\
    (This)->lpVtbl -> Delete_DesktopRunHistory(This)

#define ICleanupAPI_Delete_DesktopRecycleBinContents(This)	\
    (This)->lpVtbl -> Delete_DesktopRecycleBinContents(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICleanupAPI_Delete_IECache_Proxy( 
    ICleanupAPI * This,
    /* [in] */ BOOL bDeleteCache,
    /* [in] */ BOOL bDeleteCacheIndex);


void __RPC_STUB ICleanupAPI_Delete_IECache_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICleanupAPI_Delete_IECookies_Proxy( 
    ICleanupAPI * This,
    /* [in] */ BOOL bDeleteCookies,
    /* [in] */ BOOL bDeleteCookiesIndex);


void __RPC_STUB ICleanupAPI_Delete_IECookies_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICleanupAPI_Delete_IEHistory_Proxy( 
    ICleanupAPI * This,
    /* [in] */ BOOL bDeleteHistory,
    /* [in] */ BOOL bDeleteHistoryIndex);


void __RPC_STUB ICleanupAPI_Delete_IEHistory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICleanupAPI_Delete_IEAddressBarHistory_Proxy( 
    ICleanupAPI * This);


void __RPC_STUB ICleanupAPI_Delete_IEAddressBarHistory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICleanupAPI_Delete_DesktopRecentDocsHistory_Proxy( 
    ICleanupAPI * This);


void __RPC_STUB ICleanupAPI_Delete_DesktopRecentDocsHistory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICleanupAPI_Delete_DesktopRunHistory_Proxy( 
    ICleanupAPI * This);


void __RPC_STUB ICleanupAPI_Delete_DesktopRunHistory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICleanupAPI_Delete_DesktopRecycleBinContents_Proxy( 
    ICleanupAPI * This);


void __RPC_STUB ICleanupAPI_Delete_DesktopRecycleBinContents_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICleanupAPI_INTERFACE_DEFINED__ */



#ifndef __Cleanup_COMLib_LIBRARY_DEFINED__
#define __Cleanup_COMLib_LIBRARY_DEFINED__

/* library Cleanup_COMLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_Cleanup_COMLib;

EXTERN_C const CLSID CLSID_CleanupAPI;

#ifdef __cplusplus

class DECLSPEC_UUID("F5867A48-BCEE-4AED-804F-93B90C2478F2")
CleanupAPI;
#endif
#endif /* __Cleanup_COMLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


