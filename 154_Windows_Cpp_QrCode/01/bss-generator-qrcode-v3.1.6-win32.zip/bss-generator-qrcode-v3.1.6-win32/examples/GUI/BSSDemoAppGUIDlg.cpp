// BSSDemoAppGUIDlg.cpp : implementation file
//

#include "stdafx.h"
#include "BSSDemoAppGUI.h"
#include "BSSDemoAppGUIDlg.h"

#include "BitmapImage.h"
#include "bssQRCodeGenerator.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CBSSDemoAppGUIDlg dialog




CBSSDemoAppGUIDlg::CBSSDemoAppGUIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBSSDemoAppGUIDlg::IDD, pParent)
    , m_ContentVal(_T(""))
    , m_bAutoGenerateVal(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

    m_pImgData    = 0;
    m_nImgWidth   = 0;
    m_nImgHeight  = 0;
    m_nImgRowDist = 0;

    for( int n = 0; n < 256; n++ )
    {
        m_bmInfo.rgbqPalette[ n ].rgbRed   = n;
        m_bmInfo.rgbqPalette[ n ].rgbGreen = n;
        m_bmInfo.rgbqPalette[ n ].rgbBlue  = n;
    }

    m_bmInfo.bmih.biSize          = sizeof( BITMAPINFOHEADER );
    m_bmInfo.bmih.biWidth         = 0;
    m_bmInfo.bmih.biHeight        = 0;
    m_bmInfo.bmih.biPlanes        = 1;
    m_bmInfo.bmih.biBitCount      = 8;
    m_bmInfo.bmih.biCompression   = 0;
    m_bmInfo.bmih.biSizeImage     = 0;
    m_bmInfo.bmih.biXPelsPerMeter = 0;
    m_bmInfo.bmih.biYPelsPerMeter = 0;
    m_bmInfo.bmih.biClrUsed       = 0;
    m_bmInfo.bmih.biClrImportant  = 0;
}


CBSSDemoAppGUIDlg::~CBSSDemoAppGUIDlg()
{
    BSS_ReleaseQRCodeImage( m_pImgData, 
                            m_nImgWidth, 
                            m_nImgHeight, 
                            m_nImgRowDist );
}


void CBSSDemoAppGUIDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Text(pDX, IDC_CONTENT, m_ContentVal);
    DDX_Control(pDX, IDC_MOD_SIZE, m_ModSizeCtrl);
    DDX_Control(pDX, IDC_VIEW, m_ViewCtrl);
    DDX_Check(pDX, IDC_AUTO_GENERATE, m_bAutoGenerateVal);
}

BEGIN_MESSAGE_MAP(CBSSDemoAppGUIDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
    ON_BN_CLICKED(IDC_GENERATE, &CBSSDemoAppGUIDlg::OnGenerate)
    ON_BN_CLICKED(IDC_SAVE_IMAGE, &CBSSDemoAppGUIDlg::OnSaveImage)
    ON_CBN_SELCHANGE(IDC_MOD_SIZE, &CBSSDemoAppGUIDlg::OnChangeModSize)
    ON_EN_CHANGE(IDC_CONTENT, &CBSSDemoAppGUIDlg::OnChangeContent)
END_MESSAGE_MAP()


// CBSSDemoAppGUIDlg message handlers

BOOL CBSSDemoAppGUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
    m_ModSizeCtrl.AddString( _T( "1 pixel" ) );
    m_ModSizeCtrl.AddString( _T( "2 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "3 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "4 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "5 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "6 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "7 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "8 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "9 pixels" ) );
    m_ModSizeCtrl.AddString( _T( "10 pixels" ) );
    m_ModSizeCtrl.SetCurSel( 2 );

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CBSSDemoAppGUIDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CBSSDemoAppGUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();

        CRect ViewRect;
        m_ViewCtrl.GetClientRect( ViewRect );

        CDC* pDC = m_ViewCtrl.GetDC();
        pDC->FillSolidRect( ViewRect, GetSysColor( COLOR_WINDOW ) );

        DrawSymbol( pDC, ViewRect );
	}
}


void CBSSDemoAppGUIDlg::DrawSymbol( CDC* pDC, CRect ViewRect )
{
    if( !m_ErrMsg.IsEmpty() )
    {
        ViewRect.top += ViewRect.Height() / 3;

        pDC->SelectObject( GetStockObject( ANSI_VAR_FONT ) );
        pDC->SetTextColor( RGB( 0, 0, 255 ) );
        pDC->DrawText( m_ErrMsg, ViewRect, DT_CENTER | DT_WORDBREAK );

        return;
    }

    // Prepare BITMAPINFOHEADER structure
    m_bmInfo.bmih.biWidth  = m_nImgWidth;
    m_bmInfo.bmih.biHeight = -m_nImgHeight;

    // Default parameters likely for bcg_vmStretch mode
    // (image will stretch on PictureControl)

    int iViewX = 0;
    int iViewY = 0;
    int iViewW = ViewRect.Width();
    int iViewH = ViewRect.Height();

    //
    // Mode of proportional scaling on PictureControl
    //

    if( m_nImgWidth <= ViewRect.Width() && m_nImgHeight <= ViewRect.Height() )
    {
         iViewX = ( ViewRect.Width() - m_nImgWidth ) / 2;
         iViewY = ( ViewRect.Height() - m_nImgHeight ) / 2;
         iViewW = m_nImgWidth;
         iViewH = m_nImgHeight;
    }
    else
    {
        if( m_nImgWidth >= m_nImgHeight )
        {
            double dAsp = (double)ViewRect.Width() / (double)m_nImgWidth;

            iViewW = (int)( m_nImgWidth * dAsp );
            iViewH = (int)( m_nImgHeight * dAsp );

            if( iViewW > ViewRect.Width() ) iViewW = ViewRect.Width();
            if( iViewH > ViewRect.Height() ) iViewH = ViewRect.Height();

            iViewY = ( ViewRect.Height() - iViewH ) / 2;
        }
        else
        {
            double dAsp = (double)ViewRect.Height() / (double)m_nImgHeight;

            iViewW = (int)( m_nImgWidth * dAsp );
            iViewH = (int)( m_nImgHeight * dAsp );

            if( iViewW > ViewRect.Width() ) iViewW = ViewRect.Width();
            if( iViewH > ViewRect.Height() ) iViewH = ViewRect.Height();

            iViewX = ( ViewRect.Width() - iViewW ) / 2;
        }
    }

    ::StretchDIBits( pDC->GetSafeHdc(),
                     iViewX,
                     iViewY,
                     iViewW,
                     iViewH,
                     0,
                     0,
                     m_nImgWidth,
                     m_nImgHeight,
                     (LPVOID)m_pImgData,
                     (LPBITMAPINFO)&m_bmInfo,
                     DIB_RGB_COLORS,
                     SRCCOPY );
}


void CBSSDemoAppGUIDlg::OnOK()
{
    OnGenerate();
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CBSSDemoAppGUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


// Conversion from Unicode string to ANSI string
std::string UnicodeToStr( const TCHAR* pchStr )
{
    CArray<char> CharData;

    int iBuffSize = WideCharToMultiByte( CP_ACP, 0, pchStr, lstrlen( pchStr ) + 1, NULL, 0, NULL, NULL );

    CharData.SetSize( iBuffSize );

    WideCharToMultiByte( CP_ACP, 0, pchStr, lstrlen( pchStr ) + 1, &CharData[ 0 ], iBuffSize, NULL, NULL );

    return std::string( &CharData[ 0 ] );
}


void CBSSDemoAppGUIDlg::OnGenerate()
{
    UpdateData();

    if( m_pImgData != NULL )
    {
        BSS_ReleaseQRCodeImage( m_pImgData, 
                                m_nImgWidth, 
                                m_nImgHeight, 
                                m_nImgRowDist );

        m_pImgData = NULL;
    }

    int nModSize = m_ModSizeCtrl.GetCurSel() + 1;
    std::string ANSIContent = UnicodeToStr( m_ContentVal );

    const char* pSymbolData = ANSIContent.c_str();
    int   iSymbolDataSize   = (int)m_ContentVal.GetLength();

    int nRes = BSS_GenerateQRCode( pSymbolData,
                                   iSymbolDataSize,
                                   nModSize,
                                   4,
                                   (void**)&m_pImgData,
                                   &m_nImgWidth,
                                   &m_nImgHeight,
                                   &m_nImgRowDist );

    switch( nRes )
    {
    case BSSG_QRCODE_OK:
         m_ErrMsg = _T("");
         break;

    case BSSG_QRCODE_ERR_GENERIC:
         m_ErrMsg = _T("Generic error code.\nThe library doesn�t clarify or cannot determine what is happening.");
         break;
    case BSSG_QRCODE_ERR_OUTOFMEMORY:
         m_ErrMsg = _T("Ran out of memory.\nSome allocation failed.");
         break;
    case BSSG_QRCODE_ERR_NOTSUPPORTED:
         m_ErrMsg = _T("The feature requested is not supported.");
         break;
    case BSSG_QRCODE_ERR_INVALIDARGS:
         m_ErrMsg = _T("Argument validation failed.");
         break;	
    case BSSG_QRCODE_ERR_OUTOFSYMBOLOGY:
         m_ErrMsg = _T("Cannot create the barcode symbol that would be contain this specified input data string by the reason of  some bar code symbology limitation (one or more characters from input data string do not belong  to symbology character set, input data string is too long, etc.)");
         break;	
    }

    Invalidate();
}

void CBSSDemoAppGUIDlg::OnSaveImage()
{
    CFileDialog FileDlg( FALSE,
                         _T("bmp"), 
                         NULL, 
                         OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
                         _T("Windows Bitmap (*.bmp)|*.bmp|All Files (*.*)|*.*||"),
                         NULL );

    if( FileDlg.DoModal() == IDOK && m_nImgWidth > 0 && m_nImgHeight > 0 )
    {
        CBitmapImage Image;
        Image.Attach( m_pImgData, m_nImgWidth, m_nImgHeight, m_nImgRowDist );

        if( Image.Save8bppBitmap( UnicodeToStr( FileDlg.GetPathName() ).c_str() ) )
        {
            AfxMessageBox( _T("I/O Error: Unable to open the output file."), MB_ICONEXCLAMATION );
        }

        Image.Detach();
     }
}

void CBSSDemoAppGUIDlg::OnChangeModSize()
{
    UpdateData();

    if( m_bAutoGenerateVal )
        OnGenerate();
}

void CBSSDemoAppGUIDlg::OnChangeContent()
{
    UpdateData();

    if( m_bAutoGenerateVal )
        OnGenerate();
}
