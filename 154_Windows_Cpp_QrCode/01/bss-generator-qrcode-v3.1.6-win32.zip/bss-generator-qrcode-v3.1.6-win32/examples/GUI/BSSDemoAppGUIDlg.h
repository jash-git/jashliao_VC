// BSSDemoAppGUIDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CBSSDemoAppGUIDlg dialog
class CBSSDemoAppGUIDlg : public CDialog
{
// Construction
public:
	CBSSDemoAppGUIDlg(CWnd* pParent = NULL);	// standard constructor

    ~CBSSDemoAppGUIDlg();

// Dialog Data
	enum { IDD = IDD_BSSDEMOAPPGUI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

    struct {
        BITMAPINFOHEADER bmih;
        RGBQUAD          rgbqPalette[ 256 ];
    } m_bmInfo;

    // Image attributes
    unsigned char* m_pImgData;
    int            m_nImgWidth;
    int            m_nImgHeight;
    int            m_nImgRowDist;

    CString m_ErrMsg;

    void OnOK();
    void DrawSymbol( CDC* pDC, CRect ViewRect );

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
    afx_msg void OnGenerate();
    afx_msg void OnSaveImage();
    CString m_ContentVal;
    CComboBox m_ModSizeCtrl;
    CStatic m_ViewCtrl;
    afx_msg void OnChangeModSize();
    BOOL m_bAutoGenerateVal;
    afx_msg void OnChangeContent();
};
